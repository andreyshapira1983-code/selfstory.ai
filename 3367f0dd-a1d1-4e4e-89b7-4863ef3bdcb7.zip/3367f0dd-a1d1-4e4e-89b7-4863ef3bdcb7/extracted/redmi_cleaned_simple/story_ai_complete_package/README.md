# Story AI - Collaborative Storytelling Platform

This package contains the complete Story AI application, including source code, documentation, tests, and deployment configurations.

## Directory Structure

- **src/**: Source code for the application
- **docs/**: Documentation files
- **tests/**: Test scripts
- **deployment/**: Deployment configurations

## Getting Started

1. Install dependencies: `npm install`
2. Start development server: `npm run dev`
3. Build for production: `npm run build`

## Documentation

See the `docs/` directory for detailed documentation on the application architecture, API, and features.
