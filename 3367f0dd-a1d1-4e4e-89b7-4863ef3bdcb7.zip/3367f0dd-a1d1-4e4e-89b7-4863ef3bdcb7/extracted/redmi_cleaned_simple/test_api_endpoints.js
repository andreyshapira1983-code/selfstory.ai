/**
 * API Endpoints Testing Script
 * 
 * This script tests the API endpoints for the Story AI application
 * using Jest and Supertest.
 */

const request = require('supertest');
const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

// Import server app
const app = require('./src/server/index');

// Test data
let testUser = {
  name: 'API Test User',
  email: `api.test.${Date.now()}@example.com`,
  password: 'password123'
};
let authToken = '';
let testStoryId = '';
let testCommentId = '';
let testCollaboratorId = '';
let testAISuggestionId = '';

// MongoDB connection string - using a test database
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/story_ai_test';

// Connect to MongoDB before tests
beforeAll(async () => {
  try {
    await mongoose.connect(MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useCreateIndex: true,
      useFindAndModify: false
    });
    console.log('\u2705 MongoDB connected successfully for API tests');
  } catch (error) {
    console.error('\u274c MongoDB connection error:', error.message);
    process.exit(1);
  }
});

// Disconnect from MongoDB after tests
afterAll(async () => {
  await mongoose.disconnect();
  console.log('\u2705 MongoDB disconnected successfully after API tests');
});

// Authentication Tests
describe('Authentication API', () => {
  // Test user registration
  test('POST /api/users/register - Register a new user', async () => {
    const response = await request(app)
      .post('/api/users/register')
      .send(testUser)
      .expect('Content-Type', /json/)
      .expect(201);
    
    expect(response.body).toHaveProperty('token');
    expect(response.body).toHaveProperty('user');
    expect(response.body.user).toHaveProperty('_id');
    expect(response.body.user.name).toBe(testUser.name);
    expect(response.body.user.email).toBe(testUser.email);
    
    // Save user ID for later tests
    testUser.id = response.body.user._id;
  });
  
  // Test user login
  test('POST /api/users/login - Login with registered user', async () => {
    const response = await request(app)
      .post('/api/users/login')
      .send({
        email: testUser.email,
        password: testUser.password
      })
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(response.body).toHaveProperty('token');
    expect(response.body).toHaveProperty('user');
    expect(response.body.user.name).toBe(testUser.name);
    expect(response.body.user.email).toBe(testUser.email);
    
    // Save auth token for later tests
    authToken = response.body.token;
  });
  
  // Test get current user
  test('GET /api/users/me - Get current user profile', async () => {
    const response = await request(app)
      .get('/api/users/me')
      .set('Authorization', `Bearer ${authToken}`)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(response.body).toHaveProperty('_id');
    expect(response.body.name).toBe(testUser.name);
    expect(response.body.email).toBe(testUser.email);
  });
});

// Story API Tests
describe('Story API', () => {
  // Test create story
  test('POST /api/stories - Create a new story', async () => {
    const storyData = {
      title: 'API Test Story',
      description: 'This is a test story created via API',
      content: 'Once upon a time, there was an API test story...',
      tags: ['api', 'test', 'story']
    };
    
    const response = await request(app)
      .post('/api/stories')
      .set('Authorization', `Bearer ${authToken}`)
      .send(storyData)
      .expect('Content-Type', /json/)
      .expect(201);
    
    expect(response.body).toHaveProperty('_id');
    expect(response.body.title).toBe(storyData.title);
    expect(response.body.description).toBe(storyData.description);
    expect(response.body.content).toBe(storyData.content);
    expect(response.body.author).toBe(testUser.id);
    expect(response.body).toHaveProperty('documentId');
    
    // Save story ID for later tests
    testStoryId = response.body._id;
  });
  
  // Test get all stories
  test('GET /api/stories - Get all stories', async () => {
    const response = await request(app)
      .get('/api/stories')
      .set('Authorization', `Bearer ${authToken}`)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(Array.isArray(response.body)).toBeTruthy();
    expect(response.body.length).toBeGreaterThan(0);
    
    // Check if our test story is in the list
    const foundStory = response.body.find(story => story._id === testStoryId);
    expect(foundStory).toBeTruthy();
  });
  
  // Test get story by ID
  test('GET /api/stories/:id - Get story by ID', async () => {
    const response = await request(app)
      .get(`/api/stories/${testStoryId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(response.body).toHaveProperty('_id');
    expect(response.body._id).toBe(testStoryId);
    expect(response.body).toHaveProperty('author');
    expect(response.body.author._id).toBe(testUser.id);
  });
  
  // Test update story
  test('PUT /api/stories/:id - Update story', async () => {
    const updateData = {
      title: 'Updated API Test Story',
      description: 'This story has been updated via API test'
    };
    
    const response = await request(app)
      .put(`/api/stories/${testStoryId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .send(updateData)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(response.body).toHaveProperty('_id');
    expect(response.body._id).toBe(testStoryId);
    expect(response.body.title).toBe(updateData.title);
    expect(response.body.description).toBe(updateData.description);
  });
});

// Comment API Tests
describe('Comment API', () => {
  // Test create comment
  test('POST /api/comments - Create a new comment', async () => {
    const commentData = {
      story: testStoryId,
      content: 'This is a test comment via API',
      position: {
        from: 10,
        to: 20
      }
    };
    
    const response = await request(app)
      .post('/api/comments')
      .set('Authorization', `Bearer ${authToken}`)
      .send(commentData)
      .expect('Content-Type', /json/)
      .expect(201);
    
    expect(response.body).toHaveProperty('_id');
    expect(response.body.content).toBe(commentData.content);
    expect(response.body.story).toBe(testStoryId);
    expect(response.body.author).toBe(testUser.id);
    expect(response.body.position.from).toBe(commentData.position.from);
    expect(response.body.position.to).toBe(commentData.position.to);
    
    // Save comment ID for later tests
    testCommentId = response.body._id;
  });
  
  // Test get comments for a story
  test('GET /api/comments/story/:storyId - Get comments for a story', async () => {
    const response = await request(app)
      .get(`/api/comments/story/${testStoryId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(Array.isArray(response.body)).toBeTruthy();
    expect(response.body.length).toBeGreaterThan(0);
    
    // Check if our test comment is in the list
    const foundComment = response.body.find(comment => comment._id === testCommentId);
    expect(foundComment).toBeTruthy();
  });
  
  // Test update comment
  test('PUT /api/comments/:id - Update comment', async () => {
    const updateData = {
      content: 'This comment has been updated via API test'
    };
    
    const response = await request(app)
      .put(`/api/comments/${testCommentId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .send(updateData)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(response.body).toHaveProperty('_id');
    expect(response.body._id).toBe(testCommentId);
    expect(response.body.content).toBe(updateData.content);
  });
  
  // Test add reply to comment
  test('POST /api/comments/:id/replies - Add reply to comment', async () => {
    const replyData = {
      content: 'This is a test reply via API'
    };
    
    const response = await request(app)
      .post(`/api/comments/${testCommentId}/replies`)
      .set('Authorization', `Bearer ${authToken}`)
      .send(replyData)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(response.body).toHaveProperty('_id');
    expect(response.body._id).toBe(testCommentId);
    expect(response.body.replies).toHaveLength(1);
    expect(response.body.replies[0].content).toBe(replyData.content);
    expect(response.body.replies[0].author).toBe(testUser.id);
  });
});

// Collaborator API Tests
describe('Collaborator API', () => {
  // Create a second user to be a collaborator
  let collaboratorUser = {
    name: 'Collaborator Test User',
    email: `collaborator.test.${Date.now()}@example.com`,
    password: 'password123'
  };
  let collaboratorToken = '';
  
  // Register collaborator user
  test('Register collaborator user', async () => {
    const response = await request(app)
      .post('/api/users/register')
      .send(collaboratorUser)
      .expect('Content-Type', /json/)
      .expect(201);
    
    collaboratorUser.id = response.body.user._id;
    collaboratorToken = response.body.token;
  });
  
  // Test add collaborator
  test('POST /api/collaborators - Add a collaborator to a story', async () => {
    const collaboratorData = {
      story: testStoryId,
      user: collaboratorUser.id,
      role: 'editor'
    };
    
    const response = await request(app)
      .post('/api/collaborators')
      .set('Authorization', `Bearer ${authToken}`)
      .send(collaboratorData)
      .expect('Content-Type', /json/)
      .expect(201);
    
    expect(response.body).toHaveProperty('_id');
    expect(response.body.story).toBe(testStoryId);
    expect(response.body.user).toBe(collaboratorUser.id);
    expect(response.body.role).toBe(collaboratorData.role);
    expect(response.body.addedBy).toBe(testUser.id);
    
    // Save collaborator ID for later tests
    testCollaboratorId = response.body._id;
  });
  
  // Test get collaborators for a story
  test('GET /api/collaborators/story/:storyId - Get collaborators for a story', async () => {
    const response = await request(app)
      .get(`/api/collaborators/story/${testStoryId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(Array.isArray(response.body)).toBeTruthy();
    expect(response.body.length).toBeGreaterThan(0);
    
    // Check if our test collaborator is in the list
    const foundCollaborator = response.body.find(collab => collab._id === testCollaboratorId);
    expect(foundCollaborator).toBeTruthy();
  });
  
  // Test update collaborator role
  test('PUT /api/collaborators/:id - Update collaborator role', async () => {
    const updateData = {
      role: 'viewer'
    };
    
    const response = await request(app)
      .put(`/api/collaborators/${testCollaboratorId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .send(updateData)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(response.body).toHaveProperty('_id');
    expect(response.body._id).toBe(testCollaboratorId);
    expect(response.body.role).toBe(updateData.role);
  });
  
  // Test access story as collaborator
  test('GET /api/stories/:id - Access story as collaborator', async () => {
    const response = await request(app)
      .get(`/api/stories/${testStoryId}`)
      .set('Authorization', `Bearer ${collaboratorToken}`)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(response.body).toHaveProperty('_id');
    expect(response.body._id).toBe(testStoryId);
  });
});

// AI Suggestion API Tests
describe('AI Suggestion API', () => {
  // Test create AI suggestion
  test('POST /api/ai-suggestions - Create a new AI suggestion', async () => {
    const suggestionData = {
      story: testStoryId,
      type: 'grammar',
      content: 'This is a test AI suggestion via API',
      position: {
        from: 30,
        to: 40
      },
      originalText: 'Original text with error',
      suggestedText: 'Corrected text suggestion',
      explanation: 'This suggestion fixes a grammatical error'
    };
    
    const response = await request(app)
      .post('/api/ai-suggestions')
      .set('Authorization', `Bearer ${authToken}`)
      .send(suggestionData)
      .expect('Content-Type', /json/)
      .expect(201);
    
    expect(response.body).toHaveProperty('_id');
    expect(response.body.story).toBe(testStoryId);
    expect(response.body.type).toBe(suggestionData.type);
    expect(response.body.content).toBe(suggestionData.content);
    expect(response.body.originalText).toBe(suggestionData.originalText);
    expect(response.body.suggestedText).toBe(suggestionData.suggestedText);
    expect(response.body.requestedBy).toBe(testUser.id);
    
    // Save AI suggestion ID for later tests
    testAISuggestionId = response.body._id;
  });
  
  // Test get AI suggestions for a story
  test('GET /api/ai-suggestions/story/:storyId - Get AI suggestions for a story', async () => {
    const response = await request(app)
      .get(`/api/ai-suggestions/story/${testStoryId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(Array.isArray(response.body)).toBeTruthy();
    expect(response.body.length).toBeGreaterThan(0);
    
    // Check if our test AI suggestion is in the list
    const foundSuggestion = response.body.find(suggestion => suggestion._id === testAISuggestionId);
    expect(foundSuggestion).toBeTruthy();
  });
  
  // Test apply AI suggestion
  test('PUT /api/ai-suggestions/:id/apply - Apply AI suggestion', async () => {
    const response = await request(app)
      .put(`/api/ai-suggestions/${testAISuggestionId}/apply`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(response.body).toHaveProperty('_id');
    expect(response.body._id).toBe(testAISuggestionId);
    expect(response.body.applied).toBe(true);
    expect(response.body.appliedBy).toBe(testUser.id);
    expect(response.body).toHaveProperty('appliedAt');
  });
});

// Cleanup Tests
describe('Cleanup API Tests', () => {
  // Test delete AI suggestion
  test('DELETE /api/ai-suggestions/:id - Delete AI suggestion', async () => {
    await request(app)
      .delete(`/api/ai-suggestions/${testAISuggestionId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);
    
    // Verify deletion
    const response = await request(app)
      .get(`/api/ai-suggestions/${testAISuggestionId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(404);
  });
  
  // Test delete comment
  test('DELETE /api/comments/:id - Delete comment', async () => {
    await request(app)
      .delete(`/api/comments/${testCommentId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);
    
    // Verify deletion
    const response = await request(app)
      .get(`/api/comments/${testCommentId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(404);
  });
  
  // Test delete collaborator
  test('DELETE /api/collaborators/:id - Delete collaborator', async () => {
    await request(app)
      .delete(`/api/collaborators/${testCollaboratorId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);
    
    // Verify deletion
    const response = await request(app)
      .get(`/api/collaborators/${testCollaboratorId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(404);
  });
  
  // Test delete story
  test('DELETE /api/stories/:id - Delete story', async () => {
    await request(app)
      .delete(`/api/stories/${testStoryId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);
    
    // Verify deletion
    const response = await request(app)
      .get(`/api/stories/${testStoryId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(404);
  });
  
  // Test delete user
  test('DELETE /api/users/:id - Delete user', async () => {
    await request(app)
      .delete(`/api/users/${testUser.id}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);
    
    // Verify deletion by trying to login
    const response = await request(app)
      .post('/api/users/login')
      .send({
        email: testUser.email,
        password: testUser.password
      })
      .expect(401);
  });
  
  // Test delete collaborator user
  test('DELETE /api/users/:id - Delete collaborator user', async () => {
    await request(app)
      .delete(`/api/users/${collaboratorUser.id}`)
      .set('Authorization', `Bearer ${collaboratorToken}`)
      .expect(200);
  });
});