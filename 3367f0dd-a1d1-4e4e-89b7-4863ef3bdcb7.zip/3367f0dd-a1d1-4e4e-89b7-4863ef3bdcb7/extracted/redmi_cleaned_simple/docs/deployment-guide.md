# Story AI - Deployment Guide

This guide provides instructions for deploying the Story AI application to production environments.

## Prerequisites

Before deploying, ensure you have the following:

- Node.js 16.x or higher
- MongoDB 5.x or higher
- A server or cloud provider (AWS, Heroku, DigitalOcean, etc.)
- Domain name (optional but recommended)
- SSL certificate (recommended for production)

## Environment Setup

1. Clone the repository:
   ```bash
   git clone https://github.com/your-organization/story-ai.git
   cd story-ai
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a production `.env` file:
   ```bash
   cp .env.example .env.production
   ```

4. Configure the production environment variables:
   ```
   # Server Configuration
   PORT=5000
   NODE_ENV=production

   # Client Configuration
   CLIENT_URL=https://your-domain.com
   VITE_API_URL=https://your-domain.com/api

   # MongoDB Configuration
   MONGODB_URI=mongodb://username:password@your-mongodb-host:27017/story-ai

   # JWT Secret (for authentication)
   JWT_SECRET=your_strong_random_jwt_secret_key_here
   JWT_EXPIRES_IN=7d

   # WebSocket Configuration
   WS_SERVER_PATH=/ws-server
   WS_PORT=5001
   VITE_WS_URL=wss://your-domain.com

   # AI Service API Keys
   OPENAI_API_KEY=your_openai_api_key_here

   # Logging
   LOG_LEVEL=info

   # Security
   CORS_ORIGIN=https://your-domain.com
   ```

## Build Process

1. Build the client application:
   ```bash
   npm run build
   ```

   This will create a `dist` directory with optimized production files.

2. Test the production build locally:
   ```bash
   npm run preview
   ```

## Deployment Options

### Option 1: Traditional Server Deployment

1. Transfer the application files to your server:
   ```bash
   rsync -avz --exclude 'node_modules' --exclude '.git' ./ user@your-server:/path/to/app
   ```

2. Install dependencies on the server:
   ```bash
   cd /path/to/app
   npm install --production
   ```

3. Set up a process manager (PM2):
   ```bash
   npm install -g pm2
   pm2 start src/server/index.js --name "story-ai"
   pm2 save
   pm2 startup
   ```

4. Configure Nginx as a reverse proxy:
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;

       # Redirect HTTP to HTTPS
       return 301 https://$host$request_uri;
   }

   server {
       listen 443 ssl;
       server_name your-domain.com;

       ssl_certificate /path/to/ssl/certificate.crt;
       ssl_certificate_key /path/to/ssl/private.key;

       # SSL configuration
       ssl_protocols TLSv1.2 TLSv1.3;
       ssl_prefer_server_ciphers on;
       ssl_ciphers 'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384';
       ssl_session_cache shared:SSL:10m;
       ssl_session_timeout 10m;

       # API and static files
       location / {
           proxy_pass http://localhost:5000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }

       # WebSocket server
       location /ws-server {
           proxy_pass http://localhost:5001;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection "upgrade";
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

5. Restart Nginx:
   ```bash
   sudo systemctl restart nginx
   ```

### Option 2: Docker Deployment

1. Create a Dockerfile in the project root:
   ```dockerfile
   FROM node:16-alpine

   WORKDIR /app

   COPY package*.json ./
   RUN npm ci --only=production

   COPY . .

   RUN npm run build

   EXPOSE 5000
   EXPOSE 5001

   CMD ["node", "src/server/index.js"]
   ```

2. Create a docker-compose.yml file:
   ```yaml
   version: '3'
   services:
     app:
       build: .
       ports:
         - "5000:5000"
         - "5001:5001"
       environment:
         - NODE_ENV=production
         - PORT=5000
         - MONGODB_URI=mongodb://mongo:27017/story-ai
         - JWT_SECRET=your_strong_random_jwt_secret_key_here
         - CLIENT_URL=https://your-domain.com
         - WS_SERVER_PATH=/ws-server
         - WS_PORT=5001
       depends_on:
         - mongo
       restart: always

     mongo:
       image: mongo:5
       ports:
         - "27017:27017"
       volumes:
         - mongo-data:/data/db
       restart: always

   volumes:
     mongo-data:
   ```

3. Build and run with Docker Compose:
   ```bash
   docker-compose up -d
   ```

### Option 3: Cloud Platform Deployment

#### Heroku

1. Create a Procfile:
   ```
   web: node src/server/index.js
   ```

2. Add the MongoDB add-on:
   ```bash
   heroku addons:create mongolab
   ```

3. Set environment variables:
   ```bash
   heroku config:set NODE_ENV=production
   heroku config:set JWT_SECRET=your_strong_random_jwt_secret_key_here
   heroku config:set CLIENT_URL=https://your-app-name.herokuapp.com
   heroku config:set WS_SERVER_PATH=/ws-server
   ```

4. Deploy to Heroku:
   ```bash
   git push heroku main
   ```

#### AWS Elastic Beanstalk

1. Install the EB CLI:
   ```bash
   pip install awsebcli
   ```

2. Initialize EB:
   ```bash
   eb init
   ```

3. Create an environment:
   ```bash
   eb create story-ai-production
   ```

4. Set environment variables:
   ```bash
   eb setenv NODE_ENV=production JWT_SECRET=your_strong_random_jwt_secret_key_here CLIENT_URL=https://your-domain.com
   ```

5. Deploy:
   ```bash
   eb deploy
   ```

## Database Migration

For production deployment, you may need to migrate data:

1. Create a migration script:
   ```javascript
   // scripts/migrate.js
   const mongoose = require('mongoose');
   const dotenv = require('dotenv');

   dotenv.config({ path: '.env.production' });

   const MONGODB_URI = process.env.MONGODB_URI;

   mongoose.connect(MONGODB_URI, {
     useNewUrlParser: true,
     useUnifiedTopology: true,
   });

   // Add migration logic here
   // Example: Update schema, transform data, etc.

   console.log('Migration completed');
   process.exit(0);
   ```

2. Run the migration:
   ```bash
   node scripts/migrate.js
   ```

## Monitoring and Maintenance

1. Set up application monitoring:
   - Use PM2 monitoring: `pm2 monit`
   - Consider services like New Relic, Datadog, or Sentry

2. Set up database backups:
   ```bash
   # Daily MongoDB backup
   mongodump --uri="$MONGODB_URI" --out=/path/to/backup/$(date +"%Y-%m-%d")
   ```

3. Set up log rotation:
   ```bash
   # Using logrotate
   sudo nano /etc/logrotate.d/story-ai
   ```
   
   Add the following configuration:
   ```
   /path/to/app/logs/*.log {
       daily
       rotate 14
       compress
       delaycompress
       notifempty
       create 0640 www-data www-data
       sharedscripts
       postrotate
           pm2 reload story-ai
       endscript
   }
   ```

## Scaling Considerations

As your application grows, consider these scaling strategies:

1. **Horizontal Scaling**: Deploy multiple application instances behind a load balancer
2. **Database Scaling**: Set up MongoDB replication and sharding
3. **WebSocket Scaling**: Use Redis for pub/sub to synchronize WebSocket servers
4. **CDN Integration**: Use a CDN for static assets
5. **Caching**: Implement Redis caching for frequently accessed data

## Troubleshooting

Common deployment issues and solutions:

1. **Connection Refused**: Check if the server is running and ports are correctly configured
2. **WebSocket Connection Failures**: Ensure proxy settings are correctly forwarding WebSocket connections
3. **Database Connection Issues**: Verify MongoDB connection string and network access
4. **Memory Issues**: Monitor memory usage and adjust Node.js memory limits if needed

## Security Checklist

Before going live, verify these security measures:

- [ ] SSL/TLS is properly configured
- [ ] JWT secret is strong and secure
- [ ] Environment variables are properly set
- [ ] MongoDB authentication is enabled
- [ ] Rate limiting is implemented
- [ ] CORS is properly configured
- [ ] Security headers are set (Helmet middleware)
- [ ] Input validation is implemented
- [ ] Authentication and authorization are working correctly
- [ ] Regular security updates are scheduled