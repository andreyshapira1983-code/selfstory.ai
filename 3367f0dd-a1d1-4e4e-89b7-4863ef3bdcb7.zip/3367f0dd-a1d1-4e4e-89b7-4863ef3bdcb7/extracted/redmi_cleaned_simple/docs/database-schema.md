# Story AI - Database Schema Documentation

## Overview

Story AI uses MongoDB as its primary database, leveraging its flexibility and scalability for storing user data, stories, collaborations, comments, and AI suggestions. This document outlines the database schema, collection relationships, indexes, and data validation rules.

## Database Collections

### Users Collection

Stores user account information and profile data.

```javascript
{
  _id: ObjectId,
  name: String,              // User's display name
  email: String,             // User's email address (unique)
  password: String,          // Hashed password
  profileColor: String,      // Color for user avatar (hex code)
  bio: String,               // Optional user biography
  avatar: String,            // Optional URL to user's avatar image
  resetPasswordToken: String,// For password reset functionality
  resetPasswordExpire: Date, // Expiration for reset token
  createdAt: Date,           // Account creation timestamp
  updatedAt: Date            // Last update timestamp
}
```

#### Indexes:
- `email`: Unique index for fast lookups and to ensure email uniqueness
- `resetPasswordToken`: Index for password reset functionality

#### Validation Rules:
- `name`: Required, string, max length 50 characters
- `email`: Required, string, must match email regex pattern, unique
- `password`: Required, string, min length 6 characters (before hashing)
- `profileColor`: String, valid hex color code
- `bio`: Optional, string, max length 200 characters

### Stories Collection

Stores story metadata and content references.

```javascript
{
  _id: ObjectId,
  title: String,             // Story title
  description: String,       // Story description/summary
  content: String,           // Optional stored content (for non-collaborative stories)
  author: ObjectId,          // Reference to Users collection
  coverImage: String,        // URL to cover image
  documentId: String,        // Unique ID for collaborative document (used by Yjs)
  isPublic: Boolean,         // Whether the story is publicly accessible
  tags: [String],            // Array of tags/categories
  createdAt: Date,           // Creation timestamp
  updatedAt: Date,           // Last update timestamp
  lastEditedBy: ObjectId     // Reference to Users collection (last editor)
}
```

#### Indexes:
- `author`: Index for querying stories by author
- `documentId`: Unique index for linking to collaborative documents
- `tags`: Index for tag-based queries
- `createdAt`: Index for sorting by creation date
- `updatedAt`: Index for sorting by update date

#### Validation Rules:
- `title`: Required, string, max length 100 characters
- `description`: Optional, string, max length 500 characters
- `author`: Required, valid ObjectId reference to Users collection
- `documentId`: Required, string, unique
- `isPublic`: Boolean, defaults to false
- `tags`: Array of strings

### Collaborators Collection

Stores collaboration relationships between users and stories.

```javascript
{
  _id: ObjectId,
  story: ObjectId,           // Reference to Stories collection
  user: ObjectId,            // Reference to Users collection
  role: String,              // Collaborator role (editor, viewer)
  addedBy: ObjectId,         // Reference to Users collection (who added this collaborator)
  isActive: Boolean,         // Whether the collaborator is currently active
  lastActive: Date,          // When the collaborator was last active
  createdAt: Date            // When the collaboration was established
}
```

#### Indexes:
- `story`: Index for querying collaborators by story
- `user`: Index for querying stories a user collaborates on
- `story_user`: Compound unique index to prevent duplicate collaborations
- `isActive`: Index for querying active collaborators

#### Validation Rules:
- `story`: Required, valid ObjectId reference to Stories collection
- `user`: Required, valid ObjectId reference to Users collection
- `role`: Required, string, enum: ['editor', 'viewer']
- `addedBy`: Required, valid ObjectId reference to Users collection
- `isActive`: Boolean, defaults to false

### Comments Collection

Stores comments and replies on stories.

```javascript
{
  _id: ObjectId,
  story: ObjectId,           // Reference to Stories collection
  content: String,           // Comment text
  author: ObjectId,          // Reference to Users collection
  position: {                // Position in the document
    from: Number,            // Start position
    to: Number               // End position
  },
  resolved: Boolean,         // Whether the comment is resolved
  resolvedBy: ObjectId,      // Reference to Users collection (who resolved it)
  resolvedAt: Date,          // When the comment was resolved
  replies: [{                // Array of reply objects
    _id: ObjectId,           // Auto-generated for each reply
    content: String,         // Reply text
    author: ObjectId,        // Reference to Users collection
    createdAt: Date          // Reply creation timestamp
  }],
  createdAt: Date,           // Comment creation timestamp
  updatedAt: Date            // Last update timestamp
}
```

#### Indexes:
- `story`: Index for querying comments by story
- `author`: Index for querying comments by author
- `createdAt`: Index for sorting by creation date
- `resolved`: Index for filtering resolved/unresolved comments

#### Validation Rules:
- `story`: Required, valid ObjectId reference to Stories collection
- `content`: Required, string
- `author`: Required, valid ObjectId reference to Users collection
- `position`: Required object with numeric from and to fields
- `resolved`: Boolean, defaults to false
- `replies.content`: Required, string
- `replies.author`: Required, valid ObjectId reference to Users collection

### AISuggestions Collection

Stores AI-generated writing suggestions.

```javascript
{
  _id: ObjectId,
  story: ObjectId,           // Reference to Stories collection
  type: String,              // Suggestion type (grammar, style, content, etc.)
  content: String,           // Suggestion description
  position: {                // Position in the document
    from: Number,            // Start position
    to: Number               // End position
  },
  originalText: String,      // Original text being replaced
  suggestedText: String,     // Suggested replacement text
  explanation: String,       // Explanation of the suggestion
  applied: Boolean,          // Whether the suggestion was applied
  appliedBy: ObjectId,       // Reference to Users collection (who applied it)
  appliedAt: Date,           // When the suggestion was applied
  dismissed: Boolean,        // Whether the suggestion was dismissed
  dismissedBy: ObjectId,     // Reference to Users collection (who dismissed it)
  dismissedAt: Date,         // When the suggestion was dismissed
  requestedBy: ObjectId,     // Reference to Users collection (who requested it)
  createdAt: Date            // Suggestion creation timestamp
}
```

#### Indexes:
- `story`: Index for querying suggestions by story
- `requestedBy`: Index for querying suggestions by requester
- `type`: Index for filtering by suggestion type
- `applied`: Index for filtering applied/unapplied suggestions
- `dismissed`: Index for filtering dismissed/undismissed suggestions
- `createdAt`: Index for sorting by creation date

#### Validation Rules:
- `story`: Required, valid ObjectId reference to Stories collection
- `type`: Required, string, enum: ['grammar', 'style', 'content', 'plot', 'character', 'setting', 'dialogue', 'other']
- `content`: Required, string
- `position`: Required object with numeric from and to fields
- `originalText`: Required, string
- `suggestedText`: Required, string
- `applied`: Boolean, defaults to false
- `dismissed`: Boolean, defaults to false
- `requestedBy`: Required, valid ObjectId reference to Users collection

### Documents Collection

Stores Yjs document updates for collaborative editing (managed by Y-MongoDB).

```javascript
{
  _id: ObjectId,
  docName: String,           // Document ID (matches documentId in Stories)
  update: Binary,            // Binary Yjs update
  timestamp: Date            // Update timestamp
}
```

#### Indexes:
- `docName`: Index for querying updates by document
- `timestamp`: Index for sorting by timestamp

## Collection Relationships

### One-to-Many Relationships

1. **User to Stories**:
   - A user can author multiple stories
   - Each story has one author
   - Relationship field: `author` in Stories collection

2. **Story to Comments**:
   - A story can have multiple comments
   - Each comment belongs to one story
   - Relationship field: `story` in Comments collection

3. **Story to AISuggestions**:
   - A story can have multiple AI suggestions
   - Each AI suggestion belongs to one story
   - Relationship field: `story` in AISuggestions collection

4. **User to Comments**:
   - A user can create multiple comments
   - Each comment has one author
   - Relationship field: `author` in Comments collection

### Many-to-Many Relationships

1. **Users to Stories (Collaboration)**:
   - A user can collaborate on multiple stories
   - A story can have multiple collaborators
   - Junction collection: Collaborators
   - Relationship fields: `user` and `story` in Collaborators collection

## Data Access Patterns

### Common Queries

1. **Get all stories for a user (authored and collaborated)**:
```javascript
// Get stories authored by the user
const authoredStories = await Stories.find({ author: userId });

// Get stories where user is a collaborator
const collaborations = await Collaborators.find({ user: userId }).populate('story');
const collaboratedStories = collaborations.map(collab => collab.story);

// Combine and sort by updatedAt
const allStories = [...authoredStories, ...collaboratedStories]
  .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
```

2. **Get all collaborators for a story with their active status**:
```javascript
const collaborators = await Collaborators.find({ story: storyId })
  .populate('user', 'name email profileColor')
  .populate('addedBy', 'name email');
```

3. **Get all comments for a story**:
```javascript
const comments = await Comments.find({ story: storyId })
  .populate('author', 'name email profileColor')
  .populate('replies.author', 'name email profileColor')
  .sort('-createdAt');
```

4. **Get all AI suggestions for a story**:
```javascript
const suggestions = await AISuggestions.find({ 
  story: storyId,
  applied: false,
  dismissed: false
})
  .populate('requestedBy', 'name email profileColor')
  .sort('-createdAt');
```

5. **Get document updates for collaborative editing**:
```javascript
const updates = await Documents.find({ docName: documentId })
  .sort('timestamp');
```

## Indexing Strategy

### Performance Indexes

1. **Compound Indexes**:
   - `{ story: 1, createdAt: -1 }` on Comments collection for efficient retrieval of comments by story sorted by date
   - `{ story: 1, user: 1 }` on Collaborators collection with unique constraint to prevent duplicate collaborations
   - `{ story: 1, type: 1, applied: 1 }` on AISuggestions collection for filtering suggestions by type and status

2. **Text Indexes**:
   - `{ title: "text", description: "text" }` on Stories collection for text search functionality
   - `{ content: "text" }` on Comments collection for searching comment content

### Operational Indexes

1. **TTL Indexes**:
   - `{ resetPasswordExpire: 1 }` on Users collection with expireAfterSeconds: 0 to automatically remove expired reset tokens

## Data Validation

MongoDB schema validation is used to ensure data integrity:

```javascript
// Example validation schema for Users collection
db.createCollection("users", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["name", "email", "password"],
      properties: {
        name: {
          bsonType: "string",
          maxLength: 50,
          description: "must be a string with at most 50 characters"
        },
        email: {
          bsonType: "string",
          pattern: "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
          description: "must be a valid email address"
        },
        password: {
          bsonType: "string",
          minLength: 60, // For bcrypt hashed passwords
          description: "must be a string with at least 60 characters (hashed)"
        },
        profileColor: {
          bsonType: "string",
          pattern: "^#[0-9A-Fa-f]{6}$",
          description: "must be a valid hex color code"
        },
        bio: {
          bsonType: "string",
          maxLength: 200,
          description: "must be a string with at most 200 characters"
        }
      }
    }
  }
});
```

## Data Migration and Versioning

### Schema Versioning

Each document includes a `schemaVersion` field to track schema changes:

```javascript
{
  _id: ObjectId,
  // other fields
  schemaVersion: Number // Current schema version
}
```

### Migration Scripts

Migration scripts are used to update documents when the schema changes:

```javascript
// Example migration script to update schema version 1 to version 2
async function migrateV1ToV2() {
  const collections = ['users', 'stories', 'collaborators', 'comments', 'aisuggestions'];
  
  for (const collection of collections) {
    await db.collection(collection).updateMany(
      { schemaVersion: 1 },
      { 
        $set: { schemaVersion: 2 },
        // Add other field updates as needed
      }
    );
  }
}
```

## Backup and Recovery

### Backup Strategy

1. **Daily Full Backups**:
   - Complete database dump using MongoDB's `mongodump` tool
   - Stored in cloud storage with 30-day retention

2. **Hourly Incremental Backups**:
   - Oplog-based incremental backups
   - 24-hour retention

3. **Pre-Deployment Backups**:
   - Full backup before any schema changes or major deployments

### Recovery Procedures

1. **Point-in-Time Recovery**:
   - Restore the most recent full backup
   - Apply incremental backups up to the desired point in time

2. **Collection-Level Recovery**:
   - Restore specific collections using `mongorestore` with collection filters

3. **Document-Level Recovery**:
   - Query backup database for specific documents
   - Insert recovered documents into production database

## Performance Optimization

### Denormalization Strategies

1. **Embedded Documents**:
   - Comment replies are embedded within the comment document
   - User information (name, profileColor) is embedded in awareness states for real-time collaboration

2. **Cached Fields**:
   - Story documents include `updatedAt` and `lastEditedBy` fields to avoid querying the Documents collection
   - Collaborator documents include `isActive` and `lastActive` fields for quick access to presence information

### Query Optimization

1. **Projection**:
   - Use field projection to limit returned fields: `{ name: 1, email: 1, profileColor: 1 }`

2. **Pagination**:
   - Use `skip()` and `limit()` for paginated results
   - Use cursor-based pagination for large collections

3. **Aggregation Pipeline**:
   - Use MongoDB's aggregation pipeline for complex queries and data transformations

## Conclusion

The Story AI database schema is designed to support real-time collaborative editing, user management, and AI-powered writing assistance. The schema leverages MongoDB's flexibility while maintaining data integrity through validation rules and indexing strategies.

The relationships between collections enable efficient querying of related data, while the denormalization strategies optimize performance for common access patterns. The backup and recovery procedures ensure data durability and availability.