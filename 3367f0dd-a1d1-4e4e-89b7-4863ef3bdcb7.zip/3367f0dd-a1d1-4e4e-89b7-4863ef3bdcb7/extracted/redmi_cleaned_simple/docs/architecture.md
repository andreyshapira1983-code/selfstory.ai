# Story AI - Architecture Documentation

## System Architecture

Story AI is built on a modern web architecture that combines real-time collaboration capabilities with AI-powered writing assistance. The system follows a client-server model with specialized components for handling different aspects of the application.

### High-Level Architecture Diagram

```
┌─────────────────┐     HTTP/REST     ┌─────────────────┐
│                 │<----------------->│                 │
│  Client         │                   │  API Server     │
│  (React SPA)    │                   │  (Express)      │
│                 │                   │                 │
└────────┬────────┘                   └────────┬────────┘
         │                                     │
         │                                     │
         │                                     │
         │                                     ▼
         │                            ┌─────────────────┐
         │                            │                 │
         │                            │  Database       │
         │                            │  (MongoDB)      │
         │                            │                 │
         │                            └─────────────────┘
         │
         │
         │  WebSocket
         │
         ▼
┌─────────────────┐
│                 │
│  WebSocket      │
│  Server         │
│                 │
└─────────────────┘
```

## Component Breakdown

### 1. Client Application

The client application is a React-based Single Page Application (SPA) that provides the user interface and handles real-time collaboration.

#### Key Components:

- **React Framework**: Core UI library
- **React Router**: Client-side routing
- **TipTap Editor**: Rich text editor with collaboration support
- **Yjs Client**: CRDT implementation for real-time collaboration
- **Socket.IO Client**: Real-time communication with the server
- **Context API**: State management
- **TailwindCSS**: Styling and responsive design

#### Client Architecture:

```
┌─────────────────────────────────────────────────────────┐
│                      React Application                  │
│                                                         │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐  │
│  │             │    │             │    │             │  │
│  │  Components │    │   Contexts  │    │    Hooks    │  │
│  │             │    │             │    │             │  │
│  └─────────────┘    └─────────────┘    └─────────────┘  │
│                                                         │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐  │
│  │             │    │             │    │             │  │
│  │  TipTap     │    │    Yjs      │    │  Socket.IO  │  │
│  │  Editor     │    │   Client    │    │   Client    │  │
│  │             │    │             │    │             │  │
│  └─────────────┘    └─────────────┘    └─────────────┘  │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 2. API Server

The API server handles HTTP requests for user authentication, story management, and other CRUD operations.

#### Key Components:

- **Express**: Web framework for handling HTTP requests
- **JWT Authentication**: Token-based authentication
- **MongoDB Integration**: Database access
- **Controllers**: Business logic for different resources
- **Middleware**: Request processing and validation

#### API Server Architecture:

```
┌─────────────────────────────────────────────────────────┐
│                      Express Server                     │
│                                                         │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐  │
│  │             │    │             │    │             │  │
│  │  Routes     │    │ Controllers │    │ Middleware  │  │
│  │             │    │             │    │             │  │
│  └─────────────┘    └─────────────┘    └─────────────┘  │
│                                                         │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐  │
│  │             │    │             │    │             │  │
│  │  Models     │    │    Auth     │    │  Validation │  │
│  │             │    │             │    │             │  │
│  └─────────────┘    └─────────────┘    └─────────────┘  │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 3. WebSocket Server

The WebSocket server manages real-time collaboration using Y-Websocket protocol for document synchronization and Socket.IO for presence awareness and messaging.

#### Key Components:

- **Y-Websocket**: WebSocket server for Yjs synchronization
- **Socket.IO Server**: Real-time communication
- **Document Manager**: Manages shared documents
- **Awareness Protocol**: Tracks user presence and cursor positions

#### WebSocket Server Architecture:

```
┌─────────────────────────────────────────────────────────┐
│                    WebSocket Server                     │
│                                                         │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐  │
│  │             │    │             │    │             │  │
│  │ Y-Websocket │    │  Socket.IO  │    │  Document   │  │
│  │   Server    │    │   Server    │    │   Manager   │  │
│  │             │    │             │    │             │  │
│  └─────────────┘    └─────────────┘    └─────────────┘  │
│                                                         │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐  │
│  │             │    │             │    │             │  │
│  │  Awareness  │    │ Persistence │    │ Connection  │  │
│  │  Protocol   │    │   Layer     │    │  Handler    │  │
│  │             │    │             │    │             │  │
│  └─────────────┘    └─────────────┘    └─────────────┘  │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 4. Database

MongoDB stores user data, story metadata, comments, and AI suggestions. The actual document content is synchronized through Yjs and persisted using Y-MongoDB.

#### Key Collections:

- **Users**: User accounts and profiles
- **Stories**: Story metadata and settings
- **Collaborators**: Collaboration relationships and permissions
- **Comments**: User comments on stories
- **AISuggestions**: AI-generated writing suggestions
- **Documents**: Yjs document updates (via Y-MongoDB)

#### Database Schema:

```
┌─────────────────┐       ┌─────────────────┐
│                 │       │                 │
│      Users      │       │     Stories     │
│                 │       │                 │
└────────┬────────┘       └────────┬────────┘
         │                         │
         │                         │
         │                         │
         │                         │
┌────────▼────────┐       ┌────────▼────────┐
│                 │       │                 │
│  Collaborators  │       │    Comments     │
│                 │       │                 │
└─────────────────┘       └────────┬────────┘
                                   │
                                   │
                          ┌────────▼────────┐
                          │                 │
                          │  AISuggestions  │
                          │                 │
                          └─────────────────┘
```

## Data Flow

### 1. User Authentication Flow

```
┌─────────┐     1. Login Request     ┌─────────┐
│         │─────────────────────────>│         │
│ Client  │                          │  API    │
│         │<─────────────────────────│ Server  │
└─────────┘     2. JWT Token         └─────────┘
     │                                    │
     │                                    │
     │                                    ▼
     │                               ┌─────────┐
     │                               │         │
     │                               │   DB    │
     │                               │         │
     │                               └─────────┘
     │
     │  3. Connect with Token
     ▼
┌─────────┐
│WebSocket│
│ Server  │
└─────────┘
```

### 2. Collaborative Editing Flow

```
┌─────────┐                          ┌─────────┐
│ Client A│                          │WebSocket│
│         │◄─────────────────────────┤ Server  │
└─────────┘                          └─────────┘
     ▲                                    ▲
     │                                    │
     │                                    │
     │                                    │
     │                                    │
     │                                    │
     ▼                                    ▼
┌─────────┐                          ┌─────────┐
│ Client B│                          │   DB    │
│         │◄─────────────────────────┤         │
└─────────┘                          └─────────┘
```

### 3. AI Suggestion Flow

```
┌─────────┐     1. Request Suggestion    ┌─────────┐
│         │─────────────────────────────>│         │
│ Client  │                              │  API    │
│         │<─────────────────────────────│ Server  │
└─────────┘     4. Return Suggestions    └─────────┘
                                              │
                                              │ 2. Process Text
                                              ▼
                                         ┌─────────┐
                                         │   AI    │
                                         │ Service │
                                         └─────────┘
                                              │
                                              │ 3. Store Results
                                              ▼
                                         ┌─────────┐
                                         │         │
                                         │   DB    │
                                         │         │
                                         └─────────┘
```

## Technology Choices and Rationale

### Frontend

- **React**: Chosen for its component-based architecture, which allows for modular and reusable UI components.
- **TipTap**: Built on ProseMirror, TipTap provides a customizable rich text editor with excellent collaborative editing support.
- **Yjs**: A CRDT implementation that enables conflict-free real-time collaboration without requiring operational transformation.
- **TailwindCSS**: Utility-first CSS framework that enables rapid UI development with consistent design.

### Backend

- **Node.js/Express**: Provides a lightweight and efficient server with excellent WebSocket support and JavaScript compatibility.
- **MongoDB**: NoSQL database that offers flexibility for evolving data models and good performance for document-oriented data.
- **Socket.IO**: Reliable real-time bidirectional communication with fallbacks for environments where WebSockets aren't available.
- **JWT**: Stateless authentication mechanism that works well with both REST APIs and WebSocket connections.

### Real-time Collaboration

- **CRDT (Conflict-free Replicated Data Types)**: Enables conflict-free concurrent editing without requiring central coordination.
- **Yjs**: Implements CRDTs with excellent performance characteristics and integration with text editors.
- **Y-Websocket**: Efficient protocol for synchronizing Yjs documents over WebSockets.
- **Y-MongoDB**: Persistence layer for storing document updates in MongoDB.

## Scalability Considerations

- **Horizontal Scaling**: The API and WebSocket servers can be scaled horizontally behind a load balancer.
- **Database Sharding**: MongoDB can be sharded to distribute data across multiple servers.
- **Microservices**: The architecture can evolve toward microservices as specific components need to scale independently.
- **Caching**: Redis can be introduced for caching frequently accessed data and reducing database load.
- **WebSocket Clustering**: Socket.IO supports Redis adapter for clustering WebSocket connections across multiple servers.

## Security Considerations

- **Authentication**: JWT-based authentication with secure token storage.
- **Authorization**: Role-based access control for stories and collaborative editing.
- **Input Validation**: Server-side validation of all user inputs.
- **HTTPS**: All communication encrypted using TLS.
- **CORS**: Proper Cross-Origin Resource Sharing configuration.
- **Rate Limiting**: Protection against abuse and DoS attacks.
- **Content Security Policy**: Protection against XSS attacks.

## Conclusion

The Story AI architecture is designed to provide a seamless real-time collaborative writing experience with AI assistance. The combination of modern web technologies, real-time collaboration protocols, and AI integration creates a powerful platform for writers to create and collaborate on stories.