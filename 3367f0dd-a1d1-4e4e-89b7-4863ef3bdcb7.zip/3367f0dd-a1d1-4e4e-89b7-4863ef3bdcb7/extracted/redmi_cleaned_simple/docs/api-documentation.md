# Story AI - API Documentation

## Overview

The Story AI API provides programmatic access to the platform's features, including user management, story creation and editing, collaboration, comments, and AI suggestions. This document outlines the available endpoints, request and response formats, authentication methods, and error handling.

## Base URL

```
Production: https://api.story-ai.example.com
Development: http://localhost:5000
```

## Authentication

### JWT Authentication

The API uses JSON Web Tokens (JWT) for authentication. Include the token in the Authorization header of your requests:

```
Authorization: Bearer <your_jwt_token>
```

### Obtaining a Token

To obtain a JWT token, use the login or register endpoints:

#### Login

```
POST /api/users/login
```

Request body:
```json
{
  "email": "user@example.com",
  "password": "your_password"
}
```

Response:
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  }
}
```

#### Register

```
POST /api/users/register
```

Request body:
```json
{
  "name": "John Doe",
  "email": "user@example.com",
  "password": "your_password"
}
```

Response:
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  }
}
```

## API Endpoints

### User Management

#### Get Current User

```
GET /api/users/me
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c85",
  "name": "John Doe",
  "email": "user@example.com",
  "profileColor": "#3B82F6",
  "bio": "Writer and storyteller"
}
```

#### Update User Profile

```
PUT /api/users/profile
```

Request body:
```json
{
  "name": "John Smith",
  "bio": "Professional writer and storyteller",
  "profileColor": "#10B981"
}
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c85",
  "name": "John Smith",
  "email": "user@example.com",
  "profileColor": "#10B981",
  "bio": "Professional writer and storyteller"
}
```

#### Update Password

```
PUT /api/users/password
```

Request body:
```json
{
  "currentPassword": "your_current_password",
  "newPassword": "your_new_password"
}
```

Response:
```json
{
  "success": true,
  "message": "Password updated successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

#### Delete User Account

```
DELETE /api/users/:id
```

Response:
```json
{
  "success": true,
  "message": "User deleted successfully"
}
```

### Story Management

#### Create Story

```
POST /api/stories
```

Request body:
```json
{
  "title": "The Adventure Begins",
  "description": "A thrilling adventure story set in the Amazon rainforest.",
  "tags": ["adventure", "mystery", "rainforest"]
}
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c86",
  "title": "The Adventure Begins",
  "description": "A thrilling adventure story set in the Amazon rainforest.",
  "author": "60d21b4667d0d8992e610c85",
  "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "tags": ["adventure", "mystery", "rainforest"],
  "createdAt": "2023-06-22T10:00:00.000Z",
  "updatedAt": "2023-06-22T10:00:00.000Z"
}
```

#### Get All Stories

```
GET /api/stories
```

Response:
```json
[
  {
    "_id": "60d21b4667d0d8992e610c86",
    "title": "The Adventure Begins",
    "description": "A thrilling adventure story set in the Amazon rainforest.",
    "author": {
      "_id": "60d21b4667d0d8992e610c85",
      "name": "John Doe",
      "email": "user@example.com",
      "profileColor": "#3B82F6"
    },
    "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479",
    "tags": ["adventure", "mystery", "rainforest"],
    "createdAt": "2023-06-22T10:00:00.000Z",
    "updatedAt": "2023-06-22T10:00:00.000Z"
  },
  {
    "_id": "60d21b4667d0d8992e610c87",
    "title": "Echoes of Tomorrow",
    "description": "A science fiction story about time travel.",
    "author": {
      "_id": "60d21b4667d0d8992e610c85",
      "name": "John Doe",
      "email": "user@example.com",
      "profileColor": "#3B82F6"
    },
    "documentId": "story-a47ac10b-58cc-4372-a567-0e02b2c3d480",
    "tags": ["sci-fi", "time-travel"],
    "createdAt": "2023-06-23T10:00:00.000Z",
    "updatedAt": "2023-06-23T10:00:00.000Z"
  }
]
```

#### Get Story by ID

```
GET /api/stories/:id
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c86",
  "title": "The Adventure Begins",
  "description": "A thrilling adventure story set in the Amazon rainforest.",
  "author": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  },
  "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "tags": ["adventure", "mystery", "rainforest"],
  "createdAt": "2023-06-22T10:00:00.000Z",
  "updatedAt": "2023-06-22T10:00:00.000Z"
}
```

#### Update Story

```
PUT /api/stories/:id
```

Request body:
```json
{
  "title": "The Great Adventure Begins",
  "description": "An epic adventure story set in the Amazon rainforest.",
  "tags": ["adventure", "mystery", "rainforest", "epic"]
}
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c86",
  "title": "The Great Adventure Begins",
  "description": "An epic adventure story set in the Amazon rainforest.",
  "author": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  },
  "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "tags": ["adventure", "mystery", "rainforest", "epic"],
  "createdAt": "2023-06-22T10:00:00.000Z",
  "updatedAt": "2023-06-22T11:00:00.000Z"
}
```

#### Delete Story

```
DELETE /api/stories/:id
```

Response:
```json
{
  "success": true,
  "message": "Story deleted successfully",
  "story": {
    "_id": "60d21b4667d0d8992e610c86",
    "title": "The Great Adventure Begins"
  }
}
```

#### Get Story Content

```
GET /api/stories/:id/content
```

Response:
```json
{
  "content": "<p>Once upon a time, in the heart of the Amazon rainforest...</p>"
}
```

#### Update Story Content

```
PUT /api/stories/:id/content
```

Request body:
```json
{
  "content": "<p>Once upon a time, in the heart of the Amazon rainforest, there lived a tribe of indigenous people who guarded an ancient secret...</p>"
}
```

Response:
```json
{
  "success": true,
  "message": "Story content updated successfully"
}
```

### Collaborator Management

#### Add Collaborator

```
POST /api/collaborators
```

Request body:
```json
{
  "story": "60d21b4667d0d8992e610c86",
  "email": "collaborator@example.com",
  "role": "editor"
}
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c88",
  "story": "60d21b4667d0d8992e610c86",
  "user": {
    "_id": "60d21b4667d0d8992e610c89",
    "name": "Jane Smith",
    "email": "collaborator@example.com",
    "profileColor": "#10B981"
  },
  "role": "editor",
  "addedBy": "60d21b4667d0d8992e610c85",
  "createdAt": "2023-06-22T12:00:00.000Z"
}
```

#### Get Collaborators by Story

```
GET /api/collaborators/story/:storyId
```

Response:
```json
[
  {
    "_id": "60d21b4667d0d8992e610c88",
    "story": "60d21b4667d0d8992e610c86",
    "user": {
      "_id": "60d21b4667d0d8992e610c89",
      "name": "Jane Smith",
      "email": "collaborator@example.com",
      "profileColor": "#10B981"
    },
    "role": "editor",
    "addedBy": {
      "_id": "60d21b4667d0d8992e610c85",
      "name": "John Doe",
      "email": "user@example.com"
    },
    "isActive": false,
    "createdAt": "2023-06-22T12:00:00.000Z"
  }
]
```

#### Update Collaborator Role

```
PUT /api/collaborators/:id
```

Request body:
```json
{
  "role": "viewer"
}
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c88",
  "story": "60d21b4667d0d8992e610c86",
  "user": {
    "_id": "60d21b4667d0d8992e610c89",
    "name": "Jane Smith",
    "email": "collaborator@example.com",
    "profileColor": "#10B981"
  },
  "role": "viewer",
  "addedBy": "60d21b4667d0d8992e610c85",
  "createdAt": "2023-06-22T12:00:00.000Z"
}
```

#### Delete Collaborator

```
DELETE /api/collaborators/:id
```

Response:
```json
{
  "success": true,
  "message": "Collaborator removed successfully"
}
```

### Comment Management

#### Create Comment

```
POST /api/comments
```

Request body:
```json
{
  "story": "60d21b4667d0d8992e610c86",
  "content": "This paragraph needs more descriptive language.",
  "position": {
    "from": 100,
    "to": 150
  }
}
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c90",
  "story": "60d21b4667d0d8992e610c86",
  "content": "This paragraph needs more descriptive language.",
  "author": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  },
  "position": {
    "from": 100,
    "to": 150
  },
  "replies": [],
  "createdAt": "2023-06-22T13:00:00.000Z"
}
```

#### Get Comments by Story

```
GET /api/comments/story/:storyId
```

Response:
```json
[
  {
    "_id": "60d21b4667d0d8992e610c90",
    "story": "60d21b4667d0d8992e610c86",
    "content": "This paragraph needs more descriptive language.",
    "author": {
      "_id": "60d21b4667d0d8992e610c85",
      "name": "John Doe",
      "email": "user@example.com",
      "profileColor": "#3B82F6"
    },
    "position": {
      "from": 100,
      "to": 150
    },
    "replies": [],
    "createdAt": "2023-06-22T13:00:00.000Z"
  }
]
```

#### Update Comment

```
PUT /api/comments/:id
```

Request body:
```json
{
  "content": "This paragraph needs more vivid descriptive language."
}
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c90",
  "story": "60d21b4667d0d8992e610c86",
  "content": "This paragraph needs more vivid descriptive language.",
  "author": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  },
  "position": {
    "from": 100,
    "to": 150
  },
  "replies": [],
  "createdAt": "2023-06-22T13:00:00.000Z",
  "updatedAt": "2023-06-22T14:00:00.000Z"
}
```

#### Add Reply to Comment

```
POST /api/comments/:id/replies
```

Request body:
```json
{
  "content": "I agree, I'll work on improving the descriptions."
}
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c90",
  "story": "60d21b4667d0d8992e610c86",
  "content": "This paragraph needs more vivid descriptive language.",
  "author": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  },
  "position": {
    "from": 100,
    "to": 150
  },
  "replies": [
    {
      "_id": "60d21b4667d0d8992e610c91",
      "content": "I agree, I'll work on improving the descriptions.",
      "author": {
        "_id": "60d21b4667d0d8992e610c89",
        "name": "Jane Smith",
        "email": "collaborator@example.com",
        "profileColor": "#10B981"
      },
      "createdAt": "2023-06-22T15:00:00.000Z"
    }
  ],
  "createdAt": "2023-06-22T13:00:00.000Z",
  "updatedAt": "2023-06-22T15:00:00.000Z"
}
```

#### Delete Comment

```
DELETE /api/comments/:id
```

Response:
```json
{
  "success": true,
  "message": "Comment deleted successfully"
}
```

#### Resolve Comment

```
PUT /api/comments/:id/resolve
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c90",
  "story": "60d21b4667d0d8992e610c86",
  "content": "This paragraph needs more vivid descriptive language.",
  "author": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  },
  "position": {
    "from": 100,
    "to": 150
  },
  "resolved": true,
  "resolvedBy": {
    "_id": "60d21b4667d0d8992e610c89",
    "name": "Jane Smith",
    "email": "collaborator@example.com",
    "profileColor": "#10B981"
  },
  "resolvedAt": "2023-06-22T16:00:00.000Z",
  "replies": [
    {
      "_id": "60d21b4667d0d8992e610c91",
      "content": "I agree, I'll work on improving the descriptions.",
      "author": {
        "_id": "60d21b4667d0d8992e610c89",
        "name": "Jane Smith",
        "email": "collaborator@example.com",
        "profileColor": "#10B981"
      },
      "createdAt": "2023-06-22T15:00:00.000Z"
    }
  ],
  "createdAt": "2023-06-22T13:00:00.000Z",
  "updatedAt": "2023-06-22T16:00:00.000Z"
}
```

### AI Suggestion Management

#### Create AI Suggestion

```
POST /api/ai-suggestions
```

Request body:
```json
{
  "story": "60d21b4667d0d8992e610c86",
  "type": "grammar",
  "content": "Grammar correction suggestion",
  "position": {
    "from": 200,
    "to": 210
  },
  "originalText": "This is a error",
  "suggestedText": "This is an error",
  "explanation": "Use 'an' before words that start with a vowel sound"
}
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c92",
  "story": "60d21b4667d0d8992e610c86",
  "type": "grammar",
  "content": "Grammar correction suggestion",
  "position": {
    "from": 200,
    "to": 210
  },
  "originalText": "This is a error",
  "suggestedText": "This is an error",
  "explanation": "Use 'an' before words that start with a vowel sound",
  "requestedBy": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  },
  "applied": false,
  "dismissed": false,
  "createdAt": "2023-06-22T17:00:00.000Z"
}
```

#### Generate AI Suggestions

```
POST /api/ai-suggestions/generate
```

Request body:
```json
{
  "story": "60d21b4667d0d8992e610c86",
  "content": "This is the content to analyze for suggestions",
  "types": ["grammar", "style"]
}
```

Response:
```json
[
  {
    "_id": "60d21b4667d0d8992e610c93",
    "story": "60d21b4667d0d8992e610c86",
    "type": "grammar",
    "content": "Grammar correction suggestion",
    "position": {
      "from": 10,
      "to": 20
    },
    "originalText": "This is a error",
    "suggestedText": "This is an error",
    "explanation": "Use 'an' before words that start with a vowel sound",
    "requestedBy": {
      "_id": "60d21b4667d0d8992e610c85",
      "name": "John Doe",
      "email": "user@example.com",
      "profileColor": "#3B82F6"
    },
    "applied": false,
    "dismissed": false,
    "createdAt": "2023-06-22T18:00:00.000Z"
  },
  {
    "_id": "60d21b4667d0d8992e610c94",
    "story": "60d21b4667d0d8992e610c86",
    "type": "style",
    "content": "Style improvement suggestion",
    "position": {
      "from": 50,
      "to": 70
    },
    "originalText": "The man was very tired",
    "suggestedText": "The exhausted man collapsed into his chair",
    "explanation": "More descriptive language creates a stronger image",
    "requestedBy": {
      "_id": "60d21b4667d0d8992e610c85",
      "name": "John Doe",
      "email": "user@example.com",
      "profileColor": "#3B82F6"
    },
    "applied": false,
    "dismissed": false,
    "createdAt": "2023-06-22T18:00:00.000Z"
  }
]
```

#### Get AI Suggestions by Story

```
GET /api/ai-suggestions/story/:storyId
```

Response:
```json
[
  {
    "_id": "60d21b4667d0d8992e610c92",
    "story": "60d21b4667d0d8992e610c86",
    "type": "grammar",
    "content": "Grammar correction suggestion",
    "position": {
      "from": 200,
      "to": 210
    },
    "originalText": "This is a error",
    "suggestedText": "This is an error",
    "explanation": "Use 'an' before words that start with a vowel sound",
    "requestedBy": {
      "_id": "60d21b4667d0d8992e610c85",
      "name": "John Doe",
      "email": "user@example.com",
      "profileColor": "#3B82F6"
    },
    "applied": false,
    "dismissed": false,
    "createdAt": "2023-06-22T17:00:00.000Z"
  }
]
```

#### Apply AI Suggestion

```
PUT /api/ai-suggestions/:id/apply
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c92",
  "story": "60d21b4667d0d8992e610c86",
  "type": "grammar",
  "content": "Grammar correction suggestion",
  "position": {
    "from": 200,
    "to": 210
  },
  "originalText": "This is a error",
  "suggestedText": "This is an error",
  "explanation": "Use 'an' before words that start with a vowel sound",
  "requestedBy": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  },
  "applied": true,
  "appliedBy": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  },
  "appliedAt": "2023-06-22T19:00:00.000Z",
  "dismissed": false,
  "createdAt": "2023-06-22T17:00:00.000Z"
}
```

#### Dismiss AI Suggestion

```
PUT /api/ai-suggestions/:id/dismiss
```

Response:
```json
{
  "_id": "60d21b4667d0d8992e610c92",
  "story": "60d21b4667d0d8992e610c86",
  "type": "grammar",
  "content": "Grammar correction suggestion",
  "position": {
    "from": 200,
    "to": 210
  },
  "originalText": "This is a error",
  "suggestedText": "This is an error",
  "explanation": "Use 'an' before words that start with a vowel sound",
  "requestedBy": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  },
  "applied": false,
  "dismissed": true,
  "dismissedBy": {
    "_id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "email": "user@example.com",
    "profileColor": "#3B82F6"
  },
  "dismissedAt": "2023-06-22T19:00:00.000Z",
  "createdAt": "2023-06-22T17:00:00.000Z"
}
```

#### Delete AI Suggestion

```
DELETE /api/ai-suggestions/:id
```

Response:
```json
{
  "success": true,
  "message": "AI suggestion deleted successfully"
}
```

### Collaborative Editing

#### Get Document

```
GET /api/collaborative-editing/:documentId
```

Response:
```json
{
  "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "storyId": "60d21b4667d0d8992e610c86",
  "title": "The Great Adventure Begins",
  "content": "<p>Once upon a time, in the heart of the Amazon rainforest, there lived a tribe of indigenous people who guarded an ancient secret...</p>"
}
```

#### Save Document Content

```
PUT /api/collaborative-editing/:documentId
```

Request body:
```json
{
  "content": "<p>Once upon a time, in the heart of the Amazon rainforest, there lived a tribe of indigenous people who guarded an ancient secret. The secret was a hidden temple that contained powerful artifacts...</p>"
}
```

Response:
```json
{
  "success": true,
  "message": "Document saved successfully"
}
```

#### Get Active Collaborators

```
GET /api/collaborative-editing/:documentId/collaborators
```

Response:
```json
[
  {
    "_id": "author",
    "user": {
      "_id": "60d21b4667d0d8992e610c85",
      "name": "John Doe",
      "email": "user@example.com",
      "profileColor": "#3B82F6"
    },
    "role": "owner",
    "isActive": true
  },
  {
    "_id": "60d21b4667d0d8992e610c88",
    "user": {
      "_id": "60d21b4667d0d8992e610c89",
      "name": "Jane Smith",
      "email": "collaborator@example.com",
      "profileColor": "#10B981"
    },
    "role": "editor",
    "isActive": true
  }
]
```

#### Update User Presence

```
PUT /api/collaborative-editing/:documentId/presence
```

Request body:
```json
{
  "isActive": true
}
```

Response:
```json
{
  "success": true,
  "message": "Presence updated successfully"
}
```

## Error Handling

The API uses standard HTTP status codes to indicate the success or failure of requests:

- `200 OK`: The request was successful
- `201 Created`: A new resource was successfully created
- `400 Bad Request`: The request was invalid or malformed
- `401 Unauthorized`: Authentication is required or failed
- `403 Forbidden`: The authenticated user doesn't have permission to access the resource
- `404 Not Found`: The requested resource was not found
- `500 Internal Server Error`: An error occurred on the server

Error responses have the following format:

```json
{
  "success": false,
  "message": "Error message describing what went wrong"
}
```

## Rate Limiting

To prevent abuse, the API implements rate limiting:

- Authentication endpoints: 10 requests per minute
- Other endpoints: 60 requests per minute

When rate limits are exceeded, the API returns a `429 Too Many Requests` status code with a response indicating when you can retry:

```json
{
  "success": false,
  "message": "Rate limit exceeded",
  "retryAfter": 30
}
```

## Versioning

The API is versioned to ensure backward compatibility as it evolves. The current version is v1, which is the default.

To specify a different API version, include it in the URL path:

```
https://api.story-ai.example.com/v2/stories
```

## Conclusion

This documentation covers the core functionality of the Story AI API. For additional support or to report issues, please contact the development team.