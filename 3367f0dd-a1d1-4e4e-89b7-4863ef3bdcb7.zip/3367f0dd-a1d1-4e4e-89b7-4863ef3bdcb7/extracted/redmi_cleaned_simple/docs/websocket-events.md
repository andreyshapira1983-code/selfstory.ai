# Story AI - WebSocket Events Documentation

## Overview

Story AI uses WebSockets for real-time communication between clients and the server. This enables collaborative editing, user presence awareness, cursor tracking, and real-time messaging. This document outlines the WebSocket events, their payloads, and the communication flow between clients and the server.

## Connection Establishment

### WebSocket Server URL

```
Production: wss://api.story-ai.example.com/ws-server
Development: ws://localhost:5000/ws-server
```

### Connection Parameters

When connecting to the WebSocket server, include the following query parameters:

- `token`: JWT authentication token
- `documentId`: ID of the document to collaborate on (optional, can be provided later)

Example:
```
ws://localhost:5000/ws-server?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...&documentId=story-f47ac10b-58cc-4372-a567-0e02b2c3d479
```

### Connection Path

For document-specific connections, include the document ID in the path:

```
ws://localhost:5000/ws-server/story-f47ac10b-58cc-4372-a567-0e02b2c3d479?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

## WebSocket Protocols

Story AI uses two WebSocket protocols:

1. **Y-WebSocket Protocol**: Binary protocol for Yjs document synchronization
2. **Custom JSON Protocol**: Text-based protocol for user presence, cursor positions, and chat messages

## Y-WebSocket Protocol

The Y-WebSocket protocol is a binary protocol used for Yjs document synchronization. It uses message types to indicate the purpose of each message.

### Message Types

1. **Sync Step 1 (0)**: Client requests document state or server sends document state
2. **Sync Step 2 (1)**: Client sends document updates to server
3. **Awareness Update (2)**: Client or server sends awareness state updates
4. **Sync Step 2 with Update (3)**: Client sends document updates with confirmation request

### Binary Message Format

```
[messageType: UInt8][content: UInt8Array]
```

### Awareness States

Awareness states are used to track user presence, cursor positions, and other metadata. The awareness state is a JSON object with the following structure:

```json
{
  "user": {
    "id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "color": "#3B82F6"
  },
  "cursor": {
    "anchor": 10,
    "head": 15
  }
}
```

## Custom JSON Protocol

The custom JSON protocol is used for user presence, cursor positions, and chat messages. It uses JSON-encoded messages with a `type` field to indicate the purpose of each message.

### Client to Server Events

#### Join Document

Sent when a client wants to join a document for collaboration.

```json
{
  "type": "join-document",
  "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "userId": "60d21b4667d0d8992e610c85",
  "userName": "John Doe"
}
```

#### User Presence

Sent to update the user's presence status.

```json
{
  "type": "user-presence",
  "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "status": "active"
}
```

#### Cursor Update

Sent to update the user's cursor position.

```json
{
  "type": "cursor-update",
  "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "position": {
    "anchor": 100,
    "head": 110
  }
}
```

#### Get Presence

Sent to request the list of active users in a document.

```json
{
  "type": "get-presence",
  "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479"
}
```

#### Chat Message

Sent to send a chat message to all users in a document.

```json
{
  "type": "chat-message",
  "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "content": "Hello, everyone!"
}
```

#### Document Update

Sent to notify other clients about document updates (used in addition to Yjs synchronization).

```json
{
  "type": "document-update",
  "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "update": [/* binary update data as array */]
}
```

### Server to Client Events

#### User Joined

Sent when a new user joins the document.

```json
{
  "type": "user-joined",
  "socketId": "socket-123456",
  "user": {
    "id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "profileColor": "#3B82F6"
  },
  "timestamp": "2023-06-22T10:00:00.000Z"
}
```

#### User Left

Sent when a user leaves the document.

```json
{
  "type": "user-left",
  "socketId": "socket-123456",
  "user": {
    "id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "profileColor": "#3B82F6"
  },
  "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "timestamp": "2023-06-22T11:00:00.000Z"
}
```

#### User Presence

Sent to notify other clients about a user's presence status.

```json
{
  "type": "user-presence",
  "socketId": "socket-123456",
  "user": {
    "id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "profileColor": "#3B82F6"
  },
  "status": "active",
  "timestamp": "2023-06-22T10:30:00.000Z"
}
```

#### Cursor Update

Sent to notify other clients about a user's cursor position.

```json
{
  "type": "cursor-update",
  "socketId": "socket-123456",
  "user": {
    "id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "profileColor": "#3B82F6"
  },
  "position": {
    "anchor": 100,
    "head": 110
  },
  "timestamp": "2023-06-22T10:35:00.000Z"
}
```

#### Presence Update

Sent in response to a `get-presence` request, containing a list of all active users.

```json
{
  "type": "presence-update",
  "users": [
    {
      "id": "60d21b4667d0d8992e610c85",
      "name": "John Doe",
      "profileColor": "#3B82F6"
    },
    {
      "id": "60d21b4667d0d8992e610c89",
      "name": "Jane Smith",
      "profileColor": "#10B981"
    }
  ],
  "timestamp": "2023-06-22T10:40:00.000Z"
}
```

#### Chat Message

Sent to broadcast a chat message to all users in a document.

```json
{
  "type": "chat-message",
  "user": {
    "id": "60d21b4667d0d8992e610c85",
    "name": "John Doe",
    "profileColor": "#3B82F6"
  },
  "content": "Hello, everyone!",
  "timestamp": "2023-06-22T10:45:00.000Z"
}
```

#### Document Update

Sent to notify clients about document updates (used in addition to Yjs synchronization).

```json
{
  "type": "document-update",
  "documentId": "story-f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "update": [/* binary update data as array */],
  "origin": "socket-123456",
  "timestamp": "2023-06-22T10:50:00.000Z"
}
```

## Communication Flow

### Initial Connection

1. Client connects to WebSocket server with JWT token and document ID
2. Server authenticates the client and checks document access permissions
3. Server sends initial document state to the client (Sync Step 1)
4. Server sends current awareness states to the client
5. Server broadcasts "user joined" event to other clients
6. Client applies the document state and awareness states

### Real-time Editing

1. Client makes changes to the document
2. Client sends document updates to the server (Sync Step 2)
3. Server applies updates to the shared document
4. Server broadcasts updates to all other clients
5. Other clients apply the updates to their local documents

### Cursor Position Updates

1. Client updates cursor position locally
2. Client sends cursor position update to the server
3. Server broadcasts cursor position to all other clients
4. Other clients update the remote cursor position in their UI

### User Presence

1. Client sends presence status to the server
2. Server updates the user's presence status
3. Server broadcasts presence update to all other clients
4. Other clients update their UI to reflect the user's presence

### Disconnection

1. Client disconnects from the WebSocket server
2. Server detects the disconnection
3. Server removes the client from the document's active clients
4. Server broadcasts "user left" event to other clients
5. Server updates the collaborator's active status in the database

## Error Handling

### Connection Errors

If the WebSocket connection fails, the client should attempt to reconnect with exponential backoff:

1. First attempt: Immediate
2. Second attempt: After 1 second
3. Third attempt: After 3 seconds
4. Fourth attempt: After 7 seconds
5. Subsequent attempts: After 15 seconds

### Authentication Errors

If authentication fails, the server will close the connection with a close code of 4001 and a reason message.

### Permission Errors

If the user doesn't have permission to access the document, the server will close the connection with a close code of 4003 and a reason message.

### Document Not Found

If the document doesn't exist, the server will close the connection with a close code of 4004 and a reason message.

## WebSocket Close Codes

- `1000`: Normal closure
- `1001`: Going away (browser tab closed)
- `1006`: Abnormal closure (connection lost)
- `4001`: Authentication failed
- `4002`: Invalid message format
- `4003`: Permission denied
- `4004`: Document not found
- `4005`: Rate limit exceeded

## Best Practices

### Connection Management

- Implement reconnection logic with exponential backoff
- Handle connection errors gracefully
- Update UI to reflect connection status

### State Synchronization

- Use Yjs for document synchronization
- Use awareness protocol for cursor positions and user presence
- Handle conflicts using CRDT (Conflict-free Replicated Data Types)

### Performance Optimization

- Batch updates when possible
- Use binary protocol for document updates
- Implement debouncing for cursor position updates

## Example: Collaborative Editing Session

1. User A opens a document
   - Connects to WebSocket server
   - Receives document state
   - Receives awareness states

2. User B opens the same document
   - Connects to WebSocket server
   - Receives document state
   - Receives awareness states
   - User A receives "user joined" event

3. User A edits the document
   - Local document is updated
   - Updates are sent to the server
   - Server broadcasts updates to User B
   - User B's document is updated

4. User B moves cursor
   - Cursor position is sent to the server
   - Server broadcasts cursor position to User A
   - User A sees User B's cursor

5. User A closes the document
   - WebSocket connection is closed
   - Server broadcasts "user left" event to User B
   - User B's UI is updated to reflect User A's departure

## Conclusion

This documentation covers the WebSocket events and communication flow for the Story AI platform. By following these protocols, clients can implement real-time collaborative editing, user presence awareness, and cursor tracking.