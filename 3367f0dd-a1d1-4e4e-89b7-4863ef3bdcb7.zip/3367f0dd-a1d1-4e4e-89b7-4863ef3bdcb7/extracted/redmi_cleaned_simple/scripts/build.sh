#!/bin/bash

# Story AI Build Script
# This script automates the build process for the Story AI application

# Exit on error
set -e

# Display help message
display_help() {
  echo "Story AI Build Script"
  echo "Usage: ./build.sh [options]"
  echo ""
  echo "Options:"
  echo "  -e, --env ENV     Specify environment (development, staging, production)"
  echo "  -c, --clean       Clean build directory before building"
  echo "  -t, --test        Run tests before building"
  echo "  -d, --deploy      Deploy after building"
  echo "  -h, --help        Display this help message"
  echo ""
  echo "Example: ./build.sh -e production -c -t"
}

# Default values
ENV="development"
CLEAN=false
RUN_TESTS=false
DEPLOY=false

# Parse command line arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    -e|--env)
      ENV="$2"
      shift 2
      ;;
    -c|--clean)
      CLEAN=true
      shift
      ;;
    -t|--test)
      RUN_TESTS=true
      shift
      ;;
    -d|--deploy)
      DEPLOY=true
      shift
      ;;
    -h|--help)
      display_help
      exit 0
      ;;
    *)
      echo "Unknown option: $1"
      display_help
      exit 1
      ;;
  esac
done

# Validate environment
if [[ "$ENV" != "development" && "$ENV" != "staging" && "$ENV" != "production" ]]; then
  echo "Error: Invalid environment. Must be one of: development, staging, production"
  exit 1
fi

# Display build information
echo "===== Story AI Build ====="
echo "Environment: $ENV"
echo "Clean build: $CLEAN"
echo "Run tests: $RUN_TESTS"
echo "Deploy after build: $DEPLOY"
echo "=========================="

# Set environment variables
export NODE_ENV=$ENV

# Clean build directory if requested
if [ "$CLEAN" = true ]; then
  echo "Cleaning build directory..."
  rm -rf dist
  rm -rf node_modules/.cache
  echo "Build directory cleaned."
fi

# Install dependencies
echo "Installing dependencies..."
npm ci
echo "Dependencies installed."

# Run tests if requested
if [ "$RUN_TESTS" = true ]; then
  echo "Running tests..."
  npm test
  echo "Tests completed."
fi

# Build the application
echo "Building application for $ENV environment..."
npm run build
echo "Build completed."

# Deploy if requested
if [ "$DEPLOY" = true ]; then
  echo "Deploying application to $ENV environment..."
  
  case $ENV in
    development)
      echo "Skipping deployment for development environment."
      ;;
    staging)
      # Add staging deployment commands here
      echo "Deploying to staging server..."
      # Example: rsync -avz --exclude 'node_modules' --exclude '.git' ./ user@staging-server:/path/to/app
      ;;
    production)
      # Add production deployment commands here
      echo "Deploying to production server..."
      # Example: rsync -avz --exclude 'node_modules' --exclude '.git' ./ user@production-server:/path/to/app
      ;;
  esac
  
  echo "Deployment completed."
fi

echo "===== Build Process Completed ====="