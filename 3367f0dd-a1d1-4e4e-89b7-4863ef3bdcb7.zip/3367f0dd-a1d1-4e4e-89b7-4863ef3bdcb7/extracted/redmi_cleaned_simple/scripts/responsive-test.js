/**
 * Responsive Design Test Script for Story AI
 * 
 * This script tests the responsive design of the Story AI application
 * across different device sizes using Puppeteer.
 */

const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

// URLs to test
const urls = [
  'http://localhost:3000/',                // Home page
  'http://localhost:3000/stories',         // Story list page
  'http://localhost:3000/editor/story-1',  // Editor page
  'http://localhost:3000/login',           // Login page
  'http://localhost:3000/register'         // Registration page
];

// Device configurations to test
const devices = [
  { name: 'Mobile Small', width: 320, height: 568 },
  { name: 'Mobile Medium', width: 375, height: 667 },
  { name: 'Mobile Large', width: 414, height: 736 },
  { name: 'Tablet', width: 768, height: 1024 },
  { name: 'Laptop', width: 1366, height: 768 },
  { name: 'Desktop', width: 1920, height: 1080 }
];

// Create results directory if it doesn't exist
const resultsDir = path.join(__dirname, '../responsive-test-results');
if (!fs.existsSync(resultsDir)) {
  fs.mkdirSync(resultsDir, { recursive: true });
}

// Main function to run responsive tests
async function runResponsiveTests() {
  console.log('Starting responsive design tests...');
  
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  
  let hasErrors = false;
  const results = {
    timestamp: new Date().toISOString(),
    tests: []
  };
  
  try {
    for (const url of urls) {
      console.log(`\nTesting ${url}`);
      
      for (const device of devices) {
        console.log(`  Testing on ${device.name} (${device.width}x${device.height})`);
        
        const page = await browser.newPage();
        await page.setViewport({ width: device.width, height: device.height });
        
        try {
          // Navigate to the page
          await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });
          
          // Wait for any client-side rendering to complete
          await page.waitForTimeout(2000);
          
          // Take a screenshot
          const screenshotPath = path.join(
            resultsDir, 
            `${url.replace(/[^a-zA-Z0-9]/g, '_')}_${device.name.replace(/\s+/g, '_')}.png`
          );
          await page.screenshot({ path: screenshotPath, fullPage: true });
          
          // Check for horizontal overflow (indicates potential responsive issues)
          const hasHorizontalOverflow = await page.evaluate(() => {
            return document.body.scrollWidth > window.innerWidth;
          });
          
          // Check for tiny text (potential readability issues on small screens)
          const hasTinyText = await page.evaluate(() => {
            const MIN_FONT_SIZE = 12; // Minimum acceptable font size in pixels
            const textElements = Array.from(document.querySelectorAll('p, span, div, a, button, h1, h2, h3, h4, h5, h6'));
            
            for (const element of textElements) {
              const style = window.getComputedStyle(element);
              const fontSize = parseFloat(style.fontSize);
              
              if (fontSize < MIN_FONT_SIZE && element.textContent.trim() !== '') {
                return true;
              }
            }
            
            return false;
          });
          
          // Check for touch target size issues
          const hasTouchTargetIssues = await page.evaluate(() => {
            const MIN_TARGET_SIZE = 44; // Minimum touch target size in pixels (WCAG 2.5.5)
            const interactiveElements = Array.from(document.querySelectorAll('a, button, [role="button"], input, select, textarea'));
            
            for (const element of interactiveElements) {
              const rect = element.getBoundingClientRect();
              if ((rect.width < MIN_TARGET_SIZE || rect.height < MIN_TARGET_SIZE) && 
                  window.getComputedStyle(element).display !== 'none') {
                return true;
              }
            }
            
            return false;
          });
          
          // Store test results
          const testResult = {
            url,
            device: device.name,
            viewport: `${device.width}x${device.height}`,
            screenshotPath,
            issues: {
              horizontalOverflow: hasHorizontalOverflow,
              tinyText: hasTinyText,
              touchTargetSize: hasTouchTargetIssues
            },
            pass: !hasHorizontalOverflow && !hasTinyText && !hasTouchTargetIssues
          };
          
          results.tests.push(testResult);
          
          // Log results
          if (testResult.pass) {
            console.log(`    ✓ Passed responsive tests`);
          } else {
            console.log(`    ✗ Failed responsive tests:`);
            if (hasHorizontalOverflow) console.log('      - Horizontal overflow detected');
            if (hasTinyText) console.log('      - Text too small detected');
            if (hasTouchTargetIssues) console.log('      - Touch target size issues detected');
            
            hasErrors = true;
          }
        } catch (error) {
          console.error(`    ✗ Error testing ${url} on ${device.name}:`, error);
          hasErrors = true;
          
          results.tests.push({
            url,
            device: device.name,
            viewport: `${device.width}x${device.height}`,
            error: error.message,
            pass: false
          });
        } finally {
          await page.close();
        }
      }
    }
    
    // Save results to file
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const resultsFile = path.join(resultsDir, `responsive-results-${timestamp}.json`);
    
    fs.writeFileSync(
      resultsFile,
      JSON.stringify(results, null, 2)
    );
    
    console.log(`\nResponsive design tests complete. Results saved to ${resultsFile}`);
    
    // Generate HTML report
    generateHtmlReport(results, timestamp);
    
    // Exit with appropriate code
    if (hasErrors) {
      console.log('\n❌ Responsive design tests failed. Please fix the issues.');
      process.exit(1);
    } else {
      console.log('\n✅ Responsive design tests passed!');
      process.exit(0);
    }
  } finally {
    await browser.close();
  }
}

// Generate HTML report
function generateHtmlReport(results, timestamp) {
  const reportFile = path.join(resultsDir, `responsive-report-${timestamp}.html`);
  
  // Group tests by URL
  const testsByUrl = {};
  results.tests.forEach(test => {
    if (!testsByUrl[test.url]) {
      testsByUrl[test.url] = [];
    }
    testsByUrl[test.url].push(test);
  });
  
  // Generate HTML content
  let html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Responsive Design Test Report - ${new Date().toLocaleDateString()}</title>
      <style>
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
          line-height: 1.6;
          color: #333;
          max-width: 1200px;
          margin: 0 auto;
          padding: 20px;
        }
        h1, h2, h3 {
          color: #2563eb;
        }
        .summary {
          background-color: #f3f4f6;
          padding: 15px;
          border-radius: 5px;
          margin-bottom: 20px;
        }
        .url-section {
          margin-bottom: 30px;
          border-bottom: 1px solid #e5e7eb;
          padding-bottom: 20px;
        }
        .device-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
          gap: 20px;
          margin-top: 20px;
        }
        .device-card {
          border: 1px solid #e5e7eb;
          border-radius: 5px;
          padding: 15px;
        }
        .device-card.pass {
          border-left: 5px solid #10b981;
        }
        .device-card.fail {
          border-left: 5px solid #ef4444;
        }
        .device-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 10px;
        }
        .status {
          display: inline-block;
          padding: 3px 8px;
          border-radius: 3px;
          font-size: 14px;
          font-weight: bold;
          color: white;
        }
        .status.pass { background-color: #10b981; }
        .status.fail { background-color: #ef4444; }
        .issues {
          margin-top: 10px;
          font-size: 14px;
        }
        .issue {
          color: #ef4444;
          margin-bottom: 5px;
        }
        .screenshot {
          width: 100%;
          height: auto;
          margin-top: 10px;
          border: 1px solid #e5e7eb;
          border-radius: 3px;
        }
      </style>
    </head>
    <body>
      <h1>Responsive Design Test Report</h1>
      <div class="summary">
        <p><strong>Date:</strong> ${new Date().toLocaleString()}</p>
        <p><strong>Total URLs Tested:</strong> ${Object.keys(testsByUrl).length}</p>
        <p><strong>Total Device Configurations:</strong> ${devices.length}</p>
        <p><strong>Total Tests:</strong> ${results.tests.length}</p>
        <p><strong>Passed Tests:</strong> ${results.tests.filter(t => t.pass).length}</p>
        <p><strong>Failed Tests:</strong> ${results.tests.filter(t => !t.pass).length}</p>
      </div>
  `;
  
  // Add tests by URL
  Object.keys(testsByUrl).forEach(url => {
    const urlTests = testsByUrl[url];
    const passedTests = urlTests.filter(t => t.pass).length;
    
    html += `
      <div class="url-section">
        <h2>URL: ${url}</h2>
        <p><strong>Tests:</strong> ${urlTests.length}</p>
        <p><strong>Passed:</strong> ${passedTests} / ${urlTests.length}</p>
        
        <div class="device-grid">
    `;
    
    urlTests.forEach(test => {
      const screenshotPath = test.screenshotPath ? 
        path.relative(resultsDir, test.screenshotPath).replace(/\\/g, '/') : 
        null;
      
      html += `
        <div class="device-card ${test.pass ? 'pass' : 'fail'}">
          <div class="device-header">
            <h3>${test.device}</h3>
            <span class="status ${test.pass ? 'pass' : 'fail'}">${test.pass ? 'PASS' : 'FAIL'}</span>
          </div>
          <p><strong>Viewport:</strong> ${test.viewport}</p>
      `;
      
      if (!test.pass && test.issues) {
        html += `<div class="issues">`;
        if (test.issues.horizontalOverflow) {
          html += `<div class="issue">✗ Horizontal overflow detected</div>`;
        }
        if (test.issues.tinyText) {
          html += `<div class="issue">✗ Text too small detected</div>`;
        }
        if (test.issues.touchTargetSize) {
          html += `<div class="issue">✗ Touch target size issues detected</div>`;
        }
        html += `</div>`;
      }
      
      if (test.error) {
        html += `<div class="issues"><div class="issue">✗ Error: ${test.error}</div></div>`;
      }
      
      if (screenshotPath) {
        html += `<img src="${screenshotPath}" alt="Screenshot of ${test.device}" class="screenshot">`;
      }
      
      html += `
        </div>
      `;
    });
    
    html += `
        </div>
      </div>
    `;
  });
  
  html += `
    </body>
    </html>
  `;
  
  fs.writeFileSync(reportFile, html);
  console.log(`HTML report generated: ${reportFile}`);
}

// Run the tests
runResponsiveTests().catch(error => {
  console.error('Error running responsive tests:', error);
  process.exit(1);
});