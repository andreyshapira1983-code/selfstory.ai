/**
 * MongoDB Connection and Model Testing Script
 * 
 * This script tests the MongoDB connection and basic CRUD operations
 * for all models in the Story AI application.
 */

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

// Import models
const User = require('./src/server/models/User');
const Story = require('./src/server/models/Story');
const Collaborator = require('./src/server/models/Collaborator');
const Comment = require('./src/server/models/Comment');
const AISuggestion = require('./src/server/models/AISuggestion');

// MongoDB connection string - using a test database
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/story_ai_test';

// Test data
let testUser = null;
let testStory = null;
let testCollaborator = null;
let testComment = null;
let testAISuggestion = null;

// Connect to MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect(MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useCreateIndex: true,
      useFindAndModify: false
    });
    console.log('\u2705 MongoDB connected successfully');
    return true;
  } catch (error) {
    console.error('\u274c MongoDB connection error:', error.message);
    process.exit(1);
  }
};

// Test User model
const testUserModel = async () => {
  console.log('\n--- Testing User Model ---');
  
  try {
    // Create a test user
    const userData = {
      name: 'Test User',
      email: `test.user.${Date.now()}@example.com`,
      password: 'password123',
      profileColor: '#3B82F6',
      bio: 'This is a test user for MongoDB testing'
    };
    
    testUser = new User(userData);
    await testUser.save();
    console.log('\u2705 User created successfully:', testUser._id);
    
    // Read user
    const foundUser = await User.findById(testUser._id);
    console.log('\u2705 User retrieved successfully:', foundUser.name);
    
    // Update user
    const updatedUser = await User.findByIdAndUpdate(
      testUser._id,
      { bio: 'Updated bio for testing' },
      { new: true }
    );
    console.log('\u2705 User updated successfully:', updatedUser.bio);
    
    // Test password comparison
    const isMatch = await testUser.comparePassword('password123');
    console.log('\u2705 Password comparison:', isMatch ? 'Successful' : 'Failed');
    
    return true;
  } catch (error) {
    console.error('\u274c User model test failed:', error.message);
    return false;
  }
};

// Test Story model
const testStoryModel = async () => {
  console.log('\n--- Testing Story Model ---');
  
  try {
    // Create a test story
    const storyData = {
      title: 'Test Story',
      description: 'This is a test story for MongoDB testing',
      content: 'Once upon a time, there was a test story in a database...',
      author: testUser._id,
      documentId: `story-${uuidv4()}`,
      isPublic: true,
      tags: ['test', 'mongodb', 'story']
    };
    
    testStory = new Story(storyData);
    await testStory.save();
    console.log('\u2705 Story created successfully:', testStory._id);
    
    // Read story
    const foundStory = await Story.findById(testStory._id).populate('author', 'name email');
    console.log('\u2705 Story retrieved successfully:', foundStory.title);
    console.log('\u2705 Author populated successfully:', foundStory.author.name);
    
    // Update story
    const updatedStory = await Story.findByIdAndUpdate(
      testStory._id,
      { title: 'Updated Test Story Title' },
      { new: true }
    );
    console.log('\u2705 Story updated successfully:', updatedStory.title);
    
    return true;
  } catch (error) {
    console.error('\u274c Story model test failed:', error.message);
    return false;
  }
};

// Test Collaborator model
const testCollaboratorModel = async () => {
  console.log('\n--- Testing Collaborator Model ---');
  
  try {
    // Create a second user to be a collaborator
    const collaboratorUser = new User({
      name: 'Collaborator User',
      email: `collaborator.${Date.now()}@example.com`,
      password: 'password123',
      profileColor: '#10B981'
    });
    await collaboratorUser.save();
    console.log('\u2705 Collaborator user created successfully:', collaboratorUser._id);
    
    // Create a test collaborator
    const collaboratorData = {
      story: testStory._id,
      user: collaboratorUser._id,
      role: 'editor',
      addedBy: testUser._id
    };
    
    testCollaborator = new Collaborator(collaboratorData);
    await testCollaborator.save();
    console.log('\u2705 Collaborator created successfully:', testCollaborator._id);
    
    // Read collaborator
    const foundCollaborator = await Collaborator.findById(testCollaborator._id)
      .populate('user', 'name email')
      .populate('story', 'title');
    console.log('\u2705 Collaborator retrieved successfully:', foundCollaborator.role);
    console.log('\u2705 User populated successfully:', foundCollaborator.user.name);
    console.log('\u2705 Story populated successfully:', foundCollaborator.story.title);
    
    // Update collaborator
    const updatedCollaborator = await Collaborator.findByIdAndUpdate(
      testCollaborator._id,
      { 
        role: 'viewer',
        isActive: true,
        lastActive: new Date()
      },
      { new: true }
    );
    console.log('\u2705 Collaborator updated successfully:', updatedCollaborator.role);
    
    return true;
  } catch (error) {
    console.error('\u274c Collaborator model test failed:', error.message);
    return false;
  }
};

// Test Comment model
const testCommentModel = async () => {
  console.log('\n--- Testing Comment Model ---');
  
  try {
    // Create a test comment
    const commentData = {
      story: testStory._id,
      content: 'This is a test comment on the story',
      author: testUser._id,
      position: {
        from: 10,
        to: 20
      }
    };
    
    testComment = new Comment(commentData);
    await testComment.save();
    console.log('\u2705 Comment created successfully:', testComment._id);
    
    // Read comment
    const foundComment = await Comment.findById(testComment._id)
      .populate('author', 'name email')
      .populate('story', 'title');
    console.log('\u2705 Comment retrieved successfully:', foundComment.content);
    console.log('\u2705 Author populated successfully:', foundComment.author.name);
    console.log('\u2705 Story populated successfully:', foundComment.story.title);
    
    // Update comment
    const updatedComment = await Comment.findByIdAndUpdate(
      testComment._id,
      { 
        content: 'Updated test comment content',
        replies: [{
          content: 'This is a reply to the test comment',
          author: testUser._id
        }]
      },
      { new: true }
    );
    console.log('\u2705 Comment updated successfully:', updatedComment.content);
    console.log('\u2705 Reply added successfully:', updatedComment.replies[0].content);
    
    return true;
  } catch (error) {
    console.error('\u274c Comment model test failed:', error.message);
    return false;
  }
};

// Test AISuggestion model
const testAISuggestionModel = async () => {
  console.log('\n--- Testing AISuggestion Model ---');
  
  try {
    // Create a test AI suggestion
    const suggestionData = {
      story: testStory._id,
      type: 'grammar',
      content: 'This is a test AI suggestion',
      position: {
        from: 30,
        to: 40
      },
      originalText: 'Original text with error',
      suggestedText: 'Corrected text suggestion',
      explanation: 'This suggestion fixes a grammatical error',
      requestedBy: testUser._id
    };
    
    testAISuggestion = new AISuggestion(suggestionData);
    await testAISuggestion.save();
    console.log('\u2705 AI Suggestion created successfully:', testAISuggestion._id);
    
    // Read AI suggestion
    const foundSuggestion = await AISuggestion.findById(testAISuggestion._id)
      .populate('requestedBy', 'name email')
      .populate('story', 'title');
    console.log('\u2705 AI Suggestion retrieved successfully:', foundSuggestion.type);
    console.log('\u2705 User populated successfully:', foundSuggestion.requestedBy.name);
    console.log('\u2705 Story populated successfully:', foundSuggestion.story.title);
    
    // Update AI suggestion
    const updatedSuggestion = await AISuggestion.findByIdAndUpdate(
      testAISuggestion._id,
      { 
        applied: true,
        appliedBy: testUser._id,
        appliedAt: new Date()
      },
      { new: true }
    );
    console.log('\u2705 AI Suggestion updated successfully:', updatedSuggestion.applied);
    
    return true;
  } catch (error) {
    console.error('\u274c AI Suggestion model test failed:', error.message);
    return false;
  }
};

// Clean up test data
const cleanupTestData = async () => {
  console.log('\n--- Cleaning up test data ---');
  
  try {
    if (testAISuggestion) {
      await AISuggestion.findByIdAndDelete(testAISuggestion._id);
      console.log('\u2705 AI Suggestion deleted successfully');
    }
    
    if (testComment) {
      await Comment.findByIdAndDelete(testComment._id);
      console.log('\u2705 Comment deleted successfully');
    }
    
    if (testCollaborator) {
      await Collaborator.findByIdAndDelete(testCollaborator._id);
      console.log('\u2705 Collaborator deleted successfully');
    }
    
    if (testStory) {
      await Story.findByIdAndDelete(testStory._id);
      console.log('\u2705 Story deleted successfully');
    }
    
    if (testUser) {
      await User.findByIdAndDelete(testUser._id);
      console.log('\u2705 User deleted successfully');
    }
    
    return true;
  } catch (error) {
    console.error('\u274c Cleanup failed:', error.message);
    return false;
  }
};

// Run all tests
const runTests = async () => {
  console.log('=== Starting MongoDB Connection and Model Tests ===\n');
  
  try {
    // Connect to MongoDB
    await connectDB();
    
    // Run model tests
    const userTestResult = await testUserModel();
    const storyTestResult = await testStoryModel();
    const collaboratorTestResult = await testCollaboratorModel();
    const commentTestResult = await testCommentModel();
    const aiSuggestionTestResult = await testAISuggestionModel();
    
    // Clean up test data
    await cleanupTestData();
    
    // Disconnect from MongoDB
    await mongoose.disconnect();
    console.log('\n\u2705 MongoDB disconnected successfully');
    
    // Print test summary
    console.log('\n=== Test Summary ===');
    console.log(`User Model: ${userTestResult ? '\u2705 PASSED' : '\u274c FAILED'}`);
    console.log(`Story Model: ${storyTestResult ? '\u2705 PASSED' : '\u274c FAILED'}`);
    console.log(`Collaborator Model: ${collaboratorTestResult ? '\u2705 PASSED' : '\u274c FAILED'}`);
    console.log(`Comment Model: ${commentTestResult ? '\u2705 PASSED' : '\u274c FAILED'}`);
    console.log(`AI Suggestion Model: ${aiSuggestionTestResult ? '\u2705 PASSED' : '\u274c FAILED'}`);
    
    const allPassed = userTestResult && storyTestResult && collaboratorTestResult && 
                      commentTestResult && aiSuggestionTestResult;
    
    console.log(`\nOverall Test Result: ${allPassed ? '\u2705 ALL TESTS PASSED' : '\u274c SOME TESTS FAILED'}`);
    
  } catch (error) {
    console.error('\n\u274c Test execution failed:', error.message);
  }
};

// Execute tests
runTests();