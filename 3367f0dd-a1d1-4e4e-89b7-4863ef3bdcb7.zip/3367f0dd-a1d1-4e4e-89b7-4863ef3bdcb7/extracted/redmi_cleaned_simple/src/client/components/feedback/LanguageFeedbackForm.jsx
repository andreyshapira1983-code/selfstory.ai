import React, { useState, useEffect } from 'react';
import useFeedback from '../../hooks/useFeedback';
import useAI from '../../hooks/useAI';

/**
 * Component for collecting language-specific feedback from users
 */
const LanguageFeedbackForm = ({ text, language: initialLanguage, onSubmitSuccess, onCancel }) => {
  const { submitLanguageFeedback, getErrorTaxonomy, getLanguageFeedbackPrompts, loading, error } = useFeedback();
  const { detectLanguage } = useAI();
  
  const [language, setLanguage] = useState(initialLanguage || '');
  const [errorType, setErrorType] = useState('');
  const [description, setDescription] = useState('');
  const [correction, setCorrection] = useState('');
  const [context, setContext] = useState('');
  const [errorTaxonomy, setErrorTaxonomy] = useState(null);
  const [feedbackPrompts, setFeedbackPrompts] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [detectedLanguage, setDetectedLanguage] = useState('');
  
  // Detect language if not provided
  useEffect(() => {
    const detectTextLanguage = async () => {
      if (!initialLanguage && text) {
        try {
          const detected = await detectLanguage(text);
          setDetectedLanguage(detected);
          setLanguage(detected);
        } catch (error) {
          console.error('Error detecting language:', error);
        }
      }
    };
    
    detectTextLanguage();
  }, [initialLanguage, text, detectLanguage]);
  
  // Load error taxonomy
  useEffect(() => {
    const loadErrorTaxonomy = async () => {
      try {
        const taxonomy = await getErrorTaxonomy();
        setErrorTaxonomy(taxonomy);
      } catch (error) {
        console.error('Error loading error taxonomy:', error);
      }
    };
    
    loadErrorTaxonomy();
  }, [getErrorTaxonomy]);
  
  // Load language-specific feedback prompts
  useEffect(() => {
    const loadFeedbackPrompts = async () => {
      if (language) {
        try {
          const prompts = await getLanguageFeedbackPrompts(language);
          setFeedbackPrompts(prompts);
        } catch (error) {
          console.error('Error loading feedback prompts:', error);
        }
      }
    };
    
    loadFeedbackPrompts();
  }, [language, getLanguageFeedbackPrompts]);
  
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!errorType) {
      alert('Please select an error type');
      return;
    }
    
    setSubmitting(true);
    
    try {
      await submitLanguageFeedback(
        text,
        language,
        errorType,
        description,
        correction,
        context
      );
      
      setSuccess(true);
      setSubmitting(false);
      
      // Call onSubmitSuccess callback if provided
      if (onSubmitSuccess) {
        onSubmitSuccess();
      }
    } catch (error) {
      console.error('Error submitting feedback:', error);
      setSubmitting(false);
    }
  };
  
  // If feedback was successfully submitted, show success message
  if (success) {
    return (
      <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
        <strong className="font-bold">Thank you!</strong>
        <span className="block sm:inline"> Your feedback has been submitted successfully.</span>
        <button
          onClick={onCancel || (() => setSuccess(false))}
          className="mt-3 bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-4 rounded"
        >
          Close
        </button>
      </div>
    );
  }
  
  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <h2 className="text-2xl font-bold mb-6">
        {feedbackPrompts?.title || 'Submit Language Feedback'}
      </h2>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
          <strong className="font-bold">Error!</strong>
          <span className="block sm:inline"> {error}</span>
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="text">
            Text with Issue
          </label>
          <textarea
            id="text"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            rows="3"
            value={text}
            readOnly
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="language">
            Language
          </label>
          <div className="flex items-center">
            <input
              id="language"
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              type="text"
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              placeholder="Language code (e.g., en, es, zh)"
            />
            {detectedLanguage && (
              <span className="ml-2 text-sm text-gray-500">
                Detected: {detectedLanguage}
              </span>
            )}
          </div>
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="errorType">
            Error Type
          </label>
          <select
            id="errorType"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            value={errorType}
            onChange={(e) => setErrorType(e.target.value)}
            required
          >
            <option value="">Select an error type</option>
            {errorTaxonomy && Object.keys(errorTaxonomy).map((key) => (
              <option key={key} value={key}>
                {errorTaxonomy[key].name}
              </option>
            ))}
          </select>
          {errorType && errorTaxonomy && errorTaxonomy[errorType] && (
            <p className="text-sm text-gray-500 mt-1">
              {errorTaxonomy[errorType].description}
            </p>
          )}
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="correction">
            Suggested Correction
          </label>
          <textarea
            id="correction"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            rows="3"
            value={correction}
            onChange={(e) => setCorrection(e.target.value)}
            placeholder="Enter your suggested correction"
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
            Description
          </label>
          <textarea
            id="description"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            rows="3"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the issue in more detail"
          />
        </div>
        
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="context">
            Context (Optional)
          </label>
          <textarea
            id="context"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            rows="2"
            value={context}
            onChange={(e) => setContext(e.target.value)}
            placeholder="Provide any additional context"
          />
        </div>
        
        <div className="flex items-center justify-between">
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            disabled={submitting}
          >
            {submitting ? 'Submitting...' : 'Submit Feedback'}
          </button>
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
              disabled={submitting}
            >
              Cancel
            </button>
          )}
        </div>
      </form>
      
      {feedbackPrompts?.options && (
        <div className="mt-6">
          <h3 className="text-lg font-medium mb-2">Common Issues</h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <ul className="list-disc pl-5 space-y-1">
              {feedbackPrompts.options.map((option, index) => (
                <li key={index} className="text-gray-700">{option}</li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default LanguageFeedbackForm;