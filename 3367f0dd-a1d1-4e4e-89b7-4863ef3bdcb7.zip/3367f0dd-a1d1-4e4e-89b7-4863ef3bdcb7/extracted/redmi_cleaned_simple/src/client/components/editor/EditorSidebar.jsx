import React, { useState } from 'react';
import CollaboratorsList from './CollaboratorsList';

const EditorSidebar = ({ storyId }) => {
  const [activeTab, setActiveTab] = useState('collaborators');

  const tabs = [
    { id: 'collaborators', label: 'Collaborators' },
    { id: 'comments', label: 'Comments' },
    { id: 'ai-suggestions', label: 'AI Suggestions' }
  ];

  return (
    <div className="h-full flex flex-col">
      {/* Tabs */}
      <div className="flex border-b border-gray-200">
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={`flex-1 py-3 text-sm font-medium text-center ${
              activeTab === tab.id
                ? 'text-indigo-600 border-b-2 border-indigo-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-auto p-4">
        {activeTab === 'collaborators' && (
          <CollaboratorsList storyId={storyId} />
        )}

        {activeTab === 'comments' && (
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
              <div className="flex items-start mb-2">
                <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-white mr-3">
                  C
                </div>
                <div>
                  <div className="flex items-center">
                    <h4 className="font-medium">Collaborator 1</h4>
                    <span className="ml-2 text-xs text-gray-500">2 hours ago</span>
                  </div>
                  <p className="text-gray-700">This is a test comment</p>
                </div>
              </div>
              <div className="ml-11 mt-2">
                <button className="text-sm text-indigo-600 hover:text-indigo-800">Reply</button>
              </div>
            </div>

            <div className="mt-4">
              <textarea
                className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="Add a comment..."
                rows="3"
              ></textarea>
              <div className="mt-2 flex justify-end">
                <button className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors">
                  Comment
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'ai-suggestions' && (
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <div className="flex items-start">
                <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white mr-3">
                  AI
                </div>
                <div>
                  <div className="flex items-center">
                    <h4 className="font-medium">Grammar Suggestion</h4>
                    <span className="ml-2 text-xs text-gray-500">Just now</span>
                  </div>
                  <p className="text-gray-700 mb-2">This is a test suggestion</p>
                  <div className="bg-white p-2 rounded border border-gray-200 mb-2">
                    <p className="text-gray-500 text-sm line-through">Original text with error</p>
                    <p className="text-green-600 text-sm">Corrected text suggestion</p>
                  </div>
                  <p className="text-gray-600 text-sm italic">This suggestion fixes a grammatical error</p>
                </div>
              </div>
              <div className="ml-11 mt-2 flex space-x-2">
                <button className="text-sm bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700">
                  Apply
                </button>
                <button className="text-sm bg-gray-200 text-gray-700 px-3 py-1 rounded hover:bg-gray-300">
                  Dismiss
                </button>
              </div>
            </div>

            <div className="mt-4">
              <button className="w-full bg-blue-100 text-blue-700 p-3 rounded-md hover:bg-blue-200 transition-colors flex items-center justify-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                </svg>
                Generate AI Suggestions
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EditorSidebar;