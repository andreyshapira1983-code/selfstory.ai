import React, { useEffect, useContext } from 'react';
import { EditorContent } from '@tiptap/react';
import { CollaborationContext } from '../../context/CollaborationContext';
import { useCollaborativeEditor } from '../../hooks/useCollaborativeEditor';
import { useStories } from '../../hooks/useStories';

const CollaborativeEditor = ({ storyId }) => {
  const { ydoc, awareness, status: connectionStatus } = useContext(CollaborationContext);
  const { editor, status: editorStatus, error } = useCollaborativeEditor(ydoc, awareness);
  const { currentStory } = useStories();

  // Set initial content if available
  useEffect(() => {
    if (editor && currentStory && currentStory.content) {
      // Only set content if editor is empty
      if (editor.isEmpty) {
        editor.commands.setContent(currentStory.content);
      }
    }
  }, [editor, currentStory]);

  // Auto-save content periodically
  useEffect(() => {
    if (!editor || !storyId) return;

    const saveInterval = setInterval(() => {
      if (editor.isEmpty) return;
      
      const content = editor.getHTML();
      // In a real app, you would save this content to the server
      console.log('Auto-saving content:', content);
      
      // Example API call (commented out)
      // api.put(`/stories/${storyId}/content`, { content });
      
    }, 30000); // Save every 30 seconds

    return () => {
      clearInterval(saveInterval);
    };
  }, [editor, storyId]);

  // Connection status indicator
  const getStatusIndicator = () => {
    if (error) {
      return (
        <div className="flex items-center text-red-600">
          <span className="w-2 h-2 bg-red-600 rounded-full mr-2"></span>
          Error: {error}
        </div>
      );
    }

    switch (connectionStatus) {
      case 'connected':
        return (
          <div className="flex items-center text-green-600">
            <span className="w-2 h-2 bg-green-600 rounded-full mr-2"></span>
            Connected
          </div>
        );
      case 'connecting':
        return (
          <div className="flex items-center text-yellow-600">
            <span className="w-2 h-2 bg-yellow-600 rounded-full mr-2"></span>
            Connecting...
          </div>
        );
      case 'disconnected':
        return (
          <div className="flex items-center text-red-600">
            <span className="w-2 h-2 bg-red-600 rounded-full mr-2"></span>
            Disconnected
          </div>
        );
      default:
        return (
          <div className="flex items-center text-gray-600">
            <span className="w-2 h-2 bg-gray-600 rounded-full mr-2"></span>
            {connectionStatus}
          </div>
        );
    }
  };

  // Active users display
  const getActiveUsers = () => {
    if (!awareness) return null;
    
    const users = [];
    awareness.getStates().forEach((state, clientId) => {
      if (state.user) {
        users.push({
          clientId,
          ...state.user
        });
      }
    });

    if (users.length <= 1) return null;

    return (
      <div className="flex -space-x-2 overflow-hidden">
        {users.map((user, index) => (
          <div
            key={user.clientId}
            className="w-8 h-8 rounded-full flex items-center justify-center text-white border-2 border-white"
            style={{ backgroundColor: user.color || '#3B82F6' }}
            title={user.name}
          >
            {user.name ? user.name[0].toUpperCase() : 'U'}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Editor Status Bar */}
      <div className="px-4 py-2 border-b border-gray-200 flex justify-between items-center bg-gray-50 rounded-t-lg">
        {getStatusIndicator()}
        {getActiveUsers()}
      </div>

      {/* Editor Content */}
      <div className="p-4">
        {editor ? (
          <EditorContent 
            editor={editor} 
            className="prose prose-lg max-w-none min-h-[500px] focus:outline-none"
            data-testid="editor-content"
          />
        ) : (
          <div className="flex justify-center items-center h-[500px] bg-gray-50 border border-dashed border-gray-300 rounded">
            <div className="text-gray-500">Loading editor...</div>
          </div>
        )}
      </div>

      {/* Editor Footer */}
      <div className="px-4 py-2 border-t border-gray-200 flex justify-between items-center text-sm text-gray-500 bg-gray-50 rounded-b-lg">
        <div>
          {editor && !editor.isEmpty ? (
            <span>{editor.storage.characterCount.characters()} characters</span>
          ) : (
            <span>0 characters</span>
          )}
        </div>
        <div>
          {editorStatus === 'connected' ? (
            <span className="text-green-600">Changes saved automatically</span>
          ) : (
            <span className="text-yellow-600">Waiting to connect...</span>
          )}
        </div>
      </div>
    </div>
  );
};

export default CollaborativeEditor;