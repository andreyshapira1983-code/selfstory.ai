import React, { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import useFeedback from '../../hooks/useFeedback';
import AISuggestionCard from '../ai/AISuggestionCard';

/**
 * Component for displaying and processing the human validation queue
 * Only accessible to users with reviewer role
 */
const HumanValidationQueue = () => {
  const { user } = useAuth();
  const { submitValidationResult, getErrorTaxonomy, loading, error } = useFeedback();
  
  const [validations, setValidations] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [errorTaxonomy, setErrorTaxonomy] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [classification, setClassification] = useState('');
  const [submitting, setSubmitting] = useState(false);
  
  // Check if user is reviewer
  const isReviewer = user && user.roles && (user.roles.includes('reviewer') || user.roles.includes('admin'));
  
  // Load error taxonomy
  useEffect(() => {
    const loadErrorTaxonomy = async () => {
      try {
        const taxonomy = await getErrorTaxonomy();
        setErrorTaxonomy(taxonomy);
      } catch (error) {
        console.error('Error loading error taxonomy:', error);
      }
    };
    
    loadErrorTaxonomy();
  }, [getErrorTaxonomy]);
  
  // Load validation queue
  useEffect(() => {
    if (isReviewer) {
      // In a real implementation, this would fetch from an API
      // For now, we'll use mock data
      const mockValidations = [
        {
          id: 'val_1',
          correction: {
            id: 'corr_1',
            originalText: 'This is a error in the text.',
            suggestedText: 'This is an error in the text.',
            confidence: 0.92,
            errorType: 'grammar',
            explanation: 'Use "an" before words that start with a vowel sound',
            language: 'en'
          },
          priority: 'high',
          submittedAt: new Date().toISOString()
        },
        {
          id: 'val_2',
          correction: {
            id: 'corr_2',
            originalText: 'The man was very tired after the long journey.',
            suggestedText: 'The exhausted man collapsed after the long journey.',
            confidence: 0.78,
            errorType: 'style',
            explanation: 'More descriptive language creates a stronger image',
            language: 'en'
          },
          priority: 'medium',
          submittedAt: new Date().toISOString()
        },
        {
          id: 'val_3',
          correction: {
            id: 'corr_3',
            originalText: 'Paris is the capital of Italy.',
            suggestedText: 'Paris is the capital of France.',
            confidence: 0.98,
            errorType: 'factual',
            explanation: 'Paris is the capital of France, not Italy',
            language: 'en'
          },
          priority: 'high',
          submittedAt: new Date().toISOString()
        }
      ];
      
      setValidations(mockValidations);
    }
  }, [isReviewer]);
  
  // Get current validation
  const currentValidation = validations[currentIndex];
  
  // Handle approve
  const handleApprove = async () => {
    if (!currentValidation) return;
    
    setSubmitting(true);
    
    try {
      await submitValidationResult(
        currentValidation.id,
        true,
        feedback,
        classification ? { errorType: classification } : null
      );
      
      // Move to next validation
      handleNext();
    } catch (error) {
      console.error('Error approving validation:', error);
    } finally {
      setSubmitting(false);
    }
  };
  
  // Handle reject
  const handleReject = async () => {
    if (!currentValidation) return;
    
    if (!feedback) {
      alert('Please provide feedback for rejection');
      return;
    }
    
    setSubmitting(true);
    
    try {
      await submitValidationResult(
        currentValidation.id,
        false,
        feedback,
        classification ? { errorType: classification } : null
      );
      
      // Move to next validation
      handleNext();
    } catch (error) {
      console.error('Error rejecting validation:', error);
    } finally {
      setSubmitting(false);
    }
  };
  
  // Handle next
  const handleNext = () => {
    if (currentIndex < validations.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setFeedback('');
      setClassification('');
    }
  };
  
  // Handle previous
  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setFeedback('');
      setClassification('');
    }
  };
  
  // If user is not reviewer, show access denied
  if (!isReviewer) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
        <strong className="font-bold">Access Denied!</strong>
        <span className="block sm:inline"> You do not have permission to access the validation queue.</span>
      </div>
    );
  }
  
  // If loading, show loading indicator
  if (loading && validations.length === 0) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  // If error, show error message
  if (error) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
        <strong className="font-bold">Error!</strong>
        <span className="block sm:inline"> {error}</span>
      </div>
    );
  }
  
  // If no validations, show empty message
  if (!validations || validations.length === 0) {
    return (
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-2xl font-bold mb-6">Validation Queue</h2>
        <div className="text-center py-8 text-gray-500">
          No validations in queue. Great job!
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <h2 className="text-2xl font-bold mb-2">Validation Queue</h2>
      <div className="text-sm text-gray-500 mb-6">
        {currentIndex + 1} of {validations.length} validations
      </div>
      
      {/* Current Validation */}
      {currentValidation && (
        <div>
          {/* Priority Badge */}
          <div className="mb-4">
            <span className={`inline-block rounded-full px-3 py-1 text-xs font-medium ${
              currentValidation.priority === 'high' 
                ? 'bg-red-100 text-red-800' 
                : currentValidation.priority === 'medium'
                ? 'bg-yellow-100 text-yellow-800'
                : 'bg-blue-100 text-blue-800'
            }`}>
              {currentValidation.priority.charAt(0).toUpperCase() + currentValidation.priority.slice(1)} Priority
            </span>
            <span className="ml-2 text-xs text-gray-500">
              Submitted {new Date(currentValidation.submittedAt).toLocaleString()}
            </span>
          </div>
          
          {/* Suggestion Card */}
          <AISuggestionCard
            suggestion={currentValidation.correction}
            showActions={false}
            showFeedback={false}
          />
          
          {/* Validation Form */}
          <div className="mt-6 border-t pt-4">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="classification">
                Error Classification
              </label>
              <select
                id="classification"
                className="w-full px-3 py-2 text-sm text-gray-700 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={classification}
                onChange={(e) => setClassification(e.target.value)}
              >
                <option value="">Select classification (optional)</option>
                {errorTaxonomy && Object.keys(errorTaxonomy).map((key) => (
                  <option key={key} value={key}>
                    {errorTaxonomy[key].name}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="feedback">
                Feedback
              </label>
              <textarea
                id="feedback"
                className="w-full px-3 py-2 text-sm text-gray-700 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows="3"
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                placeholder="Provide feedback on this correction"
              />
            </div>
            
            <div className="flex justify-between">
              <div className="space-x-2">
                <button
                  onClick={handleApprove}
                  className="bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-4 rounded"
                  disabled={submitting}
                >
                  {submitting ? 'Submitting...' : 'Approve'}
                </button>
                <button
                  onClick={handleReject}
                  className="bg-red-500 hover:bg-red-600 text-white font-medium py-2 px-4 rounded"
                  disabled={submitting || !feedback}
                >
                  {submitting ? 'Submitting...' : 'Reject'}
                </button>
              </div>
              
              <div className="space-x-2">
                <button
                  onClick={handlePrevious}
                  className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium py-2 px-4 rounded"
                  disabled={currentIndex === 0 || submitting}
                >
                  Previous
                </button>
                <button
                  onClick={handleNext}
                  className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium py-2 px-4 rounded"
                  disabled={currentIndex === validations.length - 1 || submitting}
                >
                  Skip
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HumanValidationQueue;