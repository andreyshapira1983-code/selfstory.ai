import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';

const Header = () => {
  const { currentUser, isAuthenticated, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="bg-indigo-600 text-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="text-2xl font-bold flex items-center">
            <svg 
              className="w-8 h-8 mr-2" 
              fill="currentColor" 
              viewBox="0 0 20 20" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M9 4.804A7.968 7.968 0 005.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 015.5 14c1.669 0 3.218.51 4.5 1.385A7.962 7.962 0 0114.5 14c1.255 0 2.443.29 3.5.804v-10A7.968 7.968 0 0014.5 4c-1.255 0-2.443.29-3.5.804V12a1 1 0 11-2 0V4.804z"></path>
            </svg>
            Story AI
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6" data-testid="desktop-nav">
            <Link to="/" className="hover:text-indigo-200 transition-colors">Home</Link>
            {isAuthenticated ? (
              <>
                <Link to="/dashboard" className="hover:text-indigo-200 transition-colors">Dashboard</Link>
                <Link to="/stories" className="hover:text-indigo-200 transition-colors">My Stories</Link>
                
                {/* User Menu */}
                <div className="relative group">
                  <button className="flex items-center hover:text-indigo-200 transition-colors">
                    <span className="w-8 h-8 rounded-full bg-indigo-800 flex items-center justify-center mr-2" style={{ backgroundColor: currentUser?.profileColor || '#4F46E5' }}>
                      {currentUser?.name?.charAt(0).toUpperCase()}
                    </span>
                    <span>{currentUser?.name}</span>
                    <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                    </svg>
                  </button>
                  
                  {/* Dropdown Menu */}
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
                    <Link to="/profile" className="block px-4 py-2 text-gray-800 hover:bg-indigo-100">Profile</Link>
                    <Link to="/settings" className="block px-4 py-2 text-gray-800 hover:bg-indigo-100">Settings</Link>
                    <button 
                      onClick={handleLogout}
                      className="block w-full text-left px-4 py-2 text-gray-800 hover:bg-indigo-100"
                    >
                      Logout
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <>
                <Link to="/login" className="hover:text-indigo-200 transition-colors">Login</Link>
                <Link to="/register" className="bg-white text-indigo-600 px-4 py-2 rounded-md hover:bg-indigo-100 transition-colors">
                  Sign Up
                </Link>
              </>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-white focus:outline-none"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="mobile-menu-button"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              {mobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 space-y-3">
            <Link to="/" className="block hover:text-indigo-200 transition-colors">Home</Link>
            {isAuthenticated ? (
              <>
                <Link to="/dashboard" className="block hover:text-indigo-200 transition-colors">Dashboard</Link>
                <Link to="/stories" className="block hover:text-indigo-200 transition-colors">My Stories</Link>
                <Link to="/profile" className="block hover:text-indigo-200 transition-colors">Profile</Link>
                <Link to="/settings" className="block hover:text-indigo-200 transition-colors">Settings</Link>
                <button 
                  onClick={handleLogout}
                  className="block w-full text-left hover:text-indigo-200 transition-colors"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="block hover:text-indigo-200 transition-colors">Login</Link>
                <Link to="/register" className="block bg-white text-indigo-600 px-4 py-2 rounded-md hover:bg-indigo-100 transition-colors">
                  Sign Up
                </Link>
              </>
            )}
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;