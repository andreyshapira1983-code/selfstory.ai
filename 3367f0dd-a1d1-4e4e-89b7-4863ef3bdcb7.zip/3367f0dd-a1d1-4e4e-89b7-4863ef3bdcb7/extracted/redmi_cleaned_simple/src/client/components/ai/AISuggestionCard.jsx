import React, { useState } from 'react';
import useFeedback from '../../hooks/useFeedback';
import LanguageFeedbackForm from '../feedback/LanguageFeedbackForm';

/**
 * Component for displaying an AI suggestion with feedback options
 */
const AISuggestionCard = ({ 
  suggestion, 
  onApply, 
  onDismiss, 
  onFeedbackSubmitted,
  showActions = true,
  showFeedback = true,
  compact = false
}) => {
  const { submitSuggestionFeedback, loading } = useFeedback();
  
  const [rating, setRating] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [showLanguageFeedback, setShowLanguageFeedback] = useState(false);
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);
  
  // Handle applying suggestion
  const handleApply = async () => {
    if (onApply) {
      await onApply(suggestion);
      
      // Submit feedback automatically when applying
      try {
        await submitSuggestionFeedback(
          suggestion.id,
          'helpful',
          '',
          true
        );
      } catch (error) {
        console.error('Error submitting feedback:', error);
      }
    }
  };
  
  // Handle dismissing suggestion
  const handleDismiss = async () => {
    if (onDismiss) {
      await onDismiss(suggestion);
    }
  };
  
  // Handle submitting feedback
  const handleSubmitFeedback = async () => {
    if (!rating) {
      alert('Please select a rating');
      return;
    }
    
    try {
      await submitSuggestionFeedback(
        suggestion.id,
        rating,
        feedback,
        false
      );
      
      setFeedbackSubmitted(true);
      
      if (onFeedbackSubmitted) {
        onFeedbackSubmitted(suggestion.id, rating, feedback);
      }
    } catch (error) {
      console.error('Error submitting feedback:', error);
    }
  };
  
  // Handle language feedback submission
  const handleLanguageFeedbackSubmitted = () => {
    setShowLanguageFeedback(false);
    setFeedbackSubmitted(true);
    
    if (onFeedbackSubmitted) {
      onFeedbackSubmitted(suggestion.id, 'language_feedback', '');
    }
  };
  
  // Calculate confidence class based on confidence level
  const getConfidenceClass = () => {
    if (suggestion.confidence >= 0.9) return 'bg-green-100 text-green-800';
    if (suggestion.confidence >= 0.7) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };
  
  // If compact mode, show simplified version
  if (compact) {
    return (
      <div className="border rounded-lg p-3 mb-3 bg-white shadow-sm hover:shadow-md transition-shadow">
        <div className="flex justify-between items-start">
          <div>
            <div className="text-sm font-medium text-gray-900 mb-1">
              {suggestion.errorType && (
                <span className="inline-block bg-gray-100 rounded-full px-2 py-0.5 text-xs font-medium text-gray-800 mr-2">
                  {suggestion.errorType}
                </span>
              )}
              {suggestion.suggestedText}
            </div>
            {suggestion.explanation && (
              <p className="text-xs text-gray-500">{suggestion.explanation}</p>
            )}
          </div>
          
          {showActions && (
            <div className="flex space-x-1">
              <button
                onClick={handleApply}
                className="text-xs bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded"
              >
                Apply
              </button>
              <button
                onClick={handleDismiss}
                className="text-xs bg-gray-200 hover:bg-gray-300 text-gray-700 px-2 py-1 rounded"
              >
                Dismiss
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }
  
  return (
    <div className="border rounded-lg p-4 mb-4 bg-white shadow-sm hover:shadow-md transition-shadow">
      {/* Header */}
      <div className="flex justify-between items-center mb-3">
        <div className="flex items-center">
          <span className="text-lg font-medium text-gray-900 mr-2">AI Suggestion</span>
          {suggestion.errorType && (
            <span className="inline-block bg-gray-100 rounded-full px-3 py-1 text-xs font-medium text-gray-800">
              {suggestion.errorType}
            </span>
          )}
        </div>
        <div className={`px-2 py-1 rounded-full text-xs font-medium ${getConfidenceClass()}`}>
          {Math.round(suggestion.confidence * 100)}% confidence
        </div>
      </div>
      
      {/* Content */}
      <div className="mb-4">
        <div className="mb-2">
          <div className="text-sm text-gray-500 mb-1">Original Text:</div>
          <div className="p-2 bg-gray-50 rounded border border-gray-200">
            {suggestion.originalText}
          </div>
        </div>
        
        <div className="mb-2">
          <div className="text-sm text-gray-500 mb-1">Suggested Text:</div>
          <div className="p-2 bg-blue-50 rounded border border-blue-200">
            {suggestion.suggestedText}
          </div>
        </div>
        
        {suggestion.explanation && (
          <div>
            <div className="text-sm text-gray-500 mb-1">Explanation:</div>
            <div className="text-sm text-gray-700">{suggestion.explanation}</div>
          </div>
        )}
      </div>
      
      {/* Actions */}
      {showActions && (
        <div className="flex space-x-2 mb-4">
          <button
            onClick={handleApply}
            className="bg-blue-500 hover:bg-blue-600 text-white font-medium py-1.5 px-3 rounded"
          >
            Apply Suggestion
          </button>
          <button
            onClick={handleDismiss}
            className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium py-1.5 px-3 rounded"
          >
            Dismiss
          </button>
        </div>
      )}
      
      {/* Feedback */}
      {showFeedback && !feedbackSubmitted && !showLanguageFeedback && (
        <div>
          <button
            onClick={() => setShowFeedbackForm(!showFeedbackForm)}
            className="text-blue-500 hover:text-blue-700 text-sm font-medium"
          >
            {showFeedbackForm ? 'Hide Feedback Form' : 'Provide Feedback'}
          </button>
          
          {showFeedbackForm && (
            <div className="mt-3 p-3 bg-gray-50 rounded-lg">
              <div className="mb-3">
                <div className="text-sm font-medium text-gray-700 mb-2">How helpful was this suggestion?</div>
                <div className="flex space-x-4">
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      className="form-radio"
                      name="rating"
                      value="helpful"
                      checked={rating === 'helpful'}
                      onChange={() => setRating('helpful')}
                    />
                    <span className="ml-2 text-sm text-gray-700">Helpful</span>
                  </label>
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      className="form-radio"
                      name="rating"
                      value="unhelpful"
                      checked={rating === 'unhelpful'}
                      onChange={() => setRating('unhelpful')}
                    />
                    <span className="ml-2 text-sm text-gray-700">Not Helpful</span>
                  </label>
                </div>
              </div>
              
              <div className="mb-3">
                <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="feedback">
                  Additional Comments (Optional)
                </label>
                <textarea
                  id="feedback"
                  className="w-full px-3 py-2 text-sm text-gray-700 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows="2"
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  placeholder="Tell us more about your experience with this suggestion"
                />
              </div>
              
              <div className="flex justify-between">
                <button
                  onClick={handleSubmitFeedback}
                  className="bg-blue-500 hover:bg-blue-600 text-white text-sm font-medium py-1.5 px-3 rounded"
                  disabled={loading || !rating}
                >
                  {loading ? 'Submitting...' : 'Submit Feedback'}
                </button>
                
                <button
                  onClick={() => setShowLanguageFeedback(true)}
                  className="text-blue-500 hover:text-blue-700 text-sm font-medium"
                >
                  Report Language Issue
                </button>
              </div>
            </div>
          )}
        </div>
      )}
      
      {/* Language Feedback Form */}
      {showLanguageFeedback && (
        <div className="mt-4">
          <LanguageFeedbackForm
            text={suggestion.originalText}
            language={suggestion.language}
            onSubmitSuccess={handleLanguageFeedbackSubmitted}
            onCancel={() => setShowLanguageFeedback(false)}
          />
        </div>
      )}
      
      {/* Feedback Submitted */}
      {feedbackSubmitted && (
        <div className="mt-2 text-sm text-green-600 font-medium">
          Thank you for your feedback!
        </div>
      )}
    </div>
  );
};

export default AISuggestionCard;