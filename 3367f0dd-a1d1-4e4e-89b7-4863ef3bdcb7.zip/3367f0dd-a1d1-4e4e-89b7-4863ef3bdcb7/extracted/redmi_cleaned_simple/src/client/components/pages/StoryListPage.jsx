import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useStories } from '../../hooks/useStories';
import { useAuth } from '../../hooks/useAuth';

const StoryListPage = () => {
  const { stories, loading, error, fetchStories, createStory, deleteStory } = useStories();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newStory, setNewStory] = useState({
    title: '',
    description: '',
    tags: ''
  });
  const [deleteConfirmation, setDeleteConfirmation] = useState(null);

  useEffect(() => {
    fetchStories();
  }, [fetchStories]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewStory(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleCreateStory = async (e) => {
    e.preventDefault();
    
    try {
      // Format tags as array
      const formattedTags = newStory.tags
        .split(',')
        .map(tag => tag.trim())
        .filter(tag => tag);
      
      const storyData = {
        ...newStory,
        tags: formattedTags
      };
      
      const createdStory = await createStory(storyData);
      setShowCreateModal(false);
      setNewStory({ title: '', description: '', tags: '' });
      
      // Navigate to the editor for the new story
      navigate(`/editor/${createdStory._id}`);
    } catch (err) {
      console.error('Failed to create story:', err);
    }
  };

  const handleDeleteClick = (storyId) => {
    setDeleteConfirmation(storyId);
  };

  const confirmDelete = async () => {
    if (deleteConfirmation) {
      try {
        await deleteStory(deleteConfirmation);
        setDeleteConfirmation(null);
      } catch (err) {
        console.error('Failed to delete story:', err);
      }
    }
  };

  const cancelDelete = () => {
    setDeleteConfirmation(null);
  };

  // Format date for display
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">My Stories</h1>
        <button
          onClick={() => setShowCreateModal(true)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors flex items-center"
        >
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
          </svg>
          Create New Story
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-600"></div>
        </div>
      ) : error ? (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      ) : stories.length === 0 ? (
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-8 text-center">
          <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
          </svg>
          <h2 className="text-xl font-semibold mb-2">No Stories Yet</h2>
          <p className="text-gray-600 mb-4">
            You haven't created any stories yet. Click the "Create New Story" button to get started.
          </p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors"
          >
            Create Your First Story
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {stories.map(story => (
            <div key={story._id} className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 flex flex-col">
              {/* Story Cover Image */}
              <div className="h-48 overflow-hidden">
                <img
                  src={story.coverImage || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80'}
                  alt={story.title}
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Story Content */}
              <div className="p-5 flex-grow">
                <h2 className="text-xl font-semibold mb-2">{story.title}</h2>
                <p className="text-gray-600 mb-4 line-clamp-2">{story.description || 'No description provided.'}</p>
                
                {/* Tags */}
                {story.tags && story.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-4">
                    {story.tags.map((tag, index) => (
                      <span key={index} className="bg-indigo-100 text-indigo-800 text-xs px-2 py-1 rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
                
                {/* Collaborators */}
                <div className="flex items-center mb-4">
                  <span className="text-sm text-gray-500 mr-2">Collaborators:</span>
                  <div className="flex -space-x-2">
                    {story.collaborators && story.collaborators.length > 0 ? (
                      story.collaborators.slice(0, 3).map((collaborator, index) => (
                        <div
                          key={index}
                          className="w-6 h-6 rounded-full bg-indigo-500 flex items-center justify-center text-white text-xs border-2 border-white"
                          title={collaborator.name || `Collaborator ${index + 1}`}
                        >
                          {(collaborator.name || 'C')[0].toUpperCase()}
                        </div>
                      ))
                    ) : (
                      <span className="text-sm text-gray-400">None</span>
                    )}
                    {story.collaborators && story.collaborators.length > 3 && (
                      <div className="w-6 h-6 rounded-full bg-gray-300 flex items-center justify-center text-xs border-2 border-white">
                        +{story.collaborators.length - 3}
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Last Edited */}
                <div className="text-sm text-gray-500">
                  Last edited: {formatDate(story.updatedAt || story.createdAt)}
                </div>
              </div>
              
              {/* Actions */}
              <div className="border-t border-gray-200 p-4 bg-gray-50 flex justify-between">
                <Link
                  to={`/editor/${story._id}`}
                  className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 transition-colors"
                >
                  Open
                </Link>
                <button
                  onClick={() => handleDeleteClick(story._id)}
                  className="text-red-600 hover:text-red-800 transition-colors"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Story Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Create New Story</h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
              </button>
            </div>
            
            <form onSubmit={handleCreateStory}>
              <div className="mb-4">
                <label htmlFor="title" className="block text-gray-700 font-medium mb-2">
                  Title *
                </label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={newStory.title}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="description" className="block text-gray-700 font-medium mb-2">
                  Description
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={newStory.description}
                  onChange={handleInputChange}
                  rows="3"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                ></textarea>
              </div>
              
              <div className="mb-6">
                <label htmlFor="tags" className="block text-gray-700 font-medium mb-2">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  id="tags"
                  name="tags"
                  value={newStory.tags}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="fantasy, adventure, sci-fi"
                />
              </div>
              
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-100 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
                >
                  Create Story
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold mb-4">Confirm Deletion</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this story? This action cannot be undone.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={cancelDelete}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-100 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StoryListPage;