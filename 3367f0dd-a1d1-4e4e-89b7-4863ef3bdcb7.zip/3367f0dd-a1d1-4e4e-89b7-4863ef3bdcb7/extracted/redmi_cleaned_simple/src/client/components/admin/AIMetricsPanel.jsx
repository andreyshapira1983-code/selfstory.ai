import React, { useState, useEffect } from 'react';
import useAI from '../../hooks/useAI';
import useFeedback from '../../hooks/useFeedback';
import { useAuth } from '../../hooks/useAuth';

/**
 * Component for displaying AI metrics and drift monitoring information
 * Only accessible to administrators
 */
const AIMetricsPanel = () => {
  const { user } = useAuth();
  const { getMetrics, checkDrift, getDriftHistory, rollbackModel, loading: aiLoading, error: aiError, metrics, driftHistory } = useAI();
  const { getFeedbackMetrics, loading: feedbackLoading, error: feedbackError, feedbackMetrics } = useFeedback();
  
  const [activeTab, setActiveTab] = useState('overview');
  const [rollbackVersion, setRollbackVersion] = useState('');
  const [rollbackStatus, setRollbackStatus] = useState(null);
  
  // Check if user is admin
  const isAdmin = user && user.roles && user.roles.includes('admin');
  
  useEffect(() => {
    if (isAdmin) {
      // Load metrics on component mount
      getMetrics();
      getFeedbackMetrics();
      getDriftHistory();
    }
  }, [isAdmin, getMetrics, getFeedbackMetrics, getDriftHistory]);
  
  // Handle manual drift check
  const handleCheckDrift = async () => {
    try {
      const result = await checkDrift();
      alert(`Drift check completed. ${result.results ? 'Drift detected: ' + (result.results.driftDetected ? 'Yes' : 'No') : ''}`);
    } catch (error) {
      console.error('Error checking drift:', error);
    }
  };
  
  // Handle model rollback
  const handleRollback = async () => {
    if (!rollbackVersion) {
      setRollbackStatus({ success: false, message: 'Please enter a version ID' });
      return;
    }
    
    try {
      const result = await rollbackModel(rollbackVersion);
      setRollbackStatus({ success: true, message: `Successfully rolled back to version ${result.versionId}` });
    } catch (error) {
      setRollbackStatus({ success: false, message: error.message || 'Failed to rollback model' });
    }
  };
  
  // If user is not admin, show access denied
  if (!isAdmin) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
        <strong className="font-bold">Access Denied!</strong>
        <span className="block sm:inline"> You do not have permission to view this page.</span>
      </div>
    );
  }
  
  // If loading, show loading indicator
  if ((aiLoading || feedbackLoading) && !metrics && !feedbackMetrics) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  // If error, show error message
  if (aiError || feedbackError) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
        <strong className="font-bold">Error!</strong>
        <span className="block sm:inline"> {aiError || feedbackError}</span>
      </div>
    );
  }
  
  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <h2 className="text-2xl font-bold mb-6">AI System Metrics</h2>
      
      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="flex -mb-px">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-2 px-4 text-center border-b-2 font-medium text-sm ${
              activeTab === 'overview'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('drift')}
            className={`py-2 px-4 text-center border-b-2 font-medium text-sm ${
              activeTab === 'drift'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Drift Monitoring
          </button>
          <button
            onClick={() => setActiveTab('feedback')}
            className={`py-2 px-4 text-center border-b-2 font-medium text-sm ${
              activeTab === 'feedback'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Feedback
          </button>
          <button
            onClick={() => setActiveTab('language')}
            className={`py-2 px-4 text-center border-b-2 font-medium text-sm ${
              activeTab === 'language'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Languages
          </button>
          <button
            onClick={() => setActiveTab('controls')}
            className={`py-2 px-4 text-center border-b-2 font-medium text-sm ${
              activeTab === 'controls'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Controls
          </button>
        </nav>
      </div>
      
      {/* Tab Content */}
      <div className="mt-6">
        {/* Overview Tab */}
        {activeTab === 'overview' && metrics && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-blue-800">Suggestions</h3>
                <p className="text-3xl font-bold">{metrics.suggestions?.totalCount || 0}</p>
                <p className="text-sm text-blue-600">Total AI suggestions</p>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-green-800">Applied Rate</h3>
                <p className="text-3xl font-bold">{Math.round((metrics.suggestions?.applicationRate || 0) * 100)}%</p>
                <p className="text-sm text-green-600">Suggestions applied</p>
              </div>
              
              <div className="bg-yellow-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-yellow-800">Helpful Rate</h3>
                <p className="text-3xl font-bold">{Math.round((metrics.suggestions?.helpfulRate || 0) * 100)}%</p>
                <p className="text-sm text-yellow-600">Rated as helpful</p>
              </div>
              
              <div className="bg-purple-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-purple-800">Languages</h3>
                <p className="text-3xl font-bold">{metrics.languages?.languageDistribution?.length || 0}</p>
                <p className="text-sm text-purple-600">Supported languages</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-4">Error Type Distribution</h3>
                {metrics.suggestions?.errorTypeDistribution?.length > 0 ? (
                  <div className="space-y-2">
                    {metrics.suggestions.errorTypeDistribution.map((item, index) => (
                      <div key={index} className="flex justify-between items-center">
                        <span className="text-gray-700">{item.errorType || 'Unknown'}</span>
                        <span className="text-gray-900 font-medium">{item.count}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No error type data available</p>
                )}
              </div>
              
              <div className="border rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-4">Drift Status</h3>
                {metrics.drift ? (
                  <div>
                    <div className="flex justify-between mb-2">
                      <span>Last Check:</span>
                      <span>{new Date(metrics.drift.lastCheckTime).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span>Drift Detected:</span>
                      <span className={metrics.drift.driftDetected ? 'text-red-600 font-bold' : 'text-green-600'}>
                        {metrics.drift.driftDetected ? 'Yes' : 'No'}
                      </span>
                    </div>
                    <div className="mt-4">
                      <h4 className="font-medium mb-2">Metrics:</h4>
                      <div className="space-y-1">
                        <div className="flex justify-between">
                          <span>Accuracy:</span>
                          <span className={metrics.drift.metrics.accuracy.drift < 0 ? 'text-red-600' : 'text-green-600'}>
                            {(metrics.drift.metrics.accuracy.drift * 100).toFixed(2)}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Satisfaction:</span>
                          <span className={metrics.drift.metrics.satisfaction.drift < 0 ? 'text-red-600' : 'text-green-600'}>
                            {(metrics.drift.metrics.satisfaction.drift * 100).toFixed(2)}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Error Rate:</span>
                          <span className={metrics.drift.metrics.errorRate.drift > 0 ? 'text-red-600' : 'text-green-600'}>
                            {(metrics.drift.metrics.errorRate.drift * 100).toFixed(2)}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Latency:</span>
                          <span className={metrics.drift.metrics.latency.drift > 0 ? 'text-red-600' : 'text-green-600'}>
                            {metrics.drift.metrics.latency.drift.toFixed(0)} ms
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="text-gray-500">No drift data available</p>
                )}
              </div>
            </div>
          </div>
        )}
        
        {/* Drift Monitoring Tab */}
        {activeTab === 'drift' && metrics && (
          <div>
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-4">Current Drift Status</h3>
              {metrics.drift ? (
                <div className="border rounded-lg p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium mb-2">Status:</h4>
                      <div className={`text-lg font-bold ${metrics.drift.driftDetected ? 'text-red-600' : 'text-green-600'}`}>
                        {metrics.drift.driftDetected ? 'Drift Detected' : 'No Drift Detected'}
                      </div>
                      <div className="text-sm text-gray-500">
                        Last checked: {new Date(metrics.drift.lastCheckTime).toLocaleString()}
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-medium mb-2">Thresholds:</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>Accuracy Drift:</span>
                          <span>{(metrics.drift.thresholds.accuracyDrift * 100).toFixed(2)}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Satisfaction Drift:</span>
                          <span>{(metrics.drift.thresholds.userSatisfactionDrift * 100).toFixed(2)}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Error Rate Increase:</span>
                          <span>{(metrics.drift.thresholds.errorRateIncrease * 100).toFixed(2)}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Latency Increase:</span>
                          <span>{(metrics.drift.thresholds.latencyIncrease * 100).toFixed(2)}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <h4 className="font-medium mb-2">Current Metrics:</h4>
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Metric</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Baseline</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Current</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Drift</th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Accuracy</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {(metrics.drift.metrics.accuracy.baseline * 100).toFixed(2)}%
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {(metrics.drift.metrics.accuracy.current * 100).toFixed(2)}%
                            </td>
                            <td className={`px-6 py-4 whitespace-nowrap text-sm ${
                              metrics.drift.metrics.accuracy.drift < 0 ? 'text-red-600' : 'text-green-600'
                            }`}>
                              {(metrics.drift.metrics.accuracy.drift * 100).toFixed(2)}%
                            </td>
                          </tr>
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Satisfaction</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {(metrics.drift.metrics.satisfaction.baseline * 100).toFixed(2)}%
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {(metrics.drift.metrics.satisfaction.current * 100).toFixed(2)}%
                            </td>
                            <td className={`px-6 py-4 whitespace-nowrap text-sm ${
                              metrics.drift.metrics.satisfaction.drift < 0 ? 'text-red-600' : 'text-green-600'
                            }`}>
                              {(metrics.drift.metrics.satisfaction.drift * 100).toFixed(2)}%
                            </td>
                          </tr>
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Error Rate</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {(metrics.drift.metrics.errorRate.baseline * 100).toFixed(2)}%
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {(metrics.drift.metrics.errorRate.current * 100).toFixed(2)}%
                            </td>
                            <td className={`px-6 py-4 whitespace-nowrap text-sm ${
                              metrics.drift.metrics.errorRate.drift > 0 ? 'text-red-600' : 'text-green-600'
                            }`}>
                              {(metrics.drift.metrics.errorRate.drift * 100).toFixed(2)}%
                            </td>
                          </tr>
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Latency</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {metrics.drift.metrics.latency.baseline} ms
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {metrics.drift.metrics.latency.current} ms
                            </td>
                            <td className={`px-6 py-4 whitespace-nowrap text-sm ${
                              metrics.drift.metrics.latency.drift > 0 ? 'text-red-600' : 'text-green-600'
                            }`}>
                              {metrics.drift.metrics.latency.drift.toFixed(0)} ms
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-gray-500">No drift data available</p>
              )}
            </div>
            
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-4">Drift History</h3>
              {driftHistory && driftHistory.length > 0 ? (
                <div className="border rounded-lg overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Timestamp</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Accuracy</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Satisfaction</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Error Rate</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Latency</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {driftHistory.map((item, index) => (
                        <tr key={index}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {new Date(item.timestamp).toLocaleString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {item.metrics?.accuracy || 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {item.metrics?.satisfaction || 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {item.metrics?.errorRate || 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {item.metrics?.latency || 'N/A'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-gray-500">No drift history available</p>
              )}
            </div>
          </div>
        )}
        
        {/* Feedback Tab */}
        {activeTab === 'feedback' && feedbackMetrics && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-blue-800">Total Feedback</h3>
                <p className="text-3xl font-bold">{feedbackMetrics.totalFeedbackCount || 0}</p>
                <p className="text-sm text-blue-600">Feedback submissions</p>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-green-800">Positive Rating</h3>
                <p className="text-3xl font-bold">{Math.round((feedbackMetrics.positiveRatio || 0) * 100)}%</p>
                <p className="text-sm text-green-600">Rated as helpful</p>
              </div>
              
              <div className="bg-yellow-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-yellow-800">Application Rate</h3>
                <p className="text-3xl font-bold">{Math.round((feedbackMetrics.applicationRate || 0) * 100)}%</p>
                <p className="text-sm text-yellow-600">Suggestions applied</p>
              </div>
              
              <div className="bg-purple-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-purple-800">Pipeline Status</h3>
                <p className="text-3xl font-bold">{feedbackMetrics.pipelineMetrics?.isProcessing ? 'Active' : 'Inactive'}</p>
                <p className="text-sm text-purple-600">Feedback processing</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-4">Error Type Distribution</h3>
                {feedbackMetrics.errorTypeDistribution?.length > 0 ? (
                  <div className="space-y-2">
                    {feedbackMetrics.errorTypeDistribution.map((item, index) => (
                      <div key={index} className="flex justify-between items-center">
                        <span className="text-gray-700">{item.errorType || 'Unknown'}</span>
                        <span className="text-gray-900 font-medium">{item.count}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No error type data available</p>
                )}
              </div>
              
              <div className="border rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-4">Pipeline Metrics</h3>
                {feedbackMetrics.pipelineMetrics ? (
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">Pending Feedback</span>
                      <span className="text-gray-900 font-medium">{feedbackMetrics.pipelineMetrics.pendingFeedbackCount}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">Processed Feedback</span>
                      <span className="text-gray-900 font-medium">{feedbackMetrics.pipelineMetrics.processedFeedbackCount}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">Processing Status</span>
                      <span className={`font-medium ${feedbackMetrics.pipelineMetrics.isProcessing ? 'text-green-600' : 'text-red-600'}`}>
                        {feedbackMetrics.pipelineMetrics.isProcessing ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    {feedbackMetrics.pipelineMetrics.lastProcessedAt && (
                      <div className="flex justify-between items-center">
                        <span className="text-gray-700">Last Processed</span>
                        <span className="text-gray-900 font-medium">
                          {new Date(feedbackMetrics.pipelineMetrics.lastProcessedAt).toLocaleString()}
                        </span>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-gray-500">No pipeline metrics available</p>
                )}
              </div>
            </div>
          </div>
        )}
        
        {/* Languages Tab */}
        {activeTab === 'language' && metrics && (
          <div>
            <h3 className="text-lg font-semibold mb-4">Language Distribution</h3>
            {metrics.languages?.languageDistribution?.length > 0 ? (
              <div className="border rounded-lg overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Language</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Count</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Applied Rate</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Helpful Rate</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {metrics.languages.languageDistribution.map((item, index) => {
                      const langMetrics = metrics.languages.languageMetrics?.[item.language] || {};
                      return (
                        <tr key={index}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {item.language || 'Unknown'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {item.count}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {langMetrics.applicationRate ? `${Math.round(langMetrics.applicationRate * 100)}%` : 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {langMetrics.helpfulRate ? `${Math.round(langMetrics.helpfulRate * 100)}%` : 'N/A'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500">No language distribution data available</p>
            )}
          </div>
        )}
        
        {/* Controls Tab */}
        {activeTab === 'controls' && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-4">Drift Monitoring</h3>
                <div className="space-y-4">
                  <div>
                    <button
                      onClick={handleCheckDrift}
                      className="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded"
                      disabled={aiLoading}
                    >
                      {aiLoading ? 'Checking...' : 'Check Drift Now'}
                    </button>
                    <p className="text-sm text-gray-500 mt-2">
                      Manually trigger a drift check to evaluate current model performance.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-4">Model Management</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Rollback to Version
                    </label>
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        value={rollbackVersion}
                        onChange={(e) => setRollbackVersion(e.target.value)}
                        placeholder="Version ID (e.g., v1.0.0)"
                        className="flex-1 border rounded-md px-3 py-2 text-sm"
                      />
                      <button
                        onClick={handleRollback}
                        className="bg-red-500 hover:bg-red-600 text-white font-medium py-2 px-4 rounded"
                        disabled={aiLoading || !rollbackVersion}
                      >
                        {aiLoading ? 'Rolling Back...' : 'Rollback'}
                      </button>
                    </div>
                    {rollbackStatus && (
                      <div className={`mt-2 text-sm ${rollbackStatus.success ? 'text-green-600' : 'text-red-600'}`}>
                        {rollbackStatus.message}
                      </div>
                    )}
                    <p className="text-sm text-gray-500 mt-2">
                      Warning: Rolling back to a previous version will affect all users immediately.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6 border rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-4">Refresh Data</h3>
              <div className="flex space-x-4">
                <button
                  onClick={getMetrics}
                  className="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded"
                  disabled={aiLoading}
                >
                  {aiLoading ? 'Refreshing...' : 'Refresh Metrics'}
                </button>
                <button
                  onClick={getFeedbackMetrics}
                  className="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded"
                  disabled={feedbackLoading}
                >
                  {feedbackLoading ? 'Refreshing...' : 'Refresh Feedback'}
                </button>
                <button
                  onClick={getDriftHistory}
                  className="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded"
                  disabled={aiLoading}
                >
                  {aiLoading ? 'Refreshing...' : 'Refresh History'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIMetricsPanel;