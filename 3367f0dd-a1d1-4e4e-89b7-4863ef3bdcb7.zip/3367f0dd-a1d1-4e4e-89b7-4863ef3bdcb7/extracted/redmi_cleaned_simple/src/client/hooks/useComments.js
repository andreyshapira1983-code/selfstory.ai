/**
 * Custom hook for managing story comments
 * Provides functions for creating, fetching, and managing comments on stories
 */

import { useState, useEffect, useCallback } from 'react';
import { useAuth } from './useAuth';
import * as api from '../utils/api';

/**
 * Hook for managing story comments
 * @param {string} storyId - ID of the story to manage comments for
 * @returns {object} - Comment management functions and state
 */
export const useComments = (storyId) => {
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { user } = useAuth();
  
  /**
   * Fetch all comments for a story
   */
  const fetchComments = useCallback(async () => {
    if (!storyId) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.get(`/stories/${storyId}/comments`);
      setComments(response.data);
    } catch (err) {
      setError(err.message || 'Failed to fetch comments');
      console.error('Error fetching comments:', err);
    } finally {
      setLoading(false);
    }
  }, [storyId]);
  
  /**
   * Add a new comment to the story
   * @param {string} content - Comment content
   * @param {string} [parentId] - Parent comment ID for replies
   * @param {string} [selectionId] - ID of text selection the comment refers to
   * @returns {Promise<object>} - New comment data
   */
  const addComment = async (content, parentId = null, selectionId = null) => {
    if (!storyId || !content) {
      throw new Error('Story ID and comment content are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const payload = {
        content,
        parentId,
        selectionId
      };
      
      const response = await api.post(`/stories/${storyId}/comments`, payload);
      
      // Update comments list
      if (parentId) {
        // If it's a reply, update the parent comment's replies
        setComments(prev => prev.map(comment => {
          if (comment.id === parentId) {
            return {
              ...comment,
              replies: [...(comment.replies || []), response.data]
            };
          }
          return comment;
        }));
      } else {
        // If it's a top-level comment, add it to the list
        setComments(prev => [...prev, response.data]);
      }
      
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to add comment');
      console.error('Error adding comment:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Update an existing comment
   * @param {string} commentId - ID of the comment to update
   * @param {string} content - New comment content
   * @returns {Promise<object>} - Updated comment data
   */
  const updateComment = async (commentId, content) => {
    if (!storyId || !commentId || !content) {
      throw new Error('Story ID, comment ID, and content are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.patch(`/stories/${storyId}/comments/${commentId}`, {
        content
      });
      
      // Update comments list
      setComments(prev => {
        // Check if it's a top-level comment
        const commentIndex = prev.findIndex(c => c.id === commentId);
        
        if (commentIndex !== -1) {
          // Update top-level comment
          const updatedComments = [...prev];
          updatedComments[commentIndex] = response.data;
          return updatedComments;
        } else {
          // Check if it's a reply
          return prev.map(comment => {
            if (comment.replies && comment.replies.some(reply => reply.id === commentId)) {
              return {
                ...comment,
                replies: comment.replies.map(reply => 
                  reply.id === commentId ? response.data : reply
                )
              };
            }
            return comment;
          });
        }
      });
      
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to update comment');
      console.error('Error updating comment:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Delete a comment
   * @param {string} commentId - ID of the comment to delete
   * @returns {Promise<boolean>} - Success status
   */
  const deleteComment = async (commentId) => {
    if (!storyId || !commentId) {
      throw new Error('Story ID and comment ID are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      await api.delete(`/stories/${storyId}/comments/${commentId}`);
      
      // Update comments list
      setComments(prev => {
        // Check if it's a top-level comment
        const filteredComments = prev.filter(c => c.id !== commentId);
        
        if (filteredComments.length !== prev.length) {
          // It was a top-level comment
          return filteredComments;
        } else {
          // Check if it's a reply
          return prev.map(comment => {
            if (comment.replies && comment.replies.some(reply => reply.id === commentId)) {
              return {
                ...comment,
                replies: comment.replies.filter(reply => reply.id !== commentId)
              };
            }
            return comment;
          });
        }
      });
      
      return true;
    } catch (err) {
      setError(err.message || 'Failed to delete comment');
      console.error('Error deleting comment:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * React to a comment (like, heart, etc.)
   * @param {string} commentId - ID of the comment
   * @param {string} reactionType - Type of reaction
   * @returns {Promise<object>} - Updated comment data
   */
  const reactToComment = async (commentId, reactionType) => {
    if (!storyId || !commentId || !reactionType) {
      throw new Error('Story ID, comment ID, and reaction type are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post(`/stories/${storyId}/comments/${commentId}/reactions`, {
        type: reactionType
      });
      
      // Update comments list with new reaction data
      setComments(prev => {
        // Check if it's a top-level comment
        const commentIndex = prev.findIndex(c => c.id === commentId);
        
        if (commentIndex !== -1) {
          // Update top-level comment
          const updatedComments = [...prev];
          updatedComments[commentIndex] = {
            ...updatedComments[commentIndex],
            reactions: response.data.reactions
          };
          return updatedComments;
        } else {
          // Check if it's a reply
          return prev.map(comment => {
            if (comment.replies && comment.replies.some(reply => reply.id === commentId)) {
              return {
                ...comment,
                replies: comment.replies.map(reply => 
                  reply.id === commentId ? {
                    ...reply,
                    reactions: response.data.reactions
                  } : reply
                )
              };
            }
            return comment;
          });
        }
      });
      
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to react to comment');
      console.error('Error reacting to comment:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Remove a reaction from a comment
   * @param {string} commentId - ID of the comment
   * @param {string} reactionType - Type of reaction to remove
   * @returns {Promise<object>} - Updated comment data
   */
  const removeReaction = async (commentId, reactionType) => {
    if (!storyId || !commentId || !reactionType) {
      throw new Error('Story ID, comment ID, and reaction type are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.delete(`/stories/${storyId}/comments/${commentId}/reactions/${reactionType}`);
      
      // Update comments list with new reaction data
      setComments(prev => {
        // Check if it's a top-level comment
        const commentIndex = prev.findIndex(c => c.id === commentId);
        
        if (commentIndex !== -1) {
          // Update top-level comment
          const updatedComments = [...prev];
          updatedComments[commentIndex] = {
            ...updatedComments[commentIndex],
            reactions: response.data.reactions
          };
          return updatedComments;
        } else {
          // Check if it's a reply
          return prev.map(comment => {
            if (comment.replies && comment.replies.some(reply => reply.id === commentId)) {
              return {
                ...comment,
                replies: comment.replies.map(reply => 
                  reply.id === commentId ? {
                    ...reply,
                    reactions: response.data.reactions
                  } : reply
                )
              };
            }
            return comment;
          });
        }
      });
      
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to remove reaction');
      console.error('Error removing reaction:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Get comments for a specific text selection
   * @param {string} selectionId - ID of the text selection
   * @returns {Array<object>} - Comments for the selection
   */
  const getCommentsForSelection = useCallback((selectionId) => {
    if (!selectionId || !comments.length) return [];
    
    return comments.filter(comment => comment.selectionId === selectionId);
  }, [comments]);
  
  /**
   * Check if user can edit a comment
   * @param {string} commentId - ID of the comment
   * @returns {boolean} - True if user can edit
   */
  const canEditComment = useCallback((commentId) => {
    if (!user || !commentId || !comments.length) return false;
    
    // Find the comment (either top-level or reply)
    const findComment = (comments) => {
      for (const comment of comments) {
        if (comment.id === commentId) {
          return comment;
        }
        if (comment.replies && comment.replies.length) {
          const found = comment.replies.find(reply => reply.id === commentId);
          if (found) return found;
        }
      }
      return null;
    };
    
    const comment = findComment(comments);
    
    // User can edit if they are the author
    return comment && comment.userId === user.id;
  }, [user, comments]);
  
  // Fetch comments on mount and when storyId changes
  useEffect(() => {
    if (storyId) {
      fetchComments();
    }
  }, [storyId, fetchComments]);
  
  return {
    comments,
    loading,
    error,
    fetchComments,
    addComment,
    updateComment,
    deleteComment,
    reactToComment,
    removeReaction,
    getCommentsForSelection,
    canEditComment
  };
};

export default useComments;