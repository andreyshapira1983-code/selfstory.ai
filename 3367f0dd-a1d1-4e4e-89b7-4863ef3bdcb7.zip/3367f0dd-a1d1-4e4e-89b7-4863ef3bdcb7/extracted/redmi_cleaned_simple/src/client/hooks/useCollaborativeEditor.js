import { useState, useEffect, useCallback } from 'react';
import { useEditor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Collaboration from '@tiptap/extension-collaboration';
import CollaborationCursor from '@tiptap/extension-collaboration-cursor';
import { useAuth } from './useAuth';

export const useCollaborativeEditor = (ydoc, awareness) => {
  const { currentUser } = useAuth();
  const [status, setStatus] = useState('initializing');
  const [error, setError] = useState(null);

  // Create a Tiptap editor with Yjs integration
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        history: false, // Disable built-in history as we use Yjs
      }),
      Collaboration.configure({
        document: ydoc ? ydoc.getXmlFragment('content') : null,
      }),
      CollaborationCursor.configure({
        provider: awareness,
        user: currentUser ? {
          name: currentUser.name,
          color: currentUser.profileColor || '#3B82F6',
          avatar: currentUser.avatar || null,
        } : null,
      }),
    ],
    editorProps: {
      attributes: {
        class: 'prose prose-lg max-w-none focus:outline-none',
      },
    },
    onUpdate: ({ editor }) => {
      // This is where you could add additional handlers for editor updates
      // For example, saving content to localStorage as a backup
    },
  }, [ydoc, awareness, currentUser]);

  // Update editor status based on Yjs provider status
  useEffect(() => {
    if (!ydoc || !awareness) {
      setStatus('disconnected');
      return;
    }

    setStatus('connected');

    // Handle errors
    const handleError = (err) => {
      console.error('Editor error:', err);
      setError(err.message || 'An error occurred with the collaborative editor');
      setStatus('error');
    };

    // Add error event listeners
    window.addEventListener('error', handleError);

    return () => {
      window.removeEventListener('error', handleError);
    };
  }, [ydoc, awareness]);

  // Get active users from awareness
  const getActiveUsers = useCallback(() => {
    if (!awareness) return [];
    
    const users = [];
    awareness.getStates().forEach((state, clientId) => {
      if (state.user) {
        users.push({
          clientId,
          ...state.user
        });
      }
    });
    
    return users;
  }, [awareness]);

  // Set content from external source (e.g., when loading a saved document)
  const setContent = useCallback((content) => {
    if (!editor || !content) return;
    
    editor.commands.setContent(content);
  }, [editor]);

  // Get current content as HTML
  const getContentHtml = useCallback(() => {
    if (!editor) return '';
    
    return editor.getHTML();
  }, [editor]);

  // Get current content as JSON
  const getContentJson = useCallback(() => {
    if (!editor) return null;
    
    return editor.getJSON();
  }, [editor]);

  return {
    editor,
    status,
    error,
    getActiveUsers,
    setContent,
    getContentHtml,
    getContentJson,
    awareness
  };
};