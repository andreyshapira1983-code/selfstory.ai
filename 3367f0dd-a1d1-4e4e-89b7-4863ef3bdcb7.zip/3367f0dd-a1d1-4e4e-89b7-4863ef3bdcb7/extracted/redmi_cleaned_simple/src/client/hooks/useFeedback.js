import { useState, useCallback, useContext } from 'react';
import { useAuth } from './useAuth';
import api from '../utils/api';

/**
 * Hook for managing feedback submission and interaction with AI services
 */
const useFeedback = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [feedbackMetrics, setFeedbackMetrics] = useState(null);
  const [errorTaxonomy, setErrorTaxonomy] = useState(null);
  const [languagePrompts, setLanguagePrompts] = useState({});

  /**
   * Submit feedback for an AI suggestion
   * @param {string} suggestionId - ID of the suggestion
   * @param {string} rating - Rating (helpful, unhelpful)
   * @param {string} feedback - Feedback text
   * @param {boolean} applied - Whether the suggestion was applied
   * @returns {Promise} - Promise resolving to the feedback result
   */
  const submitSuggestionFeedback = useCallback(async (suggestionId, rating, feedback, applied) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/feedback/suggestion', {
        suggestionId,
        rating,
        feedback,
        applied
      });
      
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to submit feedback');
      setLoading(false);
      throw err;
    }
  }, []);

  /**
   * Submit language-specific feedback
   * @param {string} text - Text with the issue
   * @param {string} language - Language code
   * @param {string} errorType - Type of error
   * @param {string} description - Description of the issue
   * @param {string} correction - Suggested correction
   * @param {string} context - Context of the text
   * @returns {Promise} - Promise resolving to the feedback result
   */
  const submitLanguageFeedback = useCallback(async (text, language, errorType, description, correction, context) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/feedback/language', {
        text,
        language,
        errorType,
        description,
        correction,
        context
      });
      
      // Update language prompts with the next prompts from the response
      if (response.data.nextPrompts) {
        setLanguagePrompts(prev => ({
          ...prev,
          [response.data.language]: response.data.nextPrompts
        }));
      }
      
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to submit language feedback');
      setLoading(false);
      throw err;
    }
  }, []);

  /**
   * Get feedback metrics (admin only)
   * @returns {Promise} - Promise resolving to the feedback metrics
   */
  const getFeedbackMetrics = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.get('/api/feedback/metrics');
      setFeedbackMetrics(response.data);
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to get feedback metrics');
      setLoading(false);
      throw err;
    }
  }, []);

  /**
   * Get language-specific feedback prompts
   * @param {string} language - Language code
   * @returns {Promise} - Promise resolving to the feedback prompts
   */
  const getLanguageFeedbackPrompts = useCallback(async (language) => {
    // Return cached prompts if available
    if (languagePrompts[language]) {
      return languagePrompts[language];
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.get(`/api/feedback/prompts/${language}`);
      
      // Cache the prompts
      setLanguagePrompts(prev => ({
        ...prev,
        [language]: response.data
      }));
      
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to get feedback prompts');
      setLoading(false);
      throw err;
    }
  }, [languagePrompts]);

  /**
   * Get error taxonomy
   * @returns {Promise} - Promise resolving to the error taxonomy
   */
  const getErrorTaxonomy = useCallback(async () => {
    // Return cached taxonomy if available
    if (errorTaxonomy) {
      return errorTaxonomy;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.get('/api/feedback/taxonomy');
      setErrorTaxonomy(response.data);
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to get error taxonomy');
      setLoading(false);
      throw err;
    }
  }, [errorTaxonomy]);

  /**
   * Submit validation result (reviewer role only)
   * @param {string} validationId - ID of the validation request
   * @param {boolean} approved - Whether the correction is approved
   * @param {string} feedback - Feedback from the reviewer
   * @param {Object} classification - Error classification
   * @returns {Promise} - Promise resolving to the validation result
   */
  const submitValidationResult = useCallback(async (validationId, approved, feedback, classification) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/feedback/validation', {
        validationId,
        approved,
        feedback,
        classification
      });
      
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to submit validation result');
      setLoading(false);
      throw err;
    }
  }, []);

  return {
    loading,
    error,
    feedbackMetrics,
    errorTaxonomy,
    languagePrompts,
    submitSuggestionFeedback,
    submitLanguageFeedback,
    getFeedbackMetrics,
    getLanguageFeedbackPrompts,
    getErrorTaxonomy,
    submitValidationResult
  };
};

export default useFeedback;