/**
 * Storage utility functions for Story AI
 * Provides functions for interacting with localStorage and sessionStorage
 * with error handling and type safety
 */

const STORAGE_PREFIX = 'story_ai_';

/**
 * Saves data to localStorage with the application prefix
 * @param {string} key - Storage key
 * @param {any} data - Data to store (will be JSON stringified)
 * @returns {boolean} - Success status
 */
export const saveToLocalStorage = (key, data) => {
  if (!key) return false;
  
  try {
    const prefixedKey = `${STORAGE_PREFIX}${key}`;
    const serializedData = JSON.stringify(data);
    localStorage.setItem(prefixedKey, serializedData);
    return true;
  } catch (error) {
    console.error('Error saving to localStorage:', error);
    return false;
  }
};

/**
 * Retrieves data from localStorage
 * @param {string} key - Storage key
 * @param {any} defaultValue - Default value if key doesn't exist
 * @returns {any} - Retrieved data or default value
 */
export const getFromLocalStorage = (key, defaultValue = null) => {
  if (!key) return defaultValue;
  
  try {
    const prefixedKey = `${STORAGE_PREFIX}${key}`;
    const serializedData = localStorage.getItem(prefixedKey);
    
    if (serializedData === null) return defaultValue;
    
    return JSON.parse(serializedData);
  } catch (error) {
    console.error('Error retrieving from localStorage:', error);
    return defaultValue;
  }
};

/**
 * Removes data from localStorage
 * @param {string} key - Storage key
 * @returns {boolean} - Success status
 */
export const removeFromLocalStorage = (key) => {
  if (!key) return false;
  
  try {
    const prefixedKey = `${STORAGE_PREFIX}${key}`;
    localStorage.removeItem(prefixedKey);
    return true;
  } catch (error) {
    console.error('Error removing from localStorage:', error);
    return false;
  }
};

/**
 * Saves data to sessionStorage with the application prefix
 * @param {string} key - Storage key
 * @param {any} data - Data to store (will be JSON stringified)
 * @returns {boolean} - Success status
 */
export const saveToSessionStorage = (key, data) => {
  if (!key) return false;
  
  try {
    const prefixedKey = `${STORAGE_PREFIX}${key}`;
    const serializedData = JSON.stringify(data);
    sessionStorage.setItem(prefixedKey, serializedData);
    return true;
  } catch (error) {
    console.error('Error saving to sessionStorage:', error);
    return false;
  }
};

/**
 * Retrieves data from sessionStorage
 * @param {string} key - Storage key
 * @param {any} defaultValue - Default value if key doesn't exist
 * @returns {any} - Retrieved data or default value
 */
export const getFromSessionStorage = (key, defaultValue = null) => {
  if (!key) return defaultValue;
  
  try {
    const prefixedKey = `${STORAGE_PREFIX}${key}`;
    const serializedData = sessionStorage.getItem(prefixedKey);
    
    if (serializedData === null) return defaultValue;
    
    return JSON.parse(serializedData);
  } catch (error) {
    console.error('Error retrieving from sessionStorage:', error);
    return defaultValue;
  }
};

/**
 * Removes data from sessionStorage
 * @param {string} key - Storage key
 * @returns {boolean} - Success status
 */
export const removeFromSessionStorage = (key) => {
  if (!key) return false;
  
  try {
    const prefixedKey = `${STORAGE_PREFIX}${key}`;
    sessionStorage.removeItem(prefixedKey);
    return true;
  } catch (error) {
    console.error('Error removing from sessionStorage:', error);
    return false;
  }
};

/**
 * Clears all application data from localStorage
 * Only removes items with the application prefix
 * @returns {boolean} - Success status
 */
export const clearAppLocalStorage = () => {
  try {
    Object.keys(localStorage).forEach(key => {
      if (key.startsWith(STORAGE_PREFIX)) {
        localStorage.removeItem(key);
      }
    });
    return true;
  } catch (error) {
    console.error('Error clearing app localStorage:', error);
    return false;
  }
};

/**
 * Clears all application data from sessionStorage
 * Only removes items with the application prefix
 * @returns {boolean} - Success status
 */
export const clearAppSessionStorage = () => {
  try {
    Object.keys(sessionStorage).forEach(key => {
      if (key.startsWith(STORAGE_PREFIX)) {
        sessionStorage.removeItem(key);
      }
    });
    return true;
  } catch (error) {
    console.error('Error clearing app sessionStorage:', error);
    return false;
  }
};

/**
 * Saves the user's editor state/draft for a specific story
 * @param {string} storyId - ID of the story
 * @param {object} editorState - Editor state to save
 * @returns {boolean} - Success status
 */
export const saveEditorDraft = (storyId, editorState) => {
  if (!storyId) return false;
  return saveToLocalStorage(`draft_${storyId}`, {
    content: editorState,
    timestamp: new Date().toISOString()
  });
};

/**
 * Retrieves a saved editor draft for a specific story
 * @param {string} storyId - ID of the story
 * @returns {object|null} - Saved draft or null if not found
 */
export const getEditorDraft = (storyId) => {
  if (!storyId) return null;
  return getFromLocalStorage(`draft_${storyId}`, null);
};

/**
 * Removes a saved editor draft for a specific story
 * @param {string} storyId - ID of the story
 * @returns {boolean} - Success status
 */
export const removeEditorDraft = (storyId) => {
  if (!storyId) return false;
  return removeFromLocalStorage(`draft_${storyId}`);
};