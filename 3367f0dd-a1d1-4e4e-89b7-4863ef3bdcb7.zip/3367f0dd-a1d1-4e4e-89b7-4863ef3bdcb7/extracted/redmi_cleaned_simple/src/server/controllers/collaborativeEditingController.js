const Story = require('../models/Story');
const Collaborator = require('../models/Collaborator');
const { getYDoc, setupWSSharedDoc } = require('../utils/documentManager');

/**
 * @desc    Get document for collaborative editing
 * @route   GET /api/collaborative-editing/:documentId
 * @access  Private
 */
exports.getDocument = async (req, res) => {
  try {
    const { documentId } = req.params;
    
    // Find story by documentId
    const story = await Story.findOne({ documentId });
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Document not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: story._id,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this document'
        });
      }
      
      // Update collaborator's active status
      await Collaborator.findByIdAndUpdate(
        isCollaborator._id,
        {
          isActive: true,
          lastActive: Date.now()
        }
      );
    }
    
    // Get the Y.js document
    const yDoc = await getYDoc(documentId);
    
    // Get the content from the document
    const contentType = yDoc.getText('content');
    const content = contentType ? contentType.toString() : '';
    
    res.status(200).json({
      documentId,
      storyId: story._id,
      title: story.title,
      content
    });
  } catch (err) {
    console.error('Get document error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Save document content
 * @route   PUT /api/collaborative-editing/:documentId
 * @access  Private
 */
exports.saveDocument = async (req, res) => {
  try {
    const { documentId } = req.params;
    const { content } = req.body;
    
    if (!content) {
      return res.status(400).json({
        success: false,
        message: 'Content is required'
      });
    }
    
    // Find story by documentId
    const story = await Story.findOne({ documentId });
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Document not found'
      });
    }
    
    // Check if user is author or editor collaborator
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const collaborator = await Collaborator.findOne({
        story: story._id,
        user: req.user.id
      });
      
      if (!collaborator || collaborator.role !== 'editor') {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to save this document'
        });
      }
    }
    
    // Update story content in database
    story.content = content;
    story.lastEditedBy = req.user.id;
    await story.save();
    
    res.status(200).json({
      success: true,
      message: 'Document saved successfully'
    });
  } catch (err) {
    console.error('Save document error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get active collaborators for a document
 * @route   GET /api/collaborative-editing/:documentId/collaborators
 * @access  Private
 */
exports.getActiveCollaborators = async (req, res) => {
  try {
    const { documentId } = req.params;
    
    // Find story by documentId
    const story = await Story.findOne({ documentId });
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Document not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: story._id,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this document'
        });
      }
    }
    
    // Get active collaborators
    const activeCollaborators = await Collaborator.find({
      story: story._id,
      isActive: true
    }).populate('user', 'name email profileColor');
    
    // Add author to the list if they're active
    // In a real application, you would track author's active status separately
    const authorData = {
      _id: 'author',
      user: await User.findById(story.author, 'name email profileColor'),
      role: 'owner',
      isActive: true
    };
    
    res.status(200).json([authorData, ...activeCollaborators]);
  } catch (err) {
    console.error('Get active collaborators error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Update user presence in a document
 * @route   PUT /api/collaborative-editing/:documentId/presence
 * @access  Private
 */
exports.updatePresence = async (req, res) => {
  try {
    const { documentId } = req.params;
    const { isActive } = req.body;
    
    // Find story by documentId
    const story = await Story.findOne({ documentId });
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Document not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const collaborator = await Collaborator.findOne({
        story: story._id,
        user: req.user.id
      });
      
      if (!collaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this document'
        });
      }
      
      // Update collaborator's active status
      await Collaborator.findByIdAndUpdate(
        collaborator._id,
        {
          isActive: isActive !== false, // Default to true if not specified
          lastActive: Date.now()
        }
      );
    } else {
      // For the author, we would update their presence in a separate table
      // In this example, we'll just acknowledge the update
    }
    
    res.status(200).json({
      success: true,
      message: 'Presence updated successfully'
    });
  } catch (err) {
    console.error('Update presence error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get document history
 * @route   GET /api/collaborative-editing/:documentId/history
 * @access  Private
 */
exports.getDocumentHistory = async (req, res) => {
  try {
    const { documentId } = req.params;
    
    // Find story by documentId
    const story = await Story.findOne({ documentId });
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Document not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: story._id,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this document'
        });
      }
    }
    
    // In a real application, you would retrieve document history from a database
    // For this example, we'll return a mock history
    const mockHistory = [
      {
        timestamp: new Date(Date.now() - 3600000), // 1 hour ago
        user: {
          _id: story.author,
          name: 'Author Name',
          profileColor: '#3B82F6'
        },
        type: 'edit',
        description: 'Edited the introduction'
      },
      {
        timestamp: new Date(Date.now() - 7200000), // 2 hours ago
        user: {
          _id: 'collaborator-id',
          name: 'Collaborator Name',
          profileColor: '#10B981'
        },
        type: 'edit',
        description: 'Fixed grammar in paragraph 3'
      }
    ];
    
    res.status(200).json(mockHistory);
  } catch (err) {
    console.error('Get document history error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Create a new document
 * @route   POST /api/collaborative-editing
 * @access  Private
 */
exports.createDocument = async (req, res) => {
  try {
    const { title, description, tags } = req.body;
    
    // Create a new story
    const story = await Story.create({
      title,
      description,
      tags,
      author: req.user.id
    });
    
    // Create a Y.js document
    await getYDoc(story.documentId);
    
    res.status(201).json(story);
  } catch (err) {
    console.error('Create document error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};