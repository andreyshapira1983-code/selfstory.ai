const Collaborator = require('../models/Collaborator');
const Story = require('../models/Story');
const User = require('../models/User');

/**
 * @desc    Add a collaborator to a story
 * @route   POST /api/collaborators
 * @access  Private
 */
exports.addCollaborator = async (req, res) => {
  try {
    const { story, user, email, role = 'editor' } = req.body;
    
    // Check if story exists
    const storyDoc = await Story.findById(story);
    
    if (!storyDoc) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is the story author
    if (storyDoc.author.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Only the story author can add collaborators'
      });
    }
    
    // Find user by ID or email
    let userDoc;
    
    if (user) {
      userDoc = await User.findById(user);
    } else if (email) {
      userDoc = await User.findOne({ email });
    } else {
      return res.status(400).json({
        success: false,
        message: 'User ID or email is required'
      });
    }
    
    if (!userDoc) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    // Check if user is already a collaborator
    const existingCollaborator = await Collaborator.findOne({
      story,
      user: userDoc._id
    });
    
    if (existingCollaborator) {
      return res.status(400).json({
        success: false,
        message: 'User is already a collaborator'
      });
    }
    
    // Check if user is the author
    if (userDoc._id.toString() === storyDoc.author.toString()) {
      return res.status(400).json({
        success: false,
        message: 'Cannot add story author as a collaborator'
      });
    }
    
    // Create collaborator
    const collaborator = await Collaborator.create({
      story,
      user: userDoc._id,
      role,
      addedBy: req.user.id
    });
    
    // Populate user details
    const populatedCollaborator = await Collaborator.findById(collaborator._id)
      .populate('user', 'name email profileColor')
      .populate('story', 'title');
    
    res.status(201).json(populatedCollaborator);
  } catch (err) {
    console.error('Add collaborator error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get all collaborators for a story
 * @route   GET /api/collaborators/story/:storyId
 * @access  Private
 */
exports.getCollaboratorsByStory = async (req, res) => {
  try {
    const { storyId } = req.params;
    
    // Check if story exists
    const story = await Story.findById(storyId);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: storyId,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this story'
        });
      }
    }
    
    // Get collaborators
    const collaborators = await Collaborator.find({ story: storyId })
      .populate('user', 'name email profileColor')
      .populate('addedBy', 'name email');
    
    res.status(200).json(collaborators);
  } catch (err) {
    console.error('Get collaborators error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get all stories where user is a collaborator
 * @route   GET /api/collaborators/user
 * @access  Private
 */
exports.getCollaborationsByUser = async (req, res) => {
  try {
    // Get collaborations
    const collaborations = await Collaborator.find({ user: req.user.id })
      .populate({
        path: 'story',
        populate: {
          path: 'author',
          select: 'name email profileColor'
        }
      });
    
    res.status(200).json(collaborations);
  } catch (err) {
    console.error('Get collaborations error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get a single collaborator
 * @route   GET /api/collaborators/:id
 * @access  Private
 */
exports.getCollaborator = async (req, res) => {
  try {
    const collaborator = await Collaborator.findById(req.params.id)
      .populate('user', 'name email profileColor')
      .populate('story', 'title author')
      .populate('addedBy', 'name email');
    
    if (!collaborator) {
      return res.status(404).json({
        success: false,
        message: 'Collaborator not found'
      });
    }
    
    // Check if user is author or the collaborator
    const story = await Story.findById(collaborator.story);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    const isAuthor = story.author.toString() === req.user.id;
    const isTheCollaborator = collaborator.user._id.toString() === req.user.id;
    
    if (!isAuthor && !isTheCollaborator) {
      const isCollaborator = await Collaborator.findOne({
        story: collaborator.story,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this collaborator'
        });
      }
    }
    
    res.status(200).json(collaborator);
  } catch (err) {
    console.error('Get collaborator error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Update collaborator role
 * @route   PUT /api/collaborators/:id
 * @access  Private
 */
exports.updateCollaborator = async (req, res) => {
  try {
    const { role } = req.body;
    
    // Validate role
    if (role && !['editor', 'viewer'].includes(role)) {
      return res.status(400).json({
        success: false,
        message: 'Role must be either editor or viewer'
      });
    }
    
    let collaborator = await Collaborator.findById(req.params.id);
    
    if (!collaborator) {
      return res.status(404).json({
        success: false,
        message: 'Collaborator not found'
      });
    }
    
    // Check if user is the story author
    const story = await Story.findById(collaborator.story);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    if (story.author.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Only the story author can update collaborators'
      });
    }
    
    // Update collaborator
    collaborator = await Collaborator.findByIdAndUpdate(
      req.params.id,
      { role },
      { new: true, runValidators: true }
    ).populate('user', 'name email profileColor');
    
    res.status(200).json(collaborator);
  } catch (err) {
    console.error('Update collaborator error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Delete collaborator
 * @route   DELETE /api/collaborators/:id
 * @access  Private
 */
exports.deleteCollaborator = async (req, res) => {
  try {
    const collaborator = await Collaborator.findById(req.params.id);
    
    if (!collaborator) {
      return res.status(404).json({
        success: false,
        message: 'Collaborator not found'
      });
    }
    
    // Check if user is the story author or the collaborator themselves
    const story = await Story.findById(collaborator.story);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    const isAuthor = story.author.toString() === req.user.id;
    const isTheCollaborator = collaborator.user.toString() === req.user.id;
    
    if (!isAuthor && !isTheCollaborator) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this collaborator'
      });
    }
    
    // Delete collaborator
    await collaborator.remove();
    
    res.status(200).json({
      success: true,
      message: 'Collaborator removed successfully'
    });
  } catch (err) {
    console.error('Delete collaborator error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Update collaborator active status
 * @route   PUT /api/collaborators/:id/status
 * @access  Private
 */
exports.updateActiveStatus = async (req, res) => {
  try {
    const { isActive } = req.body;
    
    if (isActive === undefined) {
      return res.status(400).json({
        success: false,
        message: 'isActive field is required'
      });
    }
    
    let collaborator = await Collaborator.findById(req.params.id);
    
    if (!collaborator) {
      return res.status(404).json({
        success: false,
        message: 'Collaborator not found'
      });
    }
    
    // Check if user is the collaborator
    if (collaborator.user.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Only the collaborator can update their active status'
      });
    }
    
    // Update active status
    collaborator = await Collaborator.findByIdAndUpdate(
      req.params.id,
      { 
        isActive,
        lastActive: isActive ? Date.now() : collaborator.lastActive
      },
      { new: true, runValidators: true }
    );
    
    res.status(200).json(collaborator);
  } catch (err) {
    console.error('Update active status error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};