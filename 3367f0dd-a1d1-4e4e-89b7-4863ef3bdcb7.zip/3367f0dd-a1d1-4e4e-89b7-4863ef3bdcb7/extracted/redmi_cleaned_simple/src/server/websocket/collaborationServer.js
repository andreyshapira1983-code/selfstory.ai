const WebSocket = require('ws');
const http = require('http');
const url = require('url');
const jwt = require('jsonwebtoken');
const { setupWSConnection } = require('y-websocket/bin/utils');
const { setupWSSharedDoc } = require('../utils/documentManager');
const Story = require('../models/Story');
const Collaborator = require('../models/Collaborator');
const User = require('../models/User');

/**
 * Initialize WebSocket server for collaborative editing
 * @param {http.Server} server - HTTP server instance
 */
const initWebSocketServer = (server) => {
  // Create WebSocket server
  const wss = new WebSocket.Server({ 
    noServer: true,
    // Allow connections from any origin
    verifyClient: () => true
  });

  // Handle upgrade requests
  server.on('upgrade', async (request, socket, head) => {
    // Parse URL to get documentId and token
    const pathname = url.parse(request.url).pathname;
    const params = new URLSearchParams(url.parse(request.url).query);
    
    // Extract documentId from path
    const documentIdMatch = pathname.match(/\/ws-server\/([^\/]+)/);
    const documentId = documentIdMatch ? documentIdMatch[1] : null;
    
    // Extract token from query parameters
    const token = params.get('token');
    
    if (!documentId) {
      socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');
      socket.destroy();
      return;
    }
    
    try {
      // Verify token and get user
      let user = null;
      
      if (token) {
        try {
          const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_jwt_secret_key_here');
          user = await User.findById(decoded.id).select('-password');
        } catch (err) {
          console.error('Invalid token:', err);
        }
      }
      
      // Find story by documentId
      const story = await Story.findOne({ documentId });
      
      if (!story) {
        socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
        socket.destroy();
        return;
      }
      
      // Check if user is author or collaborator
      let hasAccess = false;
      let isEditor = false;
      
      if (user) {
        // Check if user is author
        if (story.author.toString() === user._id.toString()) {
          hasAccess = true;
          isEditor = true;
        } else {
          // Check if user is collaborator
          const collaborator = await Collaborator.findOne({
            story: story._id,
            user: user._id
          });
          
          if (collaborator) {
            hasAccess = true;
            isEditor = collaborator.role === 'editor';
            
            // Update collaborator's active status
            await Collaborator.findByIdAndUpdate(
              collaborator._id,
              {
                isActive: true,
                lastActive: Date.now()
              }
            );
          }
        }
      }
      
      // If no access, reject connection
      if (!hasAccess) {
        socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
        socket.destroy();
        return;
      }
      
      // Upgrade connection
      wss.handleUpgrade(request, socket, head, (ws) => {
        // Add user info and permissions to WebSocket object
        ws.user = user;
        ws.documentId = documentId;
        ws.isEditor = isEditor;
        
        // Emit connection event
        wss.emit('connection', ws, request);
      });
    } catch (err) {
      console.error('WebSocket upgrade error:', err);
      socket.write('HTTP/1.1 500 Internal Server Error\r\n\r\n');
      socket.destroy();
    }
  });

  // Handle WebSocket connections
  wss.on('connection', (ws, req) => {
    console.log(`WebSocket connection established for document: ${ws.documentId}`);
    
    // Set up shared document
    setupWSSharedDoc(ws, ws.documentId, ws.user, ws.isEditor);
    
    // Handle user presence
    if (ws.user) {
      // Broadcast user joined event
      broadcastToDocument(wss, ws.documentId, {
        type: 'user-joined',
        user: {
          id: ws.user._id,
          name: ws.user.name,
          profileColor: ws.user.profileColor
        },
        timestamp: new Date().toISOString()
      }, ws);
    }
    
    // Handle WebSocket messages
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message);
        
        // Handle different message types
        switch (data.type) {
          case 'cursor-update':
            // Only broadcast if user is authenticated
            if (ws.user) {
              broadcastToDocument(wss, ws.documentId, {
                type: 'cursor-update',
                user: {
                  id: ws.user._id,
                  name: ws.user.name,
                  profileColor: ws.user.profileColor
                },
                position: data.position,
                timestamp: new Date().toISOString()
              }, ws);
            }
            break;
            
          case 'user-presence':
            // Only broadcast if user is authenticated
            if (ws.user) {
              broadcastToDocument(wss, ws.documentId, {
                type: 'user-presence',
                user: {
                  id: ws.user._id,
                  name: ws.user.name,
                  profileColor: ws.user.profileColor
                },
                status: data.status,
                timestamp: new Date().toISOString()
              }, ws);
            }
            break;
            
          case 'get-presence':
            // Send list of all connected users
            const users = [];
            wss.clients.forEach((client) => {
              if (client.documentId === ws.documentId && client.user) {
                users.push({
                  id: client.user._id,
                  name: client.user.name,
                  profileColor: client.user.profileColor
                });
              }
            });
            
            ws.send(JSON.stringify({
              type: 'presence-update',
              users,
              timestamp: new Date().toISOString()
            }));
            break;
            
          default:
            // Handle other message types or ignore
            break;
        }
      } catch (err) {
        console.error('Error handling WebSocket message:', err);
      }
    });
    
    // Handle WebSocket close
    ws.on('close', () => {
      console.log(`WebSocket connection closed for document: ${ws.documentId}`);
      
      // Broadcast user left event
      if (ws.user) {
        broadcastToDocument(wss, ws.documentId, {
          type: 'user-left',
          user: {
            id: ws.user._id,
            name: ws.user.name,
            profileColor: ws.user.profileColor
          },
          timestamp: new Date().toISOString()
        });
        
        // Update collaborator's active status
        if (ws.user._id) {
          updateCollaboratorStatus(ws.documentId, ws.user._id, false).catch(err => {
            console.error('Error updating collaborator status:', err);
          });
        }
      }
    });
  });

  return wss;
};

/**
 * Broadcast a message to all clients connected to a specific document
 * @param {WebSocket.Server} wss - WebSocket server instance
 * @param {string} documentId - Document ID
 * @param {object} message - Message to broadcast
 * @param {WebSocket} [exclude] - WebSocket connection to exclude from broadcast
 */
const broadcastToDocument = (wss, documentId, message, exclude = null) => {
  wss.clients.forEach((client) => {
    if (client.documentId === documentId && client !== exclude && client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message));
    }
  });
};

/**
 * Update collaborator's active status in the database
 * @param {string} documentId - Document ID
 * @param {string} userId - User ID
 * @param {boolean} isActive - Active status
 */
const updateCollaboratorStatus = async (documentId, userId, isActive) => {
  try {
    // Find story by documentId
    const story = await Story.findOne({ documentId });
    
    if (!story) {
      return;
    }
    
    // Check if user is author
    if (story.author.toString() === userId.toString()) {
      // For the author, we would update their presence in a separate table
      // In this example, we'll just return
      return;
    }
    
    // Update collaborator's active status
    await Collaborator.findOneAndUpdate(
      {
        story: story._id,
        user: userId
      },
      {
        isActive,
        lastActive: isActive ? Date.now() : undefined
      }
    );
  } catch (err) {
    console.error('Error updating collaborator status:', err);
  }
};

module.exports = { initWebSocketServer };