/**
 * Language Processing Service
 * 
 * This service provides language-specific processing strategies for different languages,
 * including segmentation, normalization, and fallback mechanisms.
 */

const { franc } = require('franc');
const { Segmenter } = require('intl-segmenter-polyfill');

class LanguageProcessingService {
  constructor() {
    // Initialize language-specific processors
    this.processors = {
      'zh': new ChineseProcessor(),
      'ru': new RussianProcessor(),
      'en': new EnglishProcessor(),
      'es': new SpanishProcessor(),
      'fr': new FrenchProcessor(),
      'de': new GermanProcessor(),
      'ja': new JapaneseProcessor(),
      'ko': new KoreanProcessor(),
      'ar': new ArabicProcessor(),
      'hi': new HindiProcessor()
    };
    
    // Default processor for fallback
    this.defaultProcessor = new GenericProcessor();
    
    // Initialize segmenter
    this.initializeSegmenter();
  }
  
  /**
   * Initialize the Unicode segmenter
   */
  async initializeSegmenter() {
    try {
      this.segmenter = new Segmenter();
    } catch (error) {
      console.error('Failed to initialize segmenter:', error);
    }
  }
  
  /**
   * Process text with language-specific strategies
   * @param {string} text - Text to process
   * @param {string} languageCode - ISO 639-1 language code (optional)
   * @returns {Object} - Processing results
   */
  async processText(text, languageCode = null) {
    try {
      // Detect language if not provided
      const detectedLanguage = languageCode || this.detectLanguage(text);
      
      // Get appropriate processor
      const processor = this.getProcessor(detectedLanguage);
      
      // Process the text
      const result = await processor.process(text);
      
      return {
        text,
        language: detectedLanguage,
        ...result
      };
    } catch (error) {
      console.error('Error processing text:', error);
      
      // Use fallback processor
      return this.fallbackProcessing(text, error);
    }
  }
  
  /**
   * Detect language of text
   * @param {string} text - Text to detect language for
   * @returns {string} - ISO 639-1 language code
   */
  detectLanguage(text) {
    try {
      // Use franc for language detection
      const detectedLanguage = franc(text);
      
      // Convert to ISO 639-1 if needed
      return this.normalizeLanguageCode(detectedLanguage);
    } catch (error) {
      console.error('Error detecting language:', error);
      return 'en'; // Default to English
    }
  }
  
  /**
   * Normalize language code to ISO 639-1
   * @param {string} code - Language code to normalize
   * @returns {string} - ISO 639-1 language code
   */
  normalizeLanguageCode(code) {
    // Mapping from franc codes to ISO 639-1
    const codeMapping = {
      'cmn': 'zh', // Mandarin Chinese
      'rus': 'ru', // Russian
      'eng': 'en', // English
      'spa': 'es', // Spanish
      'fra': 'fr', // French
      'deu': 'de', // German
      'jpn': 'ja', // Japanese
      'kor': 'ko', // Korean
      'ara': 'ar', // Arabic
      'hin': 'hi'  // Hindi
    };
    
    return codeMapping[code] || code;
  }
  
  /**
   * Get appropriate processor for language
   * @param {string} languageCode - ISO 639-1 language code
   * @returns {Object} - Language processor
   */
  getProcessor(languageCode) {
    return this.processors[languageCode] || this.defaultProcessor;
  }
  
  /**
   * Fallback processing when language-specific processing fails
   * @param {string} text - Text to process
   * @param {Error} error - Original error
   * @returns {Object} - Processing results
   */
  async fallbackProcessing(text, error) {
    console.log('Using fallback processing due to error:', error.message);
    
    try {
      // Use generic processor
      const result = await this.defaultProcessor.process(text);
      
      return {
        text,
        language: 'unknown',
        fallback: true,
        originalError: error.message,
        ...result
      };
    } catch (fallbackError) {
      console.error('Fallback processing also failed:', fallbackError);
      
      // Return minimal result
      return {
        text,
        language: 'unknown',
        fallback: true,
        error: true,
        originalError: error.message,
        fallbackError: fallbackError.message,
        tokens: text.split(/\s+/),
        sentences: [text]
      };
    }
  }
  
  /**
   * Segment text into tokens
   * @param {string} text - Text to segment
   * @param {string} granularity - Segmentation granularity (word, sentence)
   * @returns {Array} - Segmented tokens
   */
  segmentText(text, granularity = 'word') {
    try {
      if (!this.segmenter) {
        // Fallback if segmenter not available
        return granularity === 'sentence' 
          ? text.split(/[.!?]+/) 
          : text.split(/\s+/);
      }
      
      // Use Unicode segmenter
      const segments = this.segmenter.segment(text, { granularity });
      return Array.from(segments).map(segment => segment.segment);
    } catch (error) {
      console.error('Error segmenting text:', error);
      
      // Fallback
      return granularity === 'sentence' 
        ? text.split(/[.!?]+/) 
        : text.split(/\s+/);
    }
  }
  
  /**
   * Get feedback collection prompt for a specific language
   * @param {string} languageCode - ISO 639-1 language code
   * @returns {Object} - Language-specific feedback prompts
   */
  getFeedbackPrompt(languageCode) {
    const processor = this.getProcessor(languageCode);
    return processor.getFeedbackPrompt();
  }
}

/**
 * Base language processor class
 */
class BaseLanguageProcessor {
  constructor() {
    this.name = 'Base';
    this.languageCode = 'en';
  }
  
  /**
   * Process text with language-specific strategies
   * @param {string} text - Text to process
   * @returns {Object} - Processing results
   */
  async process(text) {
    // Base implementation - should be overridden
    return {
      tokens: text.split(/\s+/),
      sentences: text.split(/[.!?]+/),
      normalized: text,
      processor: this.name
    };
  }
  
  /**
   * Normalize text for the specific language
   * @param {string} text - Text to normalize
   * @returns {string} - Normalized text
   */
  normalize(text) {
    // Base implementation - should be overridden
    return text;
  }
  
  /**
   * Get feedback collection prompt
   * @returns {Object} - Feedback prompts
   */
  getFeedbackPrompt() {
    return {
      title: 'Help us improve',
      description: 'Did you notice any issues with our suggestions?',
      options: [
        'Grammatical errors',
        'Spelling mistakes',
        'Contextual misunderstanding',
        'Stylistic issues',
        'Other issues'
      ]
    };
  }
}

/**
 * Generic language processor for fallback
 */
class GenericProcessor extends BaseLanguageProcessor {
  constructor() {
    super();
    this.name = 'Generic';
    this.languageCode = 'generic';
  }
}

/**
 * Chinese language processor
 */
class ChineseProcessor extends BaseLanguageProcessor {
  constructor() {
    super();
    this.name = 'Chinese';
    this.languageCode = 'zh';
  }
  
  /**
   * Process Chinese text
   * @param {string} text - Text to process
   * @returns {Object} - Processing results
   */
  async process(text) {
    // Chinese-specific processing
    
    // Character segmentation (Chinese doesn't use spaces between words)
    const tokens = Array.from(text);
    
    // Sentence segmentation
    const sentences = text.split(/[。！？]/);
    
    // Normalize text (simplified/traditional handling could be added here)
    const normalized = this.normalize(text);
    
    // Detect tone patterns
    const tonePatterns = this.detectTonePatterns(text);
    
    return {
      tokens,
      sentences,
      normalized,
      processor: this.name,
      tonePatterns,
      ideographicFeatures: this.extractIdeographicFeatures(text)
    };
  }
  
  /**
   * Normalize Chinese text
   * @param {string} text - Text to normalize
   * @returns {string} - Normalized text
   */
  normalize(text) {
    // Convert full-width punctuation to half-width
    let normalized = text
      .replace(/，/g, ',')
      .replace(/。/g, '.')
      .replace(/：/g, ':')
      .replace(/；/g, ';')
      .replace(/！/g, '!')
      .replace(/？/g, '?')
      .replace(/（/g, '(')
      .replace(/）/g, ')');
    
    return normalized;
  }
  
  /**
   * Detect tone patterns in Chinese text
   * @param {string} text - Text to analyze
   * @returns {Object} - Tone patterns
   */
  detectTonePatterns(text) {
    // In a real implementation, this would analyze the tones of characters
    // For now, we'll return a placeholder
    return {
      firstTone: 0,
      secondTone: 0,
      thirdTone: 0,
      fourthTone: 0,
      neutralTone: 0
    };
  }
  
  /**
   * Extract ideographic features from Chinese text
   * @param {string} text - Text to analyze
   * @returns {Object} - Ideographic features
   */
  extractIdeographicFeatures(text) {
    // In a real implementation, this would analyze character components
    return {
      simplifiedCount: 0,
      traditionalCount: 0,
      commonCharacters: 0,
      rareCharacters: 0
    };
  }
  
  /**
   * Get feedback collection prompt for Chinese
   * @returns {Object} - Feedback prompts
   */
  getFeedbackPrompt() {
    return {
      title: '帮助我们改进',
      description: '您是否注意到我们的建议有任何问题？',
      options: [
        '语法错误',
        '用词不当',
        '上下文理解错误',
        '风格问题',
        '简繁转换错误',
        '其他问题'
      ]
    };
  }
}

/**
 * Russian language processor
 */
class RussianProcessor extends BaseLanguageProcessor {
  constructor() {
    super();
    this.name = 'Russian';
    this.languageCode = 'ru';
  }
  
  /**
   * Process Russian text
   * @param {string} text - Text to process
   * @returns {Object} - Processing results
   */
  async process(text) {
    // Russian-specific processing
    
    // Word tokenization
    const tokens = text.split(/\s+/);
    
    // Sentence segmentation
    const sentences = text.split(/[.!?]+/);
    
    // Normalize text
    const normalized = this.normalize(text);
    
    // Morphological analysis
    const morphology = this.analyzeMorphology(tokens);
    
    return {
      tokens,
      sentences,
      normalized,
      processor: this.name,
      morphology
    };
  }
  
  /**
   * Normalize Russian text
   * @param {string} text - Text to normalize
   * @returns {string} - Normalized text
   */
  normalize(text) {
    // Convert 'ё' to 'е' for consistency (common normalization in Russian)
    let normalized = text.replace(/ё/g, 'е').replace(/Ё/g, 'Е');
    
    return normalized;
  }
  
  /**
   * Analyze morphology of Russian words
   * @param {Array} tokens - Word tokens
   * @returns {Object} - Morphological features
   */
  analyzeMorphology(tokens) {
    // In a real implementation, this would use a Russian morphological analyzer
    // For now, we'll return a placeholder
    return {
      cases: {
        nominative: 0,
        genitive: 0,
        dative: 0,
        accusative: 0,
        instrumental: 0,
        prepositional: 0
      },
      verbAspects: {
        perfective: 0,
        imperfective: 0
      }
    };
  }
  
  /**
   * Get feedback collection prompt for Russian
   * @returns {Object} - Feedback prompts
   */
  getFeedbackPrompt() {
    return {
      title: 'Помогите нам улучшить сервис',
      description: 'Заметили ли вы какие-либо проблемы с нашими предложениями?',
      options: [
        'Грамматические ошибки',
        'Орфографические ошибки',
        'Неправильное понимание контекста',
        'Стилистические проблемы',
        'Проблемы с падежами',
        'Другие проблемы'
      ]
    };
  }
}

/**
 * English language processor
 */
class EnglishProcessor extends BaseLanguageProcessor {
  constructor() {
    super();
    this.name = 'English';
    this.languageCode = 'en';
  }
  
  /**
   * Process English text
   * @param {string} text - Text to process
   * @returns {Object} - Processing results
   */
  async process(text) {
    // English-specific processing
    
    // Word tokenization
    const tokens = text.split(/\s+/);
    
    // Sentence segmentation
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    
    // Normalize text
    const normalized = this.normalize(text);
    
    return {
      tokens,
      sentences,
      normalized,
      processor: this.name
    };
  }
  
  /**
   * Normalize English text
   * @param {string} text - Text to normalize
   * @returns {string} - Normalized text
   */
  normalize(text) {
    // Convert to lowercase for analysis (preserving original case)
    const normalized = text;
    
    return normalized;
  }
}

/**
 * Spanish language processor
 */
class SpanishProcessor extends BaseLanguageProcessor {
  constructor() {
    super();
    this.name = 'Spanish';
    this.languageCode = 'es';
  }
  
  /**
   * Process Spanish text
   * @param {string} text - Text to process
   * @returns {Object} - Processing results
   */
  async process(text) {
    // Spanish-specific processing
    
    // Word tokenization
    const tokens = text.split(/\s+/);
    
    // Sentence segmentation
    const sentences = text.split(/[.!?¡¿]+/).filter(s => s.trim().length > 0);
    
    // Normalize text
    const normalized = this.normalize(text);
    
    return {
      tokens,
      sentences,
      normalized,
      processor: this.name
    };
  }
  
  /**
   * Normalize Spanish text
   * @param {string} text - Text to normalize
   * @returns {string} - Normalized text
   */
  normalize(text) {
    // Handle Spanish-specific normalization
    return text;
  }
  
  /**
   * Get feedback collection prompt for Spanish
   * @returns {Object} - Feedback prompts
   */
  getFeedbackPrompt() {
    return {
      title: 'Ayúdanos a mejorar',
      description: '¿Notaste algún problema con nuestras sugerencias?',
      options: [
        'Errores gramaticales',
        'Errores ortográficos',
        'Malentendido contextual',
        'Problemas estilísticos',
        'Otros problemas'
      ]
    };
  }
}

/**
 * French language processor
 */
class FrenchProcessor extends BaseLanguageProcessor {
  constructor() {
    super();
    this.name = 'French';
    this.languageCode = 'fr';
  }
  
  /**
   * Process French text
   * @param {string} text - Text to process
   * @returns {Object} - Processing results
   */
  async process(text) {
    // French-specific processing
    
    // Word tokenization (handling French elision)
    const tokens = text.split(/\s+|(?<=\')(?=[a-zA-Z])/);
    
    // Sentence segmentation
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    
    // Normalize text
    const normalized = this.normalize(text);
    
    return {
      tokens,
      sentences,
      normalized,
      processor: this.name
    };
  }
  
  /**
   * Normalize French text
   * @param {string} text - Text to normalize
   * @returns {string} - Normalized text
   */
  normalize(text) {
    // Handle French-specific normalization (accents, etc.)
    return text;
  }
  
  /**
   * Get feedback collection prompt for French
   * @returns {Object} - Feedback prompts
   */
  getFeedbackPrompt() {
    return {
      title: 'Aidez-nous à nous améliorer',
      description: 'Avez-vous remarqué des problèmes avec nos suggestions?',
      options: [
        'Erreurs grammaticales',
        'Fautes d\'orthographe',
        'Incompréhension contextuelle',
        'Problèmes stylistiques',
        'Autres problèmes'
      ]
    };
  }
}

/**
 * German language processor
 */
class GermanProcessor extends BaseLanguageProcessor {
  constructor() {
    super();
    this.name = 'German';
    this.languageCode = 'de';
  }
  
  /**
   * Process German text
   * @param {string} text - Text to process
   * @returns {Object} - Processing results
   */
  async process(text) {
    // German-specific processing
    
    // Word tokenization (handling German compound words)
    const tokens = text.split(/\s+/);
    
    // Sentence segmentation
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    
    // Normalize text
    const normalized = this.normalize(text);
    
    // Compound word analysis
    const compoundWords = this.analyzeCompoundWords(tokens);
    
    return {
      tokens,
      sentences,
      normalized,
      processor: this.name,
      compoundWords
    };
  }
  
  /**
   * Normalize German text
   * @param {string} text - Text to normalize
   * @returns {string} - Normalized text
   */
  normalize(text) {
    // Handle German-specific normalization (umlauts, etc.)
    return text;
  }
  
  /**
   * Analyze German compound words
   * @param {Array} tokens - Word tokens
   * @returns {Array} - Compound word analysis
   */
  analyzeCompoundWords(tokens) {
    // In a real implementation, this would decompose German compound words
    return [];
  }
  
  /**
   * Get feedback collection prompt for German
   * @returns {Object} - Feedback prompts
   */
  getFeedbackPrompt() {
    return {
      title: 'Helfen Sie uns, besser zu werden',
      description: 'Haben Sie Probleme mit unseren Vorschlägen bemerkt?',
      options: [
        'Grammatikfehler',
        'Rechtschreibfehler',
        'Kontextuelle Missverständnisse',
        'Stilistische Probleme',
        'Andere Probleme'
      ]
    };
  }
}

/**
 * Japanese language processor
 */
class JapaneseProcessor extends BaseLanguageProcessor {
  constructor() {
    super();
    this.name = 'Japanese';
    this.languageCode = 'ja';
  }
  
  /**
   * Process Japanese text
   * @param {string} text - Text to process
   * @returns {Object} - Processing results
   */
  async process(text) {
    // Japanese-specific processing
    
    // Character segmentation
    const tokens = Array.from(text);
    
    // Sentence segmentation
    const sentences = text.split(/[。！？]/);
    
    // Normalize text
    const normalized = this.normalize(text);
    
    return {
      tokens,
      sentences,
      normalized,
      processor: this.name,
      scriptTypes: this.analyzeScriptTypes(text)
    };
  }
  
  /**
   * Normalize Japanese text
   * @param {string} text - Text to normalize
   * @returns {string} - Normalized text
   */
  normalize(text) {
    // Handle Japanese-specific normalization
    return text;
  }
  
  /**
   * Analyze script types in Japanese text
   * @param {string} text - Text to analyze
   * @returns {Object} - Script type analysis
   */
  analyzeScriptTypes(text) {
    // In a real implementation, this would count hiragana, katakana, kanji
    return {
      hiragana: 0,
      katakana: 0,
      kanji: 0,
      romaji: 0
    };
  }
  
  /**
   * Get feedback collection prompt for Japanese
   * @returns {Object} - Feedback prompts
   */
  getFeedbackPrompt() {
    return {
      title: '改善にご協力ください',
      description: '私たちの提案に問題がありましたか？',
      options: [
        '文法の誤り',
        'スペルミス',
        '文脈の誤解',
        'スタイルの問題',
        'その他の問題'
      ]
    };
  }
}

/**
 * Korean language processor
 */
class KoreanProcessor extends BaseLanguageProcessor {
  constructor() {
    super();
    this.name = 'Korean';
    this.languageCode = 'ko';
  }
  
  /**
   * Process Korean text
   * @param {string} text - Text to process
   * @returns {Object} - Processing results
   */
  async process(text) {
    // Korean-specific processing
    
    // Word tokenization
    const tokens = text.split(/\s+/);
    
    // Sentence segmentation
    const sentences = text.split(/[.!?]+/);
    
    // Normalize text
    const normalized = this.normalize(text);
    
    return {
      tokens,
      sentences,
      normalized,
      processor: this.name
    };
  }
  
  /**
   * Normalize Korean text
   * @param {string} text - Text to normalize
   * @returns {string} - Normalized text
   */
  normalize(text) {
    // Handle Korean-specific normalization
    return text;
  }
  
  /**
   * Get feedback collection prompt for Korean
   * @returns {Object} - Feedback prompts
   */
  getFeedbackPrompt() {
    return {
      title: '개선에 도움을 주세요',
      description: '저희 제안에 문제가 있었나요?',
      options: [
        '문법 오류',
        '맞춤법 오류',
        '맥락 오해',
        '문체 문제',
        '기타 문제'
      ]
    };
  }
}

/**
 * Arabic language processor
 */
class ArabicProcessor extends BaseLanguageProcessor {
  constructor() {
    super();
    this.name = 'Arabic';
    this.languageCode = 'ar';
  }
  
  /**
   * Process Arabic text
   * @param {string} text - Text to process
   * @returns {Object} - Processing results
   */
  async process(text) {
    // Arabic-specific processing
    
    // Word tokenization
    const tokens = text.split(/\s+/);
    
    // Sentence segmentation
    const sentences = text.split(/[.!?]+/);
    
    // Normalize text
    const normalized = this.normalize(text);
    
    return {
      tokens,
      sentences,
      normalized,
      processor: this.name,
      rtl: true
    };
  }
  
  /**
   * Normalize Arabic text
   * @param {string} text - Text to normalize
   * @returns {string} - Normalized text
   */
  normalize(text) {
    // Handle Arabic-specific normalization
    return text;
  }
  
  /**
   * Get feedback collection prompt for Arabic
   * @returns {Object} - Feedback prompts
   */
  getFeedbackPrompt() {
    return {
      title: 'ساعدنا على التحسين',
      description: 'هل لاحظت أي مشاكل في اقتراحاتنا؟',
      options: [
        'أخطاء نحوية',
        'أخطاء إملائية',
        'سوء فهم السياق',
        'مشاكل أسلوبية',
        'مشاكل أخرى'
      ]
    };
  }
}

/**
 * Hindi language processor
 */
class HindiProcessor extends BaseLanguageProcessor {
  constructor() {
    super();
    this.name = 'Hindi';
    this.languageCode = 'hi';
  }
  
  /**
   * Process Hindi text
   * @param {string} text - Text to process
   * @returns {Object} - Processing results
   */
  async process(text) {
    // Hindi-specific processing
    
    // Word tokenization
    const tokens = text.split(/\s+/);
    
    // Sentence segmentation
    const sentences = text.split(/[।?!]+/);
    
    // Normalize text
    const normalized = this.normalize(text);
    
    return {
      tokens,
      sentences,
      normalized,
      processor: this.name
    };
  }
  
  /**
   * Normalize Hindi text
   * @param {string} text - Text to normalize
   * @returns {string} - Normalized text
   */
  normalize(text) {
    // Handle Hindi-specific normalization
    return text;
  }
  
  /**
   * Get feedback collection prompt for Hindi
   * @returns {Object} - Feedback prompts
   */
  getFeedbackPrompt() {
    return {
      title: 'हमें सुधारने में मदद करें',
      description: 'क्या आपने हमारे सुझावों में कोई समस्या देखी?',
      options: [
        'व्याकरण संबंधी त्रुटियां',
        'वर्तनी की गलतियां',
        'संदर्भ की गलत समझ',
        'शैली संबंधी समस्याएं',
        'अन्य समस्याएं'
      ]
    };
  }
}

module.exports = LanguageProcessingService;