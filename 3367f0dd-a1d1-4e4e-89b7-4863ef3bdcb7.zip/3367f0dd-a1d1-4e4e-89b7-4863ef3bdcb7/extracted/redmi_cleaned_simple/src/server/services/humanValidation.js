/**
 * Human-in-the-Loop Validation Service
 * 
 * This service manages the workflow for human validation of AI self-corrections
 * and feedback incorporation to improve AI performance over time.
 */

const mongoose = require('mongoose');
const AISuggestion = require('../models/AISuggestion');
const User = require('../models/User');
const EventEmitter = require('events');

class HumanValidationService {
  constructor(options = {}) {
    this.options = {
      // Maximum time to wait for human validation (in milliseconds)
      validationTimeout: 24 * 60 * 60 * 1000, // Default: 24 hours
      
      // Minimum confidence threshold for auto-approval
      autoApprovalThreshold: 0.95,
      
      // Maximum number of pending validations per reviewer
      maxPendingPerReviewer: 20,
      
      // Prioritization weights
      prioritization: {
        urgency: 0.4,
        impact: 0.4,
        confidence: 0.2
      },
      
      ...options
    };
    
    // Event emitter for notifications
    this.events = new EventEmitter();
    
    // Store pending validations
    this.pendingValidations = new Map();
    
    // Store reviewer assignments
    this.reviewerAssignments = new Map();
    
    // Error classification taxonomy
    this.errorTaxonomy = {
      spelling: {
        name: 'Spelling Error',
        description: 'Incorrect spelling of words',
        examples: ['teh' instead of 'the', 'recieve' instead of 'receive']
      },
      grammar: {
        name: 'Grammar Error',
        description: 'Incorrect grammar usage',
        examples: ['He have a book', 'They was going']
      },
      style: {
        name: 'Style Issue',
        description: 'Problems with writing style or tone',
        examples: ['Inconsistent tone', 'Overly complex sentences']
      },
      factual: {
        name: 'Factual Error',
        description: 'Incorrect facts or information',
        examples: ['Paris is the capital of Italy', 'The moon is made of cheese']
      },
      logic: {
        name: 'Logical Error',
        description: 'Errors in reasoning or narrative logic',
        examples: ['Contradictory statements', 'Plot holes']
      },
      context: {
        name: 'Context Error',
        description: 'Misunderstanding or ignoring context',
        examples: ['Inappropriate suggestions', 'Missing the point of the text']
      }
    };
  }
  
  /**
   * Submit a correction for human validation
   * @param {Object} correction - The correction to validate
   * @returns {string} - Validation ID
   */
  async submitForValidation(correction) {
    try {
      // Generate validation ID
      const validationId = `val_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      // Calculate priority score
      const priorityScore = this.calculatePriorityScore(correction);
      
      // Create validation request
      const validationRequest = {
        id: validationId,
        correction,
        status: 'pending',
        submittedAt: new Date(),
        priorityScore,
        reviewers: [],
        reviews: [],
        expiresAt: new Date(Date.now() + this.options.validationTimeout)
      };
      
      // Store in pending validations
      this.pendingValidations.set(validationId, validationRequest);
      
      console.log(`Submitted correction for validation: ${validationId}`);
      
      // Check if we can auto-approve based on confidence
      if (correction.confidence >= this.options.autoApprovalThreshold) {
        console.log(`Auto-approving high-confidence correction: ${validationId}`);
        await this.processValidationResult(validationId, true, 'auto-approved', null);
        return validationId;
      }
      
      // Assign reviewers
      await this.assignReviewers(validationId);
      
      // Set expiration timer
      setTimeout(() => {
        this.handleExpiredValidation(validationId);
      }, this.options.validationTimeout);
      
      return validationId;
    } catch (error) {
      console.error('Error submitting correction for validation:', error);
      throw error;
    }
  }
  
  /**
   * Calculate priority score for a correction
   * @param {Object} correction - The correction to prioritize
   * @returns {number} - Priority score (0-1)
   */
  calculatePriorityScore(correction) {
    // Calculate urgency based on deadline or context
    const urgency = correction.deadline ? 
      Math.min(1, (new Date(correction.deadline) - new Date()) / (24 * 60 * 60 * 1000)) : 
      correction.urgency || 0.5;
    
    // Calculate impact based on severity and scope
    const impact = correction.impact || 
      (correction.severity ? correction.severity / 10 : 0.5);
    
    // Get confidence score
    const confidence = 1 - (correction.confidence || 0.5);
    
    // Calculate weighted score
    const score = (
      urgency * this.options.prioritization.urgency +
      impact * this.options.prioritization.impact +
      confidence * this.options.prioritization.confidence
    );
    
    return Math.min(1, Math.max(0, score));
  }
  
  /**
   * Assign reviewers to a validation request
   * @param {string} validationId - ID of the validation request
   */
  async assignReviewers(validationId) {
    try {
      const validationRequest = this.pendingValidations.get(validationId);
      
      if (!validationRequest) {
        throw new Error(`Validation request not found: ${validationId}`);
      }
      
      // In a real implementation, this would query a database of available reviewers
      // with appropriate expertise for the specific correction type
      
      // For now, we'll simulate finding available reviewers
      const availableReviewers = await this.findAvailableReviewers(validationRequest.correction);
      
      if (availableReviewers.length === 0) {
        console.log(`No available reviewers for validation: ${validationId}`);
        return;
      }
      
      // Assign to reviewers
      for (const reviewer of availableReviewers) {
        // Add to validation request
        validationRequest.reviewers.push(reviewer.id);
        
        // Update reviewer assignments
        if (!this.reviewerAssignments.has(reviewer.id)) {
          this.reviewerAssignments.set(reviewer.id, []);
        }
        this.reviewerAssignments.get(reviewer.id).push(validationId);
        
        // Notify reviewer
        this.events.emit('reviewer_assigned', {
          reviewerId: reviewer.id,
          validationId,
          correction: validationRequest.correction
        });
      }
      
      console.log(`Assigned ${validationRequest.reviewers.length} reviewers to validation: ${validationId}`);
    } catch (error) {
      console.error(`Error assigning reviewers to validation ${validationId}:`, error);
    }
  }
  
  /**
   * Find available reviewers for a correction
   * @param {Object} correction - The correction to find reviewers for
   * @returns {Array} - Available reviewers
   */
  async findAvailableReviewers(correction) {
    try {
      // In a real implementation, this would query a database of reviewers
      // based on expertise, availability, workload, etc.
      
      // For now, we'll simulate finding reviewers
      const mockReviewers = [
        { id: 'reviewer1', name: 'John Doe', expertise: ['grammar', 'spelling'], workload: 5 },
        { id: 'reviewer2', name: 'Jane Smith', expertise: ['style', 'logic'], workload: 8 },
        { id: 'reviewer3', name: 'Bob Johnson', expertise: ['factual', 'context'], workload: 3 }
      ];
      
      // Filter by expertise
      const relevantReviewers = mockReviewers.filter(reviewer => {
        return reviewer.expertise.includes(correction.errorType || 'grammar');
      });
      
      // Filter by workload
      const availableReviewers = relevantReviewers.filter(reviewer => {
        const currentAssignments = this.reviewerAssignments.get(reviewer.id) || [];
        return currentAssignments.length < this.options.maxPendingPerReviewer;
      });
      
      return availableReviewers;
    } catch (error) {
      console.error('Error finding available reviewers:', error);
      return [];
    }
  }
  
  /**
   * Submit a review for a validation request
   * @param {string} validationId - ID of the validation request
   * @param {string} reviewerId - ID of the reviewer
   * @param {boolean} approved - Whether the correction is approved
   * @param {string} feedback - Feedback from the reviewer
   * @param {Object} classification - Error classification
   * @returns {boolean} - Success status
   */
  async submitReview(validationId, reviewerId, approved, feedback, classification) {
    try {
      const validationRequest = this.pendingValidations.get(validationId);
      
      if (!validationRequest) {
        throw new Error(`Validation request not found: ${validationId}`);
      }
      
      // Check if reviewer is assigned
      if (!validationRequest.reviewers.includes(reviewerId)) {
        throw new Error(`Reviewer ${reviewerId} is not assigned to validation ${validationId}`);
      }
      
      // Create review
      const review = {
        reviewerId,
        approved,
        feedback,
        classification,
        submittedAt: new Date()
      };
      
      // Add to validation request
      validationRequest.reviews.push(review);
      
      console.log(`Received review for validation ${validationId} from reviewer ${reviewerId}: ${approved ? 'Approved' : 'Rejected'}`);
      
      // Check if we have enough reviews to make a decision
      if (this.canMakeDecision(validationRequest)) {
        await this.makeDecision(validationId);
      }
      
      return true;
    } catch (error) {
      console.error(`Error submitting review for validation ${validationId}:`, error);
      return false;
    }
  }
  
  /**
   * Check if we have enough reviews to make a decision
   * @param {Object} validationRequest - The validation request
   * @returns {boolean} - Whether we can make a decision
   */
  canMakeDecision(validationRequest) {
    // If we have reviews from all assigned reviewers, we can make a decision
    return validationRequest.reviews.length >= validationRequest.reviewers.length;
  }
  
  /**
   * Make a decision based on reviews
   * @param {string} validationId - ID of the validation request
   */
  async makeDecision(validationId) {
    try {
      const validationRequest = this.pendingValidations.get(validationId);
      
      if (!validationRequest) {
        throw new Error(`Validation request not found: ${validationId}`);
      }
      
      // Count approvals and rejections
      const approvals = validationRequest.reviews.filter(review => review.approved).length;
      const rejections = validationRequest.reviews.length - approvals;
      
      // Decision is approval if majority approved
      const approved = approvals > rejections;
      
      // Collect feedback
      const feedback = validationRequest.reviews
        .map(review => review.feedback)
        .filter(Boolean)
        .join('\n');
      
      // Collect classifications
      const classifications = validationRequest.reviews
        .map(review => review.classification)
        .filter(Boolean);
      
      // Process the validation result
      await this.processValidationResult(
        validationId, 
        approved, 
        approved ? 'approved' : 'rejected',
        feedback,
        classifications
      );
    } catch (error) {
      console.error(`Error making decision for validation ${validationId}:`, error);
    }
  }
  
  /**
   * Process the result of a validation
   * @param {string} validationId - ID of the validation request
   * @param {boolean} approved - Whether the correction is approved
   * @param {string} status - Status of the validation
   * @param {string} feedback - Feedback from reviewers
   * @param {Array} classifications - Error classifications
   */
  async processValidationResult(validationId, approved, status, feedback = null, classifications = []) {
    try {
      const validationRequest = this.pendingValidations.get(validationId);
      
      if (!validationRequest) {
        throw new Error(`Validation request not found: ${validationId}`);
      }
      
      // Update validation request
      validationRequest.status = status;
      validationRequest.completedAt = new Date();
      validationRequest.approved = approved;
      
      if (feedback) {
        validationRequest.feedback = feedback;
      }
      
      if (classifications && classifications.length > 0) {
        validationRequest.classifications = classifications;
      }
      
      console.log(`Validation ${validationId} ${status}: ${approved ? 'Approved' : 'Rejected'}`);
      
      // Emit event
      this.events.emit('validation_completed', {
        validationId,
        approved,
        status,
        feedback,
        classifications,
        correction: validationRequest.correction
      });
      
      // If approved, apply the correction
      if (approved) {
        await this.applyCorrection(validationRequest.correction);
      }
      
      // Store validation result for learning
      await this.storeValidationForLearning(validationRequest);
      
      // Clean up
      this.cleanupValidation(validationId);
    } catch (error) {
      console.error(`Error processing validation result for ${validationId}:`, error);
    }
  }
  
  /**
   * Apply an approved correction
   * @param {Object} correction - The correction to apply
   */
  async applyCorrection(correction) {
    try {
      // In a real implementation, this would update the content in the database
      // and notify relevant systems about the change
      
      console.log(`Applying correction: ${correction.id}`);
      
      // Emit event
      this.events.emit('correction_applied', {
        correction,
        appliedAt: new Date()
      });
      
      return true;
    } catch (error) {
      console.error('Error applying correction:', error);
      return false;
    }
  }
  
  /**
   * Store validation result for learning
   * @param {Object} validationRequest - The completed validation request
   */
  async storeValidationForLearning(validationRequest) {
    try {
      // In a real implementation, this would store the validation result
      // in a database for future learning and improvement
      
      console.log(`Storing validation for learning: ${validationRequest.id}`);
      
      // Extract learning data
      const learningData = {
        correction: validationRequest.correction,
        approved: validationRequest.approved,
        feedback: validationRequest.feedback,
        classifications: validationRequest.classifications,
        reviews: validationRequest.reviews.map(review => ({
          approved: review.approved,
          feedback: review.feedback,
          classification: review.classification
        }))
      };
      
      // Emit event
      this.events.emit('validation_stored', {
        validationId: validationRequest.id,
        learningData
      });
      
      return true;
    } catch (error) {
      console.error(`Error storing validation for learning: ${validationRequest.id}`, error);
      return false;
    }
  }
  
  /**
   * Handle expired validation requests
   * @param {string} validationId - ID of the validation request
   */
  async handleExpiredValidation(validationId) {
    try {
      const validationRequest = this.pendingValidations.get(validationId);
      
      if (!validationRequest || validationRequest.status !== 'pending') {
        // Already processed or doesn't exist
        return;
      }
      
      console.log(`Validation request expired: ${validationId}`);
      
      // If we have any reviews, make a decision based on them
      if (validationRequest.reviews.length > 0) {
        await this.makeDecision(validationId);
        return;
      }
      
      // Otherwise, reject the correction due to timeout
      await this.processValidationResult(
        validationId,
        false,
        'expired',
        'Validation request expired without reviews'
      );
    } catch (error) {
      console.error(`Error handling expired validation ${validationId}:`, error);
    }
  }
  
  /**
   * Clean up after validation is complete
   * @param {string} validationId - ID of the validation request
   */
  cleanupValidation(validationId) {
    try {
      const validationRequest = this.pendingValidations.get(validationId);
      
      if (!validationRequest) {
        return;
      }
      
      // Remove from reviewer assignments
      for (const reviewerId of validationRequest.reviewers) {
        const assignments = this.reviewerAssignments.get(reviewerId) || [];
        const updatedAssignments = assignments.filter(id => id !== validationId);
        this.reviewerAssignments.set(reviewerId, updatedAssignments);
      }
      
      // Keep the validation in the map for reference, but mark as processed
      validationRequest.processed = true;
    } catch (error) {
      console.error(`Error cleaning up validation ${validationId}:`, error);
    }
  }
  
  /**
   * Get validation request by ID
   * @param {string} validationId - ID of the validation request
   * @returns {Object} - Validation request
   */
  getValidation(validationId) {
    return this.pendingValidations.get(validationId);
  }
  
  /**
   * Get pending validations for a reviewer
   * @param {string} reviewerId - ID of the reviewer
   * @returns {Array} - Pending validations
   */
  getPendingValidationsForReviewer(reviewerId) {
    const assignments = this.reviewerAssignments.get(reviewerId) || [];
    
    return assignments
      .map(validationId => this.pendingValidations.get(validationId))
      .filter(validation => validation && validation.status === 'pending');
  }
  
  /**
   * Get error taxonomy
   * @returns {Object} - Error taxonomy
   */
  getErrorTaxonomy() {
    return this.errorTaxonomy;
  }
  
  /**
   * Register event listener
   * @param {string} event - Event name
   * @param {Function} listener - Event listener
   */
  on(event, listener) {
    this.events.on(event, listener);
    return this;
  }
  
  /**
   * Remove event listener
   * @param {string} event - Event name
   * @param {Function} listener - Event listener
   */
  off(event, listener) {
    this.events.off(event, listener);
    return this;
  }
}

module.exports = HumanValidationService;