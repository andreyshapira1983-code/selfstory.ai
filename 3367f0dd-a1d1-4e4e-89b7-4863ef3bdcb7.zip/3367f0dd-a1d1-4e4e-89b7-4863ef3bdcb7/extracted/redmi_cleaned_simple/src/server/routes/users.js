const express = require('express');
const router = express.Router();

// Mock database for users (in a real app, this would be a MongoDB collection)
const users = [
  {
    id: 'user1',
    name: 'Alex Chen',
    email: 'alex@example.com',
    color: '#3B82F6',
    avatar: null,
    createdAt: '2025-01-15T10:00:00Z'
  },
  {
    id: 'user2',
    name: 'Maya Johnson',
    email: 'maya@example.com',
    color: '#10B981',
    avatar: null,
    createdAt: '2025-02-20T14:30:00Z'
  },
  {
    id: 'user3',
    name: 'Sam Taylor',
    email: 'sam@example.com',
    color: '#F59E0B',
    avatar: null,
    createdAt: '2025-03-10T09:15:00Z'
  },
  {
    id: 'user4',
    name: 'Jordan Lee',
    email: 'jordan@example.com',
    color: '#EF4444',
    avatar: null,
    createdAt: '2025-04-05T16:45:00Z'
  }
];

// Get all users
router.get('/', (req, res) => {
  // In a real app, we would filter and paginate
  // Also, we would not return sensitive information
  const safeUsers = users.map(({ id, name, color, avatar }) => ({
    id,
    name,
    color,
    avatar
  }));
  
  res.json(safeUsers);
});

// Get a specific user
router.get('/:id', (req, res) => {
  const user = users.find(u => u.id === req.params.id);
  
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }
  
  // Don't return sensitive information
  const { id, name, color, avatar, createdAt } = user;
  
  res.json({ id, name, color, avatar, createdAt });
});

// Create a new user (simplified, no authentication)
router.post('/', (req, res) => {
  const { name, email, color } = req.body;
  
  // Validate required fields
  if (!name || !email) {
    return res.status(400).json({ message: 'Name and email are required' });
  }
  
  // Check if email already exists
  if (users.some(u => u.email === email)) {
    return res.status(409).json({ message: 'Email already in use' });
  }
  
  // Create a new user
  const newUser = {
    id: `user${users.length + 1}`,
    name,
    email,
    color: color || `#${Math.floor(Math.random() * 16777215).toString(16)}`,
    avatar: null,
    createdAt: new Date().toISOString()
  };
  
  // In a real app, we would save to the database
  users.push(newUser);
  
  // Don't return sensitive information
  const { id, color: userColor, avatar, createdAt } = newUser;
  
  res.status(201).json({ id, name, color: userColor, avatar, createdAt });
});

// Update a user
router.put('/:id', (req, res) => {
  const { name, color, avatar } = req.body;
  const userIndex = users.findIndex(u => u.id === req.params.id);
  
  if (userIndex === -1) {
    return res.status(404).json({ message: 'User not found' });
  }
  
  // In a real app, we would check permissions
  
  // Update the user
  const updatedUser = {
    ...users[userIndex],
    name: name || users[userIndex].name,
    color: color || users[userIndex].color,
    avatar: avatar !== undefined ? avatar : users[userIndex].avatar
  };
  
  users[userIndex] = updatedUser;
  
  // Don't return sensitive information
  const { id, name: userName, color: userColor, avatar: userAvatar, createdAt } = updatedUser;
  
  res.json({ id, name: userName, color: userColor, avatar: userAvatar, createdAt });
});

// Delete a user
router.delete('/:id', (req, res) => {
  const userIndex = users.findIndex(u => u.id === req.params.id);
  
  if (userIndex === -1) {
    return res.status(404).json({ message: 'User not found' });
  }
  
  // In a real app, we would check permissions
  
  // Remove the user
  const deletedUser = users.splice(userIndex, 1)[0];
  
  // Don't return sensitive information
  const { id, name, color, avatar } = deletedUser;
  
  res.json({ message: 'User deleted successfully', user: { id, name, color, avatar } });
});

module.exports = router;