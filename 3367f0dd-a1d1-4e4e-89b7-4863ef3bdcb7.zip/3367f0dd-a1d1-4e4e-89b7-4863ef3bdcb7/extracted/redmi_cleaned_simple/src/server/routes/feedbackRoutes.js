/**
 * Feedback Routes
 * 
 * This file defines the API routes for feedback collection and management.
 */

const express = require('express');
const router = express.Router();
const feedbackController = require('../controllers/feedbackController');
const authMiddleware = require('../middleware/auth');

// Apply authentication middleware to all routes
router.use(authMiddleware.authenticate);

/**
 * @route   POST /api/feedback/suggestion
 * @desc    Submit feedback for an AI suggestion
 * @access  Private
 */
router.post('/suggestion', feedbackController.submitSuggestionFeedback);

/**
 * @route   POST /api/feedback/language
 * @desc    Submit language-specific feedback
 * @access  Private
 */
router.post('/language', feedbackController.submitLanguageFeedback);

/**
 * @route   POST /api/feedback/validation
 * @desc    Submit human validation result
 * @access  Private (Reviewer role)
 */
router.post('/validation', 
  authMiddleware.checkRole(['admin', 'reviewer']), 
  feedbackController.submitValidationResult
);

/**
 * @route   GET /api/feedback/metrics
 * @desc    Get feedback metrics and statistics
 * @access  Private (Admin role)
 */
router.get('/metrics', 
  authMiddleware.checkRole(['admin']), 
  feedbackController.getFeedbackMetrics
);

/**
 * @route   GET /api/feedback/prompts/:language
 * @desc    Get language-specific feedback prompts
 * @access  Private
 */
router.get('/prompts/:language', feedbackController.getLanguageFeedbackPrompts);

/**
 * @route   GET /api/feedback/taxonomy
 * @desc    Get error taxonomy
 * @access  Private
 */
router.get('/taxonomy', feedbackController.getErrorTaxonomy);

module.exports = router;