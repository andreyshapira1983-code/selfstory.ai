/**
 * Validation Middleware
 * 
 * Provides request validation functions for different routes
 */

// Validate user registration
exports.validateUserRegistration = (req, res, next) => {
  const { name, email, password } = req.body;
  const errors = [];

  // Check required fields
  if (!name) errors.push('Name is required');
  if (!email) errors.push('Email is required');
  if (!password) errors.push('Password is required');

  // Validate email format
  if (email && !isValidEmail(email)) {
    errors.push('Please provide a valid email');
  }

  // Validate password length
  if (password && password.length < 6) {
    errors.push('Password must be at least 6 characters');
  }

  // Return errors if any
  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: errors.join(', ')
    });
  }

  next();
};

// Validate user login
exports.validateUserLogin = (req, res, next) => {
  const { email, password } = req.body;
  const errors = [];

  // Check required fields
  if (!email) errors.push('Email is required');
  if (!password) errors.push('Password is required');

  // Return errors if any
  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: errors.join(', ')
    });
  }

  next();
};

// Validate story creation
exports.validateStoryCreation = (req, res, next) => {
  const { title } = req.body;
  const errors = [];

  // Check required fields
  if (!title) errors.push('Title is required');

  // Validate title length
  if (title && title.length > 100) {
    errors.push('Title cannot be more than 100 characters');
  }

  // Return errors if any
  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: errors.join(', ')
    });
  }

  next();
};

// Validate comment creation
exports.validateCommentCreation = (req, res, next) => {
  const { content, position } = req.body;
  const errors = [];

  // Check required fields
  if (!content) errors.push('Comment content is required');
  if (!position) errors.push('Comment position is required');
  if (position && (position.from === undefined || position.to === undefined)) {
    errors.push('Comment position must include from and to values');
  }

  // Return errors if any
  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: errors.join(', ')
    });
  }

  next();
};

// Validate collaborator addition
exports.validateCollaboratorAddition = (req, res, next) => {
  const { email, role } = req.body;
  const errors = [];

  // Check required fields
  if (!email) errors.push('Collaborator email is required');

  // Validate email format
  if (email && !isValidEmail(email)) {
    errors.push('Please provide a valid email');
  }

  // Validate role if provided
  if (role && !['editor', 'viewer'].includes(role)) {
    errors.push('Role must be either editor or viewer');
  }

  // Return errors if any
  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: errors.join(', ')
    });
  }

  next();
};

// Validate AI suggestion creation
exports.validateAISuggestionCreation = (req, res, next) => {
  const { type, content, position, originalText, suggestedText } = req.body;
  const errors = [];

  // Check required fields
  if (!type) errors.push('Suggestion type is required');
  if (!content) errors.push('Suggestion content is required');
  if (!position) errors.push('Suggestion position is required');
  if (!originalText) errors.push('Original text is required');
  if (!suggestedText) errors.push('Suggested text is required');

  // Validate position
  if (position && (position.from === undefined || position.to === undefined)) {
    errors.push('Suggestion position must include from and to values');
  }

  // Validate type
  const validTypes = ['grammar', 'style', 'content', 'plot', 'character', 'setting', 'dialogue', 'other'];
  if (type && !validTypes.includes(type)) {
    errors.push(`Type must be one of: ${validTypes.join(', ')}`);
  }

  // Return errors if any
  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: errors.join(', ')
    });
  }

  next();
};

// Helper function to validate email format
function isValidEmail(email) {
  const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  return emailRegex.test(email);
}