const Y = require('yjs');
const { setupWSConnection } = require('y-websocket/bin/utils');
const { MongodbPersistence } = require('y-mongodb');
const mongoose = require('mongoose');

// Map to store active documents
const documents = new Map();

// MongoDB connection for document persistence
let mongodbPersistence = null;

// Initialize MongoDB connection
const initMongoDB = async () => {
  if (mongodbPersistence) return mongodbPersistence;
  
  try {
    // Connect to MongoDB
    const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/story-ai';
    await mongoose.connect(MONGODB_URI);
    console.log('Connected to MongoDB for document persistence');
    
    // Create MongoDB persistence provider
    mongodbPersistence = new MongodbPersistence(MONGODB_URI, {
      collectionName: 'documents',
      flushSize: 100,
      multipleCollections: true
    });
    
    return mongodbPersistence;
  } catch (error) {
    console.error('Failed to connect to MongoDB:', error);
    return null;
  }
};

// Get or create a Y.js document
const getYDoc = async (documentId) => {
  if (!documents.has(documentId)) {
    const doc = new Y.Doc();
    documents.set(documentId, doc);
    
    // Try to load document from MongoDB
    try {
      const persistence = await initMongoDB();
      if (persistence) {
        const persistedYDoc = await persistence.getYDoc(documentId);
        if (persistedYDoc) {
          Y.applyUpdate(doc, Y.encodeStateAsUpdate(persistedYDoc));
          console.log(`Loaded document ${documentId} from MongoDB`);
        }
      }
    } catch (error) {
      console.error(`Error loading document ${documentId} from MongoDB:`, error);
    }
  }
  
  return documents.get(documentId);
};

// Set up WebSocket connection for a shared document
const setupWSSharedDoc = async (io, documentId, socket) => {
  const doc = await getYDoc(documentId);
  
  // Set up WebSocket connection using y-websocket
  setupWSConnection(socket, doc, null);
  
  // Set up document persistence
  try {
    const persistence = await initMongoDB();
    if (persistence) {
      // Store updates to MongoDB
      doc.on('update', (update) => {
        persistence.storeUpdate(documentId, update)
          .catch(err => console.error(`Error storing update for document ${documentId}:`, err));
      });
    }
  } catch (error) {
    console.error(`Error setting up persistence for document ${documentId}:`, error);
  }
  
  // Handle document events
  doc.on('update', (update, origin) => {
    // If the update is from this client, broadcast to others
    if (origin === socket.id) {
      socket.to(`document:${documentId}`).emit('document-update', {
        documentId,
        update: Array.from(update),
        origin: socket.id
      });
    }
  });
  
  return doc;
};

// Clean up a document when no clients are connected
const cleanupDocument = (documentId) => {
  if (documents.has(documentId)) {
    const doc = documents.get(documentId);
    doc.destroy();
    documents.delete(documentId);
    console.log(`Cleaned up document ${documentId}`);
  }
};

module.exports = {
  getYDoc,
  setupWSSharedDoc,
  cleanupDocument,
  initMongoDB
};