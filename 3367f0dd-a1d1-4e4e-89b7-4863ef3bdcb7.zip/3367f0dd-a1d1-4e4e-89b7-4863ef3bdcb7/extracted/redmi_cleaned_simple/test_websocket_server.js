/**
 * WebSocket Server Testing Script
 * 
 * This script tests the WebSocket server functionality for real-time collaboration
 * in the Story AI application.
 */

const io = require('socket.io-client');
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');

// API and WebSocket server URLs
const API_BASE_URL = 'http://localhost:3000/api';
const WS_SERVER_URL = 'http://localhost:3000';

// Test user credentials
const TEST_USERS = [
  {
    name: 'WebSocket Test User 1',
    email: `ws.test.user1.${Date.now()}@example.com`,
    password: 'password123',
    token: null,
    id: null
  },
  {
    name: 'WebSocket Test User 2',
    email: `ws.test.user2.${Date.now()}@example.com`,
    password: 'password123',
    token: null,
    id: null
  },
  {
    name: 'WebSocket Test User 3',
    email: `ws.test.user3.${Date.now()}@example.com`,
    password: 'password123',
    token: null,
    id: null
  }
];

// Test story data
const TEST_STORY = {
  title: 'WebSocket Test Story',
  description: 'This is a test story for WebSocket testing',
  content: 'Once upon a time, there was a WebSocket test story...',
  isPublic: true,
  tags: ['test', 'websocket', 'collaboration']
};

// Store IDs and clients
let storyId = null;
let documentId = null;
const clients = [];

// Create axios instance with authorization header
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Set auth token for requests
const setAuthToken = (token) => {
  if (token) {
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  } else {
    delete api.defaults.headers.common['Authorization'];
  }
};

// Register and login test users
async function setupTestUsers() {
  console.log('\n--- Setting up test users ---');
  
  try {
    for (let i = 0; i < TEST_USERS.length; i++) {
      const user = TEST_USERS[i];
      
      // Register user
      console.log(`Registering test user ${i + 1}...`);
      const registerResponse = await axios.post(`${API_BASE_URL}/users/register`, user);
      
      if (registerResponse.status === 201) {
        console.log(`\u2705 User ${i + 1} registration successful`);
        user.token = registerResponse.data.token;
        user.id = registerResponse.data.user._id;
      } else {
        console.error(`\u274c User ${i + 1} registration failed:`, registerResponse.status);
        return false;
      }
    }
    
    return true;
  } catch (error) {
    console.error('\u274c User setup failed:', error.response?.data || error.message);
    return false;
  }
}

// Create test story
async function createTestStory() {
  console.log('\n--- Creating test story ---');
  
  try {
    // Use first user to create story
    setAuthToken(TEST_USERS[0].token);
    
    // Create story
    console.log('Creating test story...');
    const createResponse = await api.post('/stories', TEST_STORY);
    
    if (createResponse.status === 201) {
      console.log('\u2705 Story creation successful');
      storyId = createResponse.data._id;
      documentId = createResponse.data.documentId;
      
      // Add other users as collaborators
      for (let i = 1; i < TEST_USERS.length; i++) {
        console.log(`Adding user ${i + 1} as collaborator...`);
        const addResponse = await api.post(`/stories/${storyId}/collaborators`, {
          email: TEST_USERS[i].email,
          role: 'editor'
        });
        
        if (addResponse.status === 201) {
          console.log(`\u2705 User ${i + 1} added as collaborator`);
        } else {
          console.error(`\u274c Failed to add user ${i + 1} as collaborator:`, addResponse.status);
          return false;
        }
      }
      
      return true;
    } else {
      console.error('\u274c Story creation failed:', createResponse.status);
      return false;
    }
  } catch (error) {
    console.error('\u274c Story creation failed:', error.response?.data || error.message);
    return false;
  }
}

// Connect WebSocket clients
function connectWebSocketClients() {
  return new Promise((resolve) => {
    console.log('\n--- Connecting WebSocket clients ---');
    
    let connectedCount = 0;
    
    for (let i = 0; i < TEST_USERS.length; i++) {
      const user = TEST_USERS[i];
      
      console.log(`Connecting user ${i + 1} to WebSocket server...`);
      
      // Create socket client with authentication
      const client = io(WS_SERVER_URL, {
        query: {
          token: user.token,
          documentId: documentId
        },
        transports: ['websocket']
      });
      
      // Store client
      clients.push(client);
      
      // Handle connection
      client.on('connect', () => {
        console.log(`\u2705 User ${i + 1} connected to WebSocket server`);
        client.userId = user.id;
        client.userName = user.name;
        
        // Join document room
        client.emit('join-document', {
          documentId,
          userId: user.id,
          userName: user.name
        });
        
        connectedCount++;
        
        // Resolve when all clients are connected
        if (connectedCount === TEST_USERS.length) {
          // Wait a bit to ensure all clients have joined the document
          setTimeout(() => {
            resolve(true);
          }, 1000);
        }
      });
      
      // Handle connection error
      client.on('connect_error', (error) => {
        console.error(`\u274c User ${i + 1} connection error:`, error.message);
        resolve(false);
      });
    }
  });
}

// Test document updates
function testDocumentUpdates() {
  return new Promise((resolve) => {
    console.log('\n--- Testing document updates ---');
    
    // Set up event listeners for all clients
    const updateReceivedCount = new Array(clients.length).fill(0);
    
    // Listen for document updates on all clients
    for (let i = 0; i < clients.length; i++) {
      clients[i].on('document-update', (data) => {
        console.log(`\u2705 User ${i + 1} received document update from ${data.userName}`);
        updateReceivedCount[i]++;
        
        // Check if all clients have received updates from all other clients
        const allUpdatesReceived = updateReceivedCount.every(count => count === clients.length - 1);
        if (allUpdatesReceived) {
          resolve(true);
        }
      });
    }
    
    // Send document updates from each client
    for (let i = 0; i < clients.length; i++) {
      setTimeout(() => {
        console.log(`User ${i + 1} sending document update...`);
        clients[i].emit('document-update', {
          documentId,
          userId: clients[i].userId,
          userName: clients[i].userName,
          update: {
            type: 'insert',
            position: i * 10,
            content: `Text from user ${i + 1}`
          }
        });
      }, i * 500); // Stagger updates to avoid race conditions
    }
    
    // Timeout in case not all updates are received
    setTimeout(() => {
      const missingUpdates = updateReceivedCount.map((count, index) => {
        return {
          user: index + 1,
          received: count,
          expected: clients.length - 1
        };
      }).filter(item => item.received < item.expected);
      
      if (missingUpdates.length > 0) {
        console.error('\u274c Not all document updates were received:');
        missingUpdates.forEach(item => {
          console.error(`  User ${item.user}: received ${item.received}/${item.expected} updates`);
        });
        resolve(false);
      }
    }, 5000);
  });
}

// Test cursor position updates
function testCursorPositions() {
  return new Promise((resolve) => {
    console.log('\n--- Testing cursor position updates ---');
    
    // Set up event listeners for all clients
    const cursorUpdateReceivedCount = new Array(clients.length).fill(0);
    
    // Listen for cursor updates on all clients
    for (let i = 0; i < clients.length; i++) {
      clients[i].on('cursor-update', (data) => {
        console.log(`\u2705 User ${i + 1} received cursor update from ${data.userName}`);
        cursorUpdateReceivedCount[i]++;
        
        // Check if all clients have received cursor updates from all other clients
        const allCursorUpdatesReceived = cursorUpdateReceivedCount.every(count => count === clients.length - 1);
        if (allCursorUpdatesReceived) {
          resolve(true);
        }
      });
    }
    
    // Send cursor position updates from each client
    for (let i = 0; i < clients.length; i++) {
      setTimeout(() => {
        console.log(`User ${i + 1} sending cursor update...`);
        clients[i].emit('cursor-update', {
          documentId,
          userId: clients[i].userId,
          userName: clients[i].userName,
          cursor: {
            position: i * 20,
            selection: {
              from: i * 20,
              to: i * 20 + 5
            }
          }
        });
      }, i * 500); // Stagger updates to avoid race conditions
    }
    
    // Timeout in case not all updates are received
    setTimeout(() => {
      const missingUpdates = cursorUpdateReceivedCount.map((count, index) => {
        return {
          user: index + 1,
          received: count,
          expected: clients.length - 1
        };
      }).filter(item => item.received < item.expected);
      
      if (missingUpdates.length > 0) {
        console.error('\u274c Not all cursor updates were received:');
        missingUpdates.forEach(item => {
          console.error(`  User ${item.user}: received ${item.received}/${item.expected} updates`);
        });
        resolve(false);
      }
    }, 5000);
  });
}

// Test user presence
function testUserPresence() {
  return new Promise((resolve) => {
    console.log('\n--- Testing user presence ---');
    
    // Set up event listeners for all clients
    const presenceUpdateReceivedCount = new Array(clients.length).fill(0);
    
    // Listen for presence updates on all clients
    for (let i = 0; i < clients.length; i++) {
      clients[i].on('user-presence', (data) => {
        console.log(`\u2705 User ${i + 1} received presence update for ${data.users.length} users`);
        presenceUpdateReceivedCount[i]++;
        
        // Check if presence data includes all users
        if (data.users.length === clients.length) {
          console.log(`\u2705 User ${i + 1} received complete presence data`);
          
          // Check if all clients have received presence updates
          const allPresenceUpdatesReceived = presenceUpdateReceivedCount.every(count => count > 0);
          if (allPresenceUpdatesReceived) {
            resolve(true);
          }
        }
      });
    }
    
    // Request presence data from each client
    for (let i = 0; i < clients.length; i++) {
      setTimeout(() => {
        console.log(`User ${i + 1} requesting presence data...`);
        clients[i].emit('get-presence', { documentId });
      }, i * 500); // Stagger requests to avoid race conditions
    }
    
    // Timeout in case not all updates are received
    setTimeout(() => {
      const missingUpdates = presenceUpdateReceivedCount.map((count, index) => {
        return {
          user: index + 1,
          received: count,
          expected: 1
        };
      }).filter(item => item.received < item.expected);
      
      if (missingUpdates.length > 0) {
        console.error('\u274c Not all presence updates were received:');
        missingUpdates.forEach(item => {
          console.error(`  User ${item.user}: received ${item.received}/${item.expected} updates`);
        });
        resolve(false);
      }
    }, 5000);
  });
}

// Test disconnection and reconnection
function testDisconnectionAndReconnection() {
  return new Promise((resolve) => {
    console.log('\n--- Testing disconnection and reconnection ---');
    
    // Disconnect the first client
    console.log('Disconnecting User 1...');
    clients[0].disconnect();
    
    // Set up event listeners for remaining clients
    let disconnectNotificationCount = 0;
    
    // Listen for user left notifications on remaining clients
    for (let i = 1; i < clients.length; i++) {
      clients[i].once('user-left', (data) => {
        console.log(`\u2705 User ${i + 1} received notification that User 1 left`);
        disconnectNotificationCount++;
        
        // Check if all remaining clients received the notification
        if (disconnectNotificationCount === clients.length - 1) {
          console.log('All clients notified of User 1 disconnection');
          
          // Now reconnect the first client
          reconnectFirstClient();
        }
      });
    }
    
    // Function to reconnect the first client
    function reconnectFirstClient() {
      console.log('Reconnecting User 1...');
      
      // Create new socket for first user
      const newClient = io(WS_SERVER_URL, {
        query: {
          token: TEST_USERS[0].token,
          documentId: documentId
        },
        transports: ['websocket']
      });
      
      // Handle connection
      newClient.on('connect', () => {
        console.log('\u2705 User 1 reconnected to WebSocket server');
        newClient.userId = TEST_USERS[0].id;
        newClient.userName = TEST_USERS[0].name;
        
        // Join document room
        newClient.emit('join-document', {
          documentId,
          userId: TEST_USERS[0].id,
          userName: TEST_USERS[0].name
        });
        
        // Replace the old client
        clients[0] = newClient;
        
        // Set up event listeners for reconnection notifications
        let reconnectNotificationCount = 0;
        
        // Listen for user joined notifications on remaining clients
        for (let i = 1; i < clients.length; i++) {
          clients[i].once('user-joined', (data) => {
            console.log(`\u2705 User ${i + 1} received notification that User 1 rejoined`);
            reconnectNotificationCount++;
            
            // Check if all remaining clients received the notification
            if (reconnectNotificationCount === clients.length - 1) {
              console.log('All clients notified of User 1 reconnection');
              resolve(true);
            }
          });
        }
        
        // Timeout in case not all notifications are received
        setTimeout(() => {
          if (reconnectNotificationCount < clients.length - 1) {
            console.error(`\u274c Only ${reconnectNotificationCount}/${clients.length - 1} clients received reconnection notification`);
            resolve(false);
          }
        }, 3000);
      });
      
      // Handle connection error
      newClient.on('connect_error', (error) => {
        console.error('\u274c User 1 reconnection error:', error.message);
        resolve(false);
      });
    }
    
    // Timeout in case not all notifications are received
    setTimeout(() => {
      if (disconnectNotificationCount < clients.length - 1) {
        console.error(`\u274c Only ${disconnectNotificationCount}/${clients.length - 1} clients received disconnection notification`);
        resolve(false);
      }
    }, 3000);
  });
}

// Clean up test data
async function cleanupTestData() {
  console.log('\n--- Cleaning up test data ---');
  
  try {
    // Disconnect all WebSocket clients
    console.log('Disconnecting all WebSocket clients...');
    clients.forEach(client => {
      if (client.connected) {
        client.disconnect();
      }
    });
    console.log('\u2705 All WebSocket clients disconnected');
    
    // Delete test story
    console.log('Deleting test story...');
    setAuthToken(TEST_USERS[0].token);
    await api.delete(`/stories/${storyId}`);
    console.log('\u2705 Test story deleted successfully');
    
    // Delete test users
    console.log('Deleting test users...');
    for (let i = 0; i < TEST_USERS.length; i++) {
      setAuthToken(TEST_USERS[i].token);
      await api.delete(`/users/${TEST_USERS[i].id}`);
      console.log(`\u2705 Test user ${i + 1} deleted successfully`);
    }
    
    console.log('\u2705 All test data cleaned up successfully');
    return true;
  } catch (error) {
    console.error('\u274c Cleanup failed:', error.response?.data || error.message);
    return false;
  }
}

// Run all tests
async function runTests() {
  console.log('=== Starting WebSocket Server Tests ===\n');
  
  try {
    // Setup test users
    const usersSetup = await setupTestUsers();
    if (!usersSetup) {
      console.error('Cannot proceed with tests due to user setup failure');
      return;
    }
    
    // Create test story
    const storyCreated = await createTestStory();
    if (!storyCreated) {
      console.error('Cannot proceed with tests due to story creation failure');
      await cleanupTestData();
      return;
    }
    
    // Connect WebSocket clients
    const clientsConnected = await connectWebSocketClients();
    if (!clientsConnected) {
      console.error('Cannot proceed with tests due to WebSocket connection failure');
      await cleanupTestData();
      return;
    }
    
    // Test document updates
    const documentUpdatesResult = await testDocumentUpdates();
    
    // Test cursor position updates
    const cursorPositionsResult = await testCursorPositions();
    
    // Test user presence
    const userPresenceResult = await testUserPresence();
    
    // Test disconnection and reconnection
    const disconnectionResult = await testDisconnectionAndReconnection();
    
    // Clean up test data
    await cleanupTestData();
    
    // Print test summary
    console.log('\n=== WebSocket Server Test Summary ===');
    console.log(`Document Updates: ${documentUpdatesResult ? '\u2705 PASSED' : '\u274c FAILED'}`);
    console.log(`Cursor Positions: ${cursorPositionsResult ? '\u2705 PASSED' : '\u274c FAILED'}`);
    console.log(`User Presence: ${userPresenceResult ? '\u2705 PASSED' : '\u274c FAILED'}`);
    console.log(`Disconnection & Reconnection: ${disconnectionResult ? '\u2705 PASSED' : '\u274c FAILED'}`);
    
    const allPassed = documentUpdatesResult && cursorPositionsResult && 
                      userPresenceResult && disconnectionResult;
    
    console.log(`\nOverall Test Result: ${allPassed ? '\u2705 ALL TESTS PASSED' : '\u274c SOME TESTS FAILED'}`);
    
  } catch (error) {
    console.error('\n\u274c Test execution failed:', error.message);
    await cleanupTestData();
  }
}

// Run the tests
runTests().catch(error => {
  console.error('Test execution failed:', error);
});