const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

console.log('🚀 Starting StoryAI in production mode...');

// Check if the dist directory exists
const distPath = path.join(__dirname, '../dist');
if (!fs.existsSync(distPath)) {
  console.log('📦 Building the application...');
  try {
    execSync('npm run build', { stdio: 'inherit', cwd: path.join(__dirname, '..') });
    console.log('✅ Build completed successfully');
  } catch (error) {
    console.error('❌ Build failed:', error.message);
    process.exit(1);
  }
} else {
  console.log('✅ Using existing build in dist directory');
}

// Set environment variables
process.env.NODE_ENV = 'production';

// Start the server
console.log('🌐 Starting the server...');
try {
  // Use execSync with inherit to keep the process running and show logs
  execSync('node src/server/index.js', { 
    stdio: 'inherit', 
    cwd: path.join(__dirname, '..'),
    env: { ...process.env, NODE_ENV: 'production' }
  });
} catch (error) {
  console.error('❌ Server failed to start:', error.message);
  process.exit(1);
}