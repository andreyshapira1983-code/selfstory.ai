const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('Setting up StoryAI project...');

// Check if .env file exists, create if not
const envPath = path.join(__dirname, '../.env');
if (!fs.existsSync(envPath)) {
  console.log('Creating .env file...');
  fs.copyFileSync(
    path.join(__dirname, '../.env.example'), 
    envPath
  );
  console.log('✅ .env file created');
} else {
  console.log('✅ .env file already exists');
}

// Install dependencies
try {
  console.log('Installing dependencies...');
  execSync('npm install', { stdio: 'inherit' });
  console.log('✅ Dependencies installed');
} catch (error) {
  console.error('❌ Failed to install dependencies:', error.message);
  process.exit(1);
}

// Create necessary directories
const directories = [
  'public/assets',
  'public/assets/images',
  'src/client/utils',
  'src/server/controllers',
  'src/server/models',
  'src/server/routes'
];

console.log('Creating directory structure...');
directories.forEach(dir => {
  const dirPath = path.join(__dirname, '..', dir);
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
    console.log(`✅ Created ${dir}`);
  } else {
    console.log(`✅ ${dir} already exists`);
  }
});

// Create a sample .env.example file if it doesn't exist
const envExamplePath = path.join(__dirname, '../.env.example');
if (!fs.existsSync(envExamplePath)) {
  console.log('Creating .env.example file...');
  fs.writeFileSync(
    envExamplePath,
    `# Server Configuration
PORT=5000
NODE_ENV=development

# Client Configuration
VITE_API_URL=http://localhost:5000
VITE_SOCKET_URL=http://localhost:5000

# AI Service (placeholder for future integration)
AI_SERVICE_URL=
AI_SERVICE_KEY=
`
  );
  console.log('✅ .env.example file created');
}

console.log('\n🚀 Setup complete! You can now start the development server with:');
console.log('npm run dev      # Start Vite development server');
console.log('npm run dev:all  # Start both client and server');
console.log('\nHappy coding! 🎉');