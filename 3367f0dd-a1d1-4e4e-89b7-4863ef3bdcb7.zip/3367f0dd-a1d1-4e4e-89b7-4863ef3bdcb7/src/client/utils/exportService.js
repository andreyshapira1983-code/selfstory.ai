/**
 * Export Service - Handles document export to various formats
 * 
 * This module provides utilities for:
 * - PDF export with customizable options
 * - ePub export for e-readers
 * - Manuscript formatting for submissions
 * - Print-ready formatting
 * - Cover page generation
 */

import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { saveAs } from 'file-saver';
import { marked } from 'marked';

/**
 * Convert HTML content to PDF
 * 
 * @param {Object} options - PDF export options
 * @param {string} options.content - HTML or Markdown content to export
 * @param {string} options.title - Document title
 * @param {string} options.author - Document author
 * @param {string} options.filename - Output filename (without extension)
 * @param {string} options.pageSize - Page size (A4, Letter, etc.)
 * @param {Object} options.margins - Page margins in mm
 * @param {string} options.font - Font family
 * @param {number} options.fontSize - Font size in pt
 * @param {boolean} options.includeHeader - Whether to include header
 * @param {boolean} options.includeFooter - Whether to include footer
 * @param {string} options.headerText - Custom header text
 * @param {string} options.footerText - Custom footer text
 * @returns {Promise<Blob>} - PDF blob
 */
export const exportToPDF = async ({
  content,
  title = 'Document',
  author = '',
  filename = 'document',
  pageSize = 'a4',
  margins = { top: 25, right: 20, bottom: 25, left: 20 },
  font = 'helvetica',
  fontSize = 12,
  includeHeader = true,
  includeFooter = true,
  headerText = '',
  footerText = ''
}) => {
  try {
    // Convert markdown to HTML if needed
    const isMarkdown = !content.startsWith('<');
    const htmlContent = isMarkdown ? marked(content) : content;
    
    // Create a temporary container for rendering
    const container = document.createElement('div');
    container.className = 'pdf-export-container';
    container.innerHTML = htmlContent;
    container.style.width = pageSize === 'a4' ? '210mm' : '216mm'; // A4 or Letter width
    container.style.padding = '0';
    container.style.fontFamily = font;
    container.style.fontSize = `${fontSize}pt`;
    container.style.lineHeight = '1.5';
    container.style.backgroundColor = 'white';
    container.style.color = 'black';
    
    // Temporarily append to document for rendering
    document.body.appendChild(container);
    
    // Create PDF with correct page size
    const pdfWidth = pageSize === 'a4' ? 210 : 216; // mm
    const pdfHeight = pageSize === 'a4' ? 297 : 279; // mm
    
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: pageSize
    });
    
    // Set document properties
    pdf.setProperties({
      title: title,
      author: author,
      creator: 'StoryAI Export Service',
      subject: title,
      keywords: 'story, document, export'
    });
    
    // Add title page
    pdf.setFontSize(24);
    pdf.text(title, pdfWidth / 2, 60, { align: 'center' });
    
    if (author) {
      pdf.setFontSize(16);
      pdf.text(`By ${author}`, pdfWidth / 2, 80, { align: 'center' });
    }
    
    pdf.setFontSize(12);
    pdf.text(`Generated with StoryAI`, pdfWidth / 2, pdfHeight - 30, { align: 'center' });
    pdf.text(`${new Date().toLocaleDateString()}`, pdfWidth / 2, pdfHeight - 20, { align: 'center' });
    
    // Add a new page for content
    pdf.addPage();
    
    // Render HTML to canvas
    const canvas = await html2canvas(container, {
      scale: 2, // Higher scale for better quality
      useCORS: true,
      logging: false
    });
    
    // Remove the temporary container
    document.body.removeChild(container);
    
    // Calculate the number of pages needed
    const contentHeight = canvas.height;
    const pageContentHeight = (pdfHeight - margins.top - margins.bottom) * canvas.width / (pdfWidth - margins.left - margins.right);
    const pageCount = Math.ceil(contentHeight / pageContentHeight);
    
    // Add content to PDF page by page
    for (let i = 0; i < pageCount; i++) {
      if (i > 0) {
        pdf.addPage();
      }
      
      // Calculate the portion of the canvas to use for this page
      const srcY = i * pageContentHeight;
      const srcHeight = Math.min(pageContentHeight, contentHeight - srcY);
      
      // Add the image to the PDF
      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      pdf.addImage(
        imgData,
        'JPEG',
        margins.left,
        margins.top,
        pdfWidth - margins.left - margins.right,
        (pdfHeight - margins.top - margins.bottom) * (srcHeight / pageContentHeight),
        '',
        'FAST'
      );
      
      // Add header if enabled
      if (includeHeader) {
        pdf.setFontSize(10);
        pdf.setTextColor(100, 100, 100);
        const header = headerText || title;
        pdf.text(header, pdfWidth / 2, 10, { align: 'center' });
      }
      
      // Add footer if enabled
      if (includeFooter) {
        pdf.setFontSize(10);
        pdf.setTextColor(100, 100, 100);
        const footer = footerText || `Page ${i + 2} of ${pageCount + 1}`; // +1 for title page
        pdf.text(footer, pdfWidth / 2, pdfHeight - 10, { align: 'center' });
      }
    }
    
    // Save the PDF
    const pdfBlob = pdf.output('blob');
    saveAs(pdfBlob, `${filename}.pdf`);
    
    return pdfBlob;
  } catch (error) {
    console.error('PDF export failed:', error);
    throw error;
  }
};

/**
 * Convert content to ePub format
 * 
 * @param {Object} options - ePub export options
 * @param {string} options.content - HTML or Markdown content to export
 * @param {string} options.title - Document title
 * @param {string} options.author - Document author
 * @param {string} options.filename - Output filename (without extension)
 * @param {string} options.coverImage - Cover image URL or data URL
 * @param {Array<Object>} options.chapters - Chapter definitions
 * @param {Object} options.metadata - Additional metadata
 * @returns {Promise<Blob>} - ePub blob
 */
export const exportToEpub = async ({
  content,
  title = 'Document',
  author = '',
  filename = 'document',
  coverImage = '',
  chapters = [],
  metadata = {}
}) => {
  try {
    // In a real implementation, this would use a library like epub-gen
    // For now, we'll simulate the export with a delay
    
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Create a simple text file as a placeholder
    const epubContent = `
EPUB EXPORT SIMULATION
======================

Title: ${title}
Author: ${author}
Date: ${new Date().toLocaleDateString()}

This is a simulated ePub export. In a real implementation, this would be a properly formatted ePub file.

Content Preview:
---------------
${content.substring(0, 500)}...

Chapters:
--------
${chapters.map(chapter => `- ${chapter.title}`).join('\n')}

Metadata:
--------
${Object.entries(metadata).map(([key, value]) => `${key}: ${value}`).join('\n')}
    `;
    
    const blob = new Blob([epubContent], { type: 'text/plain' });
    saveAs(blob, `${filename}.epub.txt`);
    
    return blob;
  } catch (error) {
    console.error('ePub export failed:', error);
    throw error;
  }
};

/**
 * Export content in manuscript format
 * 
 * @param {Object} options - Manuscript export options
 * @param {string} options.content - Content to export
 * @param {string} options.title - Document title
 * @param {string} options.author - Document author
 * @param {string} options.authorContact - Author contact information
 * @param {string} options.filename - Output filename (without extension)
 * @param {string} options.format - Manuscript format (standard, agent, publisher)
 * @returns {Promise<Blob>} - PDF blob
 */
export const exportToManuscript = async ({
  content,
  title = 'Document',
  author = '',
  authorContact = '',
  filename = 'manuscript',
  format = 'standard'
}) => {
  try {
    // Convert markdown to HTML
    const htmlContent = marked(content);
    
    // Create manuscript HTML based on format
    let manuscriptHtml = '';
    
    switch (format) {
      case 'agent':
        manuscriptHtml = `
          <div class="manuscript agent-format">
            <div class="manuscript-header">
              <div class="author-info">
                ${author}<br>
                ${authorContact}
              </div>
              <div class="word-count">
                Word Count: ${content.split(/\s+/).length}
              </div>
              <div class="title-block">
                <h1>${title.toUpperCase()}</h1>
                <h2>by ${author}</h2>
              </div>
            </div>
            <div class="manuscript-content">
              ${htmlContent}
            </div>
          </div>
        `;
        break;
        
      case 'publisher':
        manuscriptHtml = `
          <div class="manuscript publisher-format">
            <div class="manuscript-header">
              <div class="submission-info">
                SUBMISSION
              </div>
              <div class="author-info">
                ${author}<br>
                ${authorContact}
              </div>
              <div class="title-block">
                <h1>${title}</h1>
                <h2>by ${author}</h2>
              </div>
              <div class="word-count">
                Approximately ${content.split(/\s+/).length} words
              </div>
            </div>
            <div class="manuscript-content">
              ${htmlContent}
            </div>
          </div>
        `;
        break;
        
      default: // standard
        manuscriptHtml = `
          <div class="manuscript standard-format">
            <div class="manuscript-header">
              <div class="author-info">
                ${author}<br>
                ${authorContact}
              </div>
              <div class="title-block">
                <h1>${title.toUpperCase()}</h1>
                <h2>by ${author}</h2>
              </div>
            </div>
            <div class="manuscript-content">
              ${htmlContent}
            </div>
          </div>
        `;
    }
    
    // Create a temporary container with manuscript styling
    const container = document.createElement('div');
    container.innerHTML = manuscriptHtml;
    container.style.fontFamily = 'Courier, monospace';
    container.style.fontSize = '12pt';
    container.style.lineHeight = '2';
    container.style.maxWidth = '8.5in';
    container.style.margin = '1in';
    container.style.backgroundColor = 'white';
    container.style.color = 'black';
    
    // Add manuscript-specific styles
    const style = document.createElement('style');
    style.textContent = `
      .manuscript {
        font-family: Courier, monospace;
        font-size: 12pt;
        line-height: 2;
      }
      .manuscript-header {
        margin-bottom: 2in;
      }
      .author-info {
        text-align: left;
        margin-bottom: 1in;
      }
      .title-block {
        text-align: center;
        margin: 2in 0;
      }
      .title-block h1 {
        font-size: 14pt;
        font-weight: normal;
        margin-bottom: 0.5in;
      }
      .title-block h2 {
        font-size: 12pt;
        font-weight: normal;
      }
      .word-count {
        text-align: right;
        margin-bottom: 1in;
      }
      .manuscript-content p {
        text-indent: 0.5in;
        margin: 0;
      }
      .manuscript-content h1, 
      .manuscript-content h2, 
      .manuscript-content h3 {
        text-align: center;
        font-weight: normal;
        margin: 1in 0 0.5in 0;
      }
    `;
    container.appendChild(style);
    
    // Temporarily append to document for rendering
    document.body.appendChild(container);
    
    // Export to PDF with manuscript settings
    const pdfBlob = await exportToPDF({
      content: container.outerHTML,
      title,
      author,
      filename,
      pageSize: 'letter',
      margins: { top: 25, right: 25, bottom: 25, left: 25 },
      font: 'courier',
      fontSize: 12,
      includeHeader: false,
      includeFooter: true,
      footerText: `${title} / ${author} / Page `
    });
    
    // Remove the temporary container
    document.body.removeChild(container);
    
    return pdfBlob;
  } catch (error) {
    console.error('Manuscript export failed:', error);
    throw error;
  }
};

/**
 * Generate a cover page for a document
 * 
 * @param {Object} options - Cover page options
 * @param {string} options.title - Document title
 * @param {string} options.subtitle - Document subtitle
 * @param {string} options.author - Document author
 * @param {string} options.template - Cover template name
 * @param {string} options.backgroundImage - Background image URL
 * @param {string} options.backgroundColor - Background color
 * @param {string} options.textColor - Text color
 * @returns {Promise<Blob>} - Cover page as PNG blob
 */
export const generateCoverPage = async ({
  title = 'Document Title',
  subtitle = '',
  author = '',
  template = 'modern',
  backgroundImage = '',
  backgroundColor = '#4f46e5',
  textColor = '#ffffff'
}) => {
  try {
    // Create a container for the cover
    const container = document.createElement('div');
    container.className = `cover-template ${template}`;
    container.style.width = '600px';
    container.style.height = '900px';
    container.style.position = 'relative';
    container.style.overflow = 'hidden';
    
    // Apply background
    if (backgroundImage) {
      container.style.backgroundImage = `url(${backgroundImage})`;
      container.style.backgroundSize = 'cover';
      container.style.backgroundPosition = 'center';
    } else {
      container.style.backgroundColor = backgroundColor;
    }
    
    // Create cover content based on template
    let coverContent = '';
    
    switch (template) {
      case 'minimal':
        coverContent = `
          <div class="cover-content" style="
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            width: 80%;
            color: ${textColor};
          ">
            <h1 style="
              font-size: 48px;
              margin-bottom: 20px;
              font-weight: 700;
            ">${title}</h1>
            ${subtitle ? `<h2 style="
              font-size: 24px;
              margin-bottom: 40px;
              font-weight: 400;
              opacity: 0.8;
            ">${subtitle}</h2>` : ''}
            <p style="
              font-size: 24px;
              font-weight: 500;
            ">${author}</p>
          </div>
        `;
        break;
        
      case 'classic':
        coverContent = `
          <div class="cover-content" style="
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 80px 40px;
            box-sizing: border-box;
            color: ${textColor};
          ">
            <div style="text-align: center;">
              <h2 style="
                font-size: 24px;
                font-weight: 400;
                margin-bottom: 10px;
              ">${subtitle}</h2>
            </div>
            <div style="text-align: center;">
              <h1 style="
                font-size: 60px;
                font-weight: 700;
                margin-bottom: 0;
                line-height: 1.2;
              ">${title}</h1>
            </div>
            <div style="text-align: center;">
              <p style="
                font-size: 30px;
                font-weight: 500;
              ">${author}</p>
            </div>
          </div>
        `;
        break;
        
      default: // modern
        coverContent = `
          <div class="cover-content" style="
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            padding: 60px 40px;
            box-sizing: border-box;
            background: linear-gradient(transparent, rgba(0,0,0,0.7));
            color: ${textColor};
          ">
            <h1 style="
              font-size: 54px;
              margin-bottom: 10px;
              font-weight: 700;
            ">${title}</h1>
            ${subtitle ? `<h2 style="
              font-size: 24px;
              margin-bottom: 30px;
              font-weight: 400;
              opacity: 0.9;
            ">${subtitle}</h2>` : ''}
            <p style="
              font-size: 24px;
              font-weight: 500;
            ">${author}</p>
          </div>
        `;
    }
    
    container.innerHTML = coverContent;
    
    // Temporarily append to document for rendering
    document.body.appendChild(container);
    
    // Render to canvas
    const canvas = await html2canvas(container, {
      scale: 2, // Higher scale for better quality
      useCORS: true,
      logging: false
    });
    
    // Remove the temporary container
    document.body.removeChild(container);
    
    // Convert to PNG
    return new Promise((resolve) => {
      canvas.toBlob((blob) => {
        saveAs(blob, `${title.replace(/\s+/g, '_')}_cover.png`);
        resolve(blob);
      }, 'image/png');
    });
  } catch (error) {
    console.error('Cover generation failed:', error);
    throw error;
  }
};

export default {
  exportToPDF,
  exportToEpub,
  exportToManuscript,
  generateCoverPage
};