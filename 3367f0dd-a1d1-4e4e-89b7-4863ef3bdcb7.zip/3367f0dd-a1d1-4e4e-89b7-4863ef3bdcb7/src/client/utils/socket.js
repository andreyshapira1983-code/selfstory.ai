import { io } from 'socket.io-client';

/**
 * Socket.IO utility for real-time communication
 */

// Socket.IO server URL from environment variable or default
const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000';

// Create a socket instance
let socket;

/**
 * Initialize the socket connection
 * @returns {Object} - Socket instance
 */
export const initSocket = () => {
  if (!socket) {
    socket = io(SOCKET_URL, {
      transports: ['websocket', 'polling'],
      autoConnect: true
    });
    
    // Log connection events
    socket.on('connect', () => {
      console.log('Socket connected:', socket.id);
    });
    
    socket.on('disconnect', (reason) => {
      console.log('Socket disconnected:', reason);
    });
    
    socket.on('error', (error) => {
      console.error('Socket error:', error);
    });
  }
  
  return socket;
};

/**
 * Get the socket instance
 * @returns {Object|null} - Socket instance or null if not initialized
 */
export const getSocket = () => socket;

/**
 * Join a story room for collaborative editing
 * @param {string} storyId - Story ID
 */
export const joinStory = (storyId) => {
  if (!socket) {
    initSocket();
  }
  
  socket.emit('join-story', storyId);
};

/**
 * Leave a story room
 * @param {string} storyId - Story ID
 */
export const leaveStory = (storyId) => {
  if (socket) {
    socket.emit('leave-story', storyId);
  }
};

/**
 * Send a story update
 * @param {string} storyId - Story ID
 * @param {Object} data - Update data
 */
export const updateStory = (storyId, data) => {
  if (socket) {
    socket.emit('update-story', {
      storyId,
      ...data
    });
  }
};

/**
 * Listen for story updates
 * @param {Function} callback - Callback function
 * @returns {Function} - Unsubscribe function
 */
export const onStoryUpdate = (callback) => {
  if (!socket) {
    initSocket();
  }
  
  socket.on('story-updated', callback);
  
  // Return unsubscribe function
  return () => {
    socket.off('story-updated', callback);
  };
};

/**
 * Disconnect the socket
 */
export const disconnectSocket = () => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};

// Export all socket functions
export default {
  initSocket,
  getSocket,
  joinStory,
  leaveStory,
  updateStory,
  onStoryUpdate,
  disconnectSocket
};