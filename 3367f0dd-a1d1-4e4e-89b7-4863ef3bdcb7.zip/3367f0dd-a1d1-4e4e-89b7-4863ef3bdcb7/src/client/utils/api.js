/**
 * API utility for making requests to the server
 */

// Base URL from environment variable or default
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

/**
 * Make a request to the API
 * @param {string} endpoint - API endpoint
 * @param {Object} options - Fetch options
 * @returns {Promise<any>} - Response data
 */
const apiRequest = async (endpoint, options = {}) => {
  try {
    const url = `${API_URL}${endpoint}`;
    
    // Default headers
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers
    };
    
    // Make the request
    const response = await fetch(url, {
      ...options,
      headers
    });
    
    // Parse the response
    const data = await response.json();
    
    // Check if the request was successful
    if (!response.ok) {
      throw new Error(data.message || 'Something went wrong');
    }
    
    return data;
  } catch (error) {
    console.error('API request error:', error);
    throw error;
  }
};

/**
 * API methods for stories
 */
const stories = {
  /**
   * Get all stories
   * @returns {Promise<Array>} - Array of stories
   */
  getAll: () => apiRequest('/api/stories'),
  
  /**
   * Get a story by ID
   * @param {string} id - Story ID
   * @returns {Promise<Object>} - Story object
   */
  getById: (id) => apiRequest(`/api/stories/${id}`),
  
  /**
   * Create a new story
   * @param {Object} story - Story data
   * @returns {Promise<Object>} - Created story
   */
  create: (story) => apiRequest('/api/stories', {
    method: 'POST',
    body: JSON.stringify(story)
  }),
  
  /**
   * Update a story
   * @param {string} id - Story ID
   * @param {Object} story - Story data
   * @returns {Promise<Object>} - Updated story
   */
  update: (id, story) => apiRequest(`/api/stories/${id}`, {
    method: 'PUT',
    body: JSON.stringify(story)
  }),
  
  /**
   * Delete a story
   * @param {string} id - Story ID
   * @returns {Promise<Object>} - Response data
   */
  delete: (id) => apiRequest(`/api/stories/${id}`, {
    method: 'DELETE'
  })
};

/**
 * API methods for AI assistance
 */
const ai = {
  /**
   * Generate content with AI
   * @param {Object} params - Generation parameters
   * @returns {Promise<Object>} - Generated content
   */
  generate: (params) => apiRequest('/api/ai/generate', {
    method: 'POST',
    body: JSON.stringify(params)
  }),
  
  /**
   * Improve existing content
   * @param {Object} params - Improvement parameters
   * @returns {Promise<Object>} - Improved content
   */
  improve: (params) => apiRequest('/api/ai/improve', {
    method: 'POST',
    body: JSON.stringify(params)
  })
};

// Export the API methods
const api = {
  stories,
  ai
};

export default api;