import React, { useState } from 'react';

/**
 * WelcomeStep - The first step in the onboarding process
 * Introduces the user to StoryAI and collects their name
 */
const WelcomeStep = ({ onNext }) => {
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!name.trim()) {
      setError('Please enter your name to continue');
      return;
    }
    
    onNext(name.trim());
  };

  return (
    <div className="flex flex-col items-center">
      <div className="w-24 h-24 mb-6 rounded-full bg-primary flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
        </svg>
      </div>
      
      <h2 className="text-2xl font-bold mb-4">Welcome to StoryAI</h2>
      
      <div className="max-w-lg text-center mb-8">
        <p className="mb-4">
          StoryAI is your creative writing companion that helps you craft amazing stories with the power of AI.
        </p>
        <p className="mb-4">
          Whether you're looking to write a short story, novel, or just explore creative ideas, 
          StoryAI provides the tools and inspiration you need.
        </p>
        <p>
          Let's get started by personalizing your experience.
        </p>
      </div>
      
      <form onSubmit={handleSubmit} className="w-full max-w-md">
        <div className="mb-6">
          <label htmlFor="name" className="block text-sm font-medium mb-2">
            What should we call you?
          </label>
          <input
            type="text"
            id="name"
            className="input"
            placeholder="Enter your name"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              if (error) setError('');
            }}
          />
          {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
        </div>
        
        <div className="flex justify-center">
          <button type="submit" className="btn btn-primary btn-lg">
            Let's Begin
          </button>
        </div>
      </form>
      
      <div className="mt-12 p-6 bg-card rounded-lg shadow-sm border max-w-lg">
        <h3 className="font-semibold text-lg mb-3">What you'll do next:</h3>
        <ul className="space-y-2">
          <li className="flex items-center">
            <span className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center mr-3 text-sm">1</span>
            <span>Choose your favorite story genres</span>
          </li>
          <li className="flex items-center">
            <span className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center mr-3 text-sm">2</span>
            <span>Select a story template to start with</span>
          </li>
          <li className="flex items-center">
            <span className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center mr-3 text-sm">3</span>
            <span>Create your first AI-assisted story</span>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default WelcomeStep;