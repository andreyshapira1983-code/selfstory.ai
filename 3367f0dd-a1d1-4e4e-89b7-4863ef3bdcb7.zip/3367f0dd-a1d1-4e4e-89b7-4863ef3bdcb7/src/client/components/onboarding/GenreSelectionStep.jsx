import React, { useState } from 'react';

/**
 * GenreSelectionStep - Allows users to select their preferred genres
 * These preferences will be used to personalize templates and recommendations
 */
const GenreSelectionStep = ({ onNext, onBack, initialGenres = [] }) => {
  const [selectedGenres, setSelectedGenres] = useState(initialGenres);
  const [error, setError] = useState('');

  // Available genres with descriptions and icons
  const genres = [
    {
      id: 'fantasy',
      name: 'Fantasy',
      description: 'Magical worlds, mythical creatures, and epic adventures',
      icon: '🧙‍♂️',
      color: 'bg-purple-100 dark:bg-purple-900'
    },
    {
      id: 'sci-fi',
      name: 'Science Fiction',
      description: 'Futuristic technology, space exploration, and scientific concepts',
      icon: '🚀',
      color: 'bg-blue-100 dark:bg-blue-900'
    },
    {
      id: 'mystery',
      name: 'Mystery',
      description: 'Puzzling events, detective work, and suspenseful revelations',
      icon: '🔍',
      color: 'bg-yellow-100 dark:bg-yellow-900'
    },
    {
      id: 'romance',
      name: 'Romance',
      description: 'Love stories, relationships, and emotional connections',
      icon: '❤️',
      color: 'bg-red-100 dark:bg-red-900'
    },
    {
      id: 'horror',
      name: 'Horror',
      description: 'Fear-inducing tales, supernatural threats, and psychological terror',
      icon: '👻',
      color: 'bg-gray-100 dark:bg-gray-900'
    },
    {
      id: 'adventure',
      name: 'Adventure',
      description: 'Exciting journeys, exploration, and overcoming challenges',
      icon: '🗺️',
      color: 'bg-green-100 dark:bg-green-900'
    },
    {
      id: 'historical',
      name: 'Historical',
      description: 'Stories set in the past, often based on real events',
      icon: '📜',
      color: 'bg-amber-100 dark:bg-amber-900'
    },
    {
      id: 'cyberpunk',
      name: 'Cyberpunk',
      description: 'High-tech dystopias, hackers, and corporate control',
      icon: '🤖',
      color: 'bg-pink-100 dark:bg-pink-900'
    },
    {
      id: 'folk',
      name: 'Folk & Fairy Tales',
      description: 'Traditional stories, moral lessons, and cultural heritage',
      icon: '🧚',
      color: 'bg-emerald-100 dark:bg-emerald-900'
    },
    {
      id: 'dystopian',
      name: 'Dystopian',
      description: 'Societies gone wrong, oppression, and resistance',
      icon: '🏙️',
      color: 'bg-orange-100 dark:bg-orange-900'
    },
    {
      id: 'humor',
      name: 'Humor',
      description: 'Comedic situations, witty dialogue, and lighthearted stories',
      icon: '😂',
      color: 'bg-lime-100 dark:bg-lime-900'
    },
    {
      id: 'young-adult',
      name: 'Young Adult',
      description: 'Coming-of-age stories, teen protagonists, and identity themes',
      icon: '📚',
      color: 'bg-sky-100 dark:bg-sky-900'
    }
  ];

  const toggleGenre = (genreId) => {
    setSelectedGenres(prev => {
      if (prev.includes(genreId)) {
        return prev.filter(id => id !== genreId);
      } else {
        return [...prev, genreId];
      }
    });
    
    if (error) setError('');
  };

  const handleSubmit = () => {
    if (selectedGenres.length === 0) {
      setError('Please select at least one genre to continue');
      return;
    }
    
    onNext(selectedGenres);
  };

  return (
    <div className="flex flex-col">
      <p className="text-center mb-6">
        Select the genres you enjoy. This helps us personalize your experience and recommend templates.
      </p>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 border border-red-200 text-red-700 rounded-md">
          {error}
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {genres.map((genre) => (
          <div
            key={genre.id}
            className={`genre-card ${selectedGenres.includes(genre.id) ? 'selected' : ''} ${genre.color}`}
            onClick={() => toggleGenre(genre.id)}
          >
            <div className="flex items-center mb-2">
              <span className="text-2xl mr-2">{genre.icon}</span>
              <h3 className="font-semibold">{genre.name}</h3>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300">{genre.description}</p>
          </div>
        ))}
      </div>
      
      <div className="flex justify-between mt-6">
        <button 
          type="button" 
          className="btn btn-outline"
          onClick={onBack}
        >
          Back
        </button>
        
        <button 
          type="button" 
          className="btn btn-primary"
          onClick={handleSubmit}
        >
          Continue
        </button>
      </div>
      
      <div className="mt-6 text-center">
        <p className="text-sm text-gray-500">
          Selected: {selectedGenres.length} {selectedGenres.length === 1 ? 'genre' : 'genres'}
        </p>
      </div>
    </div>
  );
};

export default GenreSelectionStep;