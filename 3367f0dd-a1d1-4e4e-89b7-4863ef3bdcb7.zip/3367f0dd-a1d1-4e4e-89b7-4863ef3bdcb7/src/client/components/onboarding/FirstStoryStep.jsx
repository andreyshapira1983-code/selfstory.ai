import React, { useState, useEffect } from 'react';

/**
 * FirstStoryStep - Allows users to create their first story using the selected template
 * Includes AI assistance options and basic story controls
 */
const FirstStoryStep = ({ onComplete, onBack, template }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated] = useState(false);
  const [error, setError] = useState('');
  
  // Story controls
  const [tone, setTone] = useState('neutral'); // neutral, formal, casual, poetic, humorous
  const [length, setLength] = useState('medium'); // short, medium, long
  
  // Generate a title based on the template
  useEffect(() => {
    if (template) {
      // In a real app, this would call an API to generate a title
      // For now, we'll just use the template title with some modifications
      setTitle(`My ${template.title}`);
      
      // Set initial content from template preview
      setContent(template.preview);
    }
  }, [template]);

  // Generate a story based on the template and controls
  const generateStory = () => {
    if (!template) {
      setError('Please select a template first');
      return;
    }
    
    setGenerating(true);
    setError('');
    
    // In a real app, this would call an AI API to generate content
    // For now, we'll simulate a response after a delay
    setTimeout(() => {
      const storyIntros = {
        'romantic-encounter': `The café was crowded, but somehow their eyes met across the room. Sarah paused, her coffee halfway to her lips, as the stranger smiled. There was something familiar about him, though she was certain they had never met before.

"Is this seat taken?" he asked, gesturing to the empty chair at her table.

Sarah hesitated only briefly before nodding. "It is now," she replied with a smile.

As he sat down, introducing himself as Michael, Sarah couldn't help but feel that this chance meeting was somehow meant to be. The afternoon sun streamed through the windows, casting a golden glow over their conversation as they discovered shared interests and parallel life paths.

"It's strange," Michael said after they'd been talking for nearly an hour, "but I feel like I've known you for years."`,

        'mystery-mansion': `The mansion stood silent on the hill, its windows like watchful eyes observing Detective Claire Morgan as she approached. The gravel driveway crunched beneath her feet, announcing her arrival to whatever—or whoever—waited inside.

Three people had disappeared within these walls in the past month. Her job was to find out why.

"Quite the place, isn't it?" said Officer Reynolds, who had been first on the scene after the latest disappearance.

Claire nodded, studying the Victorian architecture with its ornate turrets and shadowed alcoves. "Who's the owner again?"

"That's part of the mystery. Property records show it belongs to the Blackwood Trust, but no one seems to know who controls the trust."

As they reached the massive oak door, Claire noticed something unusual—scratch marks on the threshold, as if someone had desperately tried to claw their way out.`,

        'space-adventure': `Captain Lena Zhang checked the ship's scanners again. "That's impossible," she whispered, but the readings remained unchanged. The planet before them—which appeared on no star charts—was showing signs of both advanced technology and life forms unlike any in the known galaxy.

"What do we do, Captain?" asked Navigator Suresh, his voice betraying his nervousness.

The exploratory vessel Horizon had been mapping this sector for three months without incident. They were supposed to be heading home next week. A discovery like this would change everything.

"Prepare a landing party," Lena decided. "Minimal crew, maximum precautions. Whatever's down there, the Alliance will want to know about it."

As the ship entered orbit, strange energy patterns began interfering with their systems. Through the viewport, they could see vast geometric structures on the surface that seemed to shift and change even as they watched.`,

        'fantasy-quest': `The old map trembled in Elian's hands as he stood at the edge of the Whispering Forest. According to the village elders, no one who had sought the Crystal of Alandria had ever returned. But if the legends were true, the Crystal could heal his sister from the wasting sickness.

"You don't have to do this alone," said Kira, his childhood friend who had insisted on accompanying him despite the dangers.

Elian traced the path marked on the parchment. "The map shows three trials we must overcome: the Forest of Illusions, the Chasm of Echoes, and the Guardian's Labyrinth."

A cool wind rustled through the ancient trees before them, carrying whispers that sounded almost like words. Elian took a deep breath, adjusted the sword at his hip, and took his first step into the forest.

The adventure that would change their world had begun.`,

        'horror-cabin': `The laughter stopped abruptly when they heard the knock at the door. Five friends turned to stare at the cabin's entrance, their card game forgotten.

"Who could that be?" whispered Mia. "The nearest town is twenty miles away."

"And in this storm?" added Jason, glancing at the windows where rain lashed against the glass.

The knock came again, more insistent this time.

Mark, always the brave one, stood up. "Probably just a hiker caught in the rain," he said, moving toward the door.

"Don't—" began Lily, but Mark had already turned the handle.

The door swung open to reveal... nothing. Just darkness and the sound of rain.

"Hello?" Mark called, peering outside.

That's when they noticed the footprints on the wooden floor—wet, muddy prints that led from the doorway into the cabin. Prints that hadn't been there moments before.`,

        'fairy-tale': `No one believed in magic anymore—no one except Mira. In a world of smartphones and self-driving cars, she alone saw the shimmer in the air when a wish was made, or noticed how plants grew better when sung to under the full moon.

Her grandmother had taught her to look for magic in everyday things before she passed away, leaving Mira a curious silver key with no apparent lock to open.

"When the time comes, you'll know what it's for," her grandmother had said.

That time arrived on Mira's sixteenth birthday, when a strange door appeared in her bedroom wall—a door that definitely hadn't been there before. The key fit perfectly.

Beyond the threshold lay not her apartment building's hallway, but a vast meadow under an impossibly blue sky, where flowers bloomed in colors she had never seen before and distant mountains floated among the clouds.`,

        'cyberpunk-heist': `The neon lights of the city reflected in the puddles as Rio plugged into the network. Her neural implants hummed as data flowed directly into her consciousness, the corporate security systems materializing in her mind as towering red walls.

"I'm in," she subvocalized to her team. "Security's tighter than we expected. They've added quantum encryption since our last intel."

"Can you crack it?" came Dex's voice through the implant.

Rio's fingers danced over her holographic interface. "Of course I can. But it'll take time we don't have."

From his lookout position, Vex cut in: "We've got company. Corporate security drones, three blocks out and closing."

The job was supposed to be simple: infiltrate MegaTech's servers, steal the prototype AI code, get out clean. Ten million credits split four ways. Now it was looking like a suicide mission.

"Plan B," decided Rio. "We're going loud."`,

        'historical-romance': `The ballroom was filled with the elite of London society, but she only had eyes for the gardener's son. Lady Eleanor Harrington knew her father would never approve—the Earl of Westmoreland had made it clear she was to marry Lord Blackwood before the season's end.

But Thomas had grown from the boy who taught her to climb trees into a man whose gaze made her heart flutter. Now he was here, at the Midsummer Ball, not as a servant but as the guest of the renowned painter he apprenticed under.

"You shouldn't be looking at me that way," Thomas murmured as they passed each other between dances. "People will talk."

"Let them," Eleanor replied, though she knew the consequences could be severe for both of them.

As the orchestra began a waltz, Thomas extended his hand in a gesture that defied every social boundary between them. "May I have this dance, my lady?"`
      };
      
      // Select the appropriate story based on template and modify based on controls
      let generatedStory = storyIntros[template.id] || template.preview;
      
      // In a real app, the tone and length would affect the AI generation
      // Here we'll just acknowledge it in the UI
      
      setContent(generatedStory);
      setGenerating(false);
      setGenerated(true);
    }, 2000);
  };

  const handleSubmit = () => {
    if (!title.trim()) {
      setError('Please enter a title for your story');
      return;
    }
    
    if (!content.trim()) {
      setError('Your story needs some content');
      return;
    }
    
    // Create the story object
    const story = {
      title: title.trim(),
      content: content.trim(),
      template: template?.id,
      controls: {
        tone,
        length
      },
      createdAt: new Date().toISOString()
    };
    
    onComplete(story);
  };

  return (
    <div className="flex flex-col">
      <p className="text-center mb-6">
        Let's create your first story! You can start with our AI-generated content and customize it, or write your own.
      </p>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 border border-red-200 text-red-700 rounded-md">
          {error}
        </div>
      )}
      
      <div className="mb-6">
        <label htmlFor="title" className="block text-sm font-medium mb-2">
          Story Title
        </label>
        <input
          type="text"
          id="title"
          className="input"
          placeholder="Enter a title for your story"
          value={title}
          onChange={(e) => {
            setTitle(e.target.value);
            if (error) setError('');
          }}
        />
      </div>
      
      {/* Story controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 p-4 bg-gray-50 rounded-lg dark:bg-gray-800">
        <div>
          <label htmlFor="tone" className="block text-sm font-medium mb-2">
            Tone
          </label>
          <select
            id="tone"
            className="input"
            value={tone}
            onChange={(e) => setTone(e.target.value)}
          >
            <option value="neutral">Neutral</option>
            <option value="formal">Formal</option>
            <option value="casual">Casual</option>
            <option value="poetic">Poetic</option>
            <option value="humorous">Humorous</option>
          </select>
        </div>
        
        <div>
          <label htmlFor="length" className="block text-sm font-medium mb-2">
            Length
          </label>
          <select
            id="length"
            className="input"
            value={length}
            onChange={(e) => setLength(e.target.value)}
          >
            <option value="short">Short</option>
            <option value="medium">Medium</option>
            <option value="long">Long</option>
          </select>
        </div>
      </div>
      
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <label htmlFor="content" className="block text-sm font-medium">
            Story Content
          </label>
          <button
            type="button"
            className="btn btn-sm btn-secondary"
            onClick={generateStory}
            disabled={generating}
          >
            {generating ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Generating...
              </>
            ) : generated ? 'Regenerate' : 'Generate with AI'}
          </button>
        </div>
        <textarea
          id="content"
          className="input min-h-[300px]"
          placeholder="Write your story here or generate one with AI..."
          value={content}
          onChange={(e) => {
            setContent(e.target.value);
            if (error) setError('');
          }}
        />
      </div>
      
      {/* Quick edit buttons */}
      {content && (
        <div className="flex flex-wrap gap-2 mb-6">
          <button type="button" className="btn btn-sm btn-outline">
            Improve Writing
          </button>
          <button type="button" className="btn btn-sm btn-outline">
            Make Longer
          </button>
          <button type="button" className="btn btn-sm btn-outline">
            Make Shorter
          </button>
          <button type="button" className="btn btn-sm btn-outline">
            More Descriptive
          </button>
          <button type="button" className="btn btn-sm btn-outline">
            More Dialogue
          </button>
        </div>
      )}
      
      <div className="flex justify-between mt-6">
        <button 
          type="button" 
          className="btn btn-outline"
          onClick={onBack}
        >
          Back
        </button>
        
        <button 
          type="button" 
          className="btn btn-primary"
          onClick={handleSubmit}
        >
          Complete & Save Story
        </button>
      </div>
      
      <div className="mt-8 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
        <h4 className="font-medium mb-2">What happens next?</h4>
        <p className="text-sm text-gray-600 dark:text-gray-300">
          After completing onboarding, you'll be able to:
        </p>
        <ul className="text-sm text-gray-600 dark:text-gray-300 list-disc pl-5 mt-2 space-y-1">
          <li>Edit and expand your story</li>
          <li>Create new stories with different templates</li>
          <li>Collaborate with others on your stories</li>
          <li>Get AI-powered writing suggestions</li>
          <li>Publish and share your creations</li>
        </ul>
      </div>
    </div>
  );
};

export default FirstStoryStep;