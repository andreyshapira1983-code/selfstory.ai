import React, { useState, useEffect, useRef } from 'react';

/**
 * Character Relationship Diagram Component
 * 
 * Provides a visual representation of character relationships
 * Allows for creating, editing, and visualizing connections between characters
 */
const CharacterRelationshipDiagram = ({
  characters = [],
  relationships = [],
  onAddRelationship,
  onUpdateRelationship,
  onDeleteRelationship
}) => {
  const [diagramRelationships, setDiagramRelationships] = useState(relationships);
  const [activeRelationship, setActiveRelationship] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [selectedCharacters, setSelectedCharacters] = useState([]);
  const [layoutType, setLayoutType] = useState('force'); // force, circular, hierarchical
  const [zoomLevel, setZoomLevel] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [showLabels, setShowLabels] = useState(true);
  
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  
  // New relationship template
  const newRelationshipTemplate = {
    id: '',
    character1Id: '',
    character2Id: '',
    type: 'friend', // friend, family, rival, romantic, professional, etc.
    description: '',
    strength: 'medium', // weak, medium, strong
    status: 'active', // active, past, potential
    notes: ''
  };
  
  // Relationship being edited
  const [editingRelationship, setEditingRelationship] = useState({...newRelationshipTemplate});
  
  // Relationship types with colors
  const relationshipTypes = [
    { id: 'friend', name: 'Friend', color: '#10B981' }, // Green
    { id: 'family', name: 'Family', color: '#3B82F6' }, // Blue
    { id: 'rival', name: 'Rival', color: '#EF4444' }, // Red
    { id: 'romantic', name: 'Romantic', color: '#EC4899' }, // Pink
    { id: 'professional', name: 'Professional', color: '#6B7280' }, // Gray
    { id: 'mentor', name: 'Mentor', color: '#8B5CF6' }, // Purple
    { id: 'enemy', name: 'Enemy', color: '#F59E0B' }, // Amber
    { id: 'ally', name: 'Ally', color: '#10B981' } // Green
  ];
  
  // Initialize diagram relationships
  useEffect(() => {
    setDiagramRelationships(relationships);
  }, [relationships]);
  
  // Draw the diagram when relationships or characters change
  useEffect(() => {
    if (characters.length > 0 && canvasRef.current) {
      drawDiagram();
    }
  }, [characters, diagramRelationships, layoutType, zoomLevel, showLabels]);
  
  // Handle relationship selection
  const handleSelectRelationship = (relationship) => {
    setActiveRelationship(relationship);
    setEditingRelationship(relationship);
    setIsEditing(false);
    setIsCreating(false);
  };
  
  // Handle creating new relationship
  const handleCreateNew = () => {
    setEditingRelationship({...newRelationshipTemplate});
    setActiveRelationship(null);
    setIsEditing(false);
    setIsCreating(true);
    setSelectedCharacters([]);
  };
  
  // Handle editing relationship
  const handleEdit = () => {
    setIsEditing(true);
    setIsCreating(false);
  };
  
  // Handle saving relationship
  const handleSave = () => {
    if (isCreating) {
      const newId = `relationship-${Date.now()}`;
      const newRelationship = { 
        ...editingRelationship,
        id: newId
      };
      
      // Add the new relationship
      const updatedRelationships = [...diagramRelationships, newRelationship];
      setDiagramRelationships(updatedRelationships);
      setActiveRelationship(newRelationship);
      
      // Notify parent component
      if (onAddRelationship) {
        onAddRelationship(newRelationship);
      }
    } else {
      // Update the existing relationship
      const updatedRelationships = diagramRelationships.map(rel => 
        rel.id === editingRelationship.id ? editingRelationship : rel
      );
      
      setDiagramRelationships(updatedRelationships);
      setActiveRelationship(editingRelationship);
      
      // Notify parent component
      if (onUpdateRelationship) {
        onUpdateRelationship(editingRelationship);
      }
    }
    
    setIsEditing(false);
    setIsCreating(false);
  };
  
  // Handle deleting relationship
  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete this relationship?`)) {
      // Remove the relationship
      const updatedRelationships = diagramRelationships.filter(rel => rel.id !== activeRelationship.id);
      setDiagramRelationships(updatedRelationships);
      setActiveRelationship(null);
      setEditingRelationship({...newRelationshipTemplate});
      setIsEditing(false);
      setIsCreating(false);
      
      // Notify parent component
      if (onDeleteRelationship) {
        onDeleteRelationship(activeRelationship.id);
      }
    }
  };
  
  // Handle field change
  const handleFieldChange = (field, value) => {
    setEditingRelationship(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  // Handle character selection in diagram
  const handleCharacterSelect = (characterId) => {
    setSelectedCharacters(prev => {
      // If already selected, remove it
      if (prev.includes(characterId)) {
        return prev.filter(id => id !== characterId);
      }
      
      // If we already have 2 characters selected, replace the oldest one
      if (prev.length >= 2) {
        return [prev[1], characterId];
      }
      
      // Otherwise add it
      return [...prev, characterId];
    });
    
    // If we now have 2 characters selected, check if there's a relationship
    if (selectedCharacters.length === 1) {
      const char1 = selectedCharacters[0];
      const char2 = characterId;
      
      // Don't create a relationship with the same character
      if (char1 === char2) {
        return;
      }
      
      // Check if a relationship already exists
      const existingRelationship = diagramRelationships.find(rel => 
        (rel.character1Id === char1 && rel.character2Id === char2) ||
        (rel.character1Id === char2 && rel.character2Id === char1)
      );
      
      if (existingRelationship) {
        // Select the existing relationship
        handleSelectRelationship(existingRelationship);
      } else {
        // Start creating a new relationship
        setEditingRelationship({
          ...newRelationshipTemplate,
          character1Id: char1,
          character2Id: char2
        });
        setActiveRelationship(null);
        setIsEditing(false);
        setIsCreating(true);
      }
    }
  };
  
  // Handle zoom change
  const handleZoomChange = (e) => {
    setZoomLevel(parseFloat(e.target.value));
  };
  
  // Handle layout type change
  const handleLayoutChange = (layout) => {
    setLayoutType(layout);
  };
  
  // Draw the relationship diagram
  const drawDiagram = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const container = containerRef.current;
    
    // Set canvas size to match container
    canvas.width = container.clientWidth;
    canvas.height = 500; // Fixed height
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Calculate positions based on layout type
    const positions = calculatePositions();
    
    // Draw relationships (lines)
    diagramRelationships.forEach(rel => {
      const char1 = characters.find(c => c.id === rel.character1Id);
      const char2 = characters.find(c => c.id === rel.character2Id);
      
      if (!char1 || !char2) return;
      
      const pos1 = positions[rel.character1Id];
      const pos2 = positions[rel.character2Id];
      
      if (!pos1 || !pos2) return;
      
      // Get relationship type color
      const relType = relationshipTypes.find(t => t.id === rel.type);
      const color = relType ? relType.color : '#6B7280';
      
      // Set line style based on relationship strength
      ctx.lineWidth = rel.strength === 'strong' ? 3 : rel.strength === 'medium' ? 2 : 1;
      ctx.strokeStyle = color;
      
      // Set line style based on relationship status
      if (rel.status === 'past') {
        ctx.setLineDash([5, 3]);
      } else if (rel.status === 'potential') {
        ctx.setLineDash([2, 2]);
      } else {
        ctx.setLineDash([]);
      }
      
      // Draw line
      ctx.beginPath();
      ctx.moveTo(pos1.x, pos1.y);
      ctx.lineTo(pos2.x, pos2.y);
      ctx.stroke();
      
      // Draw relationship label if showLabels is true
      if (showLabels) {
        const midX = (pos1.x + pos2.x) / 2;
        const midY = (pos1.y + pos2.y) / 2;
        
        // Draw label background
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        const relName = relType ? relType.name : 'Relationship';
        const textWidth = ctx.measureText(relName).width;
        ctx.fillRect(midX - textWidth / 2 - 2, midY - 8, textWidth + 4, 16);
        
        // Draw label text
        ctx.fillStyle = color;
        ctx.font = '12px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(relName, midX, midY);
      }
    });
    
    // Draw characters (circles)
    characters.forEach(char => {
      const pos = positions[char.id];
      if (!pos) return;
      
      // Draw circle
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 20, 0, 2 * Math.PI);
      
      // Highlight selected characters
      if (selectedCharacters.includes(char.id)) {
        ctx.fillStyle = '#3B82F6';
      } else {
        ctx.fillStyle = '#6B7280';
      }
      
      ctx.fill();
      
      // Draw character name
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '12px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(char.name.charAt(0).toUpperCase(), pos.x, pos.y);
      
      // Draw character name below circle if showLabels is true
      if (showLabels) {
        ctx.fillStyle = '#000000';
        ctx.font = '12px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';
        ctx.fillText(char.name, pos.x, pos.y + 25);
      }
    });
  };
  
  // Calculate character positions based on layout type
  const calculatePositions = () => {
    const positions = {};
    const canvas = canvasRef.current;
    if (!canvas) return positions;
    
    const width = canvas.width;
    const height = canvas.height;
    const padding = 50;
    
    switch (layoutType) {
      case 'circular':
        // Arrange characters in a circle
        const radius = Math.min(width, height) / 2 - padding;
        const centerX = width / 2;
        const centerY = height / 2;
        
        characters.forEach((char, index) => {
          const angle = (index / characters.length) * 2 * Math.PI;
          positions[char.id] = {
            x: centerX + radius * Math.cos(angle) * zoomLevel,
            y: centerY + radius * Math.sin(angle) * zoomLevel
          };
        });
        break;
        
      case 'hierarchical':
        // Arrange characters in a hierarchical layout
        // This is a simplified version - a real implementation would use a more sophisticated algorithm
        const levels = {};
        
        // Assign levels based on relationships
        characters.forEach(char => {
          // Count relationships for each character
          const relCount = diagramRelationships.filter(rel => 
            rel.character1Id === char.id || rel.character2Id === char.id
          ).length;
          
          // Assign level based on relationship count
          const level = Math.min(Math.floor(relCount / 2), 3);
          if (!levels[level]) levels[level] = [];
          levels[level].push(char);
        });
        
        // Position characters based on levels
        Object.entries(levels).forEach(([level, chars]) => {
          const levelY = padding + (height - 2 * padding) * (parseInt(level) / 3);
          
          chars.forEach((char, index) => {
            const levelX = padding + (width - 2 * padding) * (index / (chars.length || 1));
            positions[char.id] = {
              x: levelX * zoomLevel,
              y: levelY * zoomLevel
            };
          });
        });
        break;
        
      case 'force':
      default:
        // Simple force-directed layout
        // In a real implementation, this would use a proper force-directed algorithm
        
        // Start with random positions
        characters.forEach(char => {
          positions[char.id] = {
            x: padding + Math.random() * (width - 2 * padding),
            y: padding + Math.random() * (height - 2 * padding)
          };
        });
        
        // Apply simple force-directed adjustments
        for (let i = 0; i < 50; i++) {
          // Repulsive forces between all characters
          characters.forEach(char1 => {
            characters.forEach(char2 => {
              if (char1.id === char2.id) return;
              
              const pos1 = positions[char1.id];
              const pos2 = positions[char2.id];
              
              const dx = pos2.x - pos1.x;
              const dy = pos2.y - pos1.y;
              const distance = Math.sqrt(dx * dx + dy * dy);
              
              if (distance < 100) {
                const force = 1 / distance;
                const moveX = dx * force * 0.1;
                const moveY = dy * force * 0.1;
                
                positions[char1.id].x -= moveX;
                positions[char1.id].y -= moveY;
                positions[char2.id].x += moveX;
                positions[char2.id].y += moveY;
              }
            });
          });
          
          // Attractive forces between related characters
          diagramRelationships.forEach(rel => {
            const pos1 = positions[rel.character1Id];
            const pos2 = positions[rel.character2Id];
            
            if (!pos1 || !pos2) return;
            
            const dx = pos2.x - pos1.x;
            const dy = pos2.y - pos1.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance > 150) {
              const force = (distance - 150) / 150;
              const moveX = dx * force * 0.1;
              const moveY = dy * force * 0.1;
              
              positions[rel.character1Id].x += moveX;
              positions[rel.character1Id].y += moveY;
              positions[rel.character2Id].x -= moveX;
              positions[rel.character2Id].y -= moveY;
            }
          });
          
          // Keep positions within bounds
          characters.forEach(char => {
            const pos = positions[char.id];
            pos.x = Math.max(padding, Math.min(width - padding, pos.x));
            pos.y = Math.max(padding, Math.min(height - padding, pos.y));
          });
        }
        
        // Apply zoom
        characters.forEach(char => {
          const pos = positions[char.id];
          const centerX = width / 2;
          const centerY = height / 2;
          
          pos.x = centerX + (pos.x - centerX) * zoomLevel;
          pos.y = centerY + (pos.y - centerY) * zoomLevel;
        });
        break;
    }
    
    return positions;
  };
  
  // Get character name by ID
  const getCharacterName = (characterId) => {
    const character = characters.find(c => c.id === characterId);
    return character ? character.name : 'Unknown Character';
  };
  
  // Get relationship type name
  const getRelationshipTypeName = (typeId) => {
    const type = relationshipTypes.find(t => t.id === typeId);
    return type ? type.name : 'Relationship';
  };
  
  // Filter relationships based on search term
  const filteredRelationships = diagramRelationships.filter(rel => {
    const char1 = getCharacterName(rel.character1Id).toLowerCase();
    const char2 = getCharacterName(rel.character2Id).toLowerCase();
    const type = getRelationshipTypeName(rel.type).toLowerCase();
    const searchLower = searchTerm.toLowerCase();
    
    return char1.includes(searchLower) || 
           char2.includes(searchLower) || 
           type.includes(searchLower) ||
           (rel.description && rel.description.toLowerCase().includes(searchLower));
  });
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      {/* Header */}
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-b border-gray-200 dark:border-gray-600">
        <h2 className="text-lg font-medium flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-primary" viewBox="0 0 20 20" fill="currentColor">
            <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
          </svg>
          Character Relationships
        </h2>
      </div>
      
      {/* Main content */}
      <div className="p-4">
        {/* Controls */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 space-y-2 md:space-y-0">
          <div className="flex items-center space-x-2">
            <button
              className="btn btn-primary"
              onClick={handleCreateNew}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
              </svg>
              Add Relationship
            </button>
            
            <div className="flex items-center space-x-1">
              <button
                className={`px-2 py-1 text-xs font-medium rounded ${
                  layoutType === 'force'
                    ? 'bg-primary text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                }`}
                onClick={() => handleLayoutChange('force')}
              >
                Force
              </button>
              <button
                className={`px-2 py-1 text-xs font-medium rounded ${
                  layoutType === 'circular'
                    ? 'bg-primary text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                }`}
                onClick={() => handleLayoutChange('circular')}
              >
                Circular
              </button>
              <button
                className={`px-2 py-1 text-xs font-medium rounded ${
                  layoutType === 'hierarchical'
                    ? 'bg-primary text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                }`}
                onClick={() => handleLayoutChange('hierarchical')}
              >
                Hierarchical
              </button>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 w-full md:w-auto">
            <input
              type="text"
              className="input"
              placeholder="Search relationships..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            
            <div className="flex items-center space-x-2">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="showLabels"
                  className="mr-1"
                  checked={showLabels}
                  onChange={() => setShowLabels(!showLabels)}
                />
                <label htmlFor="showLabels" className="text-sm">Labels</label>
              </div>
              
              <div className="flex items-center space-x-1">
                <button
                  className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
                  onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.1))}
                  title="Zoom Out"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M5 10a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1z" clipRule="evenodd" />
                  </svg>
                </button>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={zoomLevel}
                  onChange={handleZoomChange}
                  className="w-20"
                />
                <button
                  className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
                  onClick={() => setZoomLevel(Math.min(2, zoomLevel + 0.1))}
                  title="Zoom In"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Diagram visualization */}
        <div 
          className="relative mb-6 bg-gray-50 dark:bg-gray-700 rounded-lg overflow-hidden"
          ref={containerRef}
          style={{ height: '500px' }}
        >
          {characters.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
              <p className="text-gray-500 dark:text-gray-400">
                No characters available. Create some characters first.
              </p>
            </div>
          ) : (
            <canvas 
              ref={canvasRef} 
              onClick={(e) => {
                // Handle canvas click to select characters
                const canvas = canvasRef.current;
                if (!canvas) return;
                
                const rect = canvas.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                // Calculate positions
                const positions = calculatePositions();
                
                // Check if a character was clicked
                characters.forEach(char => {
                  const pos = positions[char.id];
                  if (!pos) return;
                  
                  const dx = pos.x - x;
                  const dy = pos.y - y;
                  const distance = Math.sqrt(dx * dx + dy * dy);
                  
                  if (distance <= 20) {
                    handleCharacterSelect(char.id);
                  }
                });
              }}
              className="cursor-pointer"
            />
          )}
        </div>
        
        {/* Relationship list */}
        <div className="mb-6">
          <h3 className="font-medium mb-2">Relationships</h3>
          
          {filteredRelationships.length === 0 ? (
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 text-center">
              <p className="text-gray-500 dark:text-gray-400">
                {searchTerm ? 'No relationships match your search' : 'No relationships defined yet.'}
              </p>
            </div>
          ) : (
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-600">
                  <thead className="bg-gray-100 dark:bg-gray-800">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Characters</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Type</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Strength</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Description</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-600">
                    {filteredRelationships.map(rel => (
                      <tr 
                        key={rel.id}
                        className={`hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer ${
                          activeRelationship?.id === rel.id ? 'bg-blue-50 dark:bg-blue-900 dark:bg-opacity-20' : ''
                        }`}
                        onClick={() => handleSelectRelationship(rel)}
                      >
                        <td className="px-4 py-2">
                          {getCharacterName(rel.character1Id)} & {getCharacterName(rel.character2Id)}
                        </td>
                        <td className="px-4 py-2">
                          <span 
                            className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium text-white"
                            style={{ 
                              backgroundColor: relationshipTypes.find(t => t.id === rel.type)?.color || '#6B7280'
                            }}
                          >
                            {getRelationshipTypeName(rel.type)}
                          </span>
                        </td>
                        <td className="px-4 py-2 capitalize">{rel.strength}</td>
                        <td className="px-4 py-2 capitalize">{rel.status}</td>
                        <td className="px-4 py-2 truncate max-w-xs">{rel.description}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
        
        {/* Relationship detail/edit panel */}
        {activeRelationship && !isEditing && !isCreating ? (
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-medium text-xl">
                  {getCharacterName(activeRelationship.character1Id)} & {getCharacterName(activeRelationship.character2Id)}
                </h3>
                <div className="flex items-center mt-1">
                  <span 
                    className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium text-white mr-2"
                    style={{ 
                      backgroundColor: relationshipTypes.find(t => t.id === activeRelationship.type)?.color || '#6B7280'
                    }}
                  >
                    {getRelationshipTypeName(activeRelationship.type)}
                  </span>
                  <span className="text-sm text-gray-500 dark:text-gray-400 capitalize">
                    {activeRelationship.strength} • {activeRelationship.status}
                  </span>
                </div>
              </div>
              <div className="flex space-x-2">
                <button
                  className="btn btn-sm btn-outline"
                  onClick={handleEdit}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                  </svg>
                  Edit
                </button>
                <button
                  className="btn btn-sm btn-danger"
                  onClick={handleDelete}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  Delete
                </button>
              </div>
            </div>
            
            {activeRelationship.description && (
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Description</span>
                <p className="whitespace-pre-line">{activeRelationship.description}</p>
              </div>
            )}
            
            {activeRelationship.notes && (
              <div>
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Notes</span>
                <p className="whitespace-pre-line">{activeRelationship.notes}</p>
              </div>
            )}
          </div>
        ) : (isEditing || isCreating) ? (
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <h3 className="font-medium mb-4">
              {isCreating ? 'Create New Relationship' : 'Edit Relationship'}
            </h3>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Character 1</label>
                  <select
                    className="input w-full"
                    value={editingRelationship.character1Id}
                    onChange={(e) => handleFieldChange('character1Id', e.target.value)}
                    disabled={selectedCharacters.length === 2}
                  >
                    <option value="">Select Character</option>
                    {characters.map(char => (
                      <option key={char.id} value={char.id}>{char.name}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Character 2</label>
                  <select
                    className="input w-full"
                    value={editingRelationship.character2Id}
                    onChange={(e) => handleFieldChange('character2Id', e.target.value)}
                    disabled={selectedCharacters.length === 2}
                  >
                    <option value="">Select Character</option>
                    {characters.map(char => (
                      <option key={char.id} value={char.id}>{char.name}</option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Relationship Type</label>
                  <select
                    className="input w-full"
                    value={editingRelationship.type}
                    onChange={(e) => handleFieldChange('type', e.target.value)}
                  >
                    {relationshipTypes.map(type => (
                      <option key={type.id} value={type.id}>{type.name}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Strength</label>
                  <select
                    className="input w-full"
                    value={editingRelationship.strength}
                    onChange={(e) => handleFieldChange('strength', e.target.value)}
                  >
                    <option value="weak">Weak</option>
                    <option value="medium">Medium</option>
                    <option value="strong">Strong</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Status</label>
                  <select
                    className="input w-full"
                    value={editingRelationship.status}
                    onChange={(e) => handleFieldChange('status', e.target.value)}
                  >
                    <option value="active">Active</option>
                    <option value="past">Past</option>
                    <option value="potential">Potential</option>
                  </select>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Description</label>
                <textarea
                  className="input w-full"
                  rows={3}
                  value={editingRelationship.description}
                  onChange={(e) => handleFieldChange('description', e.target.value)}
                  placeholder="Describe the relationship between these characters"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Notes</label>
                <textarea
                  className="input w-full"
                  rows={2}
                  value={editingRelationship.notes}
                  onChange={(e) => handleFieldChange('notes', e.target.value)}
                  placeholder="Additional notes about this relationship"
                />
              </div>
              
              <div className="flex justify-end space-x-3">
                <button
                  className="btn btn-outline"
                  onClick={() => {
                    if (isCreating) {
                      setIsCreating(false);
                    } else {
                      setIsEditing(false);
                    }
                    setSelectedCharacters([]);
                  }}
                >
                  Cancel
                </button>
                <button
                  className="btn btn-primary"
                  onClick={handleSave}
                  disabled={!editingRelationship.character1Id || !editingRelationship.character2Id}
                >
                  {isCreating ? 'Create Relationship' : 'Save Changes'}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 text-center">
            <p className="text-gray-500 dark:text-gray-400">
              Select a relationship to view details or click "Add Relationship" to create a new one.
              <br />
              You can also select two characters in the diagram to create a relationship between them.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CharacterRelationshipDiagram;