import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';

/**
 * CursorPresence - Shows real-time cursor positions of collaborators
 * 
 * This component visualizes where other users are currently editing in the document,
 * displaying their cursors with names and avatars for better collaboration awareness.
 */
const CursorPresence = ({ 
  collaborators, 
  documentId, 
  editorRef,
  currentUser
}) => {
  const [cursors, setCursors] = useState({});
  const [visible, setVisible] = useState(true);

  // Set up cursor tracking and synchronization
  useEffect(() => {
    if (!editorRef?.current || !documentId) return;
    
    // Function to update cursor position
    const updateCursorPosition = () => {
      if (!editorRef.current) return;
      
      const selection = window.getSelection();
      if (!selection.rangeCount) return;
      
      const range = selection.getRangeAt(0);
      const position = range.startOffset;
      
      // In a real implementation, this would send the position to the server
      // For now, we'll just simulate it locally
      console.log(`Cursor position updated: ${position}`);
      
      // Broadcast cursor position to other users
      // This would use WebSockets in a real implementation
    };
    
    // Set up event listeners for cursor movement
    const editor = editorRef.current;
    editor.addEventListener('mouseup', updateCursorPosition);
    editor.addEventListener('keyup', updateCursorPosition);
    
    // Clean up event listeners
    return () => {
      editor.removeEventListener('mouseup', updateCursorPosition);
      editor.removeEventListener('keyup', updateCursorPosition);
    };
  }, [editorRef, documentId, currentUser]);
  
  // Subscribe to cursor updates from other users
  useEffect(() => {
    // In a real implementation, this would subscribe to WebSocket events
    // For now, we'll simulate receiving cursor positions
    
    // Simulate cursor positions for collaborators
    const simulatedCursors = {};
    collaborators.forEach(collaborator => {
      if (collaborator.id !== currentUser?.id) {
        simulatedCursors[collaborator.id] = {
          position: Math.floor(Math.random() * 1000), // Random position for demo
          user: collaborator
        };
      }
    });
    
    setCursors(simulatedCursors);
    
    // In a real implementation, this would be a WebSocket subscription cleanup
    return () => {
      // Cleanup WebSocket subscription
    };
  }, [collaborators, currentUser]);
  
  // Toggle cursor visibility
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  
  // If no collaborators or not visible, don't render
  if (!visible || Object.keys(cursors).length === 0) {
    return (
      <div className="cursor-presence-toggle">
        <button 
          onClick={toggleVisibility}
          className="btn btn-sm btn-outline"
          title={visible ? "Hide collaborator cursors" : "Show collaborator cursors"}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
          </svg>
        </button>
      </div>
    );
  }
  
  // Render cursor indicators
  return (
    <div className="cursor-presence">
      <div className="cursor-presence-toggle">
        <button 
          onClick={toggleVisibility}
          className="btn btn-sm btn-primary"
          title="Hide collaborator cursors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
          </svg>
        </button>
      </div>
      
      {/* Render each collaborator's cursor */}
      {Object.values(cursors).map(({ position, user }) => (
        <div 
          key={user.id}
          className="cursor-indicator"
          style={{
            // In a real implementation, this would calculate the actual position
            // based on the text content and cursor position
            position: 'absolute',
            top: `${Math.floor(position / 50) * 20}px`, // Simulated vertical position
            left: `${(position % 50) * 10}px`, // Simulated horizontal position
          }}
        >
          <div 
            className="cursor-avatar"
            style={{ 
              backgroundColor: user.color || '#' + ((1<<24)*Math.random() | 0).toString(16),
            }}
            title={user.name}
          >
            {user.avatar ? (
              <img src={user.avatar} alt={user.name} />
            ) : (
              <span>{user.name.charAt(0).toUpperCase()}</span>
            )}
          </div>
          <div className="cursor-name" style={{ backgroundColor: user.color || '#' + ((1<<24)*Math.random() | 0).toString(16) }}>
            {user.name}
          </div>
        </div>
      ))}
    </div>
  );
};

CursorPresence.propTypes = {
  collaborators: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      avatar: PropTypes.string,
      color: PropTypes.string,
    })
  ).isRequired,
  documentId: PropTypes.string.isRequired,
  editorRef: PropTypes.object.isRequired,
  currentUser: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
  }),
};

export default CursorPresence;