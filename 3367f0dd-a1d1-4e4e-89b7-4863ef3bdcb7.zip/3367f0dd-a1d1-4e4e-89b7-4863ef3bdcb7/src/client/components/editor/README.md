# StoryAI Story Editor

The Story Editor is the central component where users create, edit, and enhance their stories. This document explains the components, functionality, and usage of the story editor.

## Components Overview

### StoryEditor.jsx
- Main component for creating and editing stories
- Integrates story controls, genre/tag system, and editor
- Provides AI assistance features
- Handles saving and template application

## Features

### Basic Editing
- Title editing with auto-save
- Content editing with rich text capabilities
- Tab-based navigation between editor, controls, and genres/tags
- Auto-save functionality to prevent data loss

### AI Assistance
- **Continue Story**: Generate additional content based on the current story
- **Improve Writing**: Enhance the quality of the existing content
- **Make Longer/Shorter**: Adjust the length of the content
- **Make Darker/Funnier**: Adjust the tone and mood of the content
- Quick access buttons for common AI operations

### Template Integration
- Browse and apply templates to start new stories
- Preview templates before application
- Confirmation before replacing existing content

### Story Controls Integration
- Access to tone, length, POV, and mood controls
- Control settings affect AI-generated content
- Preset controls for different writing styles

### Genre & Tag Integration
- Manage genres and tags for the story
- Get tag suggestions based on selected genres
- Organize stories for better discoverability

## Data Structure

```javascript
{
  id: string,           // Unique identifier
  title: string,        // Story title
  content: string,      // Story content
  genres: string[],     // Array of genre IDs
  tags: string[],       // Array of tags
  controls: {           // Story control parameters
    tone: string,
    length: string,
    pov: string,
    mood: string
  },
  template: string,     // Template ID (if used)
  createdAt: string,    // Creation timestamp
  updatedAt: string     // Last update timestamp
}
```

## UI Organization

### Tab-Based Interface
- **Editor Tab**: Main writing area with AI assistance tools
- **Controls Tab**: Story parameter controls (tone, length, POV, mood)
- **Genres & Tags Tab**: Genre selection and tag management

### Editor Toolbar
- Template selection button
- AI assistance dropdown
- Save button with status indicator

### Quick Edit Buttons
- Continue Story
- Improve Writing
- Make Longer
- Make Shorter
- Make Darker
- Make Funnier

## Implementation Notes

- The editor uses a textarea for simplicity in this version
- In a production environment, a rich text editor would be used
- AI generation is simulated with pre-defined responses
- Auto-save occurs every 30 seconds if changes are detected
- The editor supports both light and dark mode
- The component is fully responsive for all device sizes

## Usage Flow

1. User enters or edits the story title
2. User writes or edits content in the main editor
3. User can switch tabs to adjust controls or manage genres/tags
4. User can use AI assistance buttons for content enhancement
5. Changes are automatically saved periodically
6. User can manually save at any time

## Future Enhancements

- Implement a full rich text editor (TipTap/ProseMirror)
- Add real-time collaborative editing
- Implement version history and rollback
- Add more advanced AI assistance features
- Implement content analysis and suggestions
- Add export options (PDF, EPUB, etc.)
- Implement real-time word count and reading time estimates