import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import CursorPresence from './CursorPresence';
import CollaborativeChat from './CollaborativeChat';
import ConflictResolution from './ConflictResolution';
import CollaborativeBrainstorming from './CollaborativeBrainstorming';

/**
 * EnhancedCollaborativeEditor - Advanced collaborative editing component
 * 
 * This component enhances the collaborative editing experience with:
 * - Real-time cursor presence
 * - User avatars
 * - Conflict resolution
 * - Real-time chat
 * - Collaborative brainstorming tools
 */
const EnhancedCollaborativeEditor = ({
  documentId,
  initialContent,
  onContentChange,
  collaborators = [],
  currentUser,
  onSave,
}) => {
  const [content, setContent] = useState(initialContent || '');
  const [isEditing, setIsEditing] = useState(false);
  const [conflicts, setConflicts] = useState([]);
  const [showConflictModal, setShowConflictModal] = useState(false);
  const [showBrainstorming, setShowBrainstorming] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState('');
  const [cursorPosition, setCursorPosition] = useState(0);
  const [activeCollaborators, setActiveCollaborators] = useState([]);
  
  const editorRef = useRef(null);
  
  // Initialize active collaborators with random colors
  useEffect(() => {
    const collaboratorsWithColors = collaborators.map(collaborator => ({
      ...collaborator,
      color: collaborator.color || `#${Math.floor(Math.random()*16777215).toString(16)}`,
    }));
    
    setActiveCollaborators(collaboratorsWithColors);
  }, [collaborators]);
  
  // Handle content change
  const handleContentChange = (e) => {
    setContent(e.target.value);
    setIsEditing(true);
    
    if (onContentChange) {
      onContentChange(e.target.value);
    }
    
    // Update cursor position for cursor presence
    if (editorRef.current) {
      setCursorPosition(editorRef.current.selectionStart);
    }
  };
  
  // Handle cursor position change
  const handleCursorPositionChange = () => {
    if (editorRef.current) {
      setCursorPosition(editorRef.current.selectionStart);
    }
  };
  
  // Handle save
  const handleSave = () => {
    setIsSaving(true);
    
    // In a real implementation, this would call an API to save the content
    // For now, we'll simulate a delay and then update the state
    setTimeout(() => {
      setIsSaving(false);
      setIsEditing(false);
      setSaveStatus('Changes saved successfully!');
      
      setTimeout(() => {
        setSaveStatus('');
      }, 3000);
      
      if (onSave) {
        onSave(content);
      }
    }, 800);
  };
  
  // Simulate conflict detection
  useEffect(() => {
    // In a real implementation, this would be detected by the collaborative editing system
    // For now, we'll simulate a conflict occasionally
    
    const simulateConflict = () => {
      // Only simulate conflicts occasionally when editing
      if (isEditing && Math.random() > 0.9 && collaborators.length > 1) {
        const randomCollaborator = collaborators.find(c => c.id !== currentUser?.id);
        
        if (randomCollaborator) {
          // Create a simulated conflict
          const conflictPosition = Math.floor(Math.random() * content.length);
          const conflictLength = Math.floor(Math.random() * 20) + 10;
          
          const conflictStart = Math.max(0, conflictPosition - conflictLength);
          const conflictEnd = Math.min(content.length, conflictPosition + conflictLength);
          
          const conflictText = content.substring(conflictStart, conflictEnd);
          
          // Generate a slightly modified version as "their" version
          const theirVersion = conflictText
            .split(' ')
            .map(word => Math.random() > 0.7 ? word + ' ' + ['very', 'quite', 'extremely', 'somewhat'][Math.floor(Math.random() * 4)] : word)
            .join(' ');
          
          const newConflict = {
            id: `conflict-${Date.now()}`,
            index: conflicts.length,
            location: `Position ${conflictStart}-${conflictEnd}`,
            yourVersion: conflictText,
            theirVersion: theirVersion,
            user: randomCollaborator,
            timestamp: new Date().toISOString()
          };
          
          setConflicts(prev => [...prev, newConflict]);
          setShowConflictModal(true);
        }
      }
    };
    
    // Set up interval to occasionally check for conflicts
    const interval = setInterval(simulateConflict, 30000);
    
    return () => clearInterval(interval);
  }, [isEditing, content, collaborators, currentUser, conflicts]);
  
  // Handle conflict resolution
  const handleResolveConflicts = (resolutions) => {
    // In a real implementation, this would apply the resolved conflicts to the document
    // For now, we'll just log the resolutions and close the modal
    console.log('Conflicts resolved:', resolutions);
    
    setShowConflictModal(false);
    setConflicts([]);
    
    // Show success message
    setSaveStatus('Conflicts resolved successfully!');
    setTimeout(() => {
      setSaveStatus('');
    }, 3000);
  };
  
  // Toggle brainstorming panel
  const toggleBrainstorming = () => {
    setShowBrainstorming(!showBrainstorming);
  };
  
  return (
    <div className="enhanced-collaborative-editor">
      {/* Editor toolbar */}
      <div className="editor-toolbar">
        <div className="toolbar-left">
          <button 
            className="toolbar-btn"
            onClick={handleSave}
            disabled={isSaving || !isEditing}
          >
            {isSaving ? (
              <>
                <svg className="animate-spin h-4 w-4 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Saving...
              </>
            ) : 'Save'}
          </button>
          
          <button 
            className="toolbar-btn"
            onClick={toggleBrainstorming}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
            Brainstorm
          </button>
        </div>
        
        <div className="toolbar-center">
          {saveStatus && (
            <span className="save-status">{saveStatus}</span>
          )}
        </div>
        
        <div className="toolbar-right">
          <div className="active-collaborators">
            {activeCollaborators.map(collaborator => (
              <div 
                key={collaborator.id} 
                className="collaborator-avatar"
                style={{ backgroundColor: collaborator.color }}
                title={collaborator.name}
              >
                {collaborator.avatar ? (
                  <img src={collaborator.avatar} alt={collaborator.name} />
                ) : (
                  collaborator.name.charAt(0).toUpperCase()
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Editor content */}
      <div className="editor-content">
        <textarea
          ref={editorRef}
          className="content-textarea"
          value={content}
          onChange={handleContentChange}
          onKeyUp={handleCursorPositionChange}
          onClick={handleCursorPositionChange}
          placeholder="Start writing your story..."
        />
        
        {/* Cursor presence overlay */}
        <CursorPresence
          collaborators={activeCollaborators}
          documentId={documentId}
          editorRef={editorRef}
          currentUser={currentUser}
        />
      </div>
      
      {/* Collaborative chat */}
      <CollaborativeChat
        documentId={documentId}
        collaborators={activeCollaborators}
        currentUser={currentUser}
        onSendMessage={(message) => {
          // In a real implementation, this would send the message to the server
          console.log('Message sent:', message);
        }}
      />
      
      {/* Conflict resolution modal */}
      {showConflictModal && conflicts.length > 0 && (
        <ConflictResolution
          conflicts={conflicts}
          onResolve={handleResolveConflicts}
          onCancel={() => setShowConflictModal(false)}
        />
      )}
      
      {/* Collaborative brainstorming */}
      {showBrainstorming && (
        <CollaborativeBrainstorming
          documentId={documentId}
          collaborators={activeCollaborators}
          currentUser={currentUser}
          onClose={() => setShowBrainstorming(false)}
        />
      )}
    </div>
  );
};

EnhancedCollaborativeEditor.propTypes = {
  documentId: PropTypes.string.isRequired,
  initialContent: PropTypes.string,
  onContentChange: PropTypes.func,
  collaborators: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      avatar: PropTypes.string,
      color: PropTypes.string,
    })
  ),
  currentUser: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    avatar: PropTypes.string,
  }),
  onSave: PropTypes.func,
};

export default EnhancedCollaborativeEditor;