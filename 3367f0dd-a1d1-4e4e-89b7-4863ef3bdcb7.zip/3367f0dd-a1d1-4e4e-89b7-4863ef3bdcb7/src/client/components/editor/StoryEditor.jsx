import React, { useState, useEffect, useRef } from 'react';
import StoryControls from '../story-controls/StoryControls';
import GenreTagSystem from '../genre-system/GenreTagSystem';
import templates from '../templates/templateData';
import AIToolsPanel from './AIToolsPanel';

/**
 * StoryEditor - Main component for creating and editing stories
 * Integrates story controls, genre/tag system, and editor
 */
const StoryEditor = ({ initialStory = null, onSave }) => {
  // Story state
  const [story, setStory] = useState({
    id: initialStory?.id || `story-${Date.now()}`,
    title: initialStory?.title || '',
    content: initialStory?.content || '',
    genres: initialStory?.genres || [],
    tags: initialStory?.tags || [],
    controls: initialStory?.controls || {
      tone: 'neutral',
      length: 'medium',
      pov: 'third',
      mood: 'neutral'
    },
    template: initialStory?.template || null,
    createdAt: initialStory?.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  });
  
  // UI state
  const [activeTab, setActiveTab] = useState('editor');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState('');
  const [showTemplateSelector, setShowTemplateSelector] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [showAIOptions, setShowAIOptions] = useState(false);
  const [showAIPanel, setShowAIPanel] = useState(false);
  const [cursorPosition, setCursorPosition] = useState(0);
  
  // Reference to the textarea element
  const textareaRef = useRef(null);
  
  // Auto-save timer
  useEffect(() => {
    const timer = setTimeout(() => {
      if (story.title || story.content) {
        handleSave(true);
      }
    }, 30000); // Auto-save every 30 seconds
    
    return () => clearTimeout(timer);
  }, [story]);
  
  // Handle title change
  const handleTitleChange = (e) => {
    setStory(prev => ({
      ...prev,
      title: e.target.value
    }));
  };
  
  // Handle content change
  const handleContentChange = (e) => {
    setStory(prev => ({
      ...prev,
      content: e.target.value
    }));
    
    // Update cursor position for AI suggestions
    if (textareaRef.current) {
      setCursorPosition(textareaRef.current.selectionStart);
    }
  };
  
  // Handle cursor position change
  const handleCursorPositionChange = () => {
    if (textareaRef.current) {
      setCursorPosition(textareaRef.current.selectionStart);
    }
  };
  
  // Handle AI suggestion application
  const handleApplySuggestion = (suggestionText) => {
    // Insert the suggestion at the current cursor position
    if (textareaRef.current) {
      const currentContent = story.content;
      const cursorPos = textareaRef.current.selectionStart;
      
      // Insert suggestion at cursor position
      const newContent = 
        currentContent.substring(0, cursorPos) + 
        "\n\n" + suggestionText + 
        currentContent.substring(cursorPos);
      
      setStory(prev => ({
        ...prev,
        content: newContent
      }));
      
      // Focus the textarea and set cursor position after the inserted text
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.focus();
          const newPosition = cursorPos + suggestionText.length + 2; // +2 for the newlines
          textareaRef.current.setSelectionRange(newPosition, newPosition);
          setCursorPosition(newPosition);
        }
      }, 50);
    }
  };
  
  // Handle inserting AI-generated content
  const handleInsertContent = (content) => {
    // Insert the content at the current cursor position
    if (textareaRef.current) {
      const currentContent = story.content;
      const cursorPos = textareaRef.current.selectionStart;
      
      // Insert content at cursor position
      const newContent = 
        currentContent.substring(0, cursorPos) + 
        "\n\n" + content + 
        currentContent.substring(cursorPos);
      
      setStory(prev => ({
        ...prev,
        content: newContent
      }));
      
      // Focus the textarea and set cursor position after the inserted text
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.focus();
          const newPosition = cursorPos + content.length + 2; // +2 for the newlines
          textareaRef.current.setSelectionRange(newPosition, newPosition);
          setCursorPosition(newPosition);
        }
      }, 50);
    }
  };
  
  // Handle replacing content with AI-generated content
  const handleReplaceContent = (content) => {
    setStory(prev => ({
      ...prev,
      content: content
    }));
    
    // Focus the textarea
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
      }
    }, 50);
  };
  
  // Handle story controls change
  const handleControlsChange = (controls) => {
    setStory(prev => ({
      ...prev,
      controls
    }));
  };
  
  // Handle genres and tags change
  const handleGenreTagChange = ({ genres, tags }) => {
    setStory(prev => ({
      ...prev,
      genres,
      tags
    }));
  };
  
  // Handle save
  const handleSave = (isAutoSave = false) => {
    setIsSaving(true);
    
    // Update the story with current timestamp
    const updatedStory = {
      ...story,
      updatedAt: new Date().toISOString()
    };
    
    // In a real app, this would call an API to save the story
    // For now, we'll simulate a delay and then update the state
    setTimeout(() => {
      setStory(updatedStory);
      setIsSaving(false);
      
      if (!isAutoSave) {
        setSaveStatus('Story saved successfully!');
        setTimeout(() => setSaveStatus(''), 3000);
      }
      
      if (onSave) {
        onSave(updatedStory);
      }
    }, 500);
  };
  
  // Apply a template to the story
  const applyTemplate = (templateId) => {
    const template = templates.find(t => t.id === templateId);
    
    if (template) {
      // Ask for confirmation if the story already has content
      if (story.content && !window.confirm('Applying a template will replace your current content. Continue?')) {
        return;
      }
      
      setStory(prev => ({
        ...prev,
        content: template.content,
        template: template.id,
        genres: [...new Set([...prev.genres, ...template.genres])],
        tags: [...new Set([...prev.tags, ...template.tags])]
      }));
      
      setShowTemplateSelector(false);
    }
  };
  
  // Generate content with AI
  const generateWithAI = (prompt) => {
    setGenerating(true);
    
    // In a real app, this would call an AI API to generate content
    // For now, we'll simulate a response after a delay
    setTimeout(() => {
      const aiResponses = {
        'continue': `\n\nThe path ahead seemed to wind endlessly through the dense forest. ${story.title ? story.title : 'The story'} was just beginning, and the journey would test every ounce of courage and determination they possessed. As the sun began to set, casting long shadows through the trees, they knew they needed to find shelter before darkness fell completely.

"We should make camp here," suggested the oldest of the group, pointing to a small clearing just off the path. "There's enough space for all of us, and those rocks will provide some protection from the wind."

The others nodded in agreement, too exhausted to argue. They had been traveling since dawn, and their muscles ached from the long day's journey. As they set up camp, each lost in their own thoughts, none of them noticed the pair of glowing eyes watching from the underbrush, or the faint whispers carried on the evening breeze.`,
        
        'improve': story.content.replace(
          /([A-Za-z]+)/g, 
          (match) => Math.random() > 0.8 ? match + ' ' + ['vividly', 'carefully', 'quietly', 'suddenly', 'mysteriously', 'gracefully'][Math.floor(Math.random() * 6)] : match
        ),
        
        'longer': story.content + `\n\nThe implications of this discovery would echo far beyond their immediate circumstances. Everything they had believed about the world—about reality itself—was now called into question. And yet, despite the uncertainty that lay ahead, there was also a sense of exhilaration, a feeling that they stood at the threshold of something extraordinary.

"What do we do now?" The question hung in the air between them, heavy with possibility and fraught with danger.

After a moment of contemplation, the decision became clear. They couldn't turn back, not after coming this far. Whatever awaited them on the path ahead, they would face it together, drawing strength from their shared resolve and the bonds that had formed between them.

"We continue forward," came the reply, voice steady despite the fear that lurked beneath the surface. "We find answers. And then we decide what to do with them."

With renewed determination, they pressed on, each step taking them deeper into the unknown.`,
        
        'shorter': story.content.split('\n\n').slice(0, 2).join('\n\n') + '\n\n[Content condensed for brevity]',
        
        'darker': story.content.replace(
          /(day|light|bright|happy|smile|laugh)/gi,
          match => ({
            'day': 'night',
            'light': 'shadow',
            'bright': 'dim',
            'happy': 'uneasy',
            'smile': 'grimace',
            'laugh': 'nervous chuckle'
          }[match.toLowerCase()] || match)
        ) + '\n\nA sense of foreboding settled over them like a shroud. Something wasn't right here, and they all felt it—a creeping dread that worked its way into their bones and whispered warnings they couldn't quite hear.',
        
        'funnier': story.content + '\n\n"Well, this is just perfect," they said, voice dripping with sarcasm. "I was just thinking my day needed more mortal peril and existential dread. Really rounds out the experience, you know?" The others couldn't help but laugh despite the gravity of the situation. Sometimes humor was the only defense against the absurdity of their circumstances.'
      };
      
      // Get the appropriate response based on the prompt
      const newContent = aiResponses[prompt] || story.content;
      
      setStory(prev => ({
        ...prev,
        content: newContent
      }));
      
      setGenerating(false);
    }, 2000);
  };

  return (
    <div className="story-editor">
      <div className="mb-6">
        <input
          type="text"
          className="w-full text-3xl font-bold bg-transparent border-0 border-b-2 border-gray-200 dark:border-gray-700 focus:ring-0 focus:border-primary px-0 py-2"
          placeholder="Enter your story title..."
          value={story.title}
          onChange={handleTitleChange}
        />
      </div>
      
      {/* Tab navigation */}
      <div className="flex border-b border-gray-200 dark:border-gray-700 mb-6">
        <button
          className={`py-2 px-4 font-medium text-sm border-b-2 -mb-px ${
            activeTab === 'editor'
              ? 'border-primary text-primary'
              : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
          onClick={() => setActiveTab('editor')}
        >
          Editor
        </button>
        <button
          className={`py-2 px-4 font-medium text-sm border-b-2 -mb-px ${
            activeTab === 'controls'
              ? 'border-primary text-primary'
              : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
          onClick={() => setActiveTab('controls')}
        >
          Story Controls
        </button>
        <button
          className={`py-2 px-4 font-medium text-sm border-b-2 -mb-px ${
            activeTab === 'genres'
              ? 'border-primary text-primary'
              : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
          onClick={() => setActiveTab('genres')}
        >
          Genres & Tags
        </button>
      </div>
      
      {/* Editor tab */}
      {activeTab === 'editor' && (
        <div>
          {/* Editor toolbar */}
          <div className="flex flex-wrap items-center gap-2 mb-4 p-2 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <button
              className="btn btn-sm btn-outline"
              onClick={() => setShowTemplateSelector(true)}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2" />
              </svg>
              Templates
            </button>
            
            <button
              className={`btn btn-sm ${showAIPanel ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setShowAIPanel(!showAIPanel)}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              AI Writing Assistant
            </button>
            
            <div className="relative">
              <button
                className="btn btn-sm btn-outline"
                onClick={() => setShowAIOptions(!showAIOptions)}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
                Quick AI
              </button>
              
              {showAIOptions && (
                <div className="absolute z-10 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg border border-gray-200 dark:border-gray-700">
                  <div className="py-1">
                    <button
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        generateWithAI('continue');
                        setShowAIOptions(false);
                      }}
                      disabled={generating}
                    >
                      Continue Story
                    </button>
                    <button
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        generateWithAI('improve');
                        setShowAIOptions(false);
                      }}
                      disabled={generating}
                    >
                      Improve Writing
                    </button>
                    <button
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        generateWithAI('longer');
                        setShowAIOptions(false);
                      }}
                      disabled={generating}
                    >
                      Make Longer
                    </button>
                    <button
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        generateWithAI('shorter');
                        setShowAIOptions(false);
                      }}
                      disabled={generating}
                    >
                      Make Shorter
                    </button>
                    <button
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        generateWithAI('darker');
                        setShowAIOptions(false);
                      }}
                      disabled={generating}
                    >
                      Make Darker
                    </button>
                    <button
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        generateWithAI('funnier');
                        setShowAIOptions(false);
                      }}
                      disabled={generating}
                    >
                      Make Funnier
                    </button>
                  </div>
                </div>
              )}
            </div>
            
            <div className="flex-grow"></div>
            
            <div className="flex items-center">
              {saveStatus && (
                <span className="text-sm text-green-600 dark:text-green-400 mr-3">
                  {saveStatus}
                </span>
              )}
              
              <button
                className="btn btn-sm btn-primary"
                onClick={() => handleSave()}
                disabled={isSaving}
              >
                {isSaving ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Saving...
                  </>
                ) : 'Save'}
              </button>
            </div>
          </div>
          
          {/* Content editor with AI panel */}
          <div className="mb-6 flex flex-col md:flex-row gap-6">
            <div className={`${showAIPanel ? 'md:w-2/3' : 'w-full'}`}>
              {generating ? (
                <div className="relative">
                  <textarea
                    ref={textareaRef}
                    className="input min-h-[500px] opacity-50 w-full"
                    value={story.content}
                    onChange={handleContentChange}
                    onKeyUp={handleCursorPositionChange}
                    onClick={handleCursorPositionChange}
                    placeholder="Write your story here or use AI to generate content..."
                    disabled
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <svg className="animate-spin h-10 w-10 mx-auto text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      <p className="mt-2 font-medium">Generating content...</p>
                    </div>
                  </div>
                </div>
              ) : (
                <textarea
                  ref={textareaRef}
                  className="input min-h-[500px] w-full"
                  value={story.content}
                  onChange={handleContentChange}
                  onKeyUp={handleCursorPositionChange}
                  onClick={handleCursorPositionChange}
                  placeholder="Write your story here or use AI to generate content..."
                />
              )}
            </div>
            
            {/* AI Tools Panel */}
            {showAIPanel && (
              <div className="md:w-1/3">
                <AIToolsPanel
                  content={story.content}
                  cursorPosition={cursorPosition}
                  genres={story.genres}
                  controls={story.controls}
                  onInsertContent={handleInsertContent}
                  onReplaceContent={handleReplaceContent}
                  onApplySuggestion={handleApplySuggestion}
                  isVisible={true}
                />
              </div>
            )}
          </div>
          
          {/* Quick edit buttons */}
          <div className="flex flex-wrap gap-2 mb-6">
            <button 
              className="btn btn-sm btn-outline"
              onClick={() => generateWithAI('continue')}
              disabled={generating}
            >
              Continue Story
            </button>
            <button 
              className="btn btn-sm btn-outline"
              onClick={() => generateWithAI('improve')}
              disabled={generating}
            >
              Improve Writing
            </button>
            <button 
              className="btn btn-sm btn-outline"
              onClick={() => generateWithAI('longer')}
              disabled={generating}
            >
              Make Longer
            </button>
            <button 
              className="btn btn-sm btn-outline"
              onClick={() => generateWithAI('shorter')}
              disabled={generating}
            >
              Make Shorter
            </button>
            <button 
              className="btn btn-sm btn-outline"
              onClick={() => generateWithAI('darker')}
              disabled={generating}
            >
              Make Darker
            </button>
            <button 
              className="btn btn-sm btn-outline"
              onClick={() => generateWithAI('funnier')}
              disabled={generating}
            >
              Make Funnier
            </button>
          </div>
          
          {/* Template selector modal */}
          {showTemplateSelector && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                <div className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold">Choose a Template</h2>
                    <button
                      className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                      onClick={() => setShowTemplateSelector(false)}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                  
                  <p className="mb-4">
                    Choose a template to jumpstart your story. This will replace your current content.
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    {templates.map((template) => (
                      <div
                        key={template.id}
                        className="template-card cursor-pointer"
                        onClick={() => applyTemplate(template.id)}
                      >
                        <h3 className="font-semibold text-lg mb-1">{template.title}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">{template.description}</p>
                        
                        <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-md mb-3 text-sm italic">
                          "{template.preview}"
                        </div>
                        
                        <div className="flex flex-wrap gap-1">
                          {template.genres.map(genre => (
                            <span 
                              key={genre} 
                              className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100"
                            >
                              {genre.charAt(0).toUpperCase() + genre.slice(1)}
                            </span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex justify-end">
                    <button
                      className="btn btn-outline"
                      onClick={() => setShowTemplateSelector(false)}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
      
      {/* Controls tab */}
      {activeTab === 'controls' && (
        <StoryControls
          onChange={handleControlsChange}
          initialValues={story.controls}
        />
      )}
      
      {/* Genres & Tags tab */}
      {activeTab === 'genres' && (
        <GenreTagSystem
          onChange={handleGenreTagChange}
          initialGenres={story.genres}
          initialTags={story.tags}
        />
      )}
    </div>
  );
};

export default StoryEditor;