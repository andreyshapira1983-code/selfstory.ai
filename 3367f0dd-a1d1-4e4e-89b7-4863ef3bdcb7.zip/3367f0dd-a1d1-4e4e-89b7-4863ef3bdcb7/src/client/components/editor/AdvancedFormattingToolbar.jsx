import React, { useState } from 'react';

/**
 * Advanced Formatting Toolbar Component
 * 
 * Provides rich text formatting options for the story editor
 * Includes text styling, headings, lists, and special formatting
 */
const AdvancedFormattingToolbar = ({ 
  onFormat, 
  onInsert,
  disabled = false,
  expanded = false
}) => {
  const [isExpanded, setIsExpanded] = useState(expanded);
  const [showTextStyles, setShowTextStyles] = useState(false);
  const [showHeadings, setShowHeadings] = useState(false);
  const [showInsert, setShowInsert] = useState(false);
  
  // Handle format action
  const handleFormat = (action, value = null) => {
    if (onFormat && !disabled) {
      onFormat(action, value);
    }
    
    // Close dropdowns
    setShowTextStyles(false);
    setShowHeadings(false);
    setShowInsert(false);
  };
  
  // Handle insert action
  const handleInsert = (type) => {
    if (onInsert && !disabled) {
      onInsert(type);
    }
    
    // Close dropdown
    setShowInsert(false);
  };
  
  // Toggle toolbar expansion
  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md shadow-sm">
      <div className="flex items-center flex-wrap p-1">
        {/* Basic formatting */}
        <button
          className="toolbar-btn"
          onClick={() => handleFormat('bold')}
          title="Bold"
          disabled={disabled}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path d="M13.5 10a2.5 2.5 0 01-2.5 2.5H6.5v-7h4.5a2.5 2.5 0 012.5 2.5v2z" />
            <path d="M12.5 14H6.5v3h6a3 3 0 003-3v-2a3 3 0 00-3-3z" />
          </svg>
        </button>
        
        <button
          className="toolbar-btn"
          onClick={() => handleFormat('italic')}
          title="Italic"
          disabled={disabled}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 4.5a.5.5 0 01.5-.5h3a.5.5 0 010 1h-3a.5.5 0 01-.5-.5zm-1 2a.5.5 0 01.5-.5h6a.5.5 0 010 1h-6a.5.5 0 01-.5-.5zm-2 2a.5.5 0 01.5-.5h8a.5.5 0 010 1h-8a.5.5 0 01-.5-.5zm0 2a.5.5 0 01.5-.5h8a.5.5 0 010 1h-8a.5.5 0 01-.5-.5zm3 2a.5.5 0 01.5-.5h2a.5.5 0 010 1h-2a.5.5 0 01-.5-.5z" clipRule="evenodd" />
          </svg>
        </button>
        
        <button
          className="toolbar-btn"
          onClick={() => handleFormat('underline')}
          title="Underline"
          disabled={disabled}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path d="M7 4a1 1 0 011-1h4a1 1 0 110 2H8a1 1 0 01-1-1zM5 18h10a1 1 0 010 2H5a1 1 0 010-2z" />
            <path fillRule="evenodd" d="M10 5a1 1 0 00-1 1v6a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
          </svg>
        </button>
        
        <div className="h-6 border-r border-gray-300 dark:border-gray-600 mx-1"></div>
        
        {/* Text styles dropdown */}
        <div className="relative">
          <button
            className="toolbar-btn"
            onClick={() => setShowTextStyles(!showTextStyles)}
            title="Text Styles"
            disabled={disabled}
          >
            <span className="mr-1">Styles</span>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </button>
          
          {showTextStyles && (
            <div className="absolute z-10 mt-1 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg border border-gray-200 dark:border-gray-700">
              <div className="py-1">
                <button
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                  onClick={() => handleFormat('style', 'normal')}
                >
                  Normal Text
                </button>
                <button
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 italic"
                  onClick={() => handleFormat('style', 'emphasis')}
                >
                  Emphasis
                </button>
                <button
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 font-bold"
                  onClick={() => handleFormat('style', 'strong')}
                >
                  Strong
                </button>
                <button
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 line-through"
                  onClick={() => handleFormat('style', 'strikethrough')}
                >
                  Strikethrough
                </button>
                <button
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 text-primary"
                  onClick={() => handleFormat('style', 'highlight')}
                >
                  Highlight
                </button>
                <button
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 font-mono"
                  onClick={() => handleFormat('style', 'code')}
                >
                  Code
                </button>
              </div>
            </div>
          )}
        </div>
        
        {/* Headings dropdown */}
        <div className="relative">
          <button
            className="toolbar-btn"
            onClick={() => setShowHeadings(!showHeadings)}
            title="Headings"
            disabled={disabled}
          >
            <span className="mr-1">Headings</span>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </button>
          
          {showHeadings && (
            <div className="absolute z-10 mt-1 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg border border-gray-200 dark:border-gray-700">
              <div className="py-1">
                <button
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 text-2xl font-bold"
                  onClick={() => handleFormat('heading', 1)}
                >
                  Heading 1
                </button>
                <button
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 text-xl font-bold"
                  onClick={() => handleFormat('heading', 2)}
                >
                  Heading 2
                </button>
                <button
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 text-lg font-bold"
                  onClick={() => handleFormat('heading', 3)}
                >
                  Heading 3
                </button>
                <button
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 font-bold"
                  onClick={() => handleFormat('heading', 4)}
                >
                  Heading 4
                </button>
              </div>
            </div>
          )}
        </div>
        
        <div className="h-6 border-r border-gray-300 dark:border-gray-600 mx-1"></div>
        
        {/* Lists */}
        <button
          className="toolbar-btn"
          onClick={() => handleFormat('list', 'bullet')}
          title="Bullet List"
          disabled={disabled}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M5 4a1 1 0 011-1h10a1 1 0 110 2H6a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H6a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H6a1 1 0 01-1-1zm-4-3a1 1 0 100-2 1 1 0 000 2zm0-6a1 1 0 100-2 1 1 0 000 2zm0 12a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
          </svg>
        </button>
        
        <button
          className="toolbar-btn"
          onClick={() => handleFormat('list', 'number')}
          title="Numbered List"
          disabled={disabled}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M5 4a1 1 0 011-1h10a1 1 0 110 2H6a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H6a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H6a1 1 0 01-1-1zm-4-10a1 1 0 100-2 1 1 0 000 2zm0 6a1 1 0 100-2 1 1 0 000 2zm0 6a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
          </svg>
        </button>
        
        {/* Expanded toolbar section */}
        {isExpanded && (
          <>
            <div className="h-6 border-r border-gray-300 dark:border-gray-600 mx-1"></div>
            
            {/* Alignment */}
            <button
              className="toolbar-btn"
              onClick={() => handleFormat('align', 'left')}
              title="Align Left"
              disabled={disabled}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h6a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
              </svg>
            </button>
            
            <button
              className="toolbar-btn"
              onClick={() => handleFormat('align', 'center')}
              title="Align Center"
              disabled={disabled}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3 4a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm0 4a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
              </svg>
            </button>
            
            <button
              className="toolbar-btn"
              onClick={() => handleFormat('align', 'right')}
              title="Align Right"
              disabled={disabled}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm6 4a1 1 0 011-1h6a1 1 0 110 2H10a1 1 0 01-1-1zm0 4a1 1 0 011-1h6a1 1 0 110 2H10a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
              </svg>
            </button>
            
            <div className="h-6 border-r border-gray-300 dark:border-gray-600 mx-1"></div>
            
            {/* Indentation */}
            <button
              className="toolbar-btn"
              onClick={() => handleFormat('indent', 'decrease')}
              title="Decrease Indent"
              disabled={disabled}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm8 4a1 1 0 01-1-1V8a1 1 0 112 0v4a1 1 0 01-1 1zm-8 0a1 1 0 011-1h4a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
              </svg>
            </button>
            
            <button
              className="toolbar-btn"
              onClick={() => handleFormat('indent', 'increase')}
              title="Increase Indent"
              disabled={disabled}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm4 4a1 1 0 10-2 0v4a1 1 0 102 0v-4zm4-1a1 1 0 011-1h6a1 1 0 110 2h-6a1 1 0 01-1-1zm0 4a1 1 0 011-1h6a1 1 0 110 2h-6a1 1 0 01-1-1z" clipRule="evenodd" />
              </svg>
            </button>
            
            <div className="h-6 border-r border-gray-300 dark:border-gray-600 mx-1"></div>
            
            {/* Insert dropdown */}
            <div className="relative">
              <button
                className="toolbar-btn"
                onClick={() => setShowInsert(!showInsert)}
                title="Insert"
                disabled={disabled}
              >
                <span className="mr-1">Insert</span>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
              
              {showInsert && (
                <div className="absolute z-10 mt-1 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg border border-gray-200 dark:border-gray-700">
                  <div className="py-1">
                    <button
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => handleInsert('image')}
                    >
                      Image
                    </button>
                    <button
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => handleInsert('table')}
                    >
                      Table
                    </button>
                    <button
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => handleInsert('horizontalRule')}
                    >
                      Horizontal Rule
                    </button>
                    <button
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => handleInsert('pageBreak')}
                    >
                      Page Break
                    </button>
                    <button
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => handleInsert('characterName')}
                    >
                      Character Name
                    </button>
                    <button
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => handleInsert('locationName')}
                    >
                      Location Name
                    </button>
                  </div>
                </div>
              )}
            </div>
            
            <div className="h-6 border-r border-gray-300 dark:border-gray-600 mx-1"></div>
            
            {/* Clear formatting */}
            <button
              className="toolbar-btn"
              onClick={() => handleFormat('clear')}
              title="Clear Formatting"
              disabled={disabled}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </>
        )}
        
        {/* Expand/collapse button */}
        <button
          className="toolbar-btn ml-auto"
          onClick={toggleExpand}
          title={isExpanded ? "Show Less" : "Show More"}
        >
          {isExpanded ? (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd" />
            </svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          )}
        </button>
      </div>
      
      <style jsx>{`
        .toolbar-btn {
          @apply p-2 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50 flex items-center justify-center;
        }
        
        .toolbar-btn:disabled {
          @apply opacity-50 cursor-not-allowed;
        }
      `}</style>
    </div>
  );
};

export default AdvancedFormattingToolbar;