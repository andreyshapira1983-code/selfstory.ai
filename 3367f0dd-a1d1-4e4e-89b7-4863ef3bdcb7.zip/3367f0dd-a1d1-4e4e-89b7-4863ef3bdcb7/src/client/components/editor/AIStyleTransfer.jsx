import React, { useState } from 'react';
import { applyStyle } from '../../utils/aiService';

/**
 * AI Style Transfer Component
 * 
 * Allows users to apply different writing styles to their content
 * Includes predefined styles like Hemingway, Tolkien, etc.
 */
const AIStyleTransfer = ({ content, onApplyStyle }) => {
  const [selectedStyle, setSelectedStyle] = useState('');
  const [strength, setStrength] = useState(0.7);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [preview, setPreview] = useState('');
  
  // Available writing styles
  const styles = [
    { id: 'hemingway', name: 'Hemingway', description: 'Clear, direct prose with short sentences. Sparse on adjectives.' },
    { id: 'tolkien', name: 'Tolkien', description: 'Elaborate, descriptive prose rich with detail. Long, flowing sentences.' },
    { id: 'austen', name: 'Jane Austen', description: 'Elegant, witty prose with social observations. Formal language.' },
    { id: 'king', name: 'Stephen King', description: 'Conversational tone with suspenseful pacing. Blends everyday observations.' },
    { id: 'rowling', name: 'J.K. Rowling', description: 'Accessible prose with whimsical elements. Strong character focus.' }
  ];
  
  // Handle style selection
  const handleStyleSelect = (styleId) => {
    setSelectedStyle(styleId);
    setPreview('');
  };
  
  // Handle strength change
  const handleStrengthChange = (e) => {
    setStrength(parseFloat(e.target.value));
  };
  
  // Generate style preview
  const handlePreview = async () => {
    if (!selectedStyle || !content) return;
    
    setLoading(true);
    setError(null);
    
    try {
      // Get a sample of the content (first 200 characters)
      const sampleContent = content.substring(0, 200);
      
      const result = await applyStyle({
        content: sampleContent,
        style: selectedStyle,
        strength
      });
      
      setPreview(result.styled);
    } catch (err) {
      console.error('Failed to generate style preview:', err);
      setError('Failed to generate preview');
    } finally {
      setLoading(false);
    }
  };
  
  // Apply style to entire content
  const handleApply = async () => {
    if (!selectedStyle || !content) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const result = await applyStyle({
        content,
        style: selectedStyle,
        strength
      });
      
      onApplyStyle(result.styled);
      setPreview('');
    } catch (err) {
      console.error('Failed to apply style:', err);
      setError('Failed to apply style');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
      <h3 className="text-lg font-medium mb-3">Style Transfer</h3>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Select Writing Style</label>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
          {styles.map((style) => (
            <button
              key={style.id}
              className={`p-3 rounded-md border text-left ${
                selectedStyle === style.id
                  ? 'border-primary bg-primary bg-opacity-10'
                  : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
              onClick={() => handleStyleSelect(style.id)}
            >
              <div className="font-medium">{style.name}</div>
              <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {style.description}
              </div>
            </button>
          ))}
        </div>
      </div>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">
          Style Strength: {Math.round(strength * 100)}%
        </label>
        <input
          type="range"
          min="0.1"
          max="1"
          step="0.1"
          value={strength}
          onChange={handleStrengthChange}
          className="w-full"
        />
        <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
          <span>Subtle</span>
          <span>Balanced</span>
          <span>Strong</span>
        </div>
      </div>
      
      {/* Preview section */}
      {preview && (
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">Preview</label>
          <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded border border-gray-200 dark:border-gray-600 text-sm">
            {preview}
          </div>
        </div>
      )}
      
      {/* Error message */}
      {error && (
        <div className="text-red-500 text-sm mb-4">
          {error}
        </div>
      )}
      
      <div className="flex space-x-3">
        <button
          className="btn btn-outline"
          onClick={handlePreview}
          disabled={!selectedStyle || !content || loading}
        >
          {loading && !preview ? (
            <span className="flex items-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Previewing...
            </span>
          ) : 'Preview Style'}
        </button>
        <button
          className="btn btn-primary"
          onClick={handleApply}
          disabled={!selectedStyle || !content || loading}
        >
          {loading && preview ? (
            <span className="flex items-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Applying...
            </span>
          ) : 'Apply Style'}
        </button>
      </div>
      
      <div className="mt-3 text-xs text-gray-500 dark:text-gray-400">
        Style transfer will rewrite your content to match the selected author's style while preserving the meaning.
      </div>
    </div>
  );
};

export default AIStyleTransfer;