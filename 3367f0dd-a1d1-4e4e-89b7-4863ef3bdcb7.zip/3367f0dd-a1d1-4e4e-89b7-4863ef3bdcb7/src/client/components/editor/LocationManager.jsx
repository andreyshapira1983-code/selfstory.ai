import React, { useState } from 'react';

/**
 * Location Manager Component
 * 
 * Provides tools for creating, editing, and managing story locations
 * Includes map visualization and location details
 */
const LocationManager = ({
  locations = [],
  onAddLocation,
  onUpdateLocation,
  onDeleteLocation
}) => {
  const [activeLocation, setActiveLocation] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // New location template
  const newLocationTemplate = {
    id: '',
    name: '',
    type: 'setting', // setting, landmark, building, region, etc.
    description: '',
    climate: '',
    culture: '',
    history: '',
    significance: '',
    inhabitants: [],
    connectedLocations: [],
    notes: ''
  };
  
  // Location being edited
  const [editingLocation, setEditingLocation] = useState({...newLocationTemplate});
  
  // Handle location selection
  const handleSelectLocation = (location) => {
    setActiveLocation(location);
    setEditingLocation(location);
    setIsEditing(false);
    setIsCreating(false);
  };
  
  // Handle creating new location
  const handleCreateNew = () => {
    const newId = `location-${Date.now()}`;
    setEditingLocation({...newLocationTemplate, id: newId});
    setActiveLocation(null);
    setIsEditing(false);
    setIsCreating(true);
  };
  
  // Handle editing location
  const handleEdit = () => {
    setIsEditing(true);
    setIsCreating(false);
  };
  
  // Handle saving location
  const handleSave = () => {
    if (isCreating) {
      onAddLocation(editingLocation);
      setActiveLocation(editingLocation);
    } else {
      onUpdateLocation(editingLocation);
      setActiveLocation(editingLocation);
    }
    
    setIsEditing(false);
    setIsCreating(false);
  };
  
  // Handle deleting location
  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete ${activeLocation.name}?`)) {
      onDeleteLocation(activeLocation.id);
      setActiveLocation(null);
      setEditingLocation({...newLocationTemplate});
      setIsEditing(false);
      setIsCreating(false);
    }
  };
  
  // Handle field change
  const handleFieldChange = (field, value) => {
    setEditingLocation(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  // Handle array field change (for inhabitants, connected locations)
  const handleArrayFieldChange = (field, value) => {
    const values = value.split(',').map(item => item.trim()).filter(item => item);
    
    setEditingLocation(prev => ({
      ...prev,
      [field]: values
    }));
  };
  
  // Filter locations based on search term
  const filteredLocations = locations.filter(location => 
    location.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    location.type.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      {/* Header */}
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-b border-gray-200 dark:border-gray-600">
        <h2 className="text-lg font-medium flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-primary" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
          </svg>
          Location Manager
        </h2>
      </div>
      
      {/* Main content */}
      <div className="flex flex-col md:flex-row">
        {/* Location list sidebar */}
        <div className="w-full md:w-1/3 border-r border-gray-200 dark:border-gray-600">
          <div className="p-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium">Locations</h3>
              <button
                className="btn btn-sm btn-primary"
                onClick={handleCreateNew}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                </svg>
                New
              </button>
            </div>
            
            {/* Search */}
            <div className="mb-4">
              <input
                type="text"
                className="input w-full"
                placeholder="Search locations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            {/* Location list */}
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {filteredLocations.length === 0 ? (
                <div className="text-center py-4 text-gray-500 dark:text-gray-400">
                  {searchTerm ? 'No locations match your search' : 'No locations yet'}
                </div>
              ) : (
                filteredLocations.map(location => (
                  <div
                    key={location.id}
                    className={`p-3 rounded-md cursor-pointer ${
                      activeLocation?.id === location.id
                        ? 'bg-primary bg-opacity-10 border border-primary'
                        : 'hover:bg-gray-100 dark:hover:bg-gray-700 border border-transparent'
                    }`}
                    onClick={() => handleSelectLocation(location)}
                  >
                    <div className="font-medium">{location.name}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400 capitalize">
                      {location.type}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
        
        {/* Location detail/edit panel */}
        <div className="w-full md:w-2/3 p-4">
          {activeLocation && !isEditing && !isCreating ? (
            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-medium text-xl">{activeLocation.name}</h3>
                <div className="flex space-x-2">
                  <button
                    className="btn btn-sm btn-outline"
                    onClick={handleEdit}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                    </svg>
                    Edit
                  </button>
                  <button
                    className="btn btn-sm btn-danger"
                    onClick={handleDelete}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    Delete
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Type</span>
                  <p className="capitalize">{activeLocation.type}</p>
                </div>
                
                <div>
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Climate</span>
                  <p>{activeLocation.climate}</p>
                </div>
              </div>
              
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Description</span>
                <p className="whitespace-pre-line">{activeLocation.description}</p>
              </div>
              
              {activeLocation.culture && (
                <div className="mb-4">
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Culture</span>
                  <p className="whitespace-pre-line">{activeLocation.culture}</p>
                </div>
              )}
              
              {activeLocation.history && (
                <div className="mb-4">
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">History</span>
                  <p className="whitespace-pre-line">{activeLocation.history}</p>
                </div>
              )}
              
              {activeLocation.significance && (
                <div className="mb-4">
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Significance</span>
                  <p className="whitespace-pre-line">{activeLocation.significance}</p>
                </div>
              )}
              
              {activeLocation.inhabitants.length > 0 && (
                <div className="mb-4">
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Inhabitants</span>
                  <p>{activeLocation.inhabitants.join(', ')}</p>
                </div>
              )}
              
              {activeLocation.connectedLocations.length > 0 && (
                <div className="mb-4">
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Connected Locations</span>
                  <p>{activeLocation.connectedLocations.join(', ')}</p>
                </div>
              )}
              
              {activeLocation.notes && (
                <div>
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Notes</span>
                  <p className="whitespace-pre-line">{activeLocation.notes}</p>
                </div>
              )}
            </div>
          ) : (isEditing || isCreating) ? (
            <div>
              <h3 className="font-medium mb-4">
                {isCreating ? 'Create New Location' : `Edit ${editingLocation.name}`}
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Name</label>
                  <input
                    type="text"
                    className="input w-full"
                    value={editingLocation.name}
                    onChange={(e) => handleFieldChange('name', e.target.value)}
                    placeholder="Location name"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Type</label>
                    <select
                      className="input w-full"
                      value={editingLocation.type}
                      onChange={(e) => handleFieldChange('type', e.target.value)}
                    >
                      <option value="setting">Setting</option>
                      <option value="landmark">Landmark</option>
                      <option value="building">Building</option>
                      <option value="region">Region</option>
                      <option value="city">City</option>
                      <option value="country">Country</option>
                      <option value="planet">Planet</option>
                      <option value="realm">Realm</option>
                      <option value="dungeon">Dungeon</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1">Climate</label>
                    <input
                      type="text"
                      className="input w-full"
                      value={editingLocation.climate}
                      onChange={(e) => handleFieldChange('climate', e.target.value)}
                      placeholder="Climate or weather"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <textarea
                    className="input w-full"
                    rows={3}
                    value={editingLocation.description}
                    onChange={(e) => handleFieldChange('description', e.target.value)}
                    placeholder="Describe the location's appearance and features"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Culture</label>
                  <textarea
                    className="input w-full"
                    rows={2}
                    value={editingLocation.culture}
                    onChange={(e) => handleFieldChange('culture', e.target.value)}
                    placeholder="Cultural aspects of this location"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">History</label>
                  <textarea
                    className="input w-full"
                    rows={2}
                    value={editingLocation.history}
                    onChange={(e) => handleFieldChange('history', e.target.value)}
                    placeholder="Historical background of this location"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Significance</label>
                  <textarea
                    className="input w-full"
                    rows={2}
                    value={editingLocation.significance}
                    onChange={(e) => handleFieldChange('significance', e.target.value)}
                    placeholder="Why this location matters to the story"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Inhabitants (comma separated)</label>
                  <input
                    type="text"
                    className="input w-full"
                    value={editingLocation.inhabitants.join(', ')}
                    onChange={(e) => handleArrayFieldChange('inhabitants', e.target.value)}
                    placeholder="People, creatures, or groups that inhabit this location"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Connected Locations (comma separated)</label>
                  <input
                    type="text"
                    className="input w-full"
                    value={editingLocation.connectedLocations.join(', ')}
                    onChange={(e) => handleArrayFieldChange('connectedLocations', e.target.value)}
                    placeholder="Other locations connected to this one"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Notes</label>
                  <textarea
                    className="input w-full"
                    rows={2}
                    value={editingLocation.notes}
                    onChange={(e) => handleFieldChange('notes', e.target.value)}
                    placeholder="Additional notes about this location"
                  />
                </div>
                
                <div className="flex justify-end space-x-3">
                  <button
                    className="btn btn-outline"
                    onClick={() => {
                      if (isCreating) {
                        setIsCreating(false);
                      } else {
                        setIsEditing(false);
                      }
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    className="btn btn-primary"
                    onClick={handleSave}
                    disabled={!editingLocation.name}
                  >
                    {isCreating ? 'Create Location' : 'Save Changes'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-64">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              <p className="text-gray-500 dark:text-gray-400 mb-4">Select a location or create a new one</p>
              <button
                className="btn btn-primary"
                onClick={handleCreateNew}
              >
                Create New Location
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LocationManager;