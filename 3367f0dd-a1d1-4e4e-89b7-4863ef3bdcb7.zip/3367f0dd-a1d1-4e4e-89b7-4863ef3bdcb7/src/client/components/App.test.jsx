import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

// Mock localStorage
const localStorageMock = (function() {
  let store = {};
  return {
    getItem: jest.fn(key => store[key] || null),
    setItem: jest.fn((key, value) => {
      store[key] = value.toString();
    }),
    clear: jest.fn(() => {
      store = {};
    }),
    removeItem: jest.fn(key => {
      delete store[key];
    })
  };
})();

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock
});

// Mock matchMedia
window.matchMedia = window.matchMedia || function() {
  return {
    matches: false,
    addListener: function() {},
    removeListener: function() {}
  };
};

describe('App Component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorageMock.clear();
  });

  test('renders loading screen initially', () => {
    render(<App />);
    expect(screen.getByText(/Loading StoryAI/i)).toBeInTheDocument();
  });

  test('renders onboarding when no user exists', async () => {
    // Mock setTimeout to execute immediately
    jest.useFakeTimers();
    
    render(<App />);
    
    // Fast-forward timers
    jest.runAllTimers();
    
    // Check for onboarding content
    expect(await screen.findByText(/Welcome to StoryAI/i)).toBeInTheDocument();
    
    jest.useRealTimers();
  });

  test('renders dashboard when user exists', async () => {
    // Set up localStorage with user data
    localStorageMock.setItem('storyai_user', JSON.stringify({
      id: 'user-1',
      name: 'Test User',
      preferredGenres: ['fantasy', 'sci-fi']
    }));
    
    // Mock setTimeout to execute immediately
    jest.useFakeTimers();
    
    render(<App />);
    
    // Fast-forward timers
    jest.runAllTimers();
    
    // Check for dashboard content
    expect(await screen.findByText(/Your Stories/i)).toBeInTheDocument();
    
    jest.useRealTimers();
  });
});