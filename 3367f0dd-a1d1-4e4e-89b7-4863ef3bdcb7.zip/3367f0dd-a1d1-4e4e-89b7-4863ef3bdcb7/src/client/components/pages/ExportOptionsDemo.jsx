import React, { useState } from 'react';
import ExportOptions from '../export/ExportOptions';

/**
 * ExportOptionsDemo - Demonstration page for the export options feature
 * 
 * This page showcases the export options for publishing stories in various formats:
 * - PDF with customizable options
 * - ePub for e-readers
 * - Manuscript formats for submissions
 * - Cover page generation
 */
const ExportOptionsDemo = () => {
  const [showExportOptions, setShowExportOptions] = useState(false);
  
  // Sample story content for demonstration
  const sampleStory = {
    title: "The Forgotten Lighthouse",
    author: "Alex Morgan",
    content: `# The Forgotten Lighthouse

By Alex Morgan

## Chapter 1: The Discovery

The old lighthouse stood on the edge of the cliff, its paint peeling and windows clouded with salt and time. For decades, it had been abandoned, forgotten by the town that once depended on its guiding light. But today, someone was climbing the winding path that led to its door.

Sarah Parker, a marine historian with a passion for coastal architecture, had been researching the forgotten lighthouses of New England for her upcoming book. This particular lighthouse, known locally as "The Sentinel," had caught her attention because of its unusual history. According to local records, the last lighthouse keeper had disappeared without a trace in 1952, and since then, the lighthouse had remained untouched.

"It's even more impressive up close," Sarah muttered to herself as she approached the weathered structure. The lighthouse tower rose nearly a hundred feet into the air, its once-white exterior now a patchwork of faded paint and exposed brick. The keeper's house attached to its base seemed to lean slightly toward the sea, as if yearning to join it.

Sarah set down her backpack and took out her camera, capturing several angles of the lighthouse against the dramatic backdrop of churning waves and gray skies. The October wind whipped her hair around her face as she worked, the salt spray occasionally reaching her even at this height.

After taking sufficient exterior photographs, she approached the entrance. The door was secured with a rusted padlock, but Sarah had obtained permission from the local historical society to enter. She fumbled with the key they had provided, struggling to make it turn in the corroded mechanism. Finally, with a screech of metal, the lock gave way.

The door swung open with a haunting creak, revealing a dust-filled interior untouched by modern hands. Sarah stepped inside, allowing her eyes to adjust to the dimness. The air was thick with the smell of salt, mildew, and something else she couldn't quite identify—something almost metallic.

"Hello?" she called out, more out of habit than any expectation of a response. Her voice echoed through the empty rooms, disturbing decades of silence.

The ground floor consisted of what had once been the keeper's living quarters: a small kitchen, a modest sitting area, and what appeared to be a study. Everything was covered in a thick layer of dust, but otherwise, it looked as if the keeper had simply stepped out momentarily. A coffee cup still sat on the kitchen table. A book lay open on the desk in the study. A jacket hung by the door.

Sarah moved carefully through the rooms, documenting everything with her camera. The historical society had asked her to catalog the contents before any restoration work began. But as she worked, she couldn't shake the feeling that she was being watched.

"Just nerves," she told herself. "Old buildings always feel this way."

She made her way to the spiral staircase that led up to the lantern room. Each step groaned under her weight, announcing her ascent to the empty building. The staircase wound tightly around, making her slightly dizzy as she climbed higher and higher.

Finally, she reached the lantern room at the top. The massive Fresnel lens that had once guided ships safely to shore was still intact, though dulled by years of neglect. Sarah approached it reverently, running her fingers over the intricate glass prisms.

"You're quite a beauty," she whispered to the lens.

As she circled the lantern room, Sarah noticed a small desk tucked against the wall. On it lay the lighthouse keeper's logbook, its leather cover cracked with age. Unable to resist, she carefully opened it, finding entries dating back to 1950.

The final entry, dated October 17, 1952, caught her attention:

*Strange lights on the horizon again tonight. Moving in ways no ship ever could. They're getting closer. I've radioed the mainland, but they think I'm going mad. Maybe I am. But if anyone finds this, know that I did not abandon my post. Whatever comes tonight, I will face it as a keeper should.*

Sarah felt a chill run down her spine as she read the words. The entry ended there, with no explanation of what happened to the keeper afterward.

Suddenly, the temperature in the lantern room seemed to drop. Sarah's breath fogged in front of her face, despite it being a mild autumn day. The hairs on the back of her neck stood up, and she had the distinct impression that someone was standing directly behind her.

Slowly, she turned around.

## Chapter 2: Echoes of the Past

The lantern room was empty, just as it had been when she entered. Sarah let out a shaky breath, chiding herself for getting spooked by an old logbook entry and her own imagination.

"Get it together, Parker," she muttered. "You're a historian, not a ghost hunter."

Still, she couldn't shake the unease that had settled over her. She decided to finish her documentation quickly and return tomorrow with better lighting equipment. As she turned to leave, her eye caught something scratched into the metal wall beside the desk—something she hadn't noticed before.

Leaning closer, she could make out a series of numbers and what appeared to be a crude map. The numbers looked like coordinates, and the map showed the lighthouse and a path leading from it down to a cove that Sarah didn't remember seeing from the cliff path.

Intrigued, she copied the markings into her notebook. This could be an important historical find—perhaps the keeper had cached something before his disappearance. As a responsible historian, she would need to inform the historical society, but there was no harm in doing a bit of preliminary investigation.

Sarah made her way back down the spiral staircase, her earlier unease forgotten in the excitement of discovery. As she reached the ground floor, she noticed that the light had changed. The afternoon was waning, casting long shadows through the dusty windows.

She stepped outside, locking the lighthouse door behind her, and consulted her map of the area. If her interpretation of the scratched map was correct, there should be a path leading down the cliff face about fifty yards south of the lighthouse.

Sure enough, after a short walk, she found a narrow trail that she had missed on her way up. It was overgrown and treacherous-looking, but still passable. Sarah checked her watch—she had about two hours of daylight left, plenty of time to explore the cove and get back to her car before dark.

The path down was steeper than it had appeared from above. Sarah picked her way carefully over loose rocks and through thorny brambles that seemed determined to block her way. About halfway down, the path turned sharply, revealing a view of a small, secluded cove that was indeed hidden from both the lighthouse above and the main shoreline.

"Well, I'll be damned," Sarah said to herself. "The old keeper had his own private beach."

As she continued her descent, she noticed something odd about the cove. Unlike the rocky shoreline that dominated this part of the coast, this cove had a small stretch of sandy beach. And there, just above the tideline, was what appeared to be a small wooden structure—a boathouse, perhaps?

Sarah's heart raced with anticipation. If that boathouse had remained as untouched as the lighthouse, it could contain valuable historical artifacts—maybe even clues to the keeper's fate.

The final portion of the path was the most treacherous, with several sections where the trail had eroded away completely, forcing Sarah to find alternative routes down the cliff face. By the time her feet hit the sand of the cove, her hands were scraped, and her hiking pants were torn at one knee, but her excitement outweighed her discomfort.

The structure was indeed a boathouse, though time and the elements had not been kind to it. The roof had partially collapsed, and one wall had been almost entirely reclaimed by nature, covered in a thick growth of ivy and moss. The door, however, was still intact, secured with a padlock similar to the one on the lighthouse.

Sarah tried the key she had been given, but it didn't fit. Undeterred, she examined the padlock more closely and realized that it was so corroded that a firm tug might break it open. She wrapped her hand in her jacket sleeve to protect it from sharp edges and pulled hard. With a snap, the lock broke apart, and the door swung open with a groan of protest.

The interior of the boathouse was dark, the only light filtering in through the collapsed section of the roof and the now-open door. As her eyes adjusted, Sarah could make out the shape of a small rowboat, still on its cradle, though the wood had rotted in several places. Against one wall stood a workbench covered in tools, now rusted beyond use, and fishing gear that had long since surrendered to decay.

But what caught Sarah's attention was a sea chest tucked in the corner, partially hidden under a moldering tarp. Unlike everything else in the boathouse, the chest appeared to be in remarkably good condition, its brass fittings tarnished but intact.

Sarah approached it cautiously, her historian's instincts warring with a growing sense that she was intruding on something private, something that perhaps should have remained hidden. She knelt beside the chest and carefully lifted the lid.

Inside, she found a collection of items that seemed out of place in a lighthouse keeper's possession: a sextant of unusual design, a journal bound in leather that didn't look quite like any animal hide she recognized, and a glass container holding what appeared to be seawater, but with an odd, luminescent quality that made it glow faintly even in the dim light of the boathouse.

Sarah picked up the journal and opened it carefully. Unlike the logbook in the lighthouse, this one was filled not with daily records but with detailed drawings—drawings of strange lights in the sky, of shapes beneath the waves that resembled no marine life Sarah had ever seen, and of beings that seemed neither fully human nor fully... something else.

The text accompanying these drawings was written in a language Sarah didn't recognize—not Latin or Greek or any other ancient tongue she had encountered in her studies. Yet somehow, certain words seemed to shimmer on the page, almost as if trying to translate themselves for her.

As she turned the pages, a loose photograph fell out. Sarah picked it up and found herself staring at a black-and-white image of the lighthouse keeper—she recognized him from historical records—standing on the beach of this very cove. But he wasn't alone. Beside him stood a figure that made Sarah's blood run cold.

The figure was humanoid but wrong somehow—too tall, too thin, with limbs that bent at odd angles. Its face was blurred, not from motion but as if it existed slightly out of phase with the rest of the world. And though the photograph was in black and white, Sarah could have sworn that the figure's eyes held a luminescence similar to the strange seawater in the glass container.

On the back of the photograph, a single line was written in English: "They come from the stars, but they live in the deep."

Sarah's hands trembled as she returned the photograph to the journal. The rational part of her mind—the historian, the scientist—tried to make sense of what she was seeing. Perhaps the keeper had been an amateur fiction writer, creating an elaborate fantasy world. Perhaps the photograph was an early example of double exposure or some other camera trick.

But a deeper part of her, a part connected to instincts far older than rational thought, knew that she had stumbled upon something true. Something real. Something that had been waiting in this cove for someone to find it.

As if responding to her realization, the glass container of seawater began to glow more brightly. Sarah watched, transfixed, as the luminescence within it pulsed like a heartbeat. And then, faintly at first but growing stronger, she heard a sound—a sound that seemed to come not from the air around her but from within her own mind.

It was a song, beautiful and terrible, familiar and alien. It spoke of depths beyond human comprehension, of civilizations that rose and fell before the first human ancestor crawled from the primordial ooze, of beings that traveled between stars as easily as humans crossed streets.

And it was calling her name.

Sarah didn't remember closing the journal or the sea chest. She didn't remember leaving the boathouse or climbing back up the treacherous path to the lighthouse. The next thing she knew, she was sitting in her car, her hands gripping the steering wheel so tightly that her knuckles were white, her breath coming in short, sharp gasps.

The sun had set, and stars were beginning to appear in the darkening sky. Sarah looked up at them and wondered, for the first time in her life, if something up there was looking back.

She started the car with shaking hands. She would return to her hotel, take a hot shower, and try to make sense of what she had found. Tomorrow, she would contact the historical society and share her discoveries—the coordinates, the boathouse, the sea chest.

But not the journal. Not the photograph. Not the glowing seawater. Those things she would keep to herself, at least until she understood them better.

As she drove away from the lighthouse, Sarah glanced in her rearview mirror. For just a moment, she thought she saw lights—strange, moving lights—hovering over the lantern room of the old lighthouse.

"They come from the stars," she whispered to herself, "but they live in the deep."

And somewhere in the back of her mind, the alien song continued to play.`
  };
  
  // Toggle export options modal
  const toggleExportOptions = () => {
    setShowExportOptions(!showExportOptions);
  };
  
  return (
    <div className="export-options-demo">
      <div className="demo-header">
        <h1>Export Options Demo</h1>
        <p className="demo-description">
          Experience the powerful export capabilities of StoryAI, allowing you to publish your stories in various formats.
        </p>
      </div>
      
      <div className="demo-features">
        <div className="feature-card">
          <div className="feature-icon">📄</div>
          <h3>PDF Export</h3>
          <p>Create professional PDF documents with customizable page size, fonts, margins, and more.</p>
        </div>
        
        <div className="feature-card">
          <div className="feature-icon">📱</div>
          <h3>ePub Export</h3>
          <p>Generate ePub files compatible with e-readers and digital book platforms.</p>
        </div>
        
        <div className="feature-card">
          <div className="feature-icon">📝</div>
          <h3>Manuscript Format</h3>
          <p>Format your story according to industry-standard manuscript guidelines for submissions.</p>
        </div>
        
        <div className="feature-card">
          <div className="feature-icon">🖼️</div>
          <h3>Cover Generation</h3>
          <p>Create professional book covers with customizable templates and designs.</p>
        </div>
      </div>
      
      <div className="story-preview">
        <h2>Story Preview</h2>
        <div className="story-card">
          <div className="story-header">
            <h3>{sampleStory.title}</h3>
            <p className="story-author">By {sampleStory.author}</p>
          </div>
          <div className="story-excerpt">
            <p>{sampleStory.content.split('\n\n')[2]}</p>
            <p className="excerpt-fade"></p>
          </div>
        </div>
      </div>
      
      <div className="demo-actions">
        <button 
          className="export-demo-btn"
          onClick={toggleExportOptions}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
          Export Story
        </button>
      </div>
      
      <div className="demo-instructions">
        <h2>How to Use</h2>
        <ol>
          <li>Click the "Export Story" button above to open the export options panel</li>
          <li>Choose your desired export format (PDF, ePub, Manuscript, or Cover)</li>
          <li>Customize the export settings according to your preferences</li>
          <li>Click "Export" to generate and download your file</li>
        </ol>
        <p className="note">
          Note: This is a demonstration of the export functionality. In a real implementation, the exported files would be fully functional and properly formatted.
        </p>
      </div>
      
      {/* Export Options Modal */}
      {showExportOptions && (
        <ExportOptions
          content={sampleStory.content}
          title={sampleStory.title}
          author={sampleStory.author}
          onClose={toggleExportOptions}
        />
      )}
    </div>
  );
};

export default ExportOptionsDemo;