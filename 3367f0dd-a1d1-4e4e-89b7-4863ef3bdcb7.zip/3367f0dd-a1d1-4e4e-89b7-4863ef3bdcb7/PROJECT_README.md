# StoryAI - AI-Powered Storytelling Platform

StoryAI is an interactive platform that helps users create compelling stories with the assistance of AI. The platform provides a guided onboarding experience, story templates, and AI-powered writing tools to make storytelling accessible and enjoyable for everyone.

![StoryAI Platform](https://via.placeholder.com/1200x600?text=StoryAI+Platform)

## 🌟 Key Features

### User Onboarding & First Experience
- Step-by-step introduction to the platform
- Genre preference selection
- Template-based story creation
- Guided first story experience with AI assistance

### Prompt Engineering & Story Controls
- Tone adjustment (formal, casual, poetic, etc.)
- Length control (short, medium, long)
- Point of view selection (first person, third person, etc.)
- Mood setting (happy, mysterious, tense, etc.)
- One-click iteration buttons for quick improvements

### Genre & Tag Taxonomy
- Comprehensive genre classification system
- Thematic tagging with suggestions
- Multi-tag support with normalization
- Tag recommendations based on story content

### Personalization & Recommendations
- Story recommendations based on user preferences
- Personalized templates matching preferred genres
- Feedback collection for continuous improvement

### Content Creation & Editing
- Rich text editor for story creation
- AI-powered writing assistance
- Template library for quick starts
- Auto-save and version history

### Collaborative Features (Planned)
- Real-time collaborative editing
- Comments and suggestions
- Role-based permissions
- Version control and history

## 🚀 Getting Started

### Prerequisites
- Node.js 16.x or higher
- npm 7.x or higher

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/story-ai.git
   cd story-ai
   ```

2. Run the setup script:
   ```
   npm run setup
   ```

3. Start the development server:
   ```
   npm run dev
   ```

4. To run both client and server:
   ```
   npm run dev:all
   ```

5. Open your browser and navigate to `http://localhost:3000`

## 🏗️ Project Structure

```
story-ai/
├── public/              # Static assets
├── src/
│   ├── client/
│   │   ├── components/  # React components
│   │   │   ├── editor/  # Story editor components
│   │   │   ├── genre-system/  # Genre and tag components
│   │   │   ├── onboarding/  # Onboarding flow components
│   │   │   ├── story-controls/  # Story parameter controls
│   │   │   └── templates/  # Template components
│   │   ├── styles/      # Global styles
│   │   └── utils/       # Utility functions
│   └── server/          # Server-side code
│       ├── controllers/ # API controllers
│       ├── models/      # Data models
│       └── routes/      # API routes
├── scripts/             # Utility scripts
└── __mocks__/           # Test mocks
```

## 🧩 Core Components

### Onboarding Flow
The onboarding flow guides new users through setting up their account, selecting preferred genres, and creating their first story. See [Onboarding README](src/client/components/onboarding/README.md) for details.

### Templates System
The templates system provides pre-filled story starters for different genres and styles. See [Templates README](src/client/components/templates/README.md) for details.

### Story Controls
The story controls allow users to adjust parameters like tone, length, point of view, and mood. See [Story Controls README](src/client/components/story-controls/README.md) for details.

### Genre & Tag System
The genre and tag system allows users to categorize and find stories using a comprehensive taxonomy. See [Genre System README](src/client/components/genre-system/README.md) for details.

### Story Editor
The story editor is the central component where users create, edit, and enhance their stories. See [Story Editor README](src/client/components/editor/README.md) for details.

## 🧪 Testing

Run tests with:
```
npm test
```

Run tests in watch mode:
```
npm run test:watch
```

Generate coverage report:
```
npm run test:coverage
```

## 🚢 Deployment

Build the project for production:
```
npm run build
```

Start the production server:
```
npm start
```

## 📝 Development Scripts

- `npm run setup`: Set up the project
- `npm run dev`: Start the Vite development server
- `npm run dev:all`: Start both client and server in development mode
- `npm run build`: Build the project for production
- `npm run preview`: Preview the production build locally
- `npm run lint`: Lint the code
- `npm run format`: Format the code
- `npm run server`: Start the server
- `npm run server:dev`: Start the server in development mode with auto-reload
- `npm run test`: Run tests
- `npm run test:watch`: Run tests in watch mode
- `npm run test:coverage`: Generate test coverage report

## 🔮 Future Enhancements

- **Collaborative Editing**: Real-time collaboration with multiple users
- **AI Suggestions**: More advanced AI-powered writing suggestions
- **Community Features**: Sharing stories and receiving feedback
- **Analytics**: Story performance metrics and writing insights
- **Mobile App**: Native mobile experience for on-the-go writing
- **Monetization**: Premium templates, subscription features, and royalty system

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- The React team for the amazing framework
- TailwindCSS for the utility-first CSS framework
- The open-source community for inspiration and tools