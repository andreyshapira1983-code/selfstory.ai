// Add custom jest matchers for testing-library
import '@testing-library/jest-dom';

// Mock environment variables
process.env.VITE_API_URL = 'http://localhost:5000';
process.env.VITE_SOCKET_URL = 'http://localhost:5000';

// Mock fetch
global.fetch = jest.fn(() =>
  Promise.resolve({
    ok: true,
    json: () => Promise.resolve({}),
  })
);

// Mock socket.io-client
jest.mock('socket.io-client', () => {
  const emit = jest.fn();
  const on = jest.fn();
  const off = jest.fn();
  const disconnect = jest.fn();
  
  return {
    io: jest.fn(() => ({
      emit,
      on,
      off,
      disconnect,
      id: 'mock-socket-id'
    }))
  };
});

// Mock import.meta.env
global.import = {
  meta: {
    env: {
      VITE_API_URL: 'http://localhost:5000',
      VITE_SOCKET_URL: 'http://localhost:5000'
    }
  }
};

// Create necessary mocks for files
jest.mock('__mocks__/fileMock.js', () => 'test-file-stub', { virtual: true });