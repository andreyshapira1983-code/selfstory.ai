/**
 * Feedback Pipeline Service
 * 
 * This service processes collected feedback and error classifications to improve AI models over time.
 * It implements a pipeline for aggregating feedback, analyzing patterns, and generating training data.
 */

const mongoose = require('mongoose');
const AISuggestion = require('../models/AISuggestion');
const EventEmitter = require('events');
const DriftMonitoringService = require('./driftMonitoring');

class FeedbackPipelineService {
  constructor(options = {}) {
    this.options = {
      // How often to process feedback batches (in milliseconds)
      processingInterval: 86400000, // Default: daily
      
      // Minimum feedback items required to trigger processing
      minimumFeedbackThreshold: 100,
      
      // Maximum feedback items to process in one batch
      maxBatchSize: 1000,
      
      // Weights for different feedback sources
      sourceWeights: {
        humanReviewer: 1.0,
        endUser: 0.8,
        automated: 0.6
      },
      
      // Thresholds for model retraining triggers
      retrainingThresholds: {
        errorRate: 0.1, // 10% error rate
        feedbackVolume: 500, // 500 feedback items
        driftDetected: true // Retrain if drift is detected
      },
      
      ...options
    };
    
    // Event emitter for pipeline events
    this.events = new EventEmitter();
    
    // Store feedback batches
    this.pendingFeedback = [];
    this.processedFeedback = [];
    
    // Processing state
    this.isProcessing = false;
    this.processingInterval = null;
    
    // Connect to drift monitoring service
    this.driftMonitoring = null;
  }
  
  /**
   * Initialize the feedback pipeline
   * @param {DriftMonitoringService} driftMonitoringService - Optional drift monitoring service
   */
  initialize(driftMonitoringService = null) {
    if (driftMonitoringService) {
      this.driftMonitoring = driftMonitoringService;
      
      // Listen for drift alerts
      this.driftMonitoring.on('alert', (alert) => {
        if (alert.severity === 'critical') {
          this.handleCriticalDrift(alert);
        }
      });
    }
    
    console.log('Feedback pipeline initialized');
  }
  
  /**
   * Start the feedback processing pipeline
   */
  startProcessing() {
    if (this.isProcessing) {
      console.log('Feedback pipeline is already running');
      return;
    }
    
    console.log('Starting feedback pipeline processing');
    this.isProcessing = true;
    
    // Schedule regular processing
    this.processingInterval = setInterval(() => {
      this.processFeedbackBatch();
    }, this.options.processingInterval);
    
    // Process any existing feedback
    this.processFeedbackBatch();
  }
  
  /**
   * Stop the feedback processing pipeline
   */
  stopProcessing() {
    if (!this.isProcessing) return;
    
    console.log('Stopping feedback pipeline processing');
    clearInterval(this.processingInterval);
    this.isProcessing = false;
  }
  
  /**
   * Submit feedback to the pipeline
   * @param {Object} feedback - Feedback data
   * @returns {boolean} - Success status
   */
  async submitFeedback(feedback) {
    try {
      // Validate feedback
      if (!this.validateFeedback(feedback)) {
        console.error('Invalid feedback submitted:', feedback);
        return false;
      }
      
      // Add metadata
      const enrichedFeedback = {
        ...feedback,
        receivedAt: new Date(),
        processed: false,
        weight: this.calculateFeedbackWeight(feedback)
      };
      
      // Add to pending feedback
      this.pendingFeedback.push(enrichedFeedback);
      
      console.log(`Feedback submitted: ${feedback.id}`);
      
      // Check if we should process immediately
      if (this.pendingFeedback.length >= this.options.minimumFeedbackThreshold) {
        this.processFeedbackBatch();
      }
      
      return true;
    } catch (error) {
      console.error('Error submitting feedback:', error);
      return false;
    }
  }
  
  /**
   * Validate feedback data
   * @param {Object} feedback - Feedback to validate
   * @returns {boolean} - Whether feedback is valid
   */
  validateFeedback(feedback) {
    // Check required fields
    if (!feedback.id || !feedback.type || !feedback.content) {
      return false;
    }
    
    // Check feedback type
    const validTypes = ['correction', 'rating', 'classification', 'rejection'];
    if (!validTypes.includes(feedback.type)) {
      return false;
    }
    
    return true;
  }
  
  /**
   * Calculate weight for feedback based on source and other factors
   * @param {Object} feedback - Feedback to weight
   * @returns {number} - Calculated weight
   */
  calculateFeedbackWeight(feedback) {
    // Base weight from source
    let weight = this.options.sourceWeights[feedback.source] || 0.5;
    
    // Adjust based on confidence if available
    if (feedback.confidence) {
      weight *= feedback.confidence;
    }
    
    // Adjust based on user reputation if available
    if (feedback.userReputation) {
      weight *= (0.5 + (feedback.userReputation / 2));
    }
    
    return Math.min(1.0, Math.max(0.1, weight));
  }
  
  /**
   * Process a batch of feedback
   */
  async processFeedbackBatch() {
    if (this.pendingFeedback.length === 0) {
      console.log('No pending feedback to process');
      return;
    }
    
    console.log(`Processing ${this.pendingFeedback.length} feedback items`);
    
    try {
      // Take a batch of feedback
      const batchSize = Math.min(this.pendingFeedback.length, this.options.maxBatchSize);
      const batch = this.pendingFeedback.splice(0, batchSize);
      
      // Group by error type
      const groupedFeedback = this.groupFeedbackByErrorType(batch);
      
      // Analyze patterns
      const patterns = this.analyzeErrorPatterns(groupedFeedback);
      
      // Generate training data
      const trainingData = this.generateTrainingData(batch, patterns);
      
      // Check if we should trigger retraining
      const shouldRetrain = this.checkRetrainingTriggers(batch, patterns);
      
      // Mark as processed
      const processedBatch = batch.map(item => ({
        ...item,
        processed: true,
        processedAt: new Date()
      }));
      
      // Store processed feedback
      this.processedFeedback.push(...processedBatch);
      
      // Emit processing complete event
      this.events.emit('batch_processed', {
        batchSize,
        patterns,
        trainingData,
        shouldRetrain
      });
      
      // Trigger retraining if needed
      if (shouldRetrain) {
        this.triggerModelRetraining(trainingData);
      }
      
      console.log(`Processed ${batchSize} feedback items`);
      return true;
    } catch (error) {
      console.error('Error processing feedback batch:', error);
      
      // Return failed items to pending queue
      // this.pendingFeedback.unshift(...batch);
      
      return false;
    }
  }
  
  /**
   * Group feedback by error type
   * @param {Array} batch - Batch of feedback
   * @returns {Object} - Grouped feedback
   */
  groupFeedbackByErrorType(batch) {
    const grouped = {};
    
    for (const item of batch) {
      // Skip items without classification
      if (!item.classification) continue;
      
      const errorType = item.classification.errorType || 'unknown';
      
      if (!grouped[errorType]) {
        grouped[errorType] = [];
      }
      
      grouped[errorType].push(item);
    }
    
    return grouped;
  }
  
  /**
   * Analyze error patterns in feedback
   * @param {Object} groupedFeedback - Feedback grouped by error type
   * @returns {Object} - Error patterns
   */
  analyzeErrorPatterns(groupedFeedback) {
    const patterns = {};
    
    // For each error type
    for (const [errorType, items] of Object.entries(groupedFeedback)) {
      // Skip if too few items
      if (items.length < 5) continue;
      
      // Calculate frequency
      const frequency = items.length / this.pendingFeedback.length;
      
      // Calculate average weight
      const totalWeight = items.reduce((sum, item) => sum + item.weight, 0);
      const averageWeight = totalWeight / items.length;
      
      // Extract common contexts if available
      const contexts = items
        .filter(item => item.context)
        .map(item => item.context);
      
      // Extract common corrections if available
      const corrections = items
        .filter(item => item.correction)
        .map(item => item.correction);
      
      patterns[errorType] = {
        count: items.length,
        frequency,
        averageWeight,
        contexts: this.findCommonPatterns(contexts),
        corrections: this.findCommonPatterns(corrections),
        samples: items.slice(0, 5) // Store a few samples
      };
    }
    
    return patterns;
  }
  
  /**
   * Find common patterns in a list of strings
   * @param {Array} items - List of strings
   * @returns {Array} - Common patterns
   */
  findCommonPatterns(items) {
    // In a real implementation, this would use more sophisticated pattern matching
    // For now, we'll just return the most common items
    
    if (!items || items.length === 0) return [];
    
    const counts = {};
    
    for (const item of items) {
      counts[item] = (counts[item] || 0) + 1;
    }
    
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([pattern, count]) => ({ pattern, count }));
  }
  
  /**
   * Generate training data from feedback
   * @param {Array} batch - Batch of feedback
   * @param {Object} patterns - Error patterns
   * @returns {Object} - Training data
   */
  generateTrainingData(batch, patterns) {
    // In a real implementation, this would create structured training data
    // for model fine-tuning or retraining
    
    const trainingData = {
      examples: [],
      metadata: {
        generatedAt: new Date(),
        batchSize: batch.length,
        patternCount: Object.keys(patterns).length
      }
    };
    
    // Generate examples from corrections
    for (const item of batch) {
      if (item.type !== 'correction' || !item.content || !item.correction) continue;
      
      trainingData.examples.push({
        input: item.content,
        output: item.correction,
        weight: item.weight,
        errorType: item.classification?.errorType || 'unknown'
      });
    }
    
    console.log(`Generated ${trainingData.examples.length} training examples`);
    
    return trainingData;
  }
  
  /**
   * Check if we should trigger model retraining
   * @param {Array} batch - Processed feedback batch
   * @param {Object} patterns - Error patterns
   * @returns {boolean} - Whether to trigger retraining
   */
  checkRetrainingTriggers(batch, patterns) {
    // Check feedback volume
    if (batch.length >= this.options.retrainingThresholds.feedbackVolume) {
      console.log('Retraining triggered by feedback volume');
      return true;
    }
    
    // Check error rate
    const errorItems = batch.filter(item => 
      item.type === 'correction' || item.type === 'rejection'
    );
    
    const errorRate = errorItems.length / batch.length;
    
    if (errorRate >= this.options.retrainingThresholds.errorRate) {
      console.log('Retraining triggered by high error rate');
      return true;
    }
    
    // Check if drift was detected
    if (this.driftMonitoring && this.driftMonitoring.driftDetected) {
      console.log('Retraining triggered by drift detection');
      return true;
    }
    
    return false;
  }
  
  /**
   * Trigger model retraining with generated training data
   * @param {Object} trainingData - Training data
   */
  async triggerModelRetraining(trainingData) {
    console.log('Triggering model retraining');
    
    try {
      // In a real implementation, this would:
      // 1. Save training data to a database or file
      // 2. Trigger a model retraining job
      // 3. Monitor the retraining process
      // 4. Update the model when complete
      
      // For now, we'll just emit an event
      this.events.emit('retraining_triggered', {
        timestamp: new Date(),
        trainingData: {
          exampleCount: trainingData.examples.length,
          metadata: trainingData.metadata
        }
      });
      
      console.log('Model retraining triggered successfully');
      return true;
    } catch (error) {
      console.error('Error triggering model retraining:', error);
      return false;
    }
  }
  
  /**
   * Handle critical drift alert
   * @param {Object} alert - Drift alert
   */
  async handleCriticalDrift(alert) {
    console.log('Handling critical drift alert:', alert);
    
    // Process all pending feedback immediately
    await this.processFeedbackBatch();
    
    // Trigger retraining
    const trainingData = await this.generateEmergencyTrainingData();
    await this.triggerModelRetraining(trainingData);
  }
  
  /**
   * Generate emergency training data in response to critical drift
   * @returns {Object} - Emergency training data
   */
  async generateEmergencyTrainingData() {
    // In a real implementation, this would generate a comprehensive training dataset
    // by combining recent feedback with historical data
    
    try {
      // Get recent suggestions from database
      const recentSuggestions = await AISuggestion.find({
        createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
      }).limit(1000);
      
      // Generate training examples
      const examples = recentSuggestions
        .filter(s => s.applied && s.originalText && s.suggestedText)
        .map(s => ({
          input: s.originalText,
          output: s.suggestedText,
          weight: s.rating === 'helpful' ? 1.0 : 0.5,
          errorType: s.errorType || 'unknown'
        }));
      
      return {
        examples,
        metadata: {
          generatedAt: new Date(),
          emergency: true,
          batchSize: examples.length
        }
      };
    } catch (error) {
      console.error('Error generating emergency training data:', error);
      
      // Return minimal training data
      return {
        examples: [],
        metadata: {
          generatedAt: new Date(),
          emergency: true,
          error: true
        }
      };
    }
  }
  
  /**
   * Get metrics about the feedback pipeline
   * @returns {Object} - Pipeline metrics
   */
  getMetrics() {
    return {
      pendingFeedbackCount: this.pendingFeedback.length,
      processedFeedbackCount: this.processedFeedback.length,
      isProcessing: this.isProcessing,
      lastProcessedAt: this.processedFeedback.length > 0 
        ? this.processedFeedback[this.processedFeedback.length - 1].processedAt 
        : null
    };
  }
  
  /**
   * Register event listener
   * @param {string} event - Event name
   * @param {Function} listener - Event listener
   */
  on(event, listener) {
    this.events.on(event, listener);
    return this;
  }
  
  /**
   * Remove event listener
   * @param {string} event - Event name
   * @param {Function} listener - Event listener
   */
  off(event, listener) {
    this.events.off(event, listener);
    return this;
  }
}

module.exports = FeedbackPipelineService;