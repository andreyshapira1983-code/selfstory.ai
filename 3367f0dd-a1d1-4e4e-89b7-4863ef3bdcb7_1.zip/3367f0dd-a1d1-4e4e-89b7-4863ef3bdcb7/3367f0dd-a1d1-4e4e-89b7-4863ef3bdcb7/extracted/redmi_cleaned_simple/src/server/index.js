const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');
const dotenv = require('dotenv');
const path = require('path');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const { setupWSSharedDoc } = require('./utils/documentManager');
const connectDB = require('./config/db');

// Load environment variables
dotenv.config();

// Create Express app
const app = express();
const server = http.createServer(app);

// Connect to MongoDB
connectDB();

// Configure CORS
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? process.env.CLIENT_URL || 'https://story-ai.example.com' 
    : 'http://localhost:3000',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true
}));

// Security middleware
app.use(helmet({
  contentSecurityPolicy: process.env.NODE_ENV === 'production' ? undefined : false
}));

// Compression middleware
app.use(compression());

// Logging middleware
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// Parse JSON bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../../dist')));
}

// Set up Socket.IO server
const io = new Server(server, {
  cors: {
    origin: process.env.NODE_ENV === 'production' 
      ? process.env.CLIENT_URL || 'https://story-ai.example.com' 
      : 'http://localhost:3000',
    methods: ['GET', 'POST'],
    credentials: true
  },
  path: process.env.WS_SERVER_PATH || '/socket.io'
});

// Set up API routes
app.use('/api/stories', require('./routes/stories'));
app.use('/api/users', require('./routes/users'));
app.use('/api/collaborators', require('./routes/collaborators'));
app.use('/api/feedback', require('./routes/feedbackRoutes'));
app.use('/api/ai', require('./routes/aiRoutes'));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV,
    mongodb: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
  });
});

// Handle WebSocket connections
io.on('connection', (socket) => {
  console.log('New client connected:', socket.id);
  
  // Handle document collaboration
  socket.on('join-document', (documentId) => {
    console.log(`Client ${socket.id} joined document: ${documentId}`);
    socket.join(`document:${documentId}`);
    
    // Set up shared document with y-websocket
    setupWSSharedDoc(io, documentId, socket);
    
    // Notify other clients
    socket.to(`document:${documentId}`).emit('user-joined', {
      socketId: socket.id,
      timestamp: new Date().toISOString()
    });
  });
  
  // Handle user presence
  socket.on('user-presence', (data) => {
    const { documentId, user } = data;
    console.log(`User presence update in ${documentId}:`, user.name);
    
    // Broadcast to others in the same document
    socket.to(`document:${documentId}`).emit('user-presence', {
      socketId: socket.id,
      user,
      timestamp: new Date().toISOString()
    });
  });
  
  // Handle cursor position updates
  socket.on('cursor-update', (data) => {
    const { documentId, position, user } = data;
    
    // Broadcast to others in the same document
    socket.to(`document:${documentId}`).emit('cursor-update', {
      socketId: socket.id,
      user,
      position,
      timestamp: new Date().toISOString()
    });
  });
  
  // Handle disconnection
  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
    
    // Notify all rooms this socket was in
    const rooms = Array.from(socket.rooms);
    rooms.forEach(room => {
      if (room.startsWith('document:')) {
        const documentId = room.replace('document:', '');
        socket.to(room).emit('user-left', {
          socketId: socket.id,
          documentId,
          timestamp: new Date().toISOString()
        });
      }
    });
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    error: {
      message: err.message || 'Internal Server Error',
      status: err.status || 500
    }
  });
});

// Catch-all route for SPA in production
if (process.env.NODE_ENV === 'production') {
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../../dist/index.html'));
  });
}

// Start server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = { app, server };