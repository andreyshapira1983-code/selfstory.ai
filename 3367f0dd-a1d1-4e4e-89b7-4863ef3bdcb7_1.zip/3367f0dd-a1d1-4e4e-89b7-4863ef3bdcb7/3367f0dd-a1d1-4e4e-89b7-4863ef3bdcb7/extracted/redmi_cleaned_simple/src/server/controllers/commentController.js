const Comment = require('../models/Comment');
const Story = require('../models/Story');
const Collaborator = require('../models/Collaborator');

/**
 * @desc    Create a new comment
 * @route   POST /api/comments
 * @access  Private
 */
exports.createComment = async (req, res) => {
  try {
    const { story, content, position } = req.body;
    
    // Check if story exists
    const storyDoc = await Story.findById(story);
    
    if (!storyDoc) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = storyDoc.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to comment on this story'
        });
      }
    }
    
    // Create comment
    const comment = await Comment.create({
      story,
      content,
      position,
      author: req.user.id
    });
    
    // Populate author details
    const populatedComment = await Comment.findById(comment._id)
      .populate('author', 'name email profileColor');
    
    res.status(201).json(populatedComment);
  } catch (err) {
    console.error('Create comment error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get all comments for a story
 * @route   GET /api/comments/story/:storyId
 * @access  Private
 */
exports.getCommentsByStory = async (req, res) => {
  try {
    const { storyId } = req.params;
    
    // Check if story exists
    const story = await Story.findById(storyId);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: storyId,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this story'
        });
      }
    }
    
    // Get comments
    const comments = await Comment.find({ story: storyId })
      .populate('author', 'name email profileColor')
      .populate('replies.author', 'name email profileColor')
      .sort('-createdAt');
    
    res.status(200).json(comments);
  } catch (err) {
    console.error('Get comments error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get a single comment
 * @route   GET /api/comments/:id
 * @access  Private
 */
exports.getComment = async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id)
      .populate('author', 'name email profileColor')
      .populate('replies.author', 'name email profileColor');
    
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }
    
    // Check if user is author or collaborator of the story
    const story = await Story.findById(comment.story);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: comment.story,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this comment'
        });
      }
    }
    
    res.status(200).json(comment);
  } catch (err) {
    console.error('Get comment error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Update a comment
 * @route   PUT /api/comments/:id
 * @access  Private
 */
exports.updateComment = async (req, res) => {
  try {
    const { content } = req.body;
    
    let comment = await Comment.findById(req.params.id);
    
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }
    
    // Check if user is the comment author
    if (comment.author.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this comment'
      });
    }
    
    // Update comment
    comment = await Comment.findByIdAndUpdate(
      req.params.id,
      { content },
      { new: true, runValidators: true }
    ).populate('author', 'name email profileColor');
    
    res.status(200).json(comment);
  } catch (err) {
    console.error('Update comment error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Delete a comment
 * @route   DELETE /api/comments/:id
 * @access  Private
 */
exports.deleteComment = async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }
    
    // Check if user is the comment author or story author
    const isCommentAuthor = comment.author.toString() === req.user.id;
    
    if (!isCommentAuthor) {
      const story = await Story.findById(comment.story);
      
      if (!story) {
        return res.status(404).json({
          success: false,
          message: 'Story not found'
        });
      }
      
      const isStoryAuthor = story.author.toString() === req.user.id;
      
      if (!isStoryAuthor) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to delete this comment'
        });
      }
    }
    
    // Delete comment
    await comment.remove();
    
    res.status(200).json({
      success: true,
      message: 'Comment deleted successfully'
    });
  } catch (err) {
    console.error('Delete comment error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Add a reply to a comment
 * @route   POST /api/comments/:id/replies
 * @access  Private
 */
exports.addReply = async (req, res) => {
  try {
    const { content } = req.body;
    
    if (!content) {
      return res.status(400).json({
        success: false,
        message: 'Reply content is required'
      });
    }
    
    let comment = await Comment.findById(req.params.id);
    
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }
    
    // Check if user is author or collaborator of the story
    const story = await Story.findById(comment.story);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: comment.story,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to reply to this comment'
        });
      }
    }
    
    // Add reply
    const reply = {
      content,
      author: req.user.id,
      createdAt: Date.now()
    };
    
    comment.replies.push(reply);
    await comment.save();
    
    // Populate author details
    comment = await Comment.findById(comment._id)
      .populate('author', 'name email profileColor')
      .populate('replies.author', 'name email profileColor');
    
    res.status(200).json(comment);
  } catch (err) {
    console.error('Add reply error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Delete a reply
 * @route   DELETE /api/comments/:id/replies/:replyId
 * @access  Private
 */
exports.deleteReply = async (req, res) => {
  try {
    const { id, replyId } = req.params;
    
    const comment = await Comment.findById(id);
    
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }
    
    // Find the reply
    const reply = comment.replies.id(replyId);
    
    if (!reply) {
      return res.status(404).json({
        success: false,
        message: 'Reply not found'
      });
    }
    
    // Check if user is the reply author, comment author, or story author
    const isReplyAuthor = reply.author.toString() === req.user.id;
    const isCommentAuthor = comment.author.toString() === req.user.id;
    
    if (!isReplyAuthor && !isCommentAuthor) {
      const story = await Story.findById(comment.story);
      
      if (!story) {
        return res.status(404).json({
          success: false,
          message: 'Story not found'
        });
      }
      
      const isStoryAuthor = story.author.toString() === req.user.id;
      
      if (!isStoryAuthor) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to delete this reply'
        });
      }
    }
    
    // Remove reply
    reply.remove();
    await comment.save();
    
    // Populate author details
    const updatedComment = await Comment.findById(id)
      .populate('author', 'name email profileColor')
      .populate('replies.author', 'name email profileColor');
    
    res.status(200).json(updatedComment);
  } catch (err) {
    console.error('Delete reply error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Mark a comment as resolved
 * @route   PUT /api/comments/:id/resolve
 * @access  Private
 */
exports.resolveComment = async (req, res) => {
  try {
    let comment = await Comment.findById(req.params.id);
    
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }
    
    // Check if user is author or collaborator of the story
    const story = await Story.findById(comment.story);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: comment.story,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to resolve this comment'
        });
      }
    }
    
    // Update comment
    comment = await Comment.findByIdAndUpdate(
      req.params.id,
      {
        resolved: true,
        resolvedBy: req.user.id,
        resolvedAt: Date.now()
      },
      { new: true, runValidators: true }
    )
      .populate('author', 'name email profileColor')
      .populate('resolvedBy', 'name email profileColor');
    
    res.status(200).json(comment);
  } catch (err) {
    console.error('Resolve comment error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};