const AISuggestion = require('../models/AISuggestion');
const Story = require('../models/Story');
const Collaborator = require('../models/Collaborator');
const DriftMonitoringService = require('../services/driftMonitoring');
const LanguageProcessingService = require('../services/languageProcessing');
const FeedbackPipelineService = require('../services/feedbackPipeline');
const HumanValidationService = require('../services/humanValidation');
const mongoose = require('mongoose');

// Initialize services
const driftMonitoring = new DriftMonitoringService();
const languageProcessing = new LanguageProcessingService();
const feedbackPipeline = new FeedbackPipelineService();
const humanValidation = new HumanValidationService();

// Initialize feedback pipeline with drift monitoring
feedbackPipeline.initialize(driftMonitoring);

// Start services if not already running
if (!driftMonitoring.isMonitoring) {
  driftMonitoring.startMonitoring();
}

if (!feedbackPipeline.isProcessing) {
  feedbackPipeline.startProcessing();
}

/**
 * @desc    Create a new AI suggestion
 * @route   POST /api/ai-suggestions
 * @access  Private
 */
exports.createAISuggestion = async (req, res) => {
  try {
    const { story, type, content, position, originalText, suggestedText, explanation } = req.body;
    
    // Check if story exists
    const storyDoc = await Story.findById(story);
    
    if (!storyDoc) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = storyDoc.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to create AI suggestions for this story'
        });
      }
    }
    
    // Create AI suggestion
    const aiSuggestion = await AISuggestion.create({
      story,
      type,
      content,
      position,
      originalText,
      suggestedText,
      explanation,
      requestedBy: req.user.id
    });
    
    // Populate user details
    const populatedSuggestion = await AISuggestion.findById(aiSuggestion._id)
      .populate('requestedBy', 'name email profileColor');
    
    res.status(201).json(populatedSuggestion);
  } catch (err) {
    console.error('Create AI suggestion error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get all AI suggestions for a story
 * @route   GET /api/ai-suggestions/story/:storyId
 * @access  Private
 */
exports.getAISuggestionsByStory = async (req, res) => {
  try {
    const { storyId } = req.params;
    
    // Check if story exists
    const story = await Story.findById(storyId);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: storyId,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this story'
        });
      }
    }
    
    // Get AI suggestions
    const aiSuggestions = await AISuggestion.find({ story: storyId })
      .populate('requestedBy', 'name email profileColor')
      .populate('appliedBy', 'name email profileColor')
      .populate('dismissedBy', 'name email profileColor')
      .sort('-createdAt');
    
    res.status(200).json(aiSuggestions);
  } catch (err) {
    console.error('Get AI suggestions error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get a single AI suggestion
 * @route   GET /api/ai-suggestions/:id
 * @access  Private
 */
exports.getAISuggestion = async (req, res) => {
  try {
    const aiSuggestion = await AISuggestion.findById(req.params.id)
      .populate('requestedBy', 'name email profileColor')
      .populate('appliedBy', 'name email profileColor')
      .populate('dismissedBy', 'name email profileColor');
    
    if (!aiSuggestion) {
      return res.status(404).json({
        success: false,
        message: 'AI suggestion not found'
      });
    }
    
    // Check if user is author or collaborator of the story
    const story = await Story.findById(aiSuggestion.story);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: aiSuggestion.story,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this AI suggestion'
        });
      }
    }
    
    res.status(200).json(aiSuggestion);
  } catch (err) {
    console.error('Get AI suggestion error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Apply an AI suggestion
 * @route   PUT /api/ai-suggestions/:id/apply
 * @access  Private
 */
exports.applyAISuggestion = async (req, res) => {
  try {
    let aiSuggestion = await AISuggestion.findById(req.params.id);
    
    if (!aiSuggestion) {
      return res.status(404).json({
        success: false,
        message: 'AI suggestion not found'
      });
    }
    
    // Check if user is author or editor collaborator of the story
    const story = await Story.findById(aiSuggestion.story);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const collaborator = await Collaborator.findOne({
        story: aiSuggestion.story,
        user: req.user.id
      });
      
      if (!collaborator || collaborator.role !== 'editor') {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to apply this AI suggestion'
        });
      }
    }
    
    // Check if already applied or dismissed
    if (aiSuggestion.applied) {
      return res.status(400).json({
        success: false,
        message: 'AI suggestion already applied'
      });
    }
    
    if (aiSuggestion.dismissed) {
      return res.status(400).json({
        success: false,
        message: 'AI suggestion already dismissed'
      });
    }
    
    // Apply AI suggestion
    aiSuggestion = await AISuggestion.findByIdAndUpdate(
      req.params.id,
      {
        applied: true,
        appliedBy: req.user.id,
        appliedAt: Date.now()
      },
      { new: true, runValidators: true }
    ).populate('appliedBy', 'name email profileColor');
    
    res.status(200).json(aiSuggestion);
  } catch (err) {
    console.error('Apply AI suggestion error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Dismiss an AI suggestion
 * @route   PUT /api/ai-suggestions/:id/dismiss
 * @access  Private
 */
exports.dismissAISuggestion = async (req, res) => {
  try {
    let aiSuggestion = await AISuggestion.findById(req.params.id);
    
    if (!aiSuggestion) {
      return res.status(404).json({
        success: false,
        message: 'AI suggestion not found'
      });
    }
    
    // Check if user is author or editor collaborator of the story
    const story = await Story.findById(aiSuggestion.story);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const collaborator = await Collaborator.findOne({
        story: aiSuggestion.story,
        user: req.user.id
      });
      
      if (!collaborator || collaborator.role !== 'editor') {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to dismiss this AI suggestion'
        });
      }
    }
    
    // Check if already applied or dismissed
    if (aiSuggestion.applied) {
      return res.status(400).json({
        success: false,
        message: 'AI suggestion already applied'
      });
    }
    
    if (aiSuggestion.dismissed) {
      return res.status(400).json({
        success: false,
        message: 'AI suggestion already dismissed'
      });
    }
    
    // Dismiss AI suggestion
    aiSuggestion = await AISuggestion.findByIdAndUpdate(
      req.params.id,
      {
        dismissed: true,
        dismissedBy: req.user.id,
        dismissedAt: Date.now()
      },
      { new: true, runValidators: true }
    ).populate('dismissedBy', 'name email profileColor');
    
    res.status(200).json(aiSuggestion);
  } catch (err) {
    console.error('Dismiss AI suggestion error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Delete an AI suggestion
 * @route   DELETE /api/ai-suggestions/:id
 * @access  Private
 */
exports.deleteAISuggestion = async (req, res) => {
  try {
    const aiSuggestion = await AISuggestion.findById(req.params.id);
    
    if (!aiSuggestion) {
      return res.status(404).json({
        success: false,
        message: 'AI suggestion not found'
      });
    }
    
    // Check if user is the story author or the one who requested the suggestion
    const isRequester = aiSuggestion.requestedBy.toString() === req.user.id;
    
    if (!isRequester) {
      const story = await Story.findById(aiSuggestion.story);
      
      if (!story) {
        return res.status(404).json({
          success: false,
          message: 'Story not found'
        });
      }
      
      const isStoryAuthor = story.author.toString() === req.user.id;
      
      if (!isStoryAuthor) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to delete this AI suggestion'
        });
      }
    }
    
    // Delete AI suggestion
    await aiSuggestion.remove();
    
    res.status(200).json({
      success: true,
      message: 'AI suggestion deleted successfully'
    });
  } catch (err) {
    console.error('Delete AI suggestion error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Generate AI suggestions for a story
 * @route   POST /api/ai-suggestions/generate
 * @access  Private
 */
exports.generateAISuggestions = async (req, res) => {
  try {
    const { story, content, types = ['grammar', 'style'] } = req.body;
    
    if (!story || !content) {
      return res.status(400).json({
        success: false,
        message: 'Story ID and content are required'
      });
    }
    
    // Check if story exists
    const storyDoc = await Story.findById(story);
    
    if (!storyDoc) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = storyDoc.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to generate AI suggestions for this story'
        });
      }
    }
    
    // In a real application, this would call an AI service to generate suggestions
    // For this example, we'll create some mock suggestions
    
    const mockSuggestions = [
      {
        type: 'grammar',
        content: 'Grammar correction suggestion',
        position: { from: 10, to: 20 },
        originalText: 'This is a error',
        suggestedText: 'This is an error',
        explanation: 'Use "an" before words that start with a vowel sound'
      },
      {
        type: 'style',
        content: 'Style improvement suggestion',
        position: { from: 50, to: 70 },
        originalText: 'The man was very tired',
        suggestedText: 'The exhausted man collapsed into his chair',
        explanation: 'More descriptive language creates a stronger image'
      }
    ];
    
    // Filter suggestions by requested types
    const filteredSuggestions = mockSuggestions.filter(s => types.includes(s.type));
    
    // Create AI suggestions
    const createdSuggestions = [];
    
    for (const suggestion of filteredSuggestions) {
      const aiSuggestion = await AISuggestion.create({
        story,
        type: suggestion.type,
        content: suggestion.content,
        position: suggestion.position,
        originalText: suggestion.originalText,
        suggestedText: suggestion.suggestedText,
        explanation: suggestion.explanation,
        requestedBy: req.user.id
      });
      
      createdSuggestions.push(aiSuggestion);
    }
    
    // Populate user details
    const populatedSuggestions = await AISuggestion.find({
      _id: { $in: createdSuggestions.map(s => s._id) }
    }).populate('requestedBy', 'name email profileColor');
    
    res.status(201).json(populatedSuggestions);
  } catch (err) {
    console.error('Generate AI suggestions error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get AI suggestions for text
 * @route   POST /api/ai/suggestions
 * @access  Private
 */
exports.getSuggestions = async (req, res) => {
  try {
    const { text, context, storyId, language, suggestionType } = req.body;
    
    if (!text) {
      return res.status(400).json({ error: 'Text is required' });
    }
    
    // Detect language if not provided
    const detectedLanguage = language || languageProcessing.detectLanguage(text);
    
    // Process text with language-specific strategies
    const processedText = await languageProcessing.processText(text, detectedLanguage);
    
    // Generate suggestions based on processed text
    // In a real implementation, this would call an AI service
    const suggestions = await generateSuggestions(
      processedText, 
      context, 
      suggestionType || 'grammar',
      detectedLanguage
    );
    
    // Save suggestions to database
    const savedSuggestions = await Promise.all(
      suggestions.map(async (suggestion) => {
        const newSuggestion = new AISuggestion({
          originalText: text,
          suggestedText: suggestion.text,
          confidence: suggestion.confidence,
          errorType: suggestion.errorType,
          explanation: suggestion.explanation,
          language: detectedLanguage,
          storyId: storyId || null,
          userId: req.user.id,
          context: context || null,
          generationTime: suggestion.generationTime,
          model: suggestion.model || 'gpt-3.5-turbo'
        });
        
        await newSuggestion.save();
        return newSuggestion;
      })
    );
    
    res.status(200).json({
      language: detectedLanguage,
      suggestions: savedSuggestions.map(s => ({
        id: s._id,
        originalText: s.originalText,
        suggestedText: s.suggestedText,
        confidence: s.confidence,
        errorType: s.errorType,
        explanation: s.explanation
      }))
    });
  } catch (error) {
    console.error('Error generating suggestions:', error);
    res.status(500).json({ error: 'Failed to generate suggestions' });
  }
};

/**
 * @desc    Analyze text for errors and issues
 * @route   POST /api/ai/analyze
 * @access  Private
 */
exports.analyzeText = async (req, res) => {
  try {
    const { text, language, context } = req.body;
    
    if (!text) {
      return res.status(400).json({ error: 'Text is required' });
    }
    
    // Detect language if not provided
    const detectedLanguage = language || languageProcessing.detectLanguage(text);
    
    // Process text with language-specific strategies
    const processedText = await languageProcessing.processText(text, detectedLanguage);
    
    // Analyze text for errors
    // In a real implementation, this would call an AI service
    const analysis = await analyzeTextForErrors(
      processedText, 
      context, 
      detectedLanguage
    );
    
    res.status(200).json({
      language: detectedLanguage,
      analysis
    });
  } catch (error) {
    console.error('Error analyzing text:', error);
    res.status(500).json({ error: 'Failed to analyze text' });
  }
};

/**
 * @desc    Detect language of text
 * @route   POST /api/ai/language/detect
 * @access  Private
 */
exports.detectLanguage = async (req, res) => {
  try {
    const { text } = req.body;
    
    if (!text) {
      return res.status(400).json({ error: 'Text is required' });
    }
    
    // Detect language
    const language = languageProcessing.detectLanguage(text);
    
    res.status(200).json({ language });
  } catch (error) {
    console.error('Error detecting language:', error);
    res.status(500).json({ error: 'Failed to detect language' });
  }
};

/**
 * @desc    Process text with language-specific strategies
 * @route   POST /api/ai/language/process
 * @access  Private
 */
exports.processLanguage = async (req, res) => {
  try {
    const { text, language } = req.body;
    
    if (!text) {
      return res.status(400).json({ error: 'Text is required' });
    }
    
    // Process text with language-specific strategies
    const processedText = await languageProcessing.processText(text, language);
    
    res.status(200).json(processedText);
  } catch (error) {
    console.error('Error processing language:', error);
    res.status(500).json({ error: 'Failed to process language' });
  }
};

/**
 * @desc    Get AI system metrics
 * @route   GET /api/ai/metrics
 * @access  Private (Admin role)
 */
exports.getMetrics = async (req, res) => {
  try {
    // Get metrics from services
    const driftMetrics = await getDriftMetrics();
    const suggestionMetrics = await getSuggestionMetrics();
    const languageMetrics = await getLanguageMetrics();
    const feedbackMetrics = feedbackPipeline.getMetrics();
    
    res.status(200).json({
      drift: driftMetrics,
      suggestions: suggestionMetrics,
      languages: languageMetrics,
      feedback: feedbackMetrics
    });
  } catch (error) {
    console.error('Error getting metrics:', error);
    res.status(500).json({ error: 'Failed to get metrics' });
  }
};

/**
 * @desc    Manually trigger drift check
 * @route   POST /api/ai/drift/check
 * @access  Private (Admin role)
 */
exports.checkDrift = async (req, res) => {
  try {
    // Trigger drift check
    const driftResults = await driftMonitoring.checkForDrift();
    
    res.status(200).json({
      message: 'Drift check completed',
      results: driftResults
    });
  } catch (error) {
    console.error('Error checking drift:', error);
    res.status(500).json({ error: 'Failed to check drift' });
  }
};

/**
 * @desc    Get drift detection history
 * @route   GET /api/ai/drift/history
 * @access  Private (Admin role)
 */
exports.getDriftHistory = async (req, res) => {
  try {
    // In a real implementation, this would query a database of drift checks
    // For now, we'll return the metrics history from the drift monitoring service
    const history = driftMonitoring.metricsHistory || [];
    
    res.status(200).json({
      history: history.map(item => ({
        timestamp: item.timestamp,
        metrics: item.metrics
      }))
    });
  } catch (error) {
    console.error('Error getting drift history:', error);
    res.status(500).json({ error: 'Failed to get drift history' });
  }
};

/**
 * @desc    Rollback to previous model version
 * @route   POST /api/ai/rollback
 * @access  Private (Admin role)
 */
exports.rollbackModel = async (req, res) => {
  try {
    const { versionId } = req.body;
    
    if (!versionId) {
      return res.status(400).json({ error: 'Version ID is required' });
    }
    
    // Rollback to specified version
    const success = await driftMonitoring.rollbackToVersion(versionId);
    
    if (!success) {
      return res.status(400).json({ error: 'Failed to rollback to specified version' });
    }
    
    res.status(200).json({
      message: 'Model rolled back successfully',
      versionId
    });
  } catch (error) {
    console.error('Error rolling back model:', error);
    res.status(500).json({ error: 'Failed to rollback model' });
  }
};

/**
 * Generate suggestions for text
 * @param {Object} processedText - Processed text object
 * @param {string} context - Context for suggestions
 * @param {string} suggestionType - Type of suggestions to generate
 * @param {string} language - Language code
 * @returns {Array} - Generated suggestions
 */
async function generateSuggestions(processedText, context, suggestionType, language) {
  // In a real implementation, this would call an AI service
  // For now, we'll generate mock suggestions
  
  const startTime = Date.now();
  
  // Simulate processing time
  await new Promise(resolve => setTimeout(resolve, 300));
  
  const generationTime = Date.now() - startTime;
  
  // Mock suggestions based on suggestion type
  switch (suggestionType) {
    case 'grammar':
      return [
        {
          text: processedText.text.replace('teh', 'the').replace('recieve', 'receive'),
          confidence: 0.95,
          errorType: 'spelling',
          explanation: 'Corrected common spelling errors',
          generationTime,
          model: 'gpt-3.5-turbo'
        }
      ];
    
    case 'style':
      return [
        {
          text: processedText.text.replace(/very /g, ''),
          confidence: 0.85,
          errorType: 'style',
          explanation: 'Removed unnecessary intensifiers for clearer writing',
          generationTime,
          model: 'gpt-3.5-turbo'
        }
      ];
    
    case 'content':
      return [
        {
          text: processedText.text + ' Additionally, consider expanding on this point.',
          confidence: 0.75,
          errorType: 'content',
          explanation: 'Suggested additional content to develop the idea further',
          generationTime,
          model: 'gpt-3.5-turbo'
        }
      ];
    
    default:
      return [
        {
          text: processedText.text,
          confidence: 0.5,
          errorType: 'none',
          explanation: 'No suggestions available for this text',
          generationTime,
          model: 'gpt-3.5-turbo'
        }
      ];
  }
}

/**
 * Analyze text for errors
 * @param {Object} processedText - Processed text object
 * @param {string} context - Context for analysis
 * @param {string} language - Language code
 * @returns {Object} - Analysis results
 */
async function analyzeTextForErrors(processedText, context, language) {
  // In a real implementation, this would call an AI service
  // For now, we'll generate mock analysis
  
  // Simulate processing time
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Mock analysis
  return {
    errorCount: 2,
    warningCount: 1,
    errors: [
      {
        type: 'spelling',
        text: 'teh',
        suggestion: 'the',
        confidence: 0.98,
        explanation: 'Common spelling error'
      },
      {
        type: 'grammar',
        text: 'they was',
        suggestion: 'they were',
        confidence: 0.95,
        explanation: 'Subject-verb agreement error'
      }
    ],
    warnings: [
      {
        type: 'style',
        text: 'very quickly',
        suggestion: 'quickly',
        confidence: 0.85,
        explanation: 'Unnecessary intensifier'
      }
    ],
    readability: {
      score: 75,
      grade: 'Good',
      suggestions: [
        'Consider breaking longer sentences into shorter ones',
        'Use more active voice for clarity'
      ]
    }
  };
}

/**
 * Get drift metrics
 * @returns {Object} - Drift metrics
 */
async function getDriftMetrics() {
  // In a real implementation, this would query a database of drift metrics
  // For now, we'll return mock metrics
  
  return {
    lastCheckTime: new Date(),
    driftDetected: false,
    metrics: {
      accuracy: {
        baseline: 0.92,
        current: 0.91,
        drift: -0.01
      },
      satisfaction: {
        baseline: 0.85,
        current: 0.83,
        drift: -0.02
      },
      errorRate: {
        baseline: 0.03,
        current: 0.035,
        drift: 0.005
      },
      latency: {
        baseline: 450,
        current: 470,
        drift: 20
      }
    },
    thresholds: {
      accuracyDrift: 0.05,
      userSatisfactionDrift: 0.1,
      errorRateIncrease: 0.08,
      latencyIncrease: 0.15
    }
  };
}

/**
 * Get suggestion metrics
 * @returns {Object} - Suggestion metrics
 */
async function getSuggestionMetrics() {
  try {
    // Get suggestion counts
    const totalCount = await AISuggestion.countDocuments();
    const appliedCount = await AISuggestion.countDocuments({ applied: true });
    const helpfulCount = await AISuggestion.countDocuments({ rating: 'helpful' });
    const unhelpfulCount = await AISuggestion.countDocuments({ rating: 'unhelpful' });
    
    // Get error type distribution
    const errorTypeDistribution = await AISuggestion.aggregate([
      { $group: { _id: '$errorType', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);
    
    // Calculate metrics
    const applicationRate = totalCount > 0 ? appliedCount / totalCount : 0;
    const helpfulRate = (helpfulCount + unhelpfulCount) > 0 
      ? helpfulCount / (helpfulCount + unhelpfulCount) 
      : 0;
    
    return {
      totalCount,
      appliedCount,
      helpfulCount,
      unhelpfulCount,
      applicationRate,
      helpfulRate,
      errorTypeDistribution: errorTypeDistribution.map(item => ({
        errorType: item._id || 'unknown',
        count: item.count
      }))
    };
  } catch (error) {
    console.error('Error getting suggestion metrics:', error);
    return {
      error: 'Failed to get suggestion metrics'
    };
  }
}

/**
 * Get language metrics
 * @returns {Object} - Language metrics
 */
async function getLanguageMetrics() {
  try {
    // Get language distribution
    const languageDistribution = await AISuggestion.aggregate([
      { $match: { language: { $exists: true } } },
      { $group: { _id: '$language', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);
    
    // Get language-specific metrics
    const languageMetrics = {};
    
    for (const lang of languageDistribution) {
      const language = lang._id;
      
      // Skip if no language
      if (!language) continue;
      
      // Get metrics for this language
      const totalCount = lang.count;
      const appliedCount = await AISuggestion.countDocuments({ 
        language, 
        applied: true 
      });
      const helpfulCount = await AISuggestion.countDocuments({ 
        language, 
        rating: 'helpful' 
      });
      
      languageMetrics[language] = {
        totalCount,
        appliedCount,
        helpfulCount,
        applicationRate: totalCount > 0 ? appliedCount / totalCount : 0,
        helpfulRate: helpfulCount > 0 ? helpfulCount / totalCount : 0
      };
    }
    
    return {
      languageDistribution: languageDistribution.map(item => ({
        language: item._id || 'unknown',
        count: item.count
      })),
      languageMetrics
    };
  } catch (error) {
    console.error('Error getting language metrics:', error);
    return {
      error: 'Failed to get language metrics'
    };
  }
}