const Story = require('../models/Story');
const Collaborator = require('../models/Collaborator');
const User = require('../models/User');
const { getYDoc } = require('../utils/documentManager');

/**
 * @desc    Create a new story
 * @route   POST /api/stories
 * @access  Private
 */
exports.createStory = async (req, res) => {
  try {
    // Add user to request body
    req.body.author = req.user.id;
    
    // Create story
    const story = await Story.create(req.body);
    
    // Create a Y.js document for this story
    await getYDoc(story.documentId);
    
    res.status(201).json(story);
  } catch (err) {
    console.error('Create story error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get all stories for the current user
 * @route   GET /api/stories
 * @access  Private
 */
exports.getStories = async (req, res) => {
  try {
    // Find stories where user is author
    const ownedStories = await Story.find({ author: req.user.id })
      .populate('author', 'name email profileColor')
      .sort('-updatedAt');
    
    // Find stories where user is a collaborator
    const collaborations = await Collaborator.find({ user: req.user.id })
      .populate({
        path: 'story',
        populate: {
          path: 'author',
          select: 'name email profileColor'
        }
      });
    
    // Extract stories from collaborations
    const collaboratedStories = collaborations
      .map(collab => collab.story)
      .filter(story => story); // Filter out null values
    
    // Combine and sort by updatedAt
    const allStories = [...ownedStories, ...collaboratedStories]
      .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    
    res.status(200).json(allStories);
  } catch (err) {
    console.error('Get stories error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get a single story
 * @route   GET /api/stories/:id
 * @access  Private
 */
exports.getStory = async (req, res) => {
  try {
    const story = await Story.findById(req.params.id)
      .populate('author', 'name email profileColor')
      .populate('collaborators');
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = story.author._id.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: story._id,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this story'
        });
      }
    }
    
    res.status(200).json(story);
  } catch (err) {
    console.error('Get story error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Update a story
 * @route   PUT /api/stories/:id
 * @access  Private
 */
exports.updateStory = async (req, res) => {
  try {
    let story = await Story.findById(req.params.id);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author or editor collaborator
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const collaborator = await Collaborator.findOne({
        story: story._id,
        user: req.user.id
      });
      
      if (!collaborator || collaborator.role !== 'editor') {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to update this story'
        });
      }
    }
    
    // Update lastEditedBy field
    req.body.lastEditedBy = req.user.id;
    
    // Update story
    story = await Story.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    }).populate('author', 'name email profileColor');
    
    res.status(200).json(story);
  } catch (err) {
    console.error('Update story error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Delete a story
 * @route   DELETE /api/stories/:id
 * @access  Private
 */
exports.deleteStory = async (req, res) => {
  try {
    const story = await Story.findById(req.params.id);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author
    if (story.author.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this story'
      });
    }
    
    // Delete story
    await story.remove();
    
    // Delete all collaborators for this story
    await Collaborator.deleteMany({ story: req.params.id });
    
    res.status(200).json({
      success: true,
      message: 'Story deleted successfully'
    });
  } catch (err) {
    console.error('Delete story error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get story content
 * @route   GET /api/stories/:id/content
 * @access  Private
 */
exports.getStoryContent = async (req, res) => {
  try {
    const story = await Story.findById(req.params.id);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: story._id,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this story'
        });
      }
    }
    
    // Get the Y.js document
    try {
      const yDoc = await getYDoc(story.documentId);
      
      // Get the content from the document
      const contentType = yDoc.getText('content');
      const content = contentType ? contentType.toString() : '';
      
      res.status(200).json({ content });
    } catch (error) {
      console.error('Error getting story content:', error);
      res.status(500).json({
        success: false,
        message: 'Error getting story content'
      });
    }
  } catch (err) {
    console.error('Get story content error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Update story content
 * @route   PUT /api/stories/:id/content
 * @access  Private
 */
exports.updateStoryContent = async (req, res) => {
  try {
    const { content } = req.body;
    
    if (!content) {
      return res.status(400).json({
        success: false,
        message: 'Content is required'
      });
    }
    
    const story = await Story.findById(req.params.id);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author or editor collaborator
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const collaborator = await Collaborator.findOne({
        story: story._id,
        user: req.user.id
      });
      
      if (!collaborator || collaborator.role !== 'editor') {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to update this story'
        });
      }
    }
    
    // Update story content in database
    story.content = content;
    story.lastEditedBy = req.user.id;
    await story.save();
    
    res.status(200).json({
      success: true,
      message: 'Story content updated successfully'
    });
  } catch (err) {
    console.error('Update story content error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Add collaborator to story
 * @route   POST /api/stories/:id/collaborators
 * @access  Private
 */
exports.addCollaborator = async (req, res) => {
  try {
    const { email, role = 'editor' } = req.body;
    
    // Find story
    const story = await Story.findById(req.params.id);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author
    if (story.author.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Only the story author can add collaborators'
      });
    }
    
    // Find user by email
    const user = await User.findOne({ email });
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found with that email'
      });
    }
    
    // Check if user is already a collaborator
    const existingCollaborator = await Collaborator.findOne({
      story: story._id,
      user: user._id
    });
    
    if (existingCollaborator) {
      return res.status(400).json({
        success: false,
        message: 'User is already a collaborator'
      });
    }
    
    // Check if user is the author
    if (user._id.toString() === story.author.toString()) {
      return res.status(400).json({
        success: false,
        message: 'Cannot add story author as a collaborator'
      });
    }
    
    // Create collaborator
    const collaborator = await Collaborator.create({
      story: story._id,
      user: user._id,
      role,
      addedBy: req.user.id
    });
    
    // Populate user details
    const populatedCollaborator = await Collaborator.findById(collaborator._id)
      .populate('user', 'name email profileColor');
    
    res.status(201).json(populatedCollaborator);
  } catch (err) {
    console.error('Add collaborator error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

/**
 * @desc    Get collaborators for a story
 * @route   GET /api/stories/:id/collaborators
 * @access  Private
 */
exports.getCollaborators = async (req, res) => {
  try {
    // Check if story exists and user has access
    const story = await Story.findById(req.params.id);
    
    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }
    
    // Check if user is author or collaborator
    const isAuthor = story.author.toString() === req.user.id;
    
    if (!isAuthor) {
      const isCollaborator = await Collaborator.findOne({
        story: story._id,
        user: req.user.id
      });
      
      if (!isCollaborator) {
        return res.status(403).json({
          success: false,
          message: 'Not authorized to access this story'
        });
      }
    }
    
    // Get collaborators
    const collaborators = await Collaborator.find({ story: req.params.id })
      .populate('user', 'name email profileColor')
      .populate('addedBy', 'name email');
    
    res.status(200).json(collaborators);
  } catch (err) {
    console.error('Get collaborators error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};