/**
 * Feedback Controller
 * 
 * This controller handles API endpoints for collecting and managing feedback
 * on AI suggestions and language-specific issues.
 */

const FeedbackPipelineService = require('../services/feedbackPipeline');
const DriftMonitoringService = require('../services/driftMonitoring');
const LanguageProcessingService = require('../services/languageProcessing');
const AISuggestion = require('../models/AISuggestion');
const mongoose = require('mongoose');

// Initialize services
const driftMonitoring = new DriftMonitoringService();
const feedbackPipeline = new FeedbackPipelineService();
const languageProcessing = new LanguageProcessingService();

// Initialize feedback pipeline with drift monitoring
feedbackPipeline.initialize(driftMonitoring);

// Start services
driftMonitoring.startMonitoring();
feedbackPipeline.startProcessing();

/**
 * Submit feedback for an AI suggestion
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 */
exports.submitSuggestionFeedback = async (req, res) => {
  try {
    const { suggestionId, rating, feedback, applied } = req.body;
    
    if (!suggestionId) {
      return res.status(400).json({ error: 'Suggestion ID is required' });
    }
    
    // Find the suggestion
    const suggestion = await AISuggestion.findById(suggestionId);
    
    if (!suggestion) {
      return res.status(404).json({ error: 'Suggestion not found' });
    }
    
    // Update the suggestion with feedback
    suggestion.rating = rating || suggestion.rating;
    suggestion.feedback = feedback || suggestion.feedback;
    suggestion.applied = applied !== undefined ? applied : suggestion.applied;
    suggestion.feedbackSubmittedAt = new Date();
    suggestion.feedbackSubmittedBy = req.user.id;
    
    await suggestion.save();
    
    // Submit to feedback pipeline
    const feedbackData = {
      id: `feedback_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type: 'rating',
      source: 'endUser',
      content: suggestion.originalText,
      correction: suggestion.suggestedText,
      rating,
      applied,
      feedback,
      suggestionId: suggestion._id.toString(),
      userId: req.user.id,
      userReputation: req.user.reputation || 0.5,
      language: suggestion.language || 'en',
      timestamp: new Date()
    };
    
    await feedbackPipeline.submitFeedback(feedbackData);
    
    res.status(200).json({ 
      message: 'Feedback submitted successfully',
      suggestionId: suggestion._id
    });
  } catch (error) {
    console.error('Error submitting suggestion feedback:', error);
    res.status(500).json({ error: 'Failed to submit feedback' });
  }
};

/**
 * Submit language-specific feedback
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 */
exports.submitLanguageFeedback = async (req, res) => {
  try {
    const { 
      text, 
      language, 
      errorType, 
      description, 
      correction,
      context
    } = req.body;
    
    if (!text || !errorType) {
      return res.status(400).json({ 
        error: 'Text and error type are required' 
      });
    }
    
    // Detect language if not provided
    const detectedLanguage = language || languageProcessing.detectLanguage(text);
    
    // Create feedback data
    const feedbackData = {
      id: `lang_feedback_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type: 'classification',
      source: 'endUser',
      content: text,
      correction: correction || null,
      context: context || null,
      classification: {
        errorType,
        language: detectedLanguage
      },
      description,
      userId: req.user.id,
      userReputation: req.user.reputation || 0.5,
      language: detectedLanguage,
      timestamp: new Date()
    };
    
    // Submit to feedback pipeline
    await feedbackPipeline.submitFeedback(feedbackData);
    
    // Get language-specific feedback prompts for next time
    const feedbackPrompts = languageProcessing.getFeedbackPrompt(detectedLanguage);
    
    res.status(200).json({
      message: 'Language feedback submitted successfully',
      feedbackId: feedbackData.id,
      language: detectedLanguage,
      nextPrompts: feedbackPrompts
    });
  } catch (error) {
    console.error('Error submitting language feedback:', error);
    res.status(500).json({ error: 'Failed to submit language feedback' });
  }
};

/**
 * Submit human validation result
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 */
exports.submitValidationResult = async (req, res) => {
  try {
    const { 
      validationId, 
      approved, 
      feedback, 
      classification 
    } = req.body;
    
    if (!validationId) {
      return res.status(400).json({ error: 'Validation ID is required' });
    }
    
    // Create feedback data
    const feedbackData = {
      id: `validation_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type: 'validation',
      source: 'humanReviewer',
      validationId,
      approved,
      feedback,
      classification,
      userId: req.user.id,
      userReputation: req.user.reputation || 0.8, // Reviewers have higher reputation
      timestamp: new Date()
    };
    
    // Submit to feedback pipeline
    await feedbackPipeline.submitFeedback(feedbackData);
    
    res.status(200).json({
      message: 'Validation result submitted successfully',
      feedbackId: feedbackData.id
    });
  } catch (error) {
    console.error('Error submitting validation result:', error);
    res.status(500).json({ error: 'Failed to submit validation result' });
  }
};

/**
 * Get feedback metrics and statistics
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 */
exports.getFeedbackMetrics = async (req, res) => {
  try {
    // Get pipeline metrics
    const pipelineMetrics = feedbackPipeline.getMetrics();
    
    // Get feedback statistics from database
    const totalFeedbackCount = await AISuggestion.countDocuments({
      feedbackSubmittedAt: { $exists: true }
    });
    
    const positiveRatingCount = await AISuggestion.countDocuments({
      rating: 'helpful'
    });
    
    const negativeRatingCount = await AISuggestion.countDocuments({
      rating: 'unhelpful'
    });
    
    const appliedCount = await AISuggestion.countDocuments({
      applied: true
    });
    
    // Get language distribution
    const languageDistribution = await AISuggestion.aggregate([
      { $match: { language: { $exists: true } } },
      { $group: { _id: '$language', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);
    
    // Get error type distribution
    const errorTypeDistribution = await AISuggestion.aggregate([
      { $match: { errorType: { $exists: true } } },
      { $group: { _id: '$errorType', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);
    
    res.status(200).json({
      pipelineMetrics,
      totalFeedbackCount,
      positiveRatingCount,
      negativeRatingCount,
      appliedCount,
      positiveRatio: totalFeedbackCount > 0 
        ? positiveRatingCount / totalFeedbackCount 
        : 0,
      applicationRate: totalFeedbackCount > 0 
        ? appliedCount / totalFeedbackCount 
        : 0,
      languageDistribution: languageDistribution.map(item => ({
        language: item._id,
        count: item.count
      })),
      errorTypeDistribution: errorTypeDistribution.map(item => ({
        errorType: item._id,
        count: item.count
      }))
    });
  } catch (error) {
    console.error('Error getting feedback metrics:', error);
    res.status(500).json({ error: 'Failed to get feedback metrics' });
  }
};

/**
 * Get language-specific feedback prompts
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 */
exports.getLanguageFeedbackPrompts = async (req, res) => {
  try {
    const { language } = req.params;
    
    if (!language) {
      return res.status(400).json({ error: 'Language code is required' });
    }
    
    // Get feedback prompts for the specified language
    const feedbackPrompts = languageProcessing.getFeedbackPrompt(language);
    
    res.status(200).json(feedbackPrompts);
  } catch (error) {
    console.error('Error getting language feedback prompts:', error);
    res.status(500).json({ error: 'Failed to get feedback prompts' });
  }
};

/**
 * Get error taxonomy
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 */
exports.getErrorTaxonomy = async (req, res) => {
  try {
    // This would typically come from a service or database
    // For now, we'll use a simplified version
    const errorTaxonomy = {
      spelling: {
        name: 'Spelling Error',
        description: 'Incorrect spelling of words',
        examples: ['teh' instead of 'the', 'recieve' instead of 'receive']
      },
      grammar: {
        name: 'Grammar Error',
        description: 'Incorrect grammar usage',
        examples: ['He have a book', 'They was going']
      },
      style: {
        name: 'Style Issue',
        description: 'Problems with writing style or tone',
        examples: ['Inconsistent tone', 'Overly complex sentences']
      },
      factual: {
        name: 'Factual Error',
        description: 'Incorrect facts or information',
        examples: ['Paris is the capital of Italy', 'The moon is made of cheese']
      },
      logic: {
        name: 'Logical Error',
        description: 'Errors in reasoning or narrative logic',
        examples: ['Contradictory statements', 'Plot holes']
      },
      context: {
        name: 'Context Error',
        description: 'Misunderstanding or ignoring context',
        examples: ['Inappropriate suggestions', 'Missing the point of the text']
      }
    };
    
    res.status(200).json(errorTaxonomy);
  } catch (error) {
    console.error('Error getting error taxonomy:', error);
    res.status(500).json({ error: 'Failed to get error taxonomy' });
  }
};