const mongoose = require('mongoose');

const AISuggestionSchema = new mongoose.Schema({
  story: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Story',
    required: true
  },
  type: {
    type: String,
    enum: ['grammar', 'style', 'content', 'plot', 'character', 'setting', 'dialogue', 'other'],
    required: true
  },
  content: {
    type: String,
    required: [true, 'Please provide content for the suggestion'],
    trim: true
  },
  position: {
    from: {
      type: Number,
      required: true
    },
    to: {
      type: Number,
      required: true
    }
  },
  originalText: {
    type: String,
    required: true
  },
  suggestedText: {
    type: String,
    required: true
  },
  explanation: {
    type: String
  },
  applied: {
    type: Boolean,
    default: false
  },
  appliedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  appliedAt: {
    type: Date
  },
  dismissed: {
    type: Boolean,
    default: false
  },
  dismissedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  dismissedAt: {
    type: Date
  },
  requestedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('AISuggestion', AISuggestionSchema);