const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const StorySchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Please provide a title'],
    trim: true,
    maxlength: [100, 'Title cannot be more than 100 characters']
  },
  description: {
    type: String,
    trim: true,
    maxlength: [500, 'Description cannot be more than 500 characters']
  },
  content: {
    type: String
  },
  author: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  coverImage: {
    type: String,
    default: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80'
  },
  documentId: {
    type: String,
    default: function() {
      return `story-${uuidv4()}`;
    },
    unique: true
  },
  isPublic: {
    type: Boolean,
    default: false
  },
  tags: {
    type: [String],
    default: []
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  lastEditedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for collaborators
StorySchema.virtual('collaborators', {
  ref: 'Collaborator',
  localField: '_id',
  foreignField: 'story',
  justOne: false
});

// Virtual for comments
StorySchema.virtual('comments', {
  ref: 'Comment',
  localField: '_id',
  foreignField: 'story',
  justOne: false
});

// Virtual for AI suggestions
StorySchema.virtual('aiSuggestions', {
  ref: 'AISuggestion',
  localField: '_id',
  foreignField: 'story',
  justOne: false
});

// Update the updatedAt field on save
StorySchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Story', StorySchema);