const Y = require('yjs');
const syncProtocol = require('y-protocols/sync');
const awarenessProtocol = require('y-protocols/awareness');
const encoding = require('lib0/encoding');
const decoding = require('lib0/decoding');
const map = require('lib0/map');
const debounce = require('lodash.debounce');
const { MongodbPersistence } = require('y-mongodb');
const { getYDoc } = require('../utils/documentManager');

/**
 * Map of document IDs to document instances
 * @type {Map<string, {doc: Y.Doc, awareness: awarenessProtocol.Awareness}>}
 */
const docs = new Map();

/**
 * MongoDB persistence provider
 * @type {MongodbPersistence|null}
 */
let mongodbPersistence = null;

/**
 * Initialize MongoDB connection for document persistence
 * @returns {Promise<MongodbPersistence|null>}
 */
const initMongoDB = async () => {
  if (mongodbPersistence) return mongodbPersistence;
  
  try {
    // Connect to MongoDB
    const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/story-ai';
    
    // Create MongoDB persistence provider
    mongodbPersistence = new MongodbPersistence(MONGODB_URI, {
      collectionName: 'documents',
      flushSize: 100,
      multipleCollections: true
    });
    
    console.log('Connected to MongoDB for document persistence');
    return mongodbPersistence;
  } catch (error) {
    console.error('Failed to connect to MongoDB:', error);
    return null;
  }
};

/**
 * Get or create a Y.js document with awareness
 * @param {string} docId - Document ID
 * @returns {Promise<{doc: Y.Doc, awareness: awarenessProtocol.Awareness}>}
 */
const getYDocWithAwareness = async (docId) => {
  if (!docs.has(docId)) {
    const doc = new Y.Doc();
    const awareness = new awarenessProtocol.Awareness(doc);
    
    docs.set(docId, {
      doc,
      awareness,
      clients: new Map()
    });
    
    // Set up document persistence
    try {
      const persistence = await initMongoDB();
      if (persistence) {
        const persistedYDoc = await persistence.getYDoc(docId);
        if (persistedYDoc) {
          Y.applyUpdate(doc, Y.encodeStateAsUpdate(persistedYDoc));
          console.log(`Loaded document ${docId} from MongoDB`);
        }
        
        // Store updates to MongoDB
        doc.on('update', debounce((update) => {
          persistence.storeUpdate(docId, update)
            .catch(err => console.error(`Error storing update for document ${docId}:`, err));
        }, 2000));
      }
    } catch (error) {
      console.error(`Error loading document ${docId} from MongoDB:`, error);
    }
    
    // Clean up awareness when clients disconnect
    awareness.on('change', awarenessChangeHandler(docId, awareness));
  }
  
  return docs.get(docId);
};

/**
 * Create an awareness change handler for a document
 * @param {string} docId - Document ID
 * @param {awarenessProtocol.Awareness} awareness - Awareness instance
 * @returns {Function} - Change handler function
 */
const awarenessChangeHandler = (docId, awareness) => {
  return ({ added, updated, removed }) => {
    const changedClients = added.concat(updated, removed);
    const docInfo = docs.get(docId);
    
    if (docInfo) {
      const encoder = encoding.createEncoder();
      encoding.writeVarUint(encoder, 1); // Message type 1 for awareness update
      encoding.writeVarUint8Array(encoder, awarenessProtocol.encodeAwarenessUpdate(awareness, changedClients));
      
      const message = encoding.toUint8Array(encoder);
      
      // Broadcast awareness update to all clients
      docInfo.clients.forEach((_, client) => {
        send(client, message);
      });
    }
  };
};

/**
 * Send a message to a WebSocket client
 * @param {WebSocket} client - WebSocket client
 * @param {Uint8Array} message - Message to send
 */
const send = (client, message) => {
  if (client.readyState === client.OPEN) {
    client.send(message);
  }
};

/**
 * Message handler for WebSocket messages
 * @param {WebSocket} client - WebSocket client
 * @param {Uint8Array} message - Message received
 * @param {boolean} isEditor - Whether the client has edit permissions
 */
const messageHandler = (client, message, isEditor) => {
  const docInfo = docs.get(client.docId);
  if (!docInfo) return;
  
  const { doc, awareness } = docInfo;
  
  try {
    const decoder = decoding.createDecoder(message);
    const messageType = decoding.readVarUint(decoder);
    
    switch (messageType) {
      case 0: // Sync step 1: Client sends sync step 1 to request document state
        if (!isEditor) {
          // Read-only clients can still receive document state
          const encoder = encoding.createEncoder();
          encoding.writeVarUint(encoder, 0); // Message type 0 for sync step 1
          syncProtocol.writeSyncStep1(encoder, doc);
          send(client, encoding.toUint8Array(encoder));
          break;
        }
        
        // Handle sync step 1
        const encoder1 = encoding.createEncoder();
        encoding.writeVarUint(encoder1, 0); // Message type 0 for sync step 1
        syncProtocol.writeSyncStep1(encoder1, doc);
        send(client, encoding.toUint8Array(encoder1));
        break;
        
      case 1: // Sync step 2: Server receives sync step 2 from client
        if (!isEditor) {
          // Read-only clients can't modify the document
          break;
        }
        
        // Handle sync step 2
        syncProtocol.readSyncStep2(decoder, doc);
        break;
        
      case 2: // Awareness update
        // Handle awareness update
        awarenessProtocol.applyAwarenessUpdate(awareness, decoding.readVarUint8Array(decoder), client);
        break;
        
      case 3: // Sync step 2 with update: Client sends document updates
        if (!isEditor) {
          // Read-only clients can't modify the document
          break;
        }
        
        // Handle sync step 2 with update
        syncProtocol.readSyncStep2(decoder, doc);
        
        // Send confirmation to client
        const encoder3 = encoding.createEncoder();
        encoding.writeVarUint(encoder3, 3); // Message type 3 for sync step 2 with update
        send(client, encoding.toUint8Array(encoder3));
        break;
    }
  } catch (err) {
    console.error('Error handling WebSocket message:', err);
  }
};

/**
 * Set up WebSocket connection for a shared document
 * @param {WebSocket} ws - WebSocket connection
 * @param {string} docId - Document ID
 * @param {object} user - User object
 * @param {boolean} isEditor - Whether the user has edit permissions
 */
const setupWSConnection = async (ws, docId, user, isEditor) => {
  // Get or create document with awareness
  const { doc, awareness } = await getYDocWithAwareness(docId);
  const docInfo = docs.get(docId);
  
  // Store client in document clients map
  docInfo.clients.set(ws, {
    user,
    isEditor
  });
  
  // Set document ID and user on WebSocket object
  ws.docId = docId;
  ws.user = user;
  ws.isEditor = isEditor;
  
  // Set up awareness state for this client
  if (user) {
    awareness.setLocalState({
      user: {
        id: user._id,
        name: user.name,
        color: user.profileColor || '#3B82F6'
      }
    });
  }
  
  // Send initial sync step 1 to client
  const encoder = encoding.createEncoder();
  encoding.writeVarUint(encoder, 0); // Message type 0 for sync step 1
  syncProtocol.writeSyncStep1(encoder, doc);
  send(ws, encoding.toUint8Array(encoder));
  
  // Send initial awareness state to client
  const awarenessStates = awareness.getStates();
  if (awarenessStates.size > 0) {
    const encoder = encoding.createEncoder();
    encoding.writeVarUint(encoder, 1); // Message type 1 for awareness update
    encoding.writeVarUint8Array(encoder, awarenessProtocol.encodeAwarenessUpdate(awareness, Array.from(awarenessStates.keys())));
    send(ws, encoding.toUint8Array(encoder));
  }
  
  // Handle WebSocket messages
  ws.on('message', (message) => {
    // Handle binary messages for Y.js protocol
    if (message instanceof Buffer || message instanceof ArrayBuffer || message instanceof Uint8Array) {
      messageHandler(ws, new Uint8Array(message), isEditor);
    } else {
      // Handle JSON messages for custom protocol
      try {
        const data = JSON.parse(message);
        // Handle custom messages here
      } catch (err) {
        console.error('Error parsing WebSocket message:', err);
      }
    }
  });
  
  // Handle WebSocket close
  ws.on('close', () => {
    // Remove client from document clients map
    docInfo.clients.delete(ws);
    
    // Remove client from awareness
    awarenessProtocol.removeAwarenessStates(awareness, [ws.userId], null);
    
    // Clean up document if no clients are connected
    if (docInfo.clients.size === 0) {
      // Keep document in memory for a while before cleaning up
      setTimeout(() => {
        if (docInfo.clients.size === 0) {
          docs.delete(docId);
          doc.destroy();
          console.log(`Cleaned up document ${docId}`);
        }
      }, 300000); // 5 minutes
    }
  });
};

module.exports = {
  setupWSConnection,
  getYDocWithAwareness,
  docs
};