const WebSocket = require('ws');
const Y = require('yjs');
const { setupWSSharedDoc } = require('../utils/documentManager');
const Story = require('../models/Story');
const Collaborator = require('../models/Collaborator');
const User = require('../models/User');

/**
 * Handle WebSocket connection for a document
 * @param {WebSocket} ws - WebSocket connection
 * @param {string} documentId - Document ID
 * @param {object} user - User object
 * @param {boolean} isEditor - Whether the user has edit permissions
 */
const handleConnection = (ws, documentId, user, isEditor) => {
  // Set up shared document
  setupWSSharedDoc(ws, documentId, user, isEditor);
  
  // Set up ping interval to keep connection alive
  const pingInterval = setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.ping();
    }
  }, 30000);
  
  // Handle WebSocket messages
  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);
      handleMessage(ws, data);
    } catch (err) {
      console.error('Error handling WebSocket message:', err);
    }
  });
  
  // Handle WebSocket close
  ws.on('close', () => {
    clearInterval(pingInterval);
    handleDisconnection(ws, documentId, user);
  });
  
  // Handle WebSocket errors
  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
    clearInterval(pingInterval);
  });
};

/**
 * Handle WebSocket message
 * @param {WebSocket} ws - WebSocket connection
 * @param {object} data - Message data
 */
const handleMessage = (ws, data) => {
  switch (data.type) {
    case 'cursor-update':
      handleCursorUpdate(ws, data);
      break;
      
    case 'user-presence':
      handleUserPresence(ws, data);
      break;
      
    case 'get-presence':
      handleGetPresence(ws, data);
      break;
      
    case 'chat-message':
      handleChatMessage(ws, data);
      break;
      
    default:
      // Ignore unknown message types
      break;
  }
};

/**
 * Handle cursor update message
 * @param {WebSocket} ws - WebSocket connection
 * @param {object} data - Message data
 */
const handleCursorUpdate = (ws, data) => {
  if (!ws.user || !ws.documentId) return;
  
  // Broadcast cursor update to other clients
  broadcastToDocument(ws.wss, ws.documentId, {
    type: 'cursor-update',
    user: {
      id: ws.user._id,
      name: ws.user.name,
      profileColor: ws.user.profileColor
    },
    position: data.position,
    timestamp: new Date().toISOString()
  }, ws);
};

/**
 * Handle user presence message
 * @param {WebSocket} ws - WebSocket connection
 * @param {object} data - Message data
 */
const handleUserPresence = (ws, data) => {
  if (!ws.user || !ws.documentId) return;
  
  // Broadcast user presence to other clients
  broadcastToDocument(ws.wss, ws.documentId, {
    type: 'user-presence',
    user: {
      id: ws.user._id,
      name: ws.user.name,
      profileColor: ws.user.profileColor
    },
    status: data.status,
    timestamp: new Date().toISOString()
  }, ws);
  
  // Update collaborator status in database
  updateCollaboratorStatus(ws.documentId, ws.user._id, true).catch(err => {
    console.error('Error updating collaborator status:', err);
  });
};

/**
 * Handle get presence message
 * @param {WebSocket} ws - WebSocket connection
 * @param {object} data - Message data
 */
const handleGetPresence = (ws, data) => {
  if (!ws.documentId) return;
  
  // Get all connected users for this document
  const users = [];
  ws.wss.clients.forEach((client) => {
    if (client.documentId === ws.documentId && client.user) {
      users.push({
        id: client.user._id,
        name: client.user.name,
        profileColor: client.user.profileColor,
        isEditor: client.isEditor
      });
    }
  });
  
  // Send presence update to the requesting client
  ws.send(JSON.stringify({
    type: 'presence-update',
    users,
    timestamp: new Date().toISOString()
  }));
};

/**
 * Handle chat message
 * @param {WebSocket} ws - WebSocket connection
 * @param {object} data - Message data
 */
const handleChatMessage = (ws, data) => {
  if (!ws.user || !ws.documentId || !data.content) return;
  
  // Broadcast chat message to all clients
  broadcastToDocument(ws.wss, ws.documentId, {
    type: 'chat-message',
    user: {
      id: ws.user._id,
      name: ws.user.name,
      profileColor: ws.user.profileColor
    },
    content: data.content,
    timestamp: new Date().toISOString()
  });
};

/**
 * Handle WebSocket disconnection
 * @param {WebSocket} ws - WebSocket connection
 * @param {string} documentId - Document ID
 * @param {object} user - User object
 */
const handleDisconnection = (ws, documentId, user) => {
  if (!user || !documentId) return;
  
  // Broadcast user left event
  broadcastToDocument(ws.wss, documentId, {
    type: 'user-left',
    user: {
      id: user._id,
      name: user.name,
      profileColor: user.profileColor
    },
    timestamp: new Date().toISOString()
  });
  
  // Update collaborator status in database
  updateCollaboratorStatus(documentId, user._id, false).catch(err => {
    console.error('Error updating collaborator status:', err);
  });
};

/**
 * Broadcast a message to all clients connected to a specific document
 * @param {WebSocket.Server} wss - WebSocket server instance
 * @param {string} documentId - Document ID
 * @param {object} message - Message to broadcast
 * @param {WebSocket} [exclude] - WebSocket connection to exclude from broadcast
 */
const broadcastToDocument = (wss, documentId, message, exclude = null) => {
  wss.clients.forEach((client) => {
    if (client.documentId === documentId && client !== exclude && client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message));
    }
  });
};

/**
 * Update collaborator's active status in the database
 * @param {string} documentId - Document ID
 * @param {string} userId - User ID
 * @param {boolean} isActive - Active status
 */
const updateCollaboratorStatus = async (documentId, userId, isActive) => {
  try {
    // Find story by documentId
    const story = await Story.findOne({ documentId });
    
    if (!story) {
      return;
    }
    
    // Check if user is author
    if (story.author.toString() === userId.toString()) {
      // For the author, we would update their presence in a separate table
      // In this example, we'll just return
      return;
    }
    
    // Update collaborator's active status
    await Collaborator.findOneAndUpdate(
      {
        story: story._id,
        user: userId
      },
      {
        isActive,
        lastActive: isActive ? Date.now() : undefined
      }
    );
  } catch (err) {
    console.error('Error updating collaborator status:', err);
  }
};

module.exports = {
  handleConnection,
  handleMessage,
  handleDisconnection,
  broadcastToDocument,
  updateCollaboratorStatus
};