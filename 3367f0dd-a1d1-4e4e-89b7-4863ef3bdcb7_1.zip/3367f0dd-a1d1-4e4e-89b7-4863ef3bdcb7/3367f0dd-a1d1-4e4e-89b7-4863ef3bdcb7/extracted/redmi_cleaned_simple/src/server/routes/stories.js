const express = require('express');
const router = express.Router();
const { getYDoc } = require('../utils/documentManager');

// Mock database for stories (in a real app, this would be a MongoDB collection)
const stories = [
  {
    id: '1',
    title: 'The Lost City',
    excerpt: 'An adventure into an ancient civilization hidden deep in the Amazon rainforest.',
    coverImage: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80',
    collaborators: ['user1', 'user2', 'user3'],
    lastEdited: '2025-08-01T14:30:00Z',
    tags: ['Adventure', 'Mystery'],
    createdBy: 'user1',
    createdAt: '2025-07-15T10:00:00Z'
  },
  {
    id: '2',
    title: 'Echoes of Tomorrow',
    excerpt: 'In a world where dreams can be shared, one woman discovers she can change the future.',
    coverImage: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80',
    collaborators: ['user1', 'user4'],
    lastEdited: '2025-07-28T09:15:00Z',
    tags: ['Sci-Fi', 'Drama'],
    createdBy: 'user1',
    createdAt: '2025-07-20T14:30:00Z'
  }
];

// Get all stories
router.get('/', (req, res) => {
  // In a real app, we would filter by user, pagination, etc.
  res.json(stories);
});

// Get a specific story
router.get('/:id', (req, res) => {
  const story = stories.find(s => s.id === req.params.id);
  
  if (!story) {
    return res.status(404).json({ message: 'Story not found' });
  }
  
  res.json(story);
});

// Create a new story
router.post('/', (req, res) => {
  const { title, excerpt, tags, coverImage } = req.body;
  
  // Validate required fields
  if (!title) {
    return res.status(400).json({ message: 'Title is required' });
  }
  
  // In a real app, we would get the user ID from authentication
  const userId = req.body.userId || 'user1';
  
  // Create a new story
  const newStory = {
    id: Date.now().toString(),
    title,
    excerpt: excerpt || '',
    coverImage: coverImage || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80',
    collaborators: [userId],
    lastEdited: new Date().toISOString(),
    tags: tags || [],
    createdBy: userId,
    createdAt: new Date().toISOString()
  };
  
  // In a real app, we would save to the database
  stories.push(newStory);
  
  // Create a Y.js document for this story
  getYDoc(newStory.id);
  
  res.status(201).json(newStory);
});

// Update a story
router.put('/:id', (req, res) => {
  const { title, excerpt, tags, coverImage } = req.body;
  const storyIndex = stories.findIndex(s => s.id === req.params.id);
  
  if (storyIndex === -1) {
    return res.status(404).json({ message: 'Story not found' });
  }
  
  // In a real app, we would check permissions
  
  // Update the story
  const updatedStory = {
    ...stories[storyIndex],
    title: title || stories[storyIndex].title,
    excerpt: excerpt !== undefined ? excerpt : stories[storyIndex].excerpt,
    coverImage: coverImage || stories[storyIndex].coverImage,
    tags: tags || stories[storyIndex].tags,
    lastEdited: new Date().toISOString()
  };
  
  stories[storyIndex] = updatedStory;
  
  res.json(updatedStory);
});

// Delete a story
router.delete('/:id', (req, res) => {
  const storyIndex = stories.findIndex(s => s.id === req.params.id);
  
  if (storyIndex === -1) {
    return res.status(404).json({ message: 'Story not found' });
  }
  
  // In a real app, we would check permissions
  
  // Remove the story
  const deletedStory = stories.splice(storyIndex, 1)[0];
  
  res.json({ message: 'Story deleted successfully', story: deletedStory });
});

// Get story content
router.get('/:id/content', async (req, res) => {
  const story = stories.find(s => s.id === req.params.id);
  
  if (!story) {
    return res.status(404).json({ message: 'Story not found' });
  }
  
  try {
    // Get the Y.js document
    const yDoc = await getYDoc(req.params.id);
    
    // Get the content from the document
    const contentType = yDoc.getText('content');
    const content = contentType ? contentType.toString() : '';
    
    res.json({ content });
  } catch (error) {
    console.error('Error getting story content:', error);
    res.status(500).json({ message: 'Error getting story content' });
  }
});

module.exports = router;