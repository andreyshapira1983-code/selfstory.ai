const express = require('express');
const router = express.Router();

// Mock database for story collaborators (in a real app, this would be a MongoDB collection)
const collaborators = [
  {
    storyId: '1',
    userId: 'user1',
    role: 'owner',
    joinedAt: '2025-07-15T10:00:00Z',
    lastActive: '2025-08-01T14:30:00Z'
  },
  {
    storyId: '1',
    userId: 'user2',
    role: 'editor',
    joinedAt: '2025-07-16T11:20:00Z',
    lastActive: '2025-07-30T09:45:00Z'
  },
  {
    storyId: '1',
    userId: 'user3',
    role: 'viewer',
    joinedAt: '2025-07-18T15:10:00Z',
    lastActive: '2025-07-25T16:30:00Z'
  },
  {
    storyId: '2',
    userId: 'user1',
    role: 'owner',
    joinedAt: '2025-07-20T14:30:00Z',
    lastActive: '2025-07-28T09:15:00Z'
  },
  {
    storyId: '2',
    userId: 'user4',
    role: 'editor',
    joinedAt: '2025-07-22T10:45:00Z',
    lastActive: '2025-07-27T11:20:00Z'
  }
];

// Mock users data (in a real app, this would be fetched from the users collection)
const users = [
  {
    id: 'user1',
    name: 'Alex Chen',
    color: '#3B82F6',
    avatar: null
  },
  {
    id: 'user2',
    name: 'Maya Johnson',
    color: '#10B981',
    avatar: null
  },
  {
    id: 'user3',
    name: 'Sam Taylor',
    color: '#F59E0B',
    avatar: null
  },
  {
    id: 'user4',
    name: 'Jordan Lee',
    color: '#EF4444',
    avatar: null
  }
];

// Get all collaborators for a story
router.get('/story/:storyId', (req, res) => {
  const storyCollaborators = collaborators
    .filter(c => c.storyId === req.params.storyId)
    .map(c => {
      const user = users.find(u => u.id === c.userId);
      return {
        ...c,
        user: user ? {
          id: user.id,
          name: user.name,
          color: user.color,
          avatar: user.avatar
        } : null
      };
    });
  
  res.json(storyCollaborators);
});

// Get all stories a user is collaborating on
router.get('/user/:userId', (req, res) => {
  const userCollaborations = collaborators
    .filter(c => c.userId === req.params.userId)
    .map(c => ({
      storyId: c.storyId,
      role: c.role,
      joinedAt: c.joinedAt,
      lastActive: c.lastActive
    }));
  
  res.json(userCollaborations);
});

// Add a collaborator to a story
router.post('/', (req, res) => {
  const { storyId, userId, role } = req.body;
  
  // Validate required fields
  if (!storyId || !userId) {
    return res.status(400).json({ message: 'Story ID and User ID are required' });
  }
  
  // Check if the user is already a collaborator
  if (collaborators.some(c => c.storyId === storyId && c.userId === userId)) {
    return res.status(409).json({ message: 'User is already a collaborator on this story' });
  }
  
  // Check if the user exists
  const user = users.find(u => u.id === userId);
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }
  
  // In a real app, we would check if the story exists and if the requester has permission
  
  // Create a new collaborator entry
  const newCollaborator = {
    storyId,
    userId,
    role: role || 'viewer',
    joinedAt: new Date().toISOString(),
    lastActive: new Date().toISOString()
  };
  
  // In a real app, we would save to the database
  collaborators.push(newCollaborator);
  
  // Return with user information
  const collaboratorWithUser = {
    ...newCollaborator,
    user: {
      id: user.id,
      name: user.name,
      color: user.color,
      avatar: user.avatar
    }
  };
  
  res.status(201).json(collaboratorWithUser);
});

// Update a collaborator's role
router.put('/:storyId/:userId', (req, res) => {
  const { role } = req.body;
  const { storyId, userId } = req.params;
  
  // Find the collaborator
  const collaboratorIndex = collaborators.findIndex(
    c => c.storyId === storyId && c.userId === userId
  );
  
  if (collaboratorIndex === -1) {
    return res.status(404).json({ message: 'Collaborator not found' });
  }
  
  // In a real app, we would check permissions
  
  // Update the collaborator
  const updatedCollaborator = {
    ...collaborators[collaboratorIndex],
    role: role || collaborators[collaboratorIndex].role,
    lastActive: new Date().toISOString()
  };
  
  collaborators[collaboratorIndex] = updatedCollaborator;
  
  // Return with user information
  const user = users.find(u => u.id === userId);
  const collaboratorWithUser = {
    ...updatedCollaborator,
    user: user ? {
      id: user.id,
      name: user.name,
      color: user.color,
      avatar: user.avatar
    } : null
  };
  
  res.json(collaboratorWithUser);
});

// Remove a collaborator from a story
router.delete('/:storyId/:userId', (req, res) => {
  const { storyId, userId } = req.params;
  
  // Find the collaborator
  const collaboratorIndex = collaborators.findIndex(
    c => c.storyId === storyId && c.userId === userId
  );
  
  if (collaboratorIndex === -1) {
    return res.status(404).json({ message: 'Collaborator not found' });
  }
  
  // In a real app, we would check permissions
  // Also, we would not allow removing the owner unless transferring ownership
  
  // Remove the collaborator
  const deletedCollaborator = collaborators.splice(collaboratorIndex, 1)[0];
  
  res.json({ message: 'Collaborator removed successfully', collaborator: deletedCollaborator });
});

// Update a collaborator's last active timestamp
router.put('/:storyId/:userId/active', (req, res) => {
  const { storyId, userId } = req.params;
  
  // Find the collaborator
  const collaboratorIndex = collaborators.findIndex(
    c => c.storyId === storyId && c.userId === userId
  );
  
  if (collaboratorIndex === -1) {
    return res.status(404).json({ message: 'Collaborator not found' });
  }
  
  // Update the last active timestamp
  collaborators[collaboratorIndex].lastActive = new Date().toISOString();
  
  res.json({ message: 'Last active timestamp updated' });
});

module.exports = router;