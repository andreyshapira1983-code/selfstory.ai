/**
 * AI Routes
 * 
 * This file defines the API routes for AI-related functionality,
 * including suggestions, drift monitoring, and language processing.
 */

const express = require('express');
const router = express.Router();
const aiSuggestionController = require('../controllers/aiSuggestionController');
const authMiddleware = require('../middleware/auth');

// Apply authentication middleware to all routes
router.use(authMiddleware.authenticate);

/**
 * @route   POST /api/ai/suggestions
 * @desc    Get AI suggestions for text
 * @access  Private
 */
router.post('/suggestions', aiSuggestionController.getSuggestions);

/**
 * @route   GET /api/ai/suggestions/:id
 * @desc    Get a specific AI suggestion
 * @access  Private
 */
router.get('/suggestions/:id', aiSuggestionController.getSuggestion);

/**
 * @route   POST /api/ai/analyze
 * @desc    Analyze text for errors and issues
 * @access  Private
 */
router.post('/analyze', aiSuggestionController.analyzeText);

/**
 * @route   POST /api/ai/language/detect
 * @desc    Detect language of text
 * @access  Private
 */
router.post('/language/detect', aiSuggestionController.detectLanguage);

/**
 * @route   POST /api/ai/language/process
 * @desc    Process text with language-specific strategies
 * @access  Private
 */
router.post('/language/process', aiSuggestionController.processLanguage);

/**
 * @route   GET /api/ai/metrics
 * @desc    Get AI system metrics
 * @access  Private (Admin role)
 */
router.get('/metrics', 
  authMiddleware.checkRole(['admin']), 
  aiSuggestionController.getMetrics
);

/**
 * @route   POST /api/ai/drift/check
 * @desc    Manually trigger drift check
 * @access  Private (Admin role)
 */
router.post('/drift/check', 
  authMiddleware.checkRole(['admin']), 
  aiSuggestionController.checkDrift
);

/**
 * @route   GET /api/ai/drift/history
 * @desc    Get drift detection history
 * @access  Private (Admin role)
 */
router.get('/drift/history', 
  authMiddleware.checkRole(['admin']), 
  aiSuggestionController.getDriftHistory
);

/**
 * @route   POST /api/ai/rollback
 * @desc    Rollback to previous model version
 * @access  Private (Admin role)
 */
router.post('/rollback', 
  authMiddleware.checkRole(['admin']), 
  aiSuggestionController.rollbackModel
);

module.exports = router;