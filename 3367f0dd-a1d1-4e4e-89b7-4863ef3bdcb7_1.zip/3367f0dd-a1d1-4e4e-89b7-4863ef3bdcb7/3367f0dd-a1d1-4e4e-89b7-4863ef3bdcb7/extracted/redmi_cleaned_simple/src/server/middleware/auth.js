const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Protect routes
exports.protect = async (req, res, next) => {
  let token;

  // Check for token in Authorization header
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    // Set token from Bearer token
    token = req.headers.authorization.split(' ')[1];
  }
  // Check for token in cookie
  else if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }

  // Make sure token exists
  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Not authorized to access this route'
    });
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_jwt_secret_key_here');

    // Get user from the token
    req.user = await User.findById(decoded.id);

    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'User not found'
      });
    }

    next();
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Not authorized to access this route'
    });
  }
};

// Grant access to specific roles
exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user.role || !roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `User role ${req.user.role} is not authorized to access this route`
      });
    }
    next();
  };
};

// Check if user is story owner or collaborator
exports.checkStoryAccess = async (req, res, next) => {
  try {
    const storyId = req.params.id || req.params.storyId || req.body.story;
    
    if (!storyId) {
      return res.status(400).json({
        success: false,
        message: 'Story ID is required'
      });
    }

    // Get the story
    const Story = require('../models/Story');
    const story = await Story.findById(storyId);

    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }

    // Check if user is the story owner
    if (story.author.toString() === req.user.id) {
      req.isStoryOwner = true;
      return next();
    }

    // Check if user is a collaborator
    const Collaborator = require('../models/Collaborator');
    const collaborator = await Collaborator.findOne({
      story: storyId,
      user: req.user.id
    });

    if (!collaborator) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to access this story'
      });
    }

    // Set collaborator role in request
    req.collaboratorRole = collaborator.role;
    req.isStoryOwner = false;

    // If collaborator is a viewer and the request is not GET, deny access
    if (collaborator.role === 'viewer' && req.method !== 'GET') {
      return res.status(403).json({
        success: false,
        message: 'Viewers do not have permission to modify the story'
      });
    }

    next();
  } catch (err) {
    console.error('Error checking story access:', err);
    return res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};