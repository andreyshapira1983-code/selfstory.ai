/**
 * Text utility functions for Story AI
 * Provides functions for text manipulation, formatting, and analysis
 */

/**
 * Truncates text to a specified length with ellipsis
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length before truncation
 * @returns {string} - Truncated text
 */
export const truncateText = (text, maxLength = 100) => {
  if (!text) return '';
  if (text.length <= maxLength) return text;
  
  // Try to truncate at a word boundary
  const truncated = text.substring(0, maxLength);
  const lastSpaceIndex = truncated.lastIndexOf(' ');
  
  if (lastSpaceIndex > maxLength * 0.8) {
    // If we can find a space near the end, truncate there
    return truncated.substring(0, lastSpaceIndex) + '...';
  }
  
  // Otherwise truncate at maxLength
  return truncated + '...';
};

/**
 * Extracts a snippet of text surrounding a search term
 * @param {string} text - Full text to search in
 * @param {string} searchTerm - Term to find
 * @param {number} contextLength - Number of characters to include before and after
 * @returns {string} - Text snippet with search term highlighted
 */
export const extractSearchSnippet = (text, searchTerm, contextLength = 50) => {
  if (!text || !searchTerm) return '';
  
  const lowerText = text.toLowerCase();
  const lowerSearchTerm = searchTerm.toLowerCase();
  const index = lowerText.indexOf(lowerSearchTerm);
  
  if (index === -1) return truncateText(text, 100);
  
  const start = Math.max(0, index - contextLength);
  const end = Math.min(text.length, index + searchTerm.length + contextLength);
  
  let snippet = '';
  
  if (start > 0) {
    snippet += '...';
  }
  
  snippet += text.substring(start, index);
  snippet += `<mark>${text.substring(index, index + searchTerm.length)}</mark>`;
  snippet += text.substring(index + searchTerm.length, end);
  
  if (end < text.length) {
    snippet += '...';
  }
  
  return snippet;
};

/**
 * Counts words in a text string
 * @param {string} text - Text to count words in
 * @returns {number} - Word count
 */
export const countWords = (text) => {
  if (!text) return 0;
  
  // Remove HTML tags if present
  const plainText = text.replace(/<[^>]*>/g, ' ');
  
  // Split by whitespace and filter out empty strings
  const words = plainText.split(/\s+/).filter(word => word.length > 0);
  
  return words.length;
};

/**
 * Estimates reading time in minutes
 * @param {string} text - Text to estimate reading time for
 * @param {number} wordsPerMinute - Reading speed (default: 200)
 * @returns {number} - Estimated reading time in minutes
 */
export const estimateReadingTime = (text, wordsPerMinute = 200) => {
  const wordCount = countWords(text);
  const minutes = Math.ceil(wordCount / wordsPerMinute);
  return Math.max(1, minutes); // Minimum 1 minute
};

/**
 * Formats reading time as a string
 * @param {number} minutes - Reading time in minutes
 * @returns {string} - Formatted reading time
 */
export const formatReadingTime = (minutes) => {
  if (minutes < 1) return 'less than a minute read';
  if (minutes === 1) return '1 minute read';
  return `${minutes} minute read`;
};

/**
 * Converts plain text to HTML paragraphs
 * @param {string} text - Plain text
 * @returns {string} - HTML with paragraphs
 */
export const textToParagraphs = (text) => {
  if (!text) return '';
  
  // Split by double newlines (paragraphs)
  const paragraphs = text.split(/\n\s*\n/);
  
  // Wrap each paragraph in <p> tags
  return paragraphs
    .map(p => `<p>${p.trim()}</p>`)
    .join('');
};

/**
 * Extracts plain text from HTML
 * @param {string} html - HTML string
 * @returns {string} - Plain text
 */
export const htmlToText = (html) => {
  if (!html) return '';
  
  // Create a temporary DOM element
  const temp = document.createElement('div');
  temp.innerHTML = html;
  
  // Get text content
  return temp.textContent || temp.innerText || '';
};

/**
 * Generates a slug from text (for URLs)
 * @param {string} text - Text to convert to slug
 * @returns {string} - URL-friendly slug
 */
export const generateSlug = (text) => {
  if (!text) return '';
  
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '') // Remove special characters
    .replace(/\s+/g, '-') // Replace spaces with hyphens
    .replace(/-+/g, '-') // Replace multiple hyphens with single hyphen
    .trim();
};

/**
 * Capitalizes the first letter of each word
 * @param {string} text - Text to capitalize
 * @returns {string} - Text with first letter of each word capitalized
 */
export const capitalizeWords = (text) => {
  if (!text) return '';
  
  return text
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
};

/**
 * Extracts hashtags from text
 * @param {string} text - Text to extract hashtags from
 * @returns {Array<string>} - Array of hashtags without the # symbol
 */
export const extractHashtags = (text) => {
  if (!text) return [];
  
  const hashtagRegex = /#(\w+)/g;
  const matches = text.match(hashtagRegex);
  
  if (!matches) return [];
  
  return matches.map(tag => tag.substring(1));
};

/**
 * Highlights specific terms in text
 * @param {string} text - Text to highlight terms in
 * @param {Array<string>} terms - Terms to highlight
 * @returns {string} - HTML with highlighted terms
 */
export const highlightTerms = (text, terms) => {
  if (!text || !terms || terms.length === 0) return text;
  
  let highlightedText = text;
  
  terms.forEach(term => {
    if (!term) return;
    
    const regex = new RegExp(`(${term})`, 'gi');
    highlightedText = highlightedText.replace(regex, '<mark>$1</mark>');
  });
  
  return highlightedText;
};