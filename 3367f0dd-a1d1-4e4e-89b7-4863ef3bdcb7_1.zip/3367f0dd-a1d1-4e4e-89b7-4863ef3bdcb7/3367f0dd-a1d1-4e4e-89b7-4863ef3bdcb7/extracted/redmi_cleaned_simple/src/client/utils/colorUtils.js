/**
 * Color utility functions for Story AI
 * Provides functions for generating and manipulating colors for user avatars,
 * collaboration highlights, and UI elements
 */

/**
 * Generates a consistent color based on a string (like a username)
 * @param {string} str - String to generate color from (e.g., username)
 * @returns {string} - HEX color code
 */
export const stringToColor = (str) => {
  if (!str) return '#6366F1'; // Default indigo color if no string provided
  
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  
  // Generate a hue between 0 and 360
  const hue = hash % 360;
  
  // Use a fixed saturation and lightness for consistent, readable colors
  return `hsl(${hue}, 70%, 65%)`;
};

/**
 * Generates a lighter version of a color for backgrounds
 * @param {string} color - HEX or HSL color
 * @param {number} lightnessFactor - How much lighter (0-100)
 * @returns {string} - HSL color string
 */
export const getLighterColor = (color, lightnessFactor = 90) => {
  // If color is already HSL
  if (color.startsWith('hsl')) {
    const matches = color.match(/\d+/g);
    if (matches && matches.length >= 3) {
      const [h, s] = matches;
      return `hsl(${h}, ${s}%, ${lightnessFactor}%)`;
    }
  }
  
  // If color is HEX, convert to HSL first
  if (color.startsWith('#')) {
    // Convert hex to RGB
    const r = parseInt(color.slice(1, 3), 16) / 255;
    const g = parseInt(color.slice(3, 5), 16) / 255;
    const b = parseInt(color.slice(5, 7), 16) / 255;
    
    // Find greatest and smallest channel values
    const cmin = Math.min(r, g, b);
    const cmax = Math.max(r, g, b);
    const delta = cmax - cmin;
    
    let h = 0;
    let s = 0;
    
    // Calculate hue
    if (delta === 0) h = 0;
    else if (cmax === r) h = ((g - b) / delta) % 6;
    else if (cmax === g) h = (b - r) / delta + 2;
    else h = (r - g) / delta + 4;
    
    h = Math.round(h * 60);
    if (h < 0) h += 360;
    
    // Calculate saturation
    s = delta === 0 ? 0 : delta / (1 - Math.abs(2 * cmax - 1));
    s = Math.round(s * 100);
    
    return `hsl(${h}, ${s}%, ${lightnessFactor}%)`;
  }
  
  return color; // Return original if format not recognized
};

/**
 * Determines if a color is dark and needs white text
 * @param {string} color - HEX color code
 * @returns {boolean} - True if color is dark
 */
export const isColorDark = (color) => {
  // Remove # if present
  color = color.replace('#', '');
  
  // Convert to RGB
  const r = parseInt(color.substr(0, 2), 16);
  const g = parseInt(color.substr(2, 2), 16);
  const b = parseInt(color.substr(4, 2), 16);
  
  // Calculate perceived brightness using YIQ formula
  const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
  
  // YIQ < 128 is considered dark
  return yiq < 128;
};

/**
 * Returns appropriate text color (black or white) based on background color
 * @param {string} backgroundColor - HEX color code
 * @returns {string} - Black or white as appropriate
 */
export const getContrastColor = (backgroundColor) => {
  return isColorDark(backgroundColor) ? '#FFFFFF' : '#000000';
};

/**
 * Generates a list of distinct colors for multiple users
 * @param {number} count - Number of colors needed
 * @returns {Array<string>} - Array of HEX color codes
 */
export const generateDistinctColors = (count) => {
  const colors = [];
  const goldenRatioConjugate = 0.618033988749895;
  let h = Math.random();
  
  for (let i = 0; i < count; i++) {
    h += goldenRatioConjugate;
    h %= 1;
    
    const hue = Math.floor(h * 360);
    colors.push(`hsl(${hue}, 70%, 65%)`);
  }
  
  return colors;
};