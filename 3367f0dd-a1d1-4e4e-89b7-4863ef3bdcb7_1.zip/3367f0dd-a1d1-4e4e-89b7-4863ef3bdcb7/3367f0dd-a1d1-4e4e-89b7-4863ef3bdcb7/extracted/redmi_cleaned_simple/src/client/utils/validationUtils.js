/**
 * Validation utility functions for Story AI
 * Provides functions for validating user inputs, form data, and API responses
 */

/**
 * Validates an email address
 * @param {string} email - Email to validate
 * @returns {boolean} - True if email is valid
 */
export const isValidEmail = (email) => {
  if (!email) return false;
  
  // RFC 5322 compliant email regex
  const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return emailRegex.test(email);
};

/**
 * Validates a password meets minimum requirements
 * @param {string} password - Password to validate
 * @returns {object} - Validation result with status and message
 */
export const validatePassword = (password) => {
  if (!password) {
    return { isValid: false, message: 'Password is required' };
  }
  
  if (password.length < 8) {
    return { isValid: false, message: 'Password must be at least 8 characters' };
  }
  
  // Check for at least one number
  if (!/\d/.test(password)) {
    return { isValid: false, message: 'Password must contain at least one number' };
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(password)) {
    return { isValid: false, message: 'Password must contain at least one uppercase letter' };
  }
  
  // Check for at least one special character
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    return { isValid: false, message: 'Password must contain at least one special character' };
  }
  
  return { isValid: true, message: 'Password is valid' };
};

/**
 * Validates a username
 * @param {string} username - Username to validate
 * @returns {object} - Validation result with status and message
 */
export const validateUsername = (username) => {
  if (!username) {
    return { isValid: false, message: 'Username is required' };
  }
  
  if (username.length < 3) {
    return { isValid: false, message: 'Username must be at least 3 characters' };
  }
  
  if (username.length > 30) {
    return { isValid: false, message: 'Username must be less than 30 characters' };
  }
  
  // Only allow letters, numbers, underscores, and hyphens
  if (!/^[a-zA-Z0-9_-]+$/.test(username)) {
    return { isValid: false, message: 'Username can only contain letters, numbers, underscores, and hyphens' };
  }
  
  return { isValid: true, message: 'Username is valid' };
};

/**
 * Validates a story title
 * @param {string} title - Title to validate
 * @returns {object} - Validation result with status and message
 */
export const validateStoryTitle = (title) => {
  if (!title) {
    return { isValid: false, message: 'Title is required' };
  }
  
  if (title.length < 3) {
    return { isValid: false, message: 'Title must be at least 3 characters' };
  }
  
  if (title.length > 100) {
    return { isValid: false, message: 'Title must be less than 100 characters' };
  }
  
  return { isValid: true, message: 'Title is valid' };
};

/**
 * Validates a story description
 * @param {string} description - Description to validate
 * @returns {object} - Validation result with status and message
 */
export const validateStoryDescription = (description) => {
  if (!description) {
    return { isValid: false, message: 'Description is required' };
  }
  
  if (description.length < 10) {
    return { isValid: false, message: 'Description must be at least 10 characters' };
  }
  
  if (description.length > 500) {
    return { isValid: false, message: 'Description must be less than 500 characters' };
  }
  
  return { isValid: true, message: 'Description is valid' };
};

/**
 * Validates a comment
 * @param {string} comment - Comment to validate
 * @returns {object} - Validation result with status and message
 */
export const validateComment = (comment) => {
  if (!comment) {
    return { isValid: false, message: 'Comment is required' };
  }
  
  if (comment.length < 1) {
    return { isValid: false, message: 'Comment cannot be empty' };
  }
  
  if (comment.length > 1000) {
    return { isValid: false, message: 'Comment must be less than 1000 characters' };
  }
  
  return { isValid: true, message: 'Comment is valid' };
};

/**
 * Validates form data against a schema
 * @param {object} data - Form data to validate
 * @param {object} schema - Validation schema with field names and validation functions
 * @returns {object} - Validation results with errors for each field
 */
export const validateForm = (data, schema) => {
  const errors = {};
  let isValid = true;
  
  Object.keys(schema).forEach(field => {
    const value = data[field];
    const validators = schema[field];
    
    for (const validator of validators) {
      const result = validator(value);
      
      if (!result.isValid) {
        errors[field] = result.message;
        isValid = false;
        break;
      }
    }
  });
  
  return { isValid, errors };
};

/**
 * Validates that a value is not empty
 * @param {any} value - Value to check
 * @returns {object} - Validation result
 */
export const required = (value) => {
  if (value === null || value === undefined || value === '') {
    return { isValid: false, message: 'This field is required' };
  }
  return { isValid: true, message: '' };
};

/**
 * Validates minimum length
 * @param {number} min - Minimum length
 * @returns {function} - Validation function
 */
export const minLength = (min) => (value) => {
  if (!value || value.length < min) {
    return { isValid: false, message: `Must be at least ${min} characters` };
  }
  return { isValid: true, message: '' };
};

/**
 * Validates maximum length
 * @param {number} max - Maximum length
 * @returns {function} - Validation function
 */
export const maxLength = (max) => (value) => {
  if (value && value.length > max) {
    return { isValid: false, message: `Must be less than ${max} characters` };
  }
  return { isValid: true, message: '' };
};

/**
 * Validates that a value matches a pattern
 * @param {RegExp} pattern - Regular expression pattern
 * @param {string} message - Error message
 * @returns {function} - Validation function
 */
export const matchesPattern = (pattern, message) => (value) => {
  if (!value || !pattern.test(value)) {
    return { isValid: false, message };
  }
  return { isValid: true, message: '' };
};

/**
 * Validates that a value is a number
 * @param {any} value - Value to check
 * @returns {object} - Validation result
 */
export const isNumber = (value) => {
  if (isNaN(Number(value))) {
    return { isValid: false, message: 'Must be a number' };
  }
  return { isValid: true, message: '' };
};

/**
 * Validates that a value is within a range
 * @param {number} min - Minimum value
 * @param {number} max - Maximum value
 * @returns {function} - Validation function
 */
export const inRange = (min, max) => (value) => {
  const num = Number(value);
  if (isNaN(num) || num < min || num > max) {
    return { isValid: false, message: `Must be between ${min} and ${max}` };
  }
  return { isValid: true, message: '' };
};