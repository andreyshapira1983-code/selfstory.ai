import { useState, useEffect, useCallback } from 'react';
import api from '../utils/api';
import { useAuth } from './useAuth';

export const useStories = () => {
  const [stories, setStories] = useState([]);
  const [currentStory, setCurrentStory] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { currentUser } = useAuth();

  // Fetch all stories for the current user
  const fetchStories = useCallback(async () => {
    if (!currentUser) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.get('/stories');
      setStories(response.data);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch stories');
      console.error('Error fetching stories:', err);
    } finally {
      setLoading(false);
    }
  }, [currentUser]);

  // Fetch a single story by ID
  const fetchStory = useCallback(async (storyId) => {
    if (!storyId) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.get(`/stories/${storyId}`);
      setCurrentStory(response.data);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch story');
      console.error('Error fetching story:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  // Create a new story
  const createStory = useCallback(async (storyData) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/stories', storyData);
      setStories(prevStories => [...prevStories, response.data]);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create story');
      console.error('Error creating story:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  // Update an existing story
  const updateStory = useCallback(async (storyId, storyData) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.put(`/stories/${storyId}`, storyData);
      
      // Update stories list
      setStories(prevStories => 
        prevStories.map(story => 
          story._id === storyId ? response.data : story
        )
      );
      
      // Update current story if it's the one being edited
      if (currentStory && currentStory._id === storyId) {
        setCurrentStory(response.data);
      }
      
      return response.data;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update story');
      console.error('Error updating story:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [currentStory]);

  // Delete a story
  const deleteStory = useCallback(async (storyId) => {
    setLoading(true);
    setError(null);
    
    try {
      await api.delete(`/stories/${storyId}`);
      
      // Remove from stories list
      setStories(prevStories => 
        prevStories.filter(story => story._id !== storyId)
      );
      
      // Clear current story if it's the one being deleted
      if (currentStory && currentStory._id === storyId) {
        setCurrentStory(null);
      }
      
      return true;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to delete story');
      console.error('Error deleting story:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [currentStory]);

  // Fetch stories when the component mounts
  useEffect(() => {
    fetchStories();
  }, [fetchStories]);

  return {
    stories,
    currentStory,
    loading,
    error,
    fetchStories,
    fetchStory,
    createStory,
    updateStory,
    deleteStory
  };
};