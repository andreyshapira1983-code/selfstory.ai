/**
 * Custom hook for managing story collaborators
 * Provides functions for inviting, managing, and interacting with collaborators
 */

import { useState, useEffect, useCallback } from 'react';
import { useAuth } from './useAuth';
import * as api from '../utils/api';

/**
 * Hook for managing story collaborators
 * @param {string} storyId - ID of the story to manage collaborators for
 * @returns {object} - Collaborator management functions and state
 */
export const useCollaborators = (storyId) => {
  const [collaborators, setCollaborators] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { user } = useAuth();
  
  /**
   * Fetch all collaborators for a story
   */
  const fetchCollaborators = useCallback(async () => {
    if (!storyId) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.get(`/stories/${storyId}/collaborators`);
      setCollaborators(response.data);
    } catch (err) {
      setError(err.message || 'Failed to fetch collaborators');
      console.error('Error fetching collaborators:', err);
    } finally {
      setLoading(false);
    }
  }, [storyId]);
  
  /**
   * Invite a new collaborator to the story
   * @param {string} email - Email of the user to invite
   * @param {string} role - Role to assign (viewer, editor, co-owner)
   * @returns {Promise<object>} - New collaborator data
   */
  const inviteCollaborator = async (email, role = 'editor') => {
    if (!storyId || !email) {
      throw new Error('Story ID and email are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post(`/stories/${storyId}/collaborators`, {
        email,
        role
      });
      
      // Update collaborators list
      setCollaborators(prev => [...prev, response.data]);
      
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to invite collaborator');
      console.error('Error inviting collaborator:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Remove a collaborator from the story
   * @param {string} collaboratorId - ID of the collaborator to remove
   * @returns {Promise<boolean>} - Success status
   */
  const removeCollaborator = async (collaboratorId) => {
    if (!storyId || !collaboratorId) {
      throw new Error('Story ID and collaborator ID are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      await api.delete(`/stories/${storyId}/collaborators/${collaboratorId}`);
      
      // Update collaborators list
      setCollaborators(prev => prev.filter(c => c.id !== collaboratorId));
      
      return true;
    } catch (err) {
      setError(err.message || 'Failed to remove collaborator');
      console.error('Error removing collaborator:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Update a collaborator's role
   * @param {string} collaboratorId - ID of the collaborator
   * @param {string} newRole - New role to assign
   * @returns {Promise<object>} - Updated collaborator data
   */
  const updateCollaboratorRole = async (collaboratorId, newRole) => {
    if (!storyId || !collaboratorId || !newRole) {
      throw new Error('Story ID, collaborator ID, and new role are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.patch(`/stories/${storyId}/collaborators/${collaboratorId}`, {
        role: newRole
      });
      
      // Update collaborators list
      setCollaborators(prev => 
        prev.map(c => c.id === collaboratorId ? response.data : c)
      );
      
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to update collaborator role');
      console.error('Error updating collaborator role:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Check if a user has a specific permission on the story
   * @param {string} userId - User ID to check
   * @param {string} permission - Permission to check (view, edit, manage)
   * @returns {boolean} - True if user has permission
   */
  const hasPermission = useCallback((userId, permission) => {
    if (!userId || !collaborators.length) return false;
    
    const collaborator = collaborators.find(c => c.userId === userId);
    if (!collaborator) return false;
    
    switch (permission) {
      case 'view':
        return ['viewer', 'editor', 'co-owner'].includes(collaborator.role);
      case 'edit':
        return ['editor', 'co-owner'].includes(collaborator.role);
      case 'manage':
        return collaborator.role === 'co-owner';
      default:
        return false;
    }
  }, [collaborators]);
  
  /**
   * Check if current user is the owner of the story
   * @returns {boolean} - True if current user is owner
   */
  const isOwner = useCallback(() => {
    if (!user || !collaborators.length) return false;
    
    const collaborator = collaborators.find(c => c.userId === user.id);
    return collaborator && collaborator.role === 'owner';
  }, [user, collaborators]);
  
  /**
   * Get current user's role in the story
   * @returns {string|null} - User's role or null if not a collaborator
   */
  const getCurrentUserRole = useCallback(() => {
    if (!user || !collaborators.length) return null;
    
    const collaborator = collaborators.find(c => c.userId === user.id);
    return collaborator ? collaborator.role : null;
  }, [user, collaborators]);
  
  /**
   * Check if a user is online/active
   * @param {string} userId - User ID to check
   * @returns {boolean} - True if user is online
   */
  const isUserOnline = useCallback((userId) => {
    if (!userId || !collaborators.length) return false;
    
    const collaborator = collaborators.find(c => c.userId === userId);
    return collaborator ? collaborator.isOnline : false;
  }, [collaborators]);
  
  // Fetch collaborators on mount and when storyId changes
  useEffect(() => {
    if (storyId) {
      fetchCollaborators();
    }
  }, [storyId, fetchCollaborators]);
  
  return {
    collaborators,
    loading,
    error,
    fetchCollaborators,
    inviteCollaborator,
    removeCollaborator,
    updateCollaboratorRole,
    hasPermission,
    isOwner,
    getCurrentUserRole,
    isUserOnline
  };
};

export default useCollaborators;