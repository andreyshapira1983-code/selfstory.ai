/**
 * Custom hook for managing AI writing suggestions
 * Provides functions for generating and managing AI-powered writing assistance
 */

import { useState, useCallback } from 'react';
import * as api from '../utils/api';

/**
 * Hook for managing AI writing suggestions
 * @param {string} storyId - ID of the story to generate suggestions for
 * @returns {object} - AI suggestion management functions and state
 */
export const useAISuggestions = (storyId) => {
  const [suggestions, setSuggestions] = useState([]);
  const [activeSuggestion, setActiveSuggestion] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  /**
   * Generate AI suggestions based on current content
   * @param {string} currentContent - Current editor content
   * @param {string} [prompt] - Optional specific prompt for the AI
   * @param {string} [suggestionType] - Type of suggestion (continue, improve, rewrite)
   * @returns {Promise<Array<object>>} - Generated suggestions
   */
  const generateSuggestions = async (currentContent, prompt = '', suggestionType = 'continue') => {
    if (!storyId || !currentContent) {
      throw new Error('Story ID and current content are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post(`/stories/${storyId}/ai-suggestions`, {
        content: currentContent,
        prompt,
        type: suggestionType
      });
      
      setSuggestions(response.data);
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to generate AI suggestions');
      console.error('Error generating AI suggestions:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Get alternative suggestions for a specific suggestion
   * @param {string} suggestionId - ID of the suggestion to get alternatives for
   * @returns {Promise<Array<object>>} - Alternative suggestions
   */
  const getAlternativeSuggestions = async (suggestionId) => {
    if (!storyId || !suggestionId) {
      throw new Error('Story ID and suggestion ID are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.get(`/stories/${storyId}/ai-suggestions/${suggestionId}/alternatives`);
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to get alternative suggestions');
      console.error('Error getting alternative suggestions:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Save a suggestion for future reference
   * @param {string} suggestionId - ID of the suggestion to save
   * @returns {Promise<object>} - Saved suggestion data
   */
  const saveSuggestion = async (suggestionId) => {
    if (!storyId || !suggestionId) {
      throw new Error('Story ID and suggestion ID are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post(`/stories/${storyId}/ai-suggestions/${suggestionId}/save`);
      
      // Update suggestions list to mark this one as saved
      setSuggestions(prev => 
        prev.map(suggestion => 
          suggestion.id === suggestionId 
            ? { ...suggestion, saved: true } 
            : suggestion
        )
      );
      
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to save suggestion');
      console.error('Error saving suggestion:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Apply a suggestion to the editor
   * @param {string} suggestionId - ID of the suggestion to apply
   * @returns {object} - Suggestion data to apply
   */
  const applySuggestion = useCallback((suggestionId) => {
    const suggestion = suggestions.find(s => s.id === suggestionId);
    
    if (!suggestion) {
      throw new Error('Suggestion not found');
    }
    
    setActiveSuggestion(suggestion);
    return suggestion;
  }, [suggestions]);
  
  /**
   * Clear the active suggestion
   */
  const clearActiveSuggestion = useCallback(() => {
    setActiveSuggestion(null);
  }, []);
  
  /**
   * Rate a suggestion (helpful/not helpful)
   * @param {string} suggestionId - ID of the suggestion to rate
   * @param {boolean} isHelpful - Whether the suggestion was helpful
   * @returns {Promise<object>} - Updated suggestion data
   */
  const rateSuggestion = async (suggestionId, isHelpful) => {
    if (!storyId || !suggestionId) {
      throw new Error('Story ID and suggestion ID are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post(`/stories/${storyId}/ai-suggestions/${suggestionId}/rate`, {
        isHelpful
      });
      
      // Update suggestions list with new rating
      setSuggestions(prev => 
        prev.map(suggestion => 
          suggestion.id === suggestionId 
            ? { ...suggestion, rating: isHelpful ? 'helpful' : 'not_helpful' } 
            : suggestion
        )
      );
      
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to rate suggestion');
      console.error('Error rating suggestion:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Generate a specific type of suggestion
   * @param {string} currentContent - Current editor content
   * @param {string} type - Suggestion type (continue, improve, rewrite, etc.)
   * @param {object} options - Additional options for the suggestion
   * @returns {Promise<Array<object>>} - Generated suggestions
   */
  const generateSpecificSuggestion = async (currentContent, type, options = {}) => {
    if (!storyId || !currentContent || !type) {
      throw new Error('Story ID, current content, and suggestion type are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post(`/stories/${storyId}/ai-suggestions/specific`, {
        content: currentContent,
        type,
        options
      });
      
      setSuggestions(response.data);
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to generate specific suggestion');
      console.error('Error generating specific suggestion:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Get saved suggestions for the story
   * @returns {Promise<Array<object>>} - Saved suggestions
   */
  const getSavedSuggestions = async () => {
    if (!storyId) {
      throw new Error('Story ID is required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.get(`/stories/${storyId}/ai-suggestions/saved`);
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to get saved suggestions');
      console.error('Error getting saved suggestions:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Generate a title suggestion based on story content
   * @param {string} storyContent - Content to base title on
   * @returns {Promise<Array<string>>} - Generated title suggestions
   */
  const generateTitleSuggestions = async (storyContent) => {
    if (!storyId || !storyContent) {
      throw new Error('Story ID and content are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post(`/stories/${storyId}/ai-suggestions/title`, {
        content: storyContent
      });
      
      return response.data;
    } catch (err) {
      setError(err.message || 'Failed to generate title suggestions');
      console.error('Error generating title suggestions:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Generate a summary of the story content
   * @param {string} storyContent - Content to summarize
   * @param {number} maxLength - Maximum length of summary
   * @returns {Promise<string>} - Generated summary
   */
  const generateSummary = async (storyContent, maxLength = 200) => {
    if (!storyId || !storyContent) {
      throw new Error('Story ID and content are required');
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post(`/stories/${storyId}/ai-suggestions/summary`, {
        content: storyContent,
        maxLength
      });
      
      return response.data.summary;
    } catch (err) {
      setError(err.message || 'Failed to generate summary');
      console.error('Error generating summary:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  return {
    suggestions,
    activeSuggestion,
    loading,
    error,
    generateSuggestions,
    getAlternativeSuggestions,
    saveSuggestion,
    applySuggestion,
    clearActiveSuggestion,
    rateSuggestion,
    generateSpecificSuggestion,
    getSavedSuggestions,
    generateTitleSuggestions,
    generateSummary
  };
};

export default useAISuggestions;