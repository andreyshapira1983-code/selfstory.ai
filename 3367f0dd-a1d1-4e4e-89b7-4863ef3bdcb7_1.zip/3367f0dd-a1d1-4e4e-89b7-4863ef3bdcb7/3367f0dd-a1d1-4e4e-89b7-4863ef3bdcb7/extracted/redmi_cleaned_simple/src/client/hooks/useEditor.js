/**
 * Custom hook for managing the editor state and functionality
 * Provides functions for working with the TipTap editor instance
 */

import { useState, useEffect, useCallback } from 'react';
import { useEditor as useTiptapEditor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Highlight from '@tiptap/extension-highlight';
import Typography from '@tiptap/extension-typography';
import Placeholder from '@tiptap/extension-placeholder';
import TextAlign from '@tiptap/extension-text-align';
import Image from '@tiptap/extension-image';
import Link from '@tiptap/extension-link';
import { useCollaborativeEditor } from './useCollaborativeEditor';
import { useAISuggestions } from './useAISuggestions';
import { saveEditorDraft, getEditorDraft } from '../utils/storageUtils';

/**
 * Hook for managing the editor
 * @param {string} storyId - ID of the story being edited
 * @param {boolean} isCollaborative - Whether the editor is in collaborative mode
 * @param {object} options - Additional editor options
 * @returns {object} - Editor state and functions
 */
export const useEditor = (storyId, isCollaborative = true, options = {}) => {
  const [content, setContent] = useState('');
  const [wordCount, setWordCount] = useState(0);
  const [selectedText, setSelectedText] = useState('');
  const [selectionRange, setSelectionRange] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState(null);
  const [editorReady, setEditorReady] = useState(false);
  
  // Get collaborative editor functionality if in collaborative mode
  const {
    provider,
    ydoc,
    awareness,
    undoManager,
    collaborativeExtensions,
    getActiveUsers,
    disconnect,
    connect
  } = useCollaborativeEditor(storyId, isCollaborative);
  
  // Get AI suggestions functionality
  const {
    suggestions,
    activeSuggestion,
    generateSuggestions,
    applySuggestion,
    clearActiveSuggestion
  } = useAISuggestions(storyId);
  
  // Create extensions array based on whether we're in collaborative mode
  const extensions = [
    StarterKit.configure({
      history: !isCollaborative, // Disable history in collaborative mode (Yjs handles it)
    }),
    Highlight,
    Typography,
    TextAlign.configure({
      types: ['heading', 'paragraph'],
    }),
    Image,
    Link.configure({
      openOnClick: true,
    }),
    Placeholder.configure({
      placeholder: 'Start writing your story...',
    }),
    ...(isCollaborative ? collaborativeExtensions : []),
  ];
  
  // Initialize the editor
  const editor = useTiptapEditor({
    extensions,
    content,
    autofocus: true,
    onUpdate: ({ editor }) => {
      const newContent = editor.getHTML();
      setContent(newContent);
      setWordCount(getWordCount(editor.getText()));
      
      // Auto-save draft
      if (storyId) {
        saveEditorDraft(storyId, newContent);
      }
    },
    onSelectionUpdate: ({ editor }) => {
      const selection = editor.state.selection;
      const text = editor.state.doc.textBetween(
        selection.from, 
        selection.to, 
        ' '
      );
      
      setSelectedText(text);
      setSelectionRange({
        from: selection.from,
        to: selection.to
      });
    },
    ...options
  });
  
  /**
   * Calculate word count from text
   * @param {string} text - Text to count words in
   * @returns {number} - Word count
   */
  const getWordCount = (text) => {
    return text.split(/\s+/).filter(word => word.length > 0).length;
  };
  
  /**
   * Save the current editor content
   * @returns {Promise<boolean>} - Success status
   */
  const saveContent = useCallback(async () => {
    if (!storyId || !editor) return false;
    
    setIsSaving(true);
    
    try {
      // Save to API
      await fetch(`/api/stories/${storyId}/content`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          content: editor.getHTML(),
        }),
      });
      
      const now = new Date();
      setLastSaved(now);
      return true;
    } catch (error) {
      console.error('Error saving content:', error);
      return false;
    } finally {
      setIsSaving(false);
    }
  }, [storyId, editor]);
  
  /**
   * Load content from the server
   * @returns {Promise<boolean>} - Success status
   */
  const loadContent = useCallback(async () => {
    if (!storyId || !editor) return false;
    
    try {
      // Try to load from local draft first
      const draft = getEditorDraft(storyId);
      
      if (draft && draft.content) {
        editor.commands.setContent(draft.content);
        setContent(draft.content);
        return true;
      }
      
      // If no draft, load from API
      const response = await fetch(`/api/stories/${storyId}/content`);
      const data = await response.json();
      
      if (data.content) {
        editor.commands.setContent(data.content);
        setContent(data.content);
      }
      
      return true;
    } catch (error) {
      console.error('Error loading content:', error);
      return false;
    }
  }, [storyId, editor]);
  
  /**
   * Insert content at the current cursor position
   * @param {string} contentToInsert - Content to insert
   */
  const insertContent = useCallback((contentToInsert) => {
    if (!editor) return;
    
    editor.commands.insertContent(contentToInsert);
  }, [editor]);
  
  /**
   * Replace the selected text with new content
   * @param {string} newContent - Content to replace selection with
   */
  const replaceSelection = useCallback((newContent) => {
    if (!editor || !selectionRange) return;
    
    editor.chain()
      .focus()
      .deleteRange(selectionRange)
      .insertContent(newContent)
      .run();
  }, [editor, selectionRange]);
  
  /**
   * Apply formatting to selected text
   * @param {string} format - Format to apply (bold, italic, etc.)
   */
  const formatSelection = useCallback((format) => {
    if (!editor) return;
    
    switch (format) {
      case 'bold':
        editor.chain().focus().toggleBold().run();
        break;
      case 'italic':
        editor.chain().focus().toggleItalic().run();
        break;
      case 'underline':
        editor.chain().focus().toggleUnderline().run();
        break;
      case 'strike':
        editor.chain().focus().toggleStrike().run();
        break;
      case 'code':
        editor.chain().focus().toggleCode().run();
        break;
      case 'highlight':
        editor.chain().focus().toggleHighlight().run();
        break;
      default:
        break;
    }
  }, [editor]);
  
  /**
   * Apply a heading format
   * @param {number} level - Heading level (1-6)
   */
  const applyHeading = useCallback((level) => {
    if (!editor) return;
    
    if (level === 0) {
      editor.chain().focus().setParagraph().run();
    } else {
      editor.chain().focus().toggleHeading({ level }).run();
    }
  }, [editor]);
  
  /**
   * Apply text alignment
   * @param {string} alignment - Alignment (left, center, right, justify)
   */
  const applyAlignment = useCallback((alignment) => {
    if (!editor) return;
    
    editor.chain().focus().setTextAlign(alignment).run();
  }, [editor]);
  
  /**
   * Insert an image
   * @param {string} src - Image URL
   * @param {string} alt - Alt text
   */
  const insertImage = useCallback((src, alt = '') => {
    if (!editor) return;
    
    editor.chain().focus().setImage({ src, alt }).run();
  }, [editor]);
  
  /**
   * Insert a link
   * @param {string} href - Link URL
   * @param {string} text - Link text (uses selection if not provided)
   */
  const insertLink = useCallback((href, text = null) => {
    if (!editor) return;
    
    if (text) {
      editor.chain().focus().insertContent(`<a href="${href}">${text}</a>`).run();
    } else {
      editor.chain().focus().extendMarkRange('link').setLink({ href }).run();
    }
  }, [editor]);
  
  /**
   * Apply an AI suggestion to the editor
   * @param {string} suggestionId - ID of the suggestion to apply
   */
  const applyAISuggestion = useCallback((suggestionId) => {
    if (!editor) return;
    
    const suggestion = applySuggestion(suggestionId);
    
    if (suggestion) {
      if (suggestion.type === 'continue') {
        // Move cursor to end and insert
        editor.chain().focus().setTextSelection(editor.state.doc.content.size).insertContent(suggestion.content).run();
      } else if (suggestion.type === 'rewrite' && selectionRange) {
        // Replace selected text
        replaceSelection(suggestion.content);
      } else {
        // Default: insert at cursor
        insertContent(suggestion.content);
      }
    }
  }, [editor, applySuggestion, selectionRange, insertContent, replaceSelection]);
  
  // Set editor ready state when editor is initialized
  useEffect(() => {
    if (editor) {
      setEditorReady(true);
    }
  }, [editor]);
  
  // Load content when editor is ready and storyId is available
  useEffect(() => {
    if (editor && storyId && editorReady) {
      loadContent();
    }
  }, [editor, storyId, editorReady, loadContent]);
  
  // Clean up when unmounting
  useEffect(() => {
    return () => {
      if (isCollaborative) {
        disconnect();
      }
    };
  }, [isCollaborative, disconnect]);
  
  return {
    editor,
    content,
    wordCount,
    selectedText,
    selectionRange,
    isSaving,
    lastSaved,
    editorReady,
    saveContent,
    loadContent,
    insertContent,
    replaceSelection,
    formatSelection,
    applyHeading,
    applyAlignment,
    insertImage,
    insertLink,
    applyAISuggestion,
    // Collaborative features
    isCollaborative,
    provider,
    ydoc,
    awareness,
    undoManager,
    getActiveUsers,
    connect,
    disconnect,
    // AI suggestion features
    suggestions,
    activeSuggestion,
    generateSuggestions,
    clearActiveSuggestion
  };
};

export default useEditor;