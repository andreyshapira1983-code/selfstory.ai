import { useState, useCallback } from 'react';
import { useAuth } from './useAuth';
import api from '../utils/api';

/**
 * Hook for interacting with AI services
 */
const useAI = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [metrics, setMetrics] = useState(null);
  const [driftHistory, setDriftHistory] = useState(null);

  /**
   * Get AI suggestions for text
   * @param {string} text - Text to get suggestions for
   * @param {string} context - Context for suggestions
   * @param {string} storyId - ID of the story (optional)
   * @param {string} language - Language code (optional)
   * @param {string} suggestionType - Type of suggestions to generate
   * @returns {Promise} - Promise resolving to the suggestions
   */
  const getSuggestions = useCallback(async (text, context, storyId, language, suggestionType) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/ai/suggestions', {
        text,
        context,
        storyId,
        language,
        suggestionType
      });
      
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to get suggestions');
      setLoading(false);
      throw err;
    }
  }, []);

  /**
   * Analyze text for errors and issues
   * @param {string} text - Text to analyze
   * @param {string} language - Language code (optional)
   * @param {string} context - Context for analysis (optional)
   * @returns {Promise} - Promise resolving to the analysis
   */
  const analyzeText = useCallback(async (text, language, context) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/ai/analyze', {
        text,
        language,
        context
      });
      
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to analyze text');
      setLoading(false);
      throw err;
    }
  }, []);

  /**
   * Detect language of text
   * @param {string} text - Text to detect language for
   * @returns {Promise} - Promise resolving to the detected language
   */
  const detectLanguage = useCallback(async (text) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/ai/language/detect', { text });
      setLoading(false);
      return response.data.language;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to detect language');
      setLoading(false);
      throw err;
    }
  }, []);

  /**
   * Process text with language-specific strategies
   * @param {string} text - Text to process
   * @param {string} language - Language code (optional)
   * @returns {Promise} - Promise resolving to the processed text
   */
  const processLanguage = useCallback(async (text, language) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/ai/language/process', {
        text,
        language
      });
      
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to process language');
      setLoading(false);
      throw err;
    }
  }, []);

  /**
   * Get AI system metrics (admin only)
   * @returns {Promise} - Promise resolving to the metrics
   */
  const getMetrics = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.get('/api/ai/metrics');
      setMetrics(response.data);
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to get metrics');
      setLoading(false);
      throw err;
    }
  }, []);

  /**
   * Manually trigger drift check (admin only)
   * @returns {Promise} - Promise resolving to the drift check results
   */
  const checkDrift = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/ai/drift/check');
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to check drift');
      setLoading(false);
      throw err;
    }
  }, []);

  /**
   * Get drift detection history (admin only)
   * @returns {Promise} - Promise resolving to the drift history
   */
  const getDriftHistory = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.get('/api/ai/drift/history');
      setDriftHistory(response.data.history);
      setLoading(false);
      return response.data.history;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to get drift history');
      setLoading(false);
      throw err;
    }
  }, []);

  /**
   * Rollback to previous model version (admin only)
   * @param {string} versionId - ID of the version to rollback to
   * @returns {Promise} - Promise resolving to the rollback result
   */
  const rollbackModel = useCallback(async (versionId) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/ai/rollback', { versionId });
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to rollback model');
      setLoading(false);
      throw err;
    }
  }, []);

  /**
   * Generate AI suggestions for a story
   * @param {string} storyId - ID of the story
   * @param {string} content - Content to generate suggestions for
   * @param {Array} types - Types of suggestions to generate
   * @returns {Promise} - Promise resolving to the generated suggestions
   */
  const generateStorySuggestions = useCallback(async (storyId, content, types = ['grammar', 'style']) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/ai-suggestions/generate', {
        story: storyId,
        content,
        types
      });
      
      setLoading(false);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to generate suggestions');
      setLoading(false);
      throw err;
    }
  }, []);

  return {
    loading,
    error,
    metrics,
    driftHistory,
    getSuggestions,
    analyzeText,
    detectLanguage,
    processLanguage,
    getMetrics,
    checkDrift,
    getDriftHistory,
    rollbackModel,
    generateStorySuggestions
  };
};

export default useAI;