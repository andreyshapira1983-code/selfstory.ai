import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStories } from '../../hooks/useStories';
import { CollaborationProvider } from '../../context/CollaborationContext';
import CollaborativeEditor from '../editor/CollaborativeEditor';
import EditorToolbar from '../editor/EditorToolbar';
import EditorSidebar from '../editor/EditorSidebar';

const EditorPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { fetchStory, updateStory, currentStory, loading, error } = useStories();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [title, setTitle] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState('');

  useEffect(() => {
    if (id) {
      fetchStory(id);
    }
  }, [id, fetchStory]);

  useEffect(() => {
    if (currentStory) {
      setTitle(currentStory.title);
    }
  }, [currentStory]);

  const handleTitleChange = (e) => {
    setTitle(e.target.value);
  };

  const handleTitleBlur = async () => {
    if (currentStory && title !== currentStory.title) {
      setIsSaving(true);
      setSaveStatus('Saving...');
      
      try {
        await updateStory(id, { title });
        setSaveStatus('Saved');
        
        // Clear the save status after a delay
        setTimeout(() => {
          setSaveStatus('');
        }, 2000);
      } catch (err) {
        setSaveStatus('Failed to save');
        
        // Clear the error status after a delay
        setTimeout(() => {
          setSaveStatus('');
        }, 3000);
      } finally {
        setIsSaving(false);
      }
    }
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleBackToStories = () => {
    navigate('/stories');
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
        <button
          onClick={handleBackToStories}
          className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 transition-colors"
        >
          Back to Stories
        </button>
      </div>
    );
  }

  if (!currentStory) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-4">
          Story not found
        </div>
        <button
          onClick={handleBackToStories}
          className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 transition-colors"
        >
          Back to Stories
        </button>
      </div>
    );
  }

  return (
    <CollaborationProvider documentId={currentStory.documentId || id}>
      <div className="flex flex-col h-screen">
        {/* Editor Header */}
        <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center justify-between">
          <div className="flex items-center">
            <button
              onClick={handleBackToStories}
              className="mr-4 text-gray-600 hover:text-gray-900"
              aria-label="Back to stories"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
              </svg>
            </button>
            <input
              type="text"
              value={title}
              onChange={handleTitleChange}
              onBlur={handleTitleBlur}
              className="text-xl font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 rounded px-2 py-1 w-64"
              placeholder="Story Title"
            />
            {saveStatus && (
              <span className={`ml-3 text-sm ${saveStatus === 'Saved' ? 'text-green-600' : saveStatus === 'Failed to save' ? 'text-red-600' : 'text-gray-500'}`}>
                {saveStatus}
              </span>
            )}
          </div>
          <div className="flex items-center">
            <button
              onClick={toggleSidebar}
              className="ml-4 text-gray-600 hover:text-gray-900"
              aria-label={sidebarOpen ? 'Close sidebar' : 'Open sidebar'}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                {sidebarOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 5l7 7-7 7M5 5l7 7-7 7"></path>
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 19l-7-7 7-7m8 14l-7-7 7-7"></path>
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Editor Content */}
        <div className="flex flex-1 overflow-hidden">
          <div className="flex-1 overflow-auto">
            <EditorToolbar />
            <div className="p-4">
              <CollaborativeEditor storyId={id} />
            </div>
          </div>
          
          {sidebarOpen && (
            <div className="w-80 border-l border-gray-200 bg-white overflow-auto">
              <EditorSidebar storyId={id} />
            </div>
          )}
        </div>
      </div>
    </CollaborationProvider>
  );
};

export default EditorPage;