import React, { useState, useEffect, useContext } from 'react';
import { CollaborationContext } from '../../context/CollaborationContext';
import { useAuth } from '../../hooks/useAuth';
import api from '../../utils/api';

const CollaboratorsList = ({ storyId }) => {
  const [collaborators, setCollaborators] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('editor');
  const { awareness } = useContext(CollaborationContext);
  const { currentUser } = useAuth();

  // Fetch collaborators
  useEffect(() => {
    const fetchCollaborators = async () => {
      if (!storyId) return;
      
      try {
        setLoading(true);
        const response = await api.get(`/collaborators/story/${storyId}`);
        setCollaborators(response.data);
        setError(null);
      } catch (err) {
        console.error('Error fetching collaborators:', err);
        setError('Failed to load collaborators');
      } finally {
        setLoading(false);
      }
    };

    fetchCollaborators();
  }, [storyId]);

  // Get active users from awareness
  const getActiveUsers = () => {
    if (!awareness) return new Set();
    
    const activeUserIds = new Set();
    awareness.getStates().forEach((state) => {
      if (state.user && state.user.id) {
        activeUserIds.add(state.user.id);
      }
    });
    
    return activeUserIds;
  };

  const activeUserIds = getActiveUsers();

  // Add collaborator
  const handleAddCollaborator = async (e) => {
    e.preventDefault();
    
    if (!email) return;
    
    try {
      const response = await api.post('/collaborators', {
        story: storyId,
        email,
        role
      });
      
      setCollaborators([...collaborators, response.data]);
      setShowAddModal(false);
      setEmail('');
      setRole('editor');
    } catch (err) {
      console.error('Error adding collaborator:', err);
      setError(err.response?.data?.message || 'Failed to add collaborator');
    }
  };

  // Remove collaborator
  const handleRemoveCollaborator = async (collaboratorId) => {
    try {
      await api.delete(`/collaborators/${collaboratorId}`);
      setCollaborators(collaborators.filter(c => c._id !== collaboratorId));
    } catch (err) {
      console.error('Error removing collaborator:', err);
      setError(err.response?.data?.message || 'Failed to remove collaborator');
    }
  };

  // Update collaborator role
  const handleRoleChange = async (collaboratorId, newRole) => {
    try {
      const response = await api.put(`/collaborators/${collaboratorId}`, {
        role: newRole
      });
      
      setCollaborators(collaborators.map(c => 
        c._id === collaboratorId ? response.data : c
      ));
    } catch (err) {
      console.error('Error updating collaborator role:', err);
      setError(err.response?.data?.message || 'Failed to update role');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-32">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div>
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">Collaborators</h3>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-indigo-600 text-white px-3 py-1 rounded-md hover:bg-indigo-700 transition-colors text-sm flex items-center"
        >
          <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
          </svg>
          Add
        </button>
      </div>

      {/* Owner (current user) */}
      <div className="mb-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div 
              className="w-8 h-8 rounded-full flex items-center justify-center text-white mr-3"
              style={{ backgroundColor: currentUser?.profileColor || '#3B82F6' }}
            >
              {currentUser?.name ? currentUser.name[0].toUpperCase() : 'U'}
            </div>
            <div>
              <div className="font-medium">{currentUser?.name || 'You'}</div>
              <div className="text-xs text-gray-500">{currentUser?.email}</div>
            </div>
          </div>
          <div className="bg-indigo-100 text-indigo-800 text-xs px-2 py-1 rounded">
            Owner
          </div>
        </div>
      </div>

      {/* Collaborators List */}
      <div className="space-y-3">
        {collaborators.length === 0 ? (
          <div className="text-center py-4 text-gray-500">
            No collaborators yet
          </div>
        ) : (
          collaborators.map(collaborator => (
            <div key={collaborator._id} className="p-3 bg-white rounded-lg border border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center text-white mr-3"
                    style={{ backgroundColor: collaborator.user?.profileColor || '#9CA3AF' }}
                  >
                    {collaborator.user?.name ? collaborator.user.name[0].toUpperCase() : 'C'}
                  </div>
                  <div>
                    <div className="flex items-center">
                      <span className="font-medium">{collaborator.user?.name || 'Unknown User'}</span>
                      {activeUserIds.has(collaborator.user?._id) && (
                        <span 
                          className="ml-2 w-2 h-2 bg-green-500 rounded-full"
                          data-testid="active-status"
                          title="Online"
                        ></span>
                      )}
                    </div>
                    <div className="text-xs text-gray-500">{collaborator.user?.email}</div>
                  </div>
                </div>
                <div className="flex items-center">
                  <select
                    value={collaborator.role}
                    onChange={(e) => handleRoleChange(collaborator._id, e.target.value)}
                    className="mr-2 text-xs border border-gray-300 rounded py-1 px-2"
                  >
                    <option value="editor">editor</option>
                    <option value="viewer">viewer</option>
                  </select>
                  <button
                    onClick={() => handleRemoveCollaborator(collaborator._id)}
                    className="text-red-600 hover:text-red-800"
                    title="Remove collaborator"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Collaborator Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Add Collaborator</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
              </button>
            </div>
            
            <form onSubmit={handleAddCollaborator}>
              <div className="mb-4">
                <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="role" className="block text-gray-700 font-medium mb-2">
                  Role
                </label>
                <select
                  id="role"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="editor">Editor (can edit)</option>
                  <option value="viewer">Viewer (read-only)</option>
                </select>
              </div>
              
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-100 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
                >
                  Add Collaborator
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CollaboratorsList;