import React, { useState } from 'react';
import AISuggestionCard from './AISuggestionCard';

/**
 * Component for displaying a list of AI suggestions
 */
const AISuggestionList = ({ 
  suggestions, 
  onApply, 
  onDismiss, 
  onFeedbackSubmitted,
  loading = false,
  error = null,
  compact = false,
  emptyMessage = 'No suggestions available'
}) => {
  const [filter, setFilter] = useState('all');
  const [sort, setSort] = useState('confidence');
  
  // Filter suggestions
  const filteredSuggestions = suggestions.filter(suggestion => {
    if (filter === 'all') return true;
    return suggestion.errorType === filter;
  });
  
  // Sort suggestions
  const sortedSuggestions = [...filteredSuggestions].sort((a, b) => {
    if (sort === 'confidence') {
      return b.confidence - a.confidence;
    } else if (sort === 'type') {
      return (a.errorType || '').localeCompare(b.errorType || '');
    }
    return 0;
  });
  
  // Get unique error types for filter
  const errorTypes = [...new Set(suggestions.map(s => s.errorType).filter(Boolean))];
  
  // If loading, show loading indicator
  if (loading) {
    return (
      <div className="flex justify-center items-center h-32">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  // If error, show error message
  if (error) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
        <strong className="font-bold">Error!</strong>
        <span className="block sm:inline"> {error}</span>
      </div>
    );
  }
  
  // If no suggestions, show empty message
  if (!suggestions || suggestions.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        {emptyMessage}
      </div>
    );
  }
  
  return (
    <div>
      {/* Filters and Controls */}
      {!compact && suggestions.length > 1 && (
        <div className="flex flex-wrap justify-between items-center mb-4 gap-2">
          <div className="flex items-center space-x-2">
            <label className="text-sm text-gray-700">Filter:</label>
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="text-sm border rounded-md px-2 py-1"
            >
              <option value="all">All Types</option>
              {errorTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
          
          <div className="flex items-center space-x-2">
            <label className="text-sm text-gray-700">Sort by:</label>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="text-sm border rounded-md px-2 py-1"
            >
              <option value="confidence">Confidence</option>
              <option value="type">Error Type</option>
            </select>
          </div>
          
          <div className="text-sm text-gray-500">
            Showing {sortedSuggestions.length} of {suggestions.length} suggestions
          </div>
        </div>
      )}
      
      {/* Suggestions List */}
      <div className={compact ? "space-y-2" : "space-y-4"}>
        {sortedSuggestions.map(suggestion => (
          <AISuggestionCard
            key={suggestion.id}
            suggestion={suggestion}
            onApply={onApply}
            onDismiss={onDismiss}
            onFeedbackSubmitted={onFeedbackSubmitted}
            compact={compact}
          />
        ))}
      </div>
    </div>
  );
};

export default AISuggestionList;