import React, { createContext, useState, useEffect } from 'react';
import * as Y from 'yjs';
import { WebsocketProvider } from 'y-websocket';
import { IndexeddbPersistence } from 'y-indexeddb';
import { useAuth } from '../hooks/useAuth';

export const CollaborationContext = createContext();

export const CollaborationProvider = ({ children, documentId }) => {
  const { currentUser } = useAuth();
  const [ydoc, setYdoc] = useState(null);
  const [provider, setProvider] = useState(null);
  const [awareness, setAwareness] = useState(null);
  const [status, setStatus] = useState('disconnected');
  const [error, setError] = useState(null);
  const [activeUsers, setActiveUsers] = useState([]);

  useEffect(() => {
    if (!documentId || !currentUser) return;

    // Initialize Yjs document
    const doc = new Y.Doc();
    setYdoc(doc);

    // Set up IndexedDB persistence
    const indexeddbProvider = new IndexeddbPersistence(documentId, doc);
    indexeddbProvider.on('synced', () => {
      console.log('Content from IndexedDB loaded');
    });

    // WebSocket server URL from environment variable or default
    const wsUrl = import.meta.env.VITE_WS_SERVER_URL || 'ws://localhost:5000';
    const wsPath = import.meta.env.VITE_WS_SERVER_PATH || '/ws-server';

    // Set up WebSocket provider
    const wsProvider = new WebsocketProvider(wsUrl, `${wsPath}/${documentId}`, doc, {
      connect: true,
      awareness: {
        // Set user data for awareness
        clientID: currentUser.id,
        user: {
          id: currentUser.id,
          name: currentUser.name,
          color: currentUser.profileColor || '#3B82F6'
        }
      }
    });

    // Handle connection status
    wsProvider.on('status', event => {
      setStatus(event.status);
    });

    wsProvider.on('connection-error', event => {
      console.error('WebSocket connection error:', event);
      setError('Connection error. Please check your internet connection.');
    });

    // Get awareness instance
    const awarenessInstance = wsProvider.awareness;
    setAwareness(awarenessInstance);

    // Update active users when awareness changes
    awarenessInstance.on('change', () => {
      const users = [];
      awarenessInstance.getStates().forEach((state, clientId) => {
        if (state.user) {
          users.push({
            clientId,
            ...state.user
          });
        }
      });
      setActiveUsers(users);
    });

    setProvider(wsProvider);

    // Cleanup function
    return () => {
      wsProvider.disconnect();
      doc.destroy();
    };
  }, [documentId, currentUser]);

  // Get a shared type from the Yjs document
  const getSharedType = (name, typeConstructor) => {
    if (!ydoc) return null;
    return ydoc.get(name, typeConstructor);
  };

  const value = {
    ydoc,
    provider,
    awareness,
    status,
    error,
    activeUsers,
    getSharedType
  };

  return (
    <CollaborationContext.Provider value={value}>
      {children}
    </CollaborationContext.Provider>
  );
};