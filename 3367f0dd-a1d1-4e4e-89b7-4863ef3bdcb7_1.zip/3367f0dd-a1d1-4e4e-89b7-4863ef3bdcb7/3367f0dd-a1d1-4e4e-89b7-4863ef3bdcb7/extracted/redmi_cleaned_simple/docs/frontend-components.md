# Story AI - Frontend Components Documentation

## Overview

Story AI's frontend is built using React with a component-based architecture. This document provides an overview of the key components, their relationships, state management, and interactions. The frontend is organized into logical sections including layout components, page components, editor components, and shared utilities.

## Component Hierarchy

```
App
├── Layout
│   ├── Header
│   └── Footer
├── Pages
│   ├── HomePage
│   ├── StoryListPage
│   ├── EditorPage
│   │   ├── CollaborativeEditor
│   │   ├── EditorToolbar
│   │   └── EditorSidebar
│   │       ├── CollaboratorsList
│   │       ├── CommentsList
│   │       └── AISuggestionsList
│   └── NotFoundPage
└── Shared
    ├── AuthForms
    │   ├── LoginForm
    │   └── RegisterForm
    ├── StoryCard
    ├── UserAvatar
    └── LoadingSpinner
```

## Context Providers

Story AI uses React Context API for state management across components:

### AuthContext

Manages user authentication state and provides authentication methods.

```jsx
// AuthContext.jsx
import React, { createContext, useState, useEffect } from 'react';
import api from '../utils/api';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Methods: login, register, logout, updateProfile
  
  const value = {
    currentUser,
    isAuthenticated,
    loading,
    error,
    login,
    register,
    logout,
    updateProfile
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
```

### CollaborationContext

Manages real-time collaboration state and provides methods for collaborative editing.

```jsx
// CollaborationContext.jsx
import React, { createContext, useState, useEffect } from 'react';
import * as Y from 'yjs';
import { WebsocketProvider } from 'y-websocket';
import { IndexeddbPersistence } from 'y-indexeddb';

export const CollaborationContext = createContext();

export const CollaborationProvider = ({ children, documentId }) => {
  const [ydoc, setYdoc] = useState(null);
  const [provider, setProvider] = useState(null);
  const [awareness, setAwareness] = useState(null);
  const [status, setStatus] = useState('disconnected');
  const [activeUsers, setActiveUsers] = useState([]);
  
  // Methods: getSharedType, etc.
  
  const value = {
    ydoc,
    provider,
    awareness,
    status,
    activeUsers,
    getSharedType
  };

  return (
    <CollaborationContext.Provider value={value}>
      {children}
    </CollaborationContext.Provider>
  );
};
```

## Custom Hooks

Story AI uses custom hooks to encapsulate and reuse logic across components:

### useAuth

```jsx
// useAuth.js
import { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';

export const useAuth = () => {
  const context = useContext(AuthContext);
  
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  
  return context;
};
```

### useStories

```jsx
// useStories.js
import { useState, useEffect, useCallback } from 'react';
import api from '../utils/api';

export const useStories = () => {
  const [stories, setStories] = useState([]);
  const [currentStory, setCurrentStory] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  // Methods: fetchStories, fetchStory, createStory, updateStory, deleteStory
  
  return {
    stories,
    currentStory,
    loading,
    error,
    fetchStories,
    fetchStory,
    createStory,
    updateStory,
    deleteStory
  };
};
```

### useCollaborativeEditor

```jsx
// useCollaborativeEditor.js
import { useState, useEffect, useCallback } from 'react';
import { useEditor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Collaboration from '@tiptap/extension-collaboration';
import CollaborationCursor from '@tiptap/extension-collaboration-cursor';

export const useCollaborativeEditor = (ydoc, awareness) => {
  const [status, setStatus] = useState('initializing');
  const [error, setError] = useState(null);
  
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        history: false,
      }),
      Collaboration.configure({
        document: ydoc ? ydoc.getXmlFragment('content') : null,
      }),
      CollaborationCursor.configure({
        provider: awareness,
        user: currentUser ? {
          name: currentUser.name,
          color: currentUser.profileColor || '#3B82F6',
        } : null,
      }),
    ],
  });
  
  // Methods: getActiveUsers, setContent, getContentHtml, getContentJson
  
  return {
    editor,
    status,
    error,
    getActiveUsers,
    setContent,
    getContentHtml,
    getContentJson
  };
};
```

## Key Components

### Layout Components

#### Header

The Header component provides navigation and user account controls.

```jsx
// Header.jsx
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';

const Header = () => {
  const { currentUser, isAuthenticated, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="bg-indigo-600 text-white shadow-md">
      {/* Logo */}
      {/* Navigation Links */}
      {/* User Menu / Auth Links */}
      {/* Mobile Menu */}
    </header>
  );
};

export default Header;
```

#### Footer

The Footer component provides links to various sections of the site and copyright information.

```jsx
// Footer.jsx
import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-800 text-white py-8">
      {/* Logo and Description */}
      {/* Quick Links */}
      {/* Resources */}
      {/* Copyright and Social Links */}
    </footer>
  );
};

export default Footer;
```

### Page Components

#### HomePage

The HomePage component serves as the landing page for the application.

```jsx
// HomePage.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';

const HomePage = () => {
  const { isAuthenticated } = useAuth();

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      {/* Features Section */}
      {/* How It Works Section */}
      {/* CTA Section */}
    </div>
  );
};

export default HomePage;
```

#### StoryListPage

The StoryListPage component displays a list of the user's stories and allows creating new ones.

```jsx
// StoryListPage.jsx
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useStories } from '../../hooks/useStories';
import { useAuth } from '../../hooks/useAuth';

const StoryListPage = () => {
  const { stories, loading, error, fetchStories, createStory, deleteStory } = useStories();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newStory, setNewStory] = useState({
    title: '',
    description: '',
    tags: ''
  });
  const [deleteConfirmation, setDeleteConfirmation] = useState(null);

  useEffect(() => {
    fetchStories();
  }, [fetchStories]);

  // Methods: handleInputChange, handleCreateStory, handleDeleteClick, etc.

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header with Create Button */}
      {/* Stories Grid or Empty State */}
      {/* Create Story Modal */}
      {/* Delete Confirmation Modal */}
    </div>
  );
};

export default StoryListPage;
```

#### EditorPage

The EditorPage component provides the collaborative editing environment.

```jsx
// EditorPage.jsx
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStories } from '../../hooks/useStories';
import { CollaborationProvider } from '../../context/CollaborationContext';
import CollaborativeEditor from '../editor/CollaborativeEditor';
import EditorToolbar from '../editor/EditorToolbar';
import EditorSidebar from '../editor/EditorSidebar';

const EditorPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { fetchStory, updateStory, currentStory, loading, error } = useStories();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [title, setTitle] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState('');

  useEffect(() => {
    if (id) {
      fetchStory(id);
    }
  }, [id, fetchStory]);

  // Methods: handleTitleChange, handleTitleBlur, toggleSidebar, etc.

  return (
    <CollaborationProvider documentId={currentStory?.documentId || id}>
      {/* Editor Header */}
      {/* Editor Content Area */}
      {/* Editor Sidebar */}
    </CollaborationProvider>
  );
};

export default EditorPage;
```

### Editor Components

#### CollaborativeEditor

The CollaborativeEditor component integrates TipTap with Yjs for real-time collaborative editing.

```jsx
// CollaborativeEditor.jsx
import React, { useEffect, useContext } from 'react';
import { EditorContent } from '@tiptap/react';
import { CollaborationContext } from '../../context/CollaborationContext';
import { useCollaborativeEditor } from '../../hooks/useCollaborativeEditor';
import { useStories } from '../../hooks/useStories';

const CollaborativeEditor = ({ storyId }) => {
  const { ydoc, awareness, status: connectionStatus } = useContext(CollaborationContext);
  const { editor, status: editorStatus, error } = useCollaborativeEditor(ydoc, awareness);
  const { currentStory } = useStories();

  // Methods and effects for editor setup and auto-saving

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Editor Status Bar */}
      {/* Editor Content */}
      {/* Editor Footer */}
    </div>
  );
};

export default CollaborativeEditor;
```

#### EditorToolbar

The EditorToolbar component provides formatting controls for the editor.

```jsx
// EditorToolbar.jsx
import React, { useContext } from 'react';
import { CollaborationContext } from '../../context/CollaborationContext';
import { useCollaborativeEditor } from '../../hooks/useCollaborativeEditor';

const EditorToolbar = () => {
  const { ydoc, awareness } = useContext(CollaborationContext);
  const { editor } = useCollaborativeEditor(ydoc, awareness);

  // Methods: toggleBold, toggleItalic, etc.

  return (
    <div className="bg-white border-b border-gray-200 p-2 flex flex-wrap items-center gap-1 sticky top-0 z-10">
      {/* Text Formatting Buttons */}
      {/* Headings Buttons */}
      {/* Lists Buttons */}
      {/* Block Formatting Buttons */}
      {/* Undo/Redo Buttons */}
    </div>
  );
};

export default EditorToolbar;
```

#### EditorSidebar

The EditorSidebar component provides tabs for collaborators, comments, and AI suggestions.

```jsx
// EditorSidebar.jsx
import React, { useState } from 'react';
import CollaboratorsList from './CollaboratorsList';

const EditorSidebar = ({ storyId }) => {
  const [activeTab, setActiveTab] = useState('collaborators');

  const tabs = [
    { id: 'collaborators', label: 'Collaborators' },
    { id: 'comments', label: 'Comments' },
    { id: 'ai-suggestions', label: 'AI Suggestions' }
  ];

  return (
    <div className="h-full flex flex-col">
      {/* Tabs */}
      {/* Tab Content */}
    </div>
  );
};

export default EditorSidebar;
```

#### CollaboratorsList

The CollaboratorsList component displays and manages collaborators for a story.

```jsx
// CollaboratorsList.jsx
import React, { useState, useEffect, useContext } from 'react';
import { CollaborationContext } from '../../context/CollaborationContext';
import { useAuth } from '../../hooks/useAuth';
import api from '../../utils/api';

const CollaboratorsList = ({ storyId }) => {
  const [collaborators, setCollaborators] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('editor');
  const { awareness } = useContext(CollaborationContext);
  const { currentUser } = useAuth();

  // Methods: fetchCollaborators, handleAddCollaborator, handleRemoveCollaborator, etc.

  return (
    <div>
      {/* Header with Add Button */}
      {/* Owner (Current User) */}
      {/* Collaborators List */}
      {/* Add Collaborator Modal */}
    </div>
  );
};

export default CollaboratorsList;
```

## Props and Interfaces

### Component Props

#### CollaborativeEditor Props

```typescript
interface CollaborativeEditorProps {
  storyId: string;
}
```

#### EditorSidebar Props

```typescript
interface EditorSidebarProps {
  storyId: string;
}
```

#### CollaboratorsList Props

```typescript
interface CollaboratorsListProps {
  storyId: string;
}
```

### Context Interfaces

#### AuthContext Interface

```typescript
interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  error: string | null;
  login: (credentials: LoginCredentials) => Promise<User>;
  register: (userData: RegisterData) => Promise<User>;
  logout: () => void;
  updateProfile: (userData: UpdateProfileData) => Promise<User>;
}
```

#### CollaborationContext Interface

```typescript
interface CollaborationContextType {
  ydoc: Y.Doc | null;
  provider: WebsocketProvider | null;
  awareness: any | null;
  status: 'connected' | 'connecting' | 'disconnected' | 'error';
  error: string | null;
  activeUsers: ActiveUser[];
  getSharedType: (name: string, typeConstructor: any) => any;
}
```

## State Management

### Component State

Components use React's `useState` hook for local state management:

```jsx
const [showCreateModal, setShowCreateModal] = useState(false);
const [newStory, setNewStory] = useState({
  title: '',
  description: '',
  tags: ''
});
```

### Context State

Context providers manage global state that needs to be accessed by multiple components:

```jsx
// AuthContext state
const [currentUser, setCurrentUser] = useState(null);
const [isAuthenticated, setIsAuthenticated] = useState(false);
const [loading, setLoading] = useState(true);
const [error, setError] = useState(null);

// CollaborationContext state
const [ydoc, setYdoc] = useState(null);
const [provider, setProvider] = useState(null);
const [awareness, setAwareness] = useState(null);
const [status, setStatus] = useState('disconnected');
const [activeUsers, setActiveUsers] = useState([]);
```

### Custom Hook State

Custom hooks encapsulate related state and logic:

```jsx
// useStories hook state
const [stories, setStories] = useState([]);
const [currentStory, setCurrentStory] = useState(null);
const [loading, setLoading] = useState(false);
const [error, setError] = useState(null);
```

## Component Interactions

### Parent-Child Communication

Components communicate with their children through props:

```jsx
<CollaborativeEditor storyId={id} />
<EditorSidebar storyId={id} />
```

### Child-Parent Communication

Children communicate with parents through callback props:

```jsx
// Parent component
const handleAddCollaborator = (email, role) => {
  // Add collaborator logic
};

// Child component usage
<AddCollaboratorForm onSubmit={handleAddCollaborator} />
```

### Context-Based Communication

Components communicate through context when they are not directly related:

```jsx
// Component A
const { currentUser } = useAuth();

// Component B (potentially in a different part of the component tree)
const { currentUser } = useAuth();
```

## Styling

Story AI uses TailwindCSS for styling components:

```jsx
<header className="bg-indigo-600 text-white shadow-md">
  <div className="container mx-auto px-4 py-3">
    <div className="flex justify-between items-center">
      {/* Component content */}
    </div>
  </div>
</header>
```

### Custom CSS

For more complex styling needs, custom CSS is defined in the `src/client/styles/index.css` file:

```css
/* Editor Styles */
.ProseMirror {
  min-height: 500px;
  padding: 1rem;
  outline: none;
}

.ProseMirror p {
  margin-bottom: 1em;
}

/* Collaboration Cursor Styles */
.collaboration-cursor__caret {
  position: relative;
  border-left: 1px solid;
  margin-left: -1px;
  margin-right: -1px;
  pointer-events: none;
  word-break: normal;
}

.collaboration-cursor__label {
  position: absolute;
  top: -1.4em;
  left: -1px;
  font-size: 12px;
  font-weight: 600;
  line-height: normal;
  white-space: nowrap;
  color: white;
  padding: 0.1rem 0.3rem;
  border-radius: 3px 3px 3px 0;
  user-select: none;
  pointer-events: none;
}
```

## Responsive Design

Story AI is designed to work on various screen sizes:

```jsx
// Responsive layout example
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
  {/* Grid items */}
</div>

// Responsive navigation
<nav className="hidden md:flex items-center space-x-6">
  {/* Desktop navigation items */}
</nav>

<button className="md:hidden text-white" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
  {/* Mobile menu button */}
</button>

{mobileMenuOpen && (
  <nav className="md:hidden mt-4 pb-4 space-y-3">
    {/* Mobile navigation items */}
  </nav>
)}
```

## Accessibility

Story AI follows accessibility best practices:

```jsx
// Semantic HTML
<header>...</header>
<main>...</main>
<footer>...</footer>

// ARIA attributes
<button
  aria-label="Toggle mobile menu"
  aria-expanded={mobileMenuOpen}
  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
>
  {/* Button content */}
</button>

// Focus management
<input
  className="focus:outline-none focus:ring-2 focus:ring-indigo-500"
  type="text"
  id="title"
  name="title"
/>

// Screen reader text
<span className="sr-only">Close</span>
```

## Conclusion

The Story AI frontend is built with a component-based architecture using React, with a focus on reusability, maintainability, and performance. The use of contexts and custom hooks helps manage state across the application, while the component hierarchy provides a clear structure for the UI.

The collaborative editing features are implemented using Yjs and TipTap, with WebSocket communication for real-time updates. The application is styled using TailwindCSS, with responsive design and accessibility considerations built in.