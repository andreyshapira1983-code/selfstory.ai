# Story AI - Collaborative Editing Documentation

## Overview

Story AI implements real-time collaborative editing using Conflict-free Replicated Data Types (CRDTs) through the Yjs library. This approach allows multiple users to edit the same document simultaneously without conflicts, even in the presence of network delays or disconnections.

This document explains the collaborative editing implementation, including the CRDT model, document synchronization, conflict resolution, and user awareness features.

## CRDT Implementation

### What are CRDTs?

Conflict-free Replicated Data Types (CRDTs) are data structures that can be replicated across multiple computers in a network, with each replica being updated independently and concurrently without coordination between them, and it is always mathematically possible to resolve inconsistencies that might result.

### Why Yjs?

Story AI uses Yjs as its CRDT implementation for several reasons:

1. **Performance**: Yjs is one of the fastest CRDT implementations available, with optimized algorithms for text editing.
2. **Rich Text Support**: Yjs works well with rich text editors like TipTap and ProseMirror.
3. **Network Agnostic**: Yjs can work with any network provider, making it flexible for different deployment scenarios.
4. **Persistence**: Yjs can be easily persisted to a database using providers like y-mongodb.
5. **Awareness Protocol**: Yjs includes an awareness protocol for cursor positions and user presence.

## Architecture

### Components

The collaborative editing system consists of the following components:

1. **Client-side Editor**: TipTap editor with Yjs integration
2. **Client-side Yjs Document**: Local replica of the shared document
3. **WebSocket Connection**: Communication channel between clients and server
4. **Server-side Yjs Document**: Server replica of the shared document
5. **MongoDB Persistence**: Storage for document updates
6. **Awareness Protocol**: Tracking of user presence and cursor positions

### Data Flow

```
┌─────────────┐     WebSocket     ┌─────────────┐
│             │<----------------->│             │
│  Client A   │                   │  WebSocket  │
│  (Browser)  │                   │   Server    │
│             │                   │             │
└─────────────┘                   └──────┬──────┘
                                         │
┌─────────────┐     WebSocket     ┌──────▼──────┐     ┌─────────────┐
│             │<----------------->│             │     │             │
│  Client B   │                   │    Yjs      │<--->│  MongoDB    │
│  (Browser)  │                   │  Document   │     │ Persistence │
│             │                   │             │     │             │
└─────────────┘                   └─────────────┘     └─────────────┘
```

## Document Synchronization

### Initial Connection

When a client connects to a document:

1. The client creates a local Yjs document
2. The client connects to the WebSocket server with the document ID
3. The server sends the current document state to the client
4. The client applies the document state to its local document
5. The client is now synchronized and can begin editing

### Update Propagation

When a client makes changes to the document:

1. The changes are applied to the local Yjs document
2. The changes are encoded as update messages
3. The update messages are sent to the server via WebSocket
4. The server applies the updates to its Yjs document
5. The server broadcasts the updates to all other connected clients
6. Other clients apply the updates to their local documents
7. The server persists the updates to MongoDB

### Conflict Resolution

Yjs uses a CRDT algorithm that automatically resolves conflicts without requiring explicit conflict resolution logic. The key principles are:

1. **Unique Identifiers**: Each character in the document has a unique identifier
2. **Causal Ordering**: Updates are applied in causal order
3. **Commutative Operations**: Operations can be applied in any order and still reach the same state
4. **Idempotent Updates**: Applying the same update multiple times has the same effect as applying it once

This means that even if two users edit the same part of the document simultaneously, their changes will be merged without conflicts.

## Implementation Details

### Client-side Implementation

#### Setting up the Yjs Document

```javascript
import * as Y from 'yjs';
import { WebsocketProvider } from 'y-websocket';
import { IndexeddbPersistence } from 'y-indexeddb';

// Create a Yjs document
const ydoc = new Y.Doc();

// Set up WebSocket provider
const wsProvider = new WebsocketProvider(
  'ws://localhost:5000/ws-server',
  'story-123',
  ydoc
);

// Set up IndexedDB persistence for offline support
const indexeddbProvider = new IndexeddbPersistence('story-123', ydoc);

// Get the shared text type
const ytext = ydoc.getText('content');
```

#### Integrating with TipTap Editor

```javascript
import { useEditor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Collaboration from '@tiptap/extension-collaboration';
import CollaborationCursor from '@tiptap/extension-collaboration-cursor';

const editor = useEditor({
  extensions: [
    StarterKit.configure({
      history: false, // Disable history as we use Yjs for history
    }),
    Collaboration.configure({
      document: ydoc,
      field: 'content',
    }),
    CollaborationCursor.configure({
      provider: wsProvider,
      user: {
        name: 'John Doe',
        color: '#3B82F6',
      },
    }),
  ],
  content: '',
});
```

#### Handling Awareness

```javascript
// Get awareness from the WebSocket provider
const { awareness } = wsProvider;

// Update local user state
awareness.setLocalState({
  user: {
    name: 'John Doe',
    color: '#3B82F6',
  },
  cursor: {
    anchor: 0,
    head: 0,
  },
});

// Listen for awareness changes
awareness.on('change', () => {
  const states = awareness.getStates();
  const users = [];
  
  states.forEach((state, clientId) => {
    if (state.user) {
      users.push({
        clientId,
        ...state.user,
      });
    }
  });
  
  // Update UI with active users
  updateActiveUsers(users);
});
```

### Server-side Implementation

#### Setting up the WebSocket Server

```javascript
const WebSocket = require('ws');
const http = require('http');
const Y = require('yjs');
const { setupWSConnection } = require('y-websocket/bin/utils');
const { MongodbPersistence } = require('y-mongodb');

// Create HTTP server
const server = http.createServer();

// Create WebSocket server
const wss = new WebSocket.Server({ server });

// Map of document IDs to document instances
const docs = new Map();

// MongoDB persistence
const mongodbPersistence = new MongodbPersistence('mongodb://localhost:27017/story-ai', {
  collectionName: 'documents',
});

// Handle WebSocket connections
wss.on('connection', (ws, req) => {
  // Extract document ID from URL
  const url = new URL(req.url, 'http://localhost');
  const documentId = url.pathname.slice(1);
  
  // Get or create document
  let doc = docs.get(documentId);
  if (!doc) {
    doc = new Y.Doc();
    docs.set(documentId, doc);
    
    // Load document from MongoDB
    mongodbPersistence.getYDoc(documentId).then((persistedDoc) => {
      if (persistedDoc) {
        Y.applyUpdate(doc, Y.encodeStateAsUpdate(persistedDoc));
      }
    });
    
    // Set up document persistence
    doc.on('update', (update) => {
      mongodbPersistence.storeUpdate(documentId, update);
    });
  }
  
  // Set up WebSocket connection
  setupWSConnection(ws, req, { docName: documentId, doc });
});

// Start server
server.listen(5000);
```

#### Document Manager

```javascript
const Y = require('yjs');
const { MongodbPersistence } = require('y-mongodb');

// Map to store active documents
const documents = new Map();

// MongoDB connection for document persistence
let mongodbPersistence = null;

// Initialize MongoDB connection
const initMongoDB = async () => {
  if (mongodbPersistence) return mongodbPersistence;
  
  try {
    // Connect to MongoDB
    const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/story-ai';
    
    // Create MongoDB persistence provider
    mongodbPersistence = new MongodbPersistence(MONGODB_URI, {
      collectionName: 'documents',
      flushSize: 100,
      multipleCollections: true
    });
    
    console.log('Connected to MongoDB for document persistence');
    return mongodbPersistence;
  } catch (error) {
    console.error('Failed to connect to MongoDB:', error);
    return null;
  }
};

// Get or create a Y.js document
const getYDoc = async (documentId) => {
  if (!documents.has(documentId)) {
    const doc = new Y.Doc();
    documents.set(documentId, doc);
    
    // Try to load document from MongoDB
    try {
      const persistence = await initMongoDB();
      if (persistence) {
        const persistedYDoc = await persistence.getYDoc(documentId);
        if (persistedYDoc) {
          Y.applyUpdate(doc, Y.encodeStateAsUpdate(persistedYDoc));
          console.log(`Loaded document ${documentId} from MongoDB`);
        }
      }
    } catch (error) {
      console.error(`Error loading document ${documentId} from MongoDB:`, error);
    }
  }
  
  return documents.get(documentId);
};

module.exports = {
  getYDoc,
  initMongoDB
};
```

## User Awareness

### Cursor Tracking

Story AI tracks user cursors and selections using the CollaborationCursor extension from TipTap. This extension:

1. Tracks the local user's cursor position
2. Sends cursor updates to the server via the awareness protocol
3. Receives cursor updates from other users
4. Renders remote cursors in the editor

### User Presence

User presence is tracked using the awareness protocol:

1. When a user connects to a document, their presence is added to the awareness state
2. When a user disconnects, their presence is removed from the awareness state
3. The server broadcasts awareness updates to all connected clients
4. Clients update their UI to show which users are currently active

### Implementation Example

```javascript
// Server-side awareness handling
const awarenessChangeHandler = (docName, awareness) => {
  return ({ added, updated, removed }) => {
    const changedClients = added.concat(updated, removed);
    
    // Broadcast awareness update to all clients
    awareness.getStates().forEach((state, clientId) => {
      // Send awareness update to client
    });
    
    // Update collaborator status in database
    for (const clientId of removed) {
      const state = awareness.getStates().get(clientId);
      if (state && state.user) {
        updateCollaboratorStatus(docName, state.user.id, false);
      }
    }
  };
};

// Client-side awareness handling
wsProvider.awareness.on('change', ({ added, updated, removed }) => {
  const states = wsProvider.awareness.getStates();
  const users = [];
  
  states.forEach((state, clientId) => {
    if (state.user) {
      users.push({
        clientId,
        ...state.user,
      });
    }
  });
  
  // Update UI with active users
  updateActiveUsers(users);
});
```

## Offline Support

Story AI provides offline editing support using IndexedDB:

1. Document updates are stored in IndexedDB when the user is offline
2. When the user reconnects, the updates are synchronized with the server
3. The user can continue editing even when offline
4. Changes are merged automatically when the user comes back online

### Implementation Example

```javascript
// Set up IndexedDB persistence
const indexeddbProvider = new IndexeddbPersistence('story-123', ydoc);

// Listen for sync status
indexeddbProvider.on('synced', () => {
  console.log('Content from IndexedDB loaded');
});

// Handle offline/online events
window.addEventListener('online', () => {
  wsProvider.connect();
});

window.addEventListener('offline', () => {
  // IndexedDB will continue to store updates
});
```

## Version History

Story AI tracks document version history using Yjs:

1. Each update is stored in MongoDB with a timestamp
2. The document can be restored to any previous state by applying updates up to a specific point
3. Users can view the document history and restore previous versions

### Implementation Example

```javascript
// Get document history
const getDocumentHistory = async (documentId) => {
  const persistence = await initMongoDB();
  if (!persistence) return [];
  
  // Get updates from MongoDB
  const updates = await persistence.getUpdates(documentId);
  
  // Create a new document for each version
  const versions = [];
  const doc = new Y.Doc();
  
  for (let i = 0; i < updates.length; i++) {
    // Apply update
    Y.applyUpdate(doc, updates[i].update);
    
    // Get document content
    const content = doc.getText('content').toString();
    
    // Add version to history
    versions.push({
      timestamp: updates[i].timestamp,
      content,
    });
  }
  
  return versions;
};

// Restore document to a specific version
const restoreDocumentVersion = async (documentId, versionIndex) => {
  const persistence = await initMongoDB();
  if (!persistence) return false;
  
  // Get updates from MongoDB
  const updates = await persistence.getUpdates(documentId);
  
  // Create a new document
  const doc = new Y.Doc();
  
  // Apply updates up to the specified version
  for (let i = 0; i <= versionIndex; i++) {
    Y.applyUpdate(doc, updates[i].update);
  }
  
  // Get the current document
  const currentDoc = await getYDoc(documentId);
  
  // Clear the current document
  currentDoc.getText('content').delete(0, currentDoc.getText('content').length);
  
  // Insert the content from the restored version
  currentDoc.getText('content').insert(0, doc.getText('content').toString());
  
  return true;
};
```

## Performance Considerations

### Client-side Optimization

1. **Debounce Cursor Updates**: Limit the frequency of cursor position updates to reduce network traffic
2. **Batch Document Updates**: Group small edits together to reduce the number of update messages
3. **Use IndexedDB**: Store document updates locally for offline support and faster loading

### Server-side Optimization

1. **Document Caching**: Keep active documents in memory for faster access
2. **Update Batching**: Batch updates before persisting to MongoDB
3. **Document Cleanup**: Remove inactive documents from memory after a period of inactivity
4. **Connection Pooling**: Use connection pooling for MongoDB to improve performance

## Security Considerations

### Authentication and Authorization

1. **JWT Authentication**: Verify JWT tokens for WebSocket connections
2. **Document Access Control**: Check if the user has permission to access the document
3. **Role-based Permissions**: Enforce read-only access for viewers

### Data Validation

1. **Input Sanitization**: Sanitize user input to prevent XSS attacks
2. **Update Validation**: Validate document updates before applying them
3. **Rate Limiting**: Limit the frequency of updates from a single client

## Conclusion

Story AI's collaborative editing implementation provides a seamless real-time editing experience with conflict-free synchronization, user awareness, and offline support. By leveraging Yjs and CRDTs, the platform ensures that multiple users can edit the same document simultaneously without conflicts, even in challenging network conditions.