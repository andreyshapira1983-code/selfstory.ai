#!/bin/bash

# Story AI Integration Test Script
# This script runs comprehensive tests to ensure all components work together

# Exit on error
set -e

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

# Function to print section header
print_header() {
  echo -e "\n${YELLOW}===== $1 =====${NC}"
}

# Function to print success message
print_success() {
  echo -e "${GREEN}✓ $1${NC}"
}

# Function to print error message
print_error() {
  echo -e "${RED}✗ $1${NC}"
}

# Start MongoDB if not running
start_mongodb() {
  print_header "Checking MongoDB"
  
  if pgrep mongod > /dev/null; then
    print_success "MongoDB is already running"
  else
    echo "Starting MongoDB..."
    mongod --fork --logpath /var/log/mongodb.log
    print_success "MongoDB started"
  fi
}

# Run server in background
start_server() {
  print_header "Starting Server"
  
  echo "Starting Node.js server in test mode..."
  NODE_ENV=test PORT=5001 node src/server/index.js > server.log 2>&1 &
  SERVER_PID=$!
  
  # Wait for server to start
  echo "Waiting for server to start..."
  sleep 5
  
  # Check if server is running
  if kill -0 $SERVER_PID 2>/dev/null; then
    print_success "Server started successfully (PID: $SERVER_PID)"
  else
    print_error "Server failed to start"
    cat server.log
    exit 1
  fi
}

# Run MongoDB connection tests
test_mongodb_connection() {
  print_header "Testing MongoDB Connection"
  
  echo "Running MongoDB connection tests..."
  node test_mongodb_connection.js
  
  if [ $? -eq 0 ]; then
    print_success "MongoDB connection tests passed"
  else
    print_error "MongoDB connection tests failed"
    exit 1
  fi
}

# Run API endpoint tests
test_api_endpoints() {
  print_header "Testing API Endpoints"
  
  echo "Running API endpoint tests..."
  NODE_ENV=test PORT=5001 node test_api_endpoints.js
  
  if [ $? -eq 0 ]; then
    print_success "API endpoint tests passed"
  else
    print_error "API endpoint tests failed"
    exit 1
  fi
}

# Run WebSocket tests
test_websocket() {
  print_header "Testing WebSocket Connections"
  
  echo "Running WebSocket tests..."
  NODE_ENV=test PORT=5001 node test_websocket_server.js
  
  if [ $? -eq 0 ]; then
    print_success "WebSocket tests passed"
  else
    print_error "WebSocket tests failed"
    exit 1
  fi
}

# Run frontend component tests
test_frontend_components() {
  print_header "Testing Frontend Components"
  
  echo "Running frontend component tests..."
  NODE_ENV=test npx jest test_frontend_components.js
  
  if [ $? -eq 0 ]; then
    print_success "Frontend component tests passed"
  else
    print_error "Frontend component tests failed"
    exit 1
  fi
}

# Run utility function tests
test_utility_functions() {
  print_header "Testing Utility Functions"
  
  echo "Running utility function tests..."
  NODE_ENV=test npx jest test_utility_functions.js
  
  if [ $? -eq 0 ]; then
    print_success "Utility function tests passed"
  else
    print_error "Utility function tests failed"
    exit 1
  fi
}

# Test collaborative editing functionality
test_collaborative_editing() {
  print_header "Testing Collaborative Editing"
  
  echo "Running collaborative editing tests..."
  NODE_ENV=test npx jest --testMatch="**/collaborative-editing.test.js"
  
  if [ $? -eq 0 ]; then
    print_success "Collaborative editing tests passed"
  else
    print_error "Collaborative editing tests failed"
    exit 1
  fi
}

# Run accessibility tests
test_accessibility() {
  print_header "Testing Accessibility Compliance"
  
  echo "Running accessibility tests..."
  npm run accessibility-audit
  
  if [ $? -eq 0 ]; then
    print_success "Accessibility tests passed"
  else
    print_error "Accessibility tests failed"
    exit 1
  fi
}

# Run responsive design tests
test_responsive_design() {
  print_header "Testing Responsive Design"
  
  echo "Running responsive design tests..."
  npm run test:responsive
  
  if [ $? -eq 0 ]; then
    print_success "Responsive design tests passed"
  else
    print_error "Responsive design tests failed"
    exit 1
  fi
}

# Clean up function
cleanup() {
  print_header "Cleaning Up"
  
  echo "Stopping server..."
  if [ ! -z "$SERVER_PID" ]; then
    kill $SERVER_PID
    print_success "Server stopped"
  fi
  
  echo "Removing test data..."
  # Add commands to clean up test data if needed
  
  print_success "Cleanup completed"
}

# Register cleanup function to run on exit
trap cleanup EXIT

# Main execution
print_header "Starting Integration Tests"

# Start required services
start_mongodb

# Start server
start_server

# Run tests
test_mongodb_connection
test_api_endpoints
test_websocket
test_frontend_components
test_utility_functions
test_collaborative_editing
test_accessibility
test_responsive_design

# Final report
print_header "Integration Test Results"
print_success "All tests passed successfully!"
echo -e "\nThe Story AI application is ready for deployment."