/**
 * Accessibility Audit Script for Story AI Project
 * 
 * This script analyzes the frontend codebase for common accessibility issues
 * and provides recommendations for WCAG 2.1 AA compliance.
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Configuration
const config = {
  rootDir: path.resolve(process.cwd(), 'frontend/src'),
  extensions: ['.tsx', '.jsx', '.js', '.ts'],
  outputFile: path.resolve(process.cwd(), 'accessibility-audit-results.md'),
  ignorePatterns: ['node_modules', '__tests__', '*.test.*', '*.spec.*'],
};

// Accessibility issues to check for
const accessibilityChecks = [
  {
    name: 'Missing alt attributes on images',
    pattern: /<img(?![^>]*alt=["'][^"']*["'])[^>]*>/g,
    severity: 'High',
    wcag: '1.1.1 Non-text Content',
    recommendation: 'Add descriptive alt attributes to all images. Use empty alt="" for decorative images.',
  },
  {
    name: 'Missing form input labels',
    pattern: /<input(?![^>]*aria-label=["'][^"']*["'])(?![^>]*aria-labelledby=["'][^"']*["'])[^>]*>/g,
    severity: 'High',
    wcag: '3.3.2 Labels or Instructions',
    recommendation: 'Ensure all form inputs have associated labels using htmlFor and id attributes, or aria-label/aria-labelledby.',
  },
  {
    name: 'Missing button text',
    pattern: /<button[^>]*>(\s*|<svg[^>]*>.*<\/svg>\s*)<\/button>/g,
    severity: 'High',
    wcag: '4.1.2 Name, Role, Value',
    recommendation: 'Add text content to buttons or use aria-label for icon-only buttons.',
  },
  {
    name: 'Color contrast issues (potential)',
    pattern: /(text-|bg-)(gray|red|blue|green|yellow|purple|pink|indigo|teal|orange|amber|emerald|cyan|violet|fuchsia|rose|lime)-[1-4]00/g,
    severity: 'Medium',
    wcag: '1.4.3 Contrast (Minimum)',
    recommendation: 'Ensure text has sufficient contrast with its background (4.5:1 for normal text, 3:1 for large text).',
  },
  {
    name: 'Missing heading structure',
    pattern: /<div[^>]*className=["'][^"']*(?:text-[23]xl|font-bold|font-semibold)[^"']*["'][^>]*>(?!.*<h[1-6])/g,
    severity: 'Medium',
    wcag: '1.3.1 Info and Relationships',
    recommendation: 'Use semantic heading elements (h1-h6) instead of styled divs for headings.',
  },
  {
    name: 'Missing focus indicators',
    pattern: /focus:(outline-none|ring-0)/g,
    severity: 'High',
    wcag: '2.4.7 Focus Visible',
    recommendation: 'Ensure all interactive elements have visible focus indicators.',
  },
  {
    name: 'Missing ARIA roles',
    pattern: /<(div|span)[^>]*(?:onClick|onKeyDown|onKeyPress|onKeyUp)[^>]*>/g,
    severity: 'Medium',
    wcag: '4.1.2 Name, Role, Value',
    recommendation: 'Add appropriate ARIA roles to interactive elements that don\'t have semantic HTML equivalents.',
  },
  {
    name: 'Potentially inaccessible modals',
    pattern: /modal|dialog|popup/gi,
    severity: 'Medium',
    wcag: '2.1.2 No Keyboard Trap',
    recommendation: 'Ensure modals can be navigated and closed using keyboard, and use aria-modal="true".',
  },
  {
    name: 'Missing language attribute',
    pattern: /<html(?![^>]*lang=["'][^"']*["'])[^>]*>/g,
    severity: 'Medium',
    wcag: '3.1.1 Language of Page',
    recommendation: 'Add lang attribute to the html element.',
  },
  {
    name: 'Potentially inaccessible custom select elements',
    pattern: /custom.*?select|dropdown/gi,
    severity: 'Medium',
    wcag: '4.1.2 Name, Role, Value',
    recommendation: 'Ensure custom select elements use appropriate ARIA attributes (role="listbox", etc.).',
  }
];

// Function to check if a file should be ignored
function shouldIgnoreFile(filePath) {
  return config.ignorePatterns.some(pattern => filePath.includes(pattern));
}

// Function to get all files with specified extensions
function getAllFiles(dir, extensions, fileList = []) {
  const files = fs.readdirSync(dir);
  
  files.forEach(file => {
    const filePath = path.join(dir, file);
    
    if (shouldIgnoreFile(filePath)) {
      return;
    }
    
    if (fs.statSync(filePath).isDirectory()) {
      getAllFiles(filePath, extensions, fileList);
    } else {
      const ext = path.extname(file);
      if (extensions.includes(ext)) {
        fileList.push(filePath);
      }
    }
  });
  
  return fileList;
}

// Function to check a file for accessibility issues
function checkFileForAccessibilityIssues(filePath) {
  const content = fs.readFileSync(filePath, 'utf8');
  const issues = [];
  
  accessibilityChecks.forEach(check => {
    const matches = content.match(check.pattern);
    if (matches && matches.length > 0) {
      issues.push({
        file: path.relative(config.rootDir, filePath),
        check: check.name,
        severity: check.severity,
        wcag: check.wcag,
        recommendation: check.recommendation,
        occurrences: matches.length,
      });
    }
  });
  
  return issues;
}

// Main function to run the audit
function runAccessibilityAudit() {
  console.log('Starting accessibility audit...');
  
  // Get all files to check
  const files = getAllFiles(config.rootDir, config.extensions);
  console.log(`Found ${files.length} files to check.`);
  
  // Check each file for accessibility issues
  let allIssues = [];
  files.forEach(file => {
    const issues = checkFileForAccessibilityIssues(file);
    allIssues = [...allIssues, ...issues];
  });
  
  // Group issues by type
  const issuesByType = {};
  allIssues.forEach(issue => {
    if (!issuesByType[issue.check]) {
      issuesByType[issue.check] = [];
    }
    issuesByType[issue.check].push(issue);
  });
  
  // Generate report
  let report = `# Accessibility Audit Report for Story AI Project\n\n`;
  report += `*Generated on ${new Date().toLocaleString()}*\n\n`;
  report += `## Summary\n\n`;
  report += `- Total files checked: ${files.length}\n`;
  report += `- Total issues found: ${allIssues.length}\n`;
  report += `- Issues by severity:\n`;
  
  const severityCounts = {
    High: allIssues.filter(i => i.severity === 'High').length,
    Medium: allIssues.filter(i => i.severity === 'Medium').length,
    Low: allIssues.filter(i => i.severity === 'Low').length,
  };
  
  Object.entries(severityCounts).forEach(([severity, count]) => {
    if (count > 0) {
      report += `  - ${severity}: ${count}\n`;
    }
  });
  
  report += `\n## Issues by Type\n\n`;
  
  Object.entries(issuesByType).forEach(([checkName, issues]) => {
    const firstIssue = issues[0];
    report += `### ${checkName}\n\n`;
    report += `- **Severity:** ${firstIssue.severity}\n`;
    report += `- **WCAG Criterion:** ${firstIssue.wcag}\n`;
    report += `- **Recommendation:** ${firstIssue.recommendation}\n`;
    report += `- **Occurrences:** ${issues.length}\n\n`;
    report += `#### Affected Files:\n\n`;
    
    const fileOccurrences = {};
    issues.forEach(issue => {
      if (!fileOccurrences[issue.file]) {
        fileOccurrences[issue.file] = 0;
      }
      fileOccurrences[issue.file] += issue.occurrences;
    });
    
    Object.entries(fileOccurrences)
      .sort((a, b) => b[1] - a[1])
      .forEach(([file, occurrences]) => {
        report += `- \`${file}\` (${occurrences} occurrences)\n`;
      });
    
    report += `\n`;
  });
  
  report += `## Next Steps\n\n`;
  report += `1. Address high severity issues first\n`;
  report += `2. Implement the recommendations for each issue type\n`;
  report += `3. Run automated accessibility testing tools like axe or Lighthouse\n`;
  report += `4. Conduct manual testing with keyboard navigation and screen readers\n`;
  report += `5. Create an accessibility statement for the application\n`;
  
  // Write report to file
  fs.writeFileSync(config.outputFile, report);
  console.log(`Accessibility audit complete. Report saved to ${config.outputFile}`);
}

// Run the audit
runAccessibilityAudit();