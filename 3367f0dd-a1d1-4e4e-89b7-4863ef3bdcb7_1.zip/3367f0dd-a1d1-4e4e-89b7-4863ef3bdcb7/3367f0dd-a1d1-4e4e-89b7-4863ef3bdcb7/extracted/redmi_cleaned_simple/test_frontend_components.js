/**
 * Frontend Components Testing Script
 * 
 * This script tests the React components for the Story AI application
 * using React Testing Library and Jest.
 */

import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { BrowserRouter } from 'react-router-dom';
import { AuthProvider } from './src/client/context/AuthContext';
import { CollaborationContext } from './src/client/context/CollaborationContext';

// Import components to test
import App from './src/client/App';
import CollaborativeEditor from './src/client/components/editor/CollaborativeEditor';
import CollaboratorsList from './src/client/components/editor/CollaboratorsList';
import EditorSidebar from './src/client/components/editor/EditorSidebar';
import EditorToolbar from './src/client/components/editor/EditorToolbar';
import EditorPage from './src/client/components/pages/EditorPage';
import HomePage from './src/client/components/pages/HomePage';
import StoryListPage from './src/client/components/pages/StoryListPage';

// Mock hooks
jest.mock('./src/client/hooks/useAuth', () => ({
  useAuth: () => ({
    currentUser: {
      id: 'test-user-id',
      name: 'Test User',
      email: 'test@example.com',
      profileColor: '#3B82F6'
    },
    isAuthenticated: true,
    login: jest.fn(),
    logout: jest.fn(),
    register: jest.fn()
  })
}));

jest.mock('./src/client/hooks/useStories', () => ({
  useStories: () => ({
    stories: [
      {
        _id: 'story-1',
        title: 'Test Story 1',
        description: 'This is test story 1',
        author: {
          _id: 'test-user-id',
          name: 'Test User'
        },
        updatedAt: new Date().toISOString(),
        collaborators: []
      },
      {
        _id: 'story-2',
        title: 'Test Story 2',
        description: 'This is test story 2',
        author: {
          _id: 'test-user-id',
          name: 'Test User'
        },
        updatedAt: new Date().toISOString(),
        collaborators: []
      }
    ],
    loading: false,
    error: null,
    fetchStories: jest.fn(),
    fetchStory: jest.fn(),
    createStory: jest.fn(),
    updateStory: jest.fn(),
    deleteStory: jest.fn()
  })
}));

jest.mock('./src/client/hooks/useCollaborators', () => ({
  useCollaborators: () => ({
    collaborators: [
      {
        _id: 'collab-1',
        user: {
          _id: 'user-2',
          name: 'Collaborator 1',
          profileColor: '#10B981'
        },
        role: 'editor',
        isActive: true
      },
      {
        _id: 'collab-2',
        user: {
          _id: 'user-3',
          name: 'Collaborator 2',
          profileColor: '#F59E0B'
        },
        role: 'viewer',
        isActive: false
      }
    ],
    loading: false,
    error: null,
    fetchCollaborators: jest.fn(),
    addCollaborator: jest.fn(),
    updateCollaborator: jest.fn(),
    removeCollaborator: jest.fn()
  })
}));

jest.mock('./src/client/hooks/useComments', () => ({
  useComments: () => ({
    comments: [
      {
        _id: 'comment-1',
        content: 'This is a test comment',
        author: {
          _id: 'user-2',
          name: 'Collaborator 1',
          profileColor: '#10B981'
        },
        position: { from: 10, to: 20 },
        createdAt: new Date().toISOString(),
        replies: []
      }
    ],
    loading: false,
    error: null,
    fetchComments: jest.fn(),
    addComment: jest.fn(),
    updateComment: jest.fn(),
    deleteComment: jest.fn(),
    addReply: jest.fn()
  })
}));

jest.mock('./src/client/hooks/useAISuggestions', () => ({
  useAISuggestions: () => ({
    suggestions: [
      {
        _id: 'suggestion-1',
        type: 'grammar',
        content: 'This is a test suggestion',
        position: { from: 30, to: 40 },
        originalText: 'Original text with error',
        suggestedText: 'Corrected text suggestion',
        explanation: 'This suggestion fixes a grammatical error',
        applied: false,
        dismissed: false
      }
    ],
    loading: false,
    error: null,
    fetchSuggestions: jest.fn(),
    generateSuggestion: jest.fn(),
    applySuggestion: jest.fn(),
    dismissSuggestion: jest.fn()
  })
}));

jest.mock('./src/client/hooks/useCollaborativeEditor', () => ({
  useCollaborativeEditor: () => ({
    editor: {
      commands: {
        focus: jest.fn(),
        insertContent: jest.fn(),
        setContent: jest.fn()
      },
      isActive: jest.fn().mockReturnValue(false)
    },
    status: 'connected',
    error: null,
    awareness: {
      getStates: jest.fn().mockReturnValue(new Map([
        ['user-1', { user: { name: 'Test User', color: '#3B82F6' }, cursor: { anchor: 0, head: 0 } }],
        ['user-2', { user: { name: 'Collaborator 1', color: '#10B981' }, cursor: { anchor: 10, head: 15 } }]
      ]))
    }
  })
}));

// Mock Tiptap editor
jest.mock('@tiptap/react', () => ({
  useEditor: () => ({
    commands: {
      focus: jest.fn(),
      insertContent: jest.fn(),
      setContent: jest.fn()
    },
    isActive: jest.fn().mockReturnValue(false)
  }),
  EditorContent: ({ editor }) => <div data-testid="editor-content">Editor Content</div>
}));

// Helper function to wrap components with providers
const renderWithProviders = (ui, { route = '/' } = {}) => {
  window.history.pushState({}, 'Test page', route);
  
  return render(
    <BrowserRouter>
      <AuthProvider>
        {ui}
      </AuthProvider>
    </BrowserRouter>
  );
};

// Test suite for HomePage component
describe('HomePage Component', () => {
  test('renders welcome message', () => {
    renderWithProviders(<HomePage />);
    
    expect(screen.getByText(/welcome to story ai/i)).toBeInTheDocument();
  });
  
  test('renders call-to-action buttons', () => {
    renderWithProviders(<HomePage />);
    
    expect(screen.getByText(/get started/i)).toBeInTheDocument();
    expect(screen.getByText(/learn more/i)).toBeInTheDocument();
  });
});

// Test suite for StoryListPage component
describe('StoryListPage Component', () => {
  test('renders story list', () => {
    renderWithProviders(<StoryListPage />);
    
    expect(screen.getByText('Test Story 1')).toBeInTheDocument();
    expect(screen.getByText('Test Story 2')).toBeInTheDocument();
  });
  
  test('renders create story button', () => {
    renderWithProviders(<StoryListPage />);
    
    expect(screen.getByText(/create new story/i)).toBeInTheDocument();
  });
});

// Test suite for CollaborativeEditor component
describe('CollaborativeEditor Component', () => {
  test('renders editor content', () => {
    render(<CollaborativeEditor storyId="story-1" />);
    
    expect(screen.getByTestId('editor-content')).toBeInTheDocument();
  });
  
  test('displays connection status', () => {
    render(<CollaborativeEditor storyId="story-1" />);
    
    expect(screen.getByText(/connected/i)).toBeInTheDocument();
  });
});

// Test suite for CollaboratorsList component
describe('CollaboratorsList Component', () => {
  test('renders list of collaborators', () => {
    render(<CollaboratorsList storyId="story-1" />);
    
    expect(screen.getByText('Collaborator 1')).toBeInTheDocument();
    expect(screen.getByText('Collaborator 2')).toBeInTheDocument();
  });
  
  test('displays collaborator roles', () => {
    render(<CollaboratorsList storyId="story-1" />);
    
    expect(screen.getByText('editor')).toBeInTheDocument();
    expect(screen.getByText('viewer')).toBeInTheDocument();
  });
  
  test('indicates active status', () => {
    render(<CollaboratorsList storyId="story-1" />);
    
    const activeIndicators = screen.getAllByTestId('active-status');
    expect(activeIndicators[0]).toHaveClass('active');
    expect(activeIndicators[1]).not.toHaveClass('active');
  });
});

// Test suite for EditorToolbar component
describe('EditorToolbar Component', () => {
  test('renders formatting buttons', () => {
    render(<EditorToolbar />);
    
    expect(screen.getByTitle('Bold')).toBeInTheDocument();
    expect(screen.getByTitle('Italic')).toBeInTheDocument();
    expect(screen.getByTitle('Heading')).toBeInTheDocument();
  });
  
  test('toggles format when button is clicked', () => {
    render(<EditorToolbar />);
    
    const boldButton = screen.getByTitle('Bold');
    fireEvent.click(boldButton);
    
    // In a real test, we would check if the editor command was called
    // but since we're using a mock, we just verify the button was clicked
    expect(boldButton).toHaveAttribute('aria-pressed', 'true');
  });
});

// Test suite for EditorSidebar component
describe('EditorSidebar Component', () => {
  test('renders sidebar tabs', () => {
    render(<EditorSidebar storyId="story-1" />);
    
    expect(screen.getByText('Collaborators')).toBeInTheDocument();
    expect(screen.getByText('Comments')).toBeInTheDocument();
    expect(screen.getByText('AI Suggestions')).toBeInTheDocument();
  });
  
  test('switches tabs when clicked', () => {
    render(<EditorSidebar storyId="story-1" />);
    
    // Default tab is Collaborators
    expect(screen.getByText('Collaborator 1')).toBeInTheDocument();
    
    // Click on Comments tab
    fireEvent.click(screen.getByText('Comments'));
    expect(screen.getByText('This is a test comment')).toBeInTheDocument();
    
    // Click on AI Suggestions tab
    fireEvent.click(screen.getByText('AI Suggestions'));
    expect(screen.getByText('This is a test suggestion')).toBeInTheDocument();
  });
});

// Test suite for EditorPage component
describe('EditorPage Component', () => {
  beforeEach(() => {
    // Mock useParams to return a story ID
    jest.spyOn(require('react-router-dom'), 'useParams').mockReturnValue({ id: 'story-1' });
  });
  
  test('renders editor components', () => {
    renderWithProviders(<EditorPage />);
    
    expect(screen.getByTestId('editor-content')).toBeInTheDocument();
    expect(screen.getByText('Collaborators')).toBeInTheDocument();
  });
  
  test('displays story title', async () => {
    renderWithProviders(<EditorPage />);
    
    // Wait for story to load
    await waitFor(() => {
      expect(screen.getByDisplayValue('Test Story 1')).toBeInTheDocument();
    });
  });
});

// Test suite for App component
describe('App Component', () => {
  test('renders navigation', () => {
    renderWithProviders(<App />);
    
    expect(screen.getByText('Story AI')).toBeInTheDocument();
    expect(screen.getByText('Dashboard')).toBeInTheDocument();
    expect(screen.getByText('My Stories')).toBeInTheDocument();
  });
  
  test('navigates to different pages', () => {
    renderWithProviders(<App />);
    
    // Click on My Stories link
    fireEvent.click(screen.getByText('My Stories'));
    expect(window.location.pathname).toBe('/stories');
    
    // Click on Dashboard link
    fireEvent.click(screen.getByText('Dashboard'));
    expect(window.location.pathname).toBe('/dashboard');
  });
});

// Test suite for responsive design
describe('Responsive Design', () => {
  test('adapts to mobile viewport', () => {
    // Mock window.innerWidth to simulate mobile viewport
    global.innerWidth = 480;
    global.dispatchEvent(new Event('resize'));
    
    renderWithProviders(<App />);
    
    // Check if mobile menu button is visible
    expect(screen.getByTestId('mobile-menu-button')).toBeInTheDocument();
  });
  
  test('adapts to desktop viewport', () => {
    // Mock window.innerWidth to simulate desktop viewport
    global.innerWidth = 1024;
    global.dispatchEvent(new Event('resize'));
    
    renderWithProviders(<App />);
    
    // Check if desktop navigation is visible
    expect(screen.getByTestId('desktop-nav')).toBeInTheDocument();
    expect(screen.queryByTestId('mobile-menu-button')).not.toBeInTheDocument();
  });
});

// Test suite for accessibility
describe('Accessibility', () => {
  test('has proper heading structure', () => {
    renderWithProviders(<HomePage />);
    
    const headings = screen.getAllByRole('heading');
    expect(headings.length).toBeGreaterThan(0);
    
    // Check if first heading is h1
    expect(headings[0].tagName).toBe('H1');
  });
  
  test('images have alt text', () => {
    renderWithProviders(<HomePage />);
    
    const images = screen.getAllByRole('img');
    images.forEach(img => {
      expect(img).toHaveAttribute('alt');
    });
  });
  
  test('interactive elements are keyboard accessible', () => {
    renderWithProviders(<HomePage />);
    
    const buttons = screen.getAllByRole('button');
    buttons.forEach(button => {
      expect(button).toHaveAttribute('tabIndex', '0');
    });
    
    const links = screen.getAllByRole('link');
    links.forEach(link => {
      expect(link).toHaveAttribute('href');
    });
  });
});