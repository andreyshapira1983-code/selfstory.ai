/**
 * Utility Functions Testing Script
 * 
 * This script tests the utility functions for the Story AI application
 * using Jest.
 */

// Import utility functions
const colorUtils = require('./src/client/utils/colorUtils');
const dateUtils = require('./src/client/utils/dateUtils');
const textUtils = require('./src/client/utils/textUtils');
const validationUtils = require('./src/client/utils/validationUtils');
const storageUtils = require('./src/client/utils/storageUtils');

// Mock localStorage and sessionStorage for testing
const localStorageMock = (() => {
  let store = {};
  return {
    getItem: jest.fn(key => store[key] || null),
    setItem: jest.fn((key, value) => {
      store[key] = value.toString();
    }),
    removeItem: jest.fn(key => {
      delete store[key];
    }),
    clear: jest.fn(() => {
      store = {};
    }),
    key: jest.fn(index => {
      return Object.keys(store)[index] || null;
    }),
    get length() {
      return Object.keys(store).length;
    }
  };
})();

Object.defineProperty(window, 'localStorage', { value: localStorageMock });
Object.defineProperty(window, 'sessionStorage', { value: localStorageMock });

// Test suite for colorUtils
describe('Color Utility Functions', () => {
  test('stringToColor generates consistent colors for the same string', () => {
    const color1 = colorUtils.stringToColor('test');
    const color2 = colorUtils.stringToColor('test');
    const color3 = colorUtils.stringToColor('different');
    
    expect(color1).toBe(color2);
    expect(color1).not.toBe(color3);
  });
  
  test('getLighterColor returns a lighter version of a color', () => {
    const originalColor = '#3B82F6';
    const lighterColor = colorUtils.getLighterColor(originalColor, 90);
    
    expect(lighterColor).toContain('hsl(');
    expect(lighterColor).toContain('90%');
  });
  
  test('isColorDark correctly identifies dark colors', () => {
    expect(colorUtils.isColorDark('#000000')).toBe(true);
    expect(colorUtils.isColorDark('#FFFFFF')).toBe(false);
    expect(colorUtils.isColorDark('#3B82F6')).toBe(false);
    expect(colorUtils.isColorDark('#1E3A8A')).toBe(true);
  });
  
  test('getContrastColor returns appropriate text color based on background', () => {
    expect(colorUtils.getContrastColor('#000000')).toBe('#FFFFFF');
    expect(colorUtils.getContrastColor('#FFFFFF')).toBe('#000000');
  });
  
  test('generateDistinctColors returns the requested number of colors', () => {
    const colors = colorUtils.generateDistinctColors(5);
    expect(colors.length).toBe(5);
    
    // Check that all colors are unique
    const uniqueColors = new Set(colors);
    expect(uniqueColors.size).toBe(5);
  });
});

// Test suite for dateUtils
describe('Date Utility Functions', () => {
  test('formatDate formats dates correctly', () => {
    const date = new Date('2025-01-15T12:00:00Z');
    const formatted = dateUtils.formatDate(date);
    
    expect(formatted).toMatch(/Jan 15, 2025/);
  });
  
  test('getRelativeTimeString returns appropriate relative time', () => {
    const now = new Date();
    
    // Just now
    const justNow = new Date(now.getTime() - 30 * 1000); // 30 seconds ago
    expect(dateUtils.getRelativeTimeString(justNow)).toBe('just now');
    
    // Minutes ago
    const minutesAgo = new Date(now.getTime() - 5 * 60 * 1000); // 5 minutes ago
    expect(dateUtils.getRelativeTimeString(minutesAgo)).toMatch(/minutes? ago/);
    
    // Hours ago
    const hoursAgo = new Date(now.getTime() - 3 * 60 * 60 * 1000); // 3 hours ago
    expect(dateUtils.getRelativeTimeString(hoursAgo)).toMatch(/hours? ago/);
    
    // Yesterday
    const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000); // 24 hours ago
    expect(dateUtils.getRelativeTimeString(yesterday)).toMatch(/yesterday|1 day ago/);
  });
  
  test('formatDateTime includes time in the formatted string', () => {
    const date = new Date('2025-01-15T14:30:00Z');
    const formatted = dateUtils.formatDateTime(date);
    
    expect(formatted).toMatch(/Jan 15, 2025/);
    expect(formatted).toMatch(/\d{1,2}:\d{2}/); // Contains time in format like 2:30
  });
  
  test('calculateTimeSpent returns correct time difference', () => {
    const start = new Date('2025-01-15T12:00:00Z');
    const end = new Date('2025-01-15T14:30:00Z');
    
    const timeSpent = dateUtils.calculateTimeSpent(start, end);
    expect(timeSpent).toBe('2 hours 30 minutes');
  });
});

// Test suite for textUtils
describe('Text Utility Functions', () => {
  test('truncateText shortens text and adds ellipsis', () => {
    const longText = 'This is a very long text that should be truncated because it exceeds the maximum length specified for the test.';
    const truncated = textUtils.truncateText(longText, 20);
    
    expect(truncated.length).toBeLessThan(longText.length);
    expect(truncated).toMatch(/\.\.\.$/); // Ends with ellipsis
  });
  
  test('countWords counts words correctly', () => {
    expect(textUtils.countWords('This is a test')).toBe(4);
    expect(textUtils.countWords('One-word')).toBe(1);
    expect(textUtils.countWords('   Spaces   around   words   ')).toBe(3);
  });
  
  test('estimateReadingTime calculates reading time based on word count', () => {
    // 200 words at 200 words per minute = 1 minute
    const text = Array(200).fill('word').join(' ');
    expect(textUtils.estimateReadingTime(text, 200)).toBe(1);
    
    // 400 words at 200 words per minute = 2 minutes
    const longerText = Array(400).fill('word').join(' ');
    expect(textUtils.estimateReadingTime(longerText, 200)).toBe(2);
  });
  
  test('generateSlug creates URL-friendly slugs', () => {
    expect(textUtils.generateSlug('This is a Test')).toBe('this-is-a-test');
    expect(textUtils.generateSlug('Special $#! Characters')).toBe('special-characters');
    expect(textUtils.generateSlug('Multiple   Spaces')).toBe('multiple-spaces');
  });
  
  test('capitalizeWords capitalizes first letter of each word', () => {
    expect(textUtils.capitalizeWords('hello world')).toBe('Hello World');
    expect(textUtils.capitalizeWords('ALREADY UPPERCASE')).toBe('Already Uppercase');
    expect(textUtils.capitalizeWords('miXeD cAsE')).toBe('Mixed Case');
  });
});

// Test suite for validationUtils
describe('Validation Utility Functions', () => {
  test('isValidEmail validates email addresses', () => {
    expect(validationUtils.isValidEmail('test@example.com')).toBe(true);
    expect(validationUtils.isValidEmail('invalid-email')).toBe(false);
    expect(validationUtils.isValidEmail('test@example')).toBe(false);
    expect(validationUtils.isValidEmail('')).toBe(false);
  });
  
  test('validatePassword checks password requirements', () => {
    // Valid password
    expect(validationUtils.validatePassword('Password123!')).toEqual({
      isValid: true,
      message: 'Password is valid'
    });
    
    // Too short
    expect(validationUtils.validatePassword('Pass1!')).toEqual({
      isValid: false,
      message: expect.stringContaining('at least 8 characters')
    });
    
    // No number
    expect(validationUtils.validatePassword('Password!')).toEqual({
      isValid: false,
      message: expect.stringContaining('at least one number')
    });
    
    // No uppercase
    expect(validationUtils.validatePassword('password123!')).toEqual({
      isValid: false,
      message: expect.stringContaining('at least one uppercase letter')
    });
    
    // No special character
    expect(validationUtils.validatePassword('Password123')).toEqual({
      isValid: false,
      message: expect.stringContaining('at least one special character')
    });
  });
  
  test('validateForm validates multiple fields against a schema', () => {
    const formData = {
      name: 'Test User',
      email: 'test@example.com',
      password: ''
    };
    
    const schema = {
      name: [validationUtils.required],
      email: [validationUtils.required, validationUtils.isValidEmail],
      password: [validationUtils.required]
    };
    
    const result = validationUtils.validateForm(formData, schema);
    
    expect(result.isValid).toBe(false);
    expect(result.errors).toHaveProperty('password');
  });
});

// Test suite for storageUtils
describe('Storage Utility Functions', () => {
  beforeEach(() => {
    // Clear mock storage before each test
    localStorageMock.clear();
  });
  
  test('saveToLocalStorage saves data with prefix', () => {
    const saved = storageUtils.saveToLocalStorage('testKey', { data: 'test' });
    
    expect(saved).toBe(true);
    expect(localStorageMock.setItem).toHaveBeenCalledWith(
      'story_ai_testKey',
      JSON.stringify({ data: 'test' })
    );
  });
  
  test('getFromLocalStorage retrieves saved data', () => {
    // Setup
    localStorageMock.setItem('story_ai_testKey', JSON.stringify({ data: 'test' }));
    
    // Test
    const data = storageUtils.getFromLocalStorage('testKey');
    
    expect(data).toEqual({ data: 'test' });
    expect(localStorageMock.getItem).toHaveBeenCalledWith('story_ai_testKey');
  });
  
  test('removeFromLocalStorage removes data', () => {
    // Setup
    localStorageMock.setItem('story_ai_testKey', JSON.stringify({ data: 'test' }));
    
    // Test
    const removed = storageUtils.removeFromLocalStorage('testKey');
    
    expect(removed).toBe(true);
    expect(localStorageMock.removeItem).toHaveBeenCalledWith('story_ai_testKey');
  });
  
  test('saveEditorDraft saves editor state with timestamp', () => {
    const storyId = 'story-123';
    const editorState = '<p>Test content</p>';
    
    const saved = storageUtils.saveEditorDraft(storyId, editorState);
    
    expect(saved).toBe(true);
    expect(localStorageMock.setItem).toHaveBeenCalledWith(
      expect.stringContaining(`story_ai_draft_${storyId}`),
      expect.stringContaining('timestamp')
    );
    
    // Verify the saved data contains both content and timestamp
    const savedCall = localStorageMock.setItem.mock.calls[0];
    const savedData = JSON.parse(savedCall[1]);
    
    expect(savedData).toHaveProperty('content', editorState);
    expect(savedData).toHaveProperty('timestamp');
  });
});