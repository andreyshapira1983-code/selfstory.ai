# StoryAI - AI-Powered Storytelling Platform

StoryAI is an interactive platform that helps users create compelling stories with the assistance of AI. The platform provides a guided onboarding experience, story templates, and AI-powered writing tools to make storytelling accessible and enjoyable for everyone.

## Features

### User Onboarding
- Step-by-step introduction to the platform
- Genre preference selection
- Template-based story creation
- Guided first story experience

### Story Templates
- Pre-filled story starters for different genres
- Customizable templates for various storytelling styles
- Template recommendations based on user preferences

### Story Controls
- Tone adjustment (formal, casual, poetic, etc.)
- Length control (short, medium, long)
- Point of view selection (first person, third person, etc.)
- Mood setting (happy, mysterious, tense, etc.)

### Genre & Tag System
- Comprehensive genre classification
- Thematic tagging system
- Tag suggestions based on story content and selected genres
- Multi-tag support with normalization

### AI Assistance
- "Continue Story" functionality
- "Improve Writing" feature
- Style adjustments (make darker, funnier, etc.)
- Length modifications (make longer, shorter)

### Story Management
- Story dashboard with previews
- Editing and version history
- Organization by genres and tags
- Word count and last modified tracking

## Technology Stack

- **Frontend**: React, TailwindCSS
- **UI Components**: Custom components with TailwindCSS styling
- **State Management**: React Context API
- **Build Tools**: Vite, PostCSS
- **Collaborative Editing**: TipTap, Yjs (planned)

## Getting Started

### Prerequisites

- Node.js 16.x or higher
- npm 7.x or higher

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/story-ai.git
   cd story-ai
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm run dev
   ```

4. Open your browser and navigate to `http://localhost:3000`

### Building for Production

```
npm run build
```

The built files will be in the `dist` directory.

## Project Structure

```
story-ai/
├── public/              # Static assets
├── src/
│   ├── client/
│   │   ├── components/  # React components
│   │   │   ├── editor/  # Story editor components
│   │   │   ├── genre-system/  # Genre and tag components
│   │   │   ├── onboarding/  # Onboarding flow components
│   │   │   ├── story-controls/  # Story parameter controls
│   │   │   └── templates/  # Template components
│   │   ├── styles/      # Global styles
│   │   └── index.jsx    # Entry point
│   └── server/          # Server-side code (future)
├── package.json         # Project dependencies
├── vite.config.js       # Vite configuration
├── tailwind.config.js   # Tailwind CSS configuration
└── README.md            # Project documentation
```

## Future Enhancements

- **Collaborative Editing**: Real-time collaboration with multiple users
- **AI Suggestions**: More advanced AI-powered writing suggestions
- **Community Features**: Sharing stories and receiving feedback
- **Analytics**: Story performance metrics and writing insights
- **Mobile App**: Native mobile experience for on-the-go writing

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- The React team for the amazing framework
- TailwindCSS for the utility-first CSS framework
- The open-source community for inspiration and tools