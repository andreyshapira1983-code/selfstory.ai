const fs = require('fs');
const path = require('path');

console.log('📝 Generating sample story...');

// Sample story data
const sampleStory = {
  id: 'story-sample',
  title: 'The Mysterious Artifact',
  content: `The old map trembled in Elian's hands as he stood at the edge of the Whispering Forest. According to the village elders, no one who had sought the Crystal of Alandria had ever returned. But if the legends were true, the Crystal could heal his sister from the wasting sickness.

"You don't have to do this alone," said Kira, his childhood friend who had insisted on accompanying him despite the dangers.

Elian traced the path marked on the parchment. "The map shows three trials we must overcome: the Forest of Illusions, the Chasm of Echoes, and the Guardian's Labyrinth."

A cool wind rustled through the ancient trees before them, carrying whispers that sounded almost like words. Elian took a deep breath, adjusted the sword at his hip, and took his first step into the forest.

The adventure that would change their world had begun.

As they ventured deeper into the forest, the canopy above grew thicker, filtering the sunlight into ethereal beams that danced across the forest floor. Strange flowers glowed with an inner light, illuminating their path when the sun's rays couldn't reach them.

"The Forest of Illusions," Kira whispered, her eyes wide as she watched a butterfly with wings like stained glass flit between the luminous blooms. "It's beautiful."

"And dangerous," Elian reminded her, pointing to a patch of mushrooms nearby. "Remember what the herbalist told us? Those are dreamshade caps. One breath of their spores and you'll be lost in hallucinations for days."

They carefully skirted the mushroom patch, but as they progressed, the forest seemed to shift around them. Paths that should have led north suddenly curved back on themselves. Trees they had passed appeared again, though they were certain they had been walking in a straight line.

"We're going in circles," Kira said, frustration edging her voice.

Elian consulted the map again, but the markings seemed to swim before his eyes, rearranging themselves like living things. "This is the first trial," he realized. "The forest itself is trying to confuse us."

As if in response to his words, a melodic laugh echoed through the trees, and a figure stepped out from behind a massive oak. It was a woman—or something that appeared to be a woman—with skin the color of birch bark and hair like autumn leaves.

"Few mortals recognize the forest's game so quickly," she said, her voice like wind through branches. "I am Sylphia, guardian of these woods. If you seek to pass through my domain, you must answer my riddle."

Elian and Kira exchanged glances. The map had mentioned nothing about a riddle.

"We accept your challenge," Elian said, hoping his voice sounded more confident than he felt.

Sylphia smiled, revealing teeth that seemed made of polished wood. "Very well. Answer this: I am always hungry, I must always be fed. The finger I touch will soon turn red. What am I?"

Kira furrowed her brow, thinking hard, while Elian mentally ran through possibilities. A monster? A poisonous plant? Then it hit him.

"Fire," he said. "The answer is fire."

Sylphia's smile widened. "Correct, mortal. You may pass through the Forest of Illusions. But beware—the Chasm of Echoes reveals truths many are not prepared to face."

With those words, she melted back into the tree, leaving behind only a shower of golden leaves that marked a clear path forward.

"How did you know?" Kira asked as they followed the trail of leaves.

Elian shrugged. "My father was a blacksmith. I grew up watching him tend the forge fire. 'Always hungry, always needing to be fed'—that was how he described it to me when I was young."

The path led them to the edge of a vast ravine that cut through the forest like a wound. Far below, mist swirled, obscuring the bottom. A narrow stone bridge arched across the chasm, worn smooth by the passage of time.

"The Chasm of Echoes," Elian murmured, consulting the map once more. "The second trial."

As they approached the bridge, the mist below began to stir, rising up in tendrils that reached for them like ghostly fingers. And with the mist came the whispers—echoes of voices that seemed to come from everywhere and nowhere at once.`,
  genres: ['fantasy', 'adventure'],
  tags: ['quest', 'magic', 'friendship', 'trials'],
  controls: {
    tone: 'neutral',
    length: 'medium',
    pov: 'third',
    mood: 'mysterious'
  },
  template: 'fantasy-quest',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString()
};

// Create a sample user
const sampleUser = {
  id: 'user-sample',
  name: 'Sample User',
  preferredGenres: ['fantasy', 'sci-fi', 'adventure'],
  createdAt: new Date().toISOString()
};

// Create data directory if it doesn't exist
const dataDir = path.join(__dirname, '../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Write sample story to file
fs.writeFileSync(
  path.join(dataDir, 'sample-story.json'),
  JSON.stringify(sampleStory, null, 2)
);

// Write sample user to file
fs.writeFileSync(
  path.join(dataDir, 'sample-user.json'),
  JSON.stringify(sampleUser, null, 2)
);

// Create a sample stories array
const sampleStories = [sampleStory];
fs.writeFileSync(
  path.join(dataDir, 'sample-stories.json'),
  JSON.stringify(sampleStories, null, 2)
);

console.log('✅ Sample story generated successfully');
console.log(`📁 Files created in ${dataDir}:`);
console.log('   - sample-story.json');
console.log('   - sample-user.json');
console.log('   - sample-stories.json');
console.log('\n🔍 You can use these files for testing and development');