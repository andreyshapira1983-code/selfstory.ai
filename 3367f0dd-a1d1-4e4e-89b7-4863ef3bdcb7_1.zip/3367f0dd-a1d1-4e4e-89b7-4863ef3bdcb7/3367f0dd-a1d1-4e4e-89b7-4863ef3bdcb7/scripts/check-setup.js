const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const http = require('http');

console.log('🔍 Checking StoryAI setup...');

// Check if Node.js version is compatible
const nodeVersion = process.version;
console.log(`Node.js version: ${nodeVersion}`);
const majorVersion = parseInt(nodeVersion.slice(1).split('.')[0], 10);

if (majorVersion < 16) {
  console.error('❌ Node.js version must be 16.x or higher');
  process.exit(1);
} else {
  console.log('✅ Node.js version is compatible');
}

// Check if npm is installed
try {
  const npmVersion = execSync('npm --version').toString().trim();
  console.log(`npm version: ${npmVersion}`);
  console.log('✅ npm is installed');
} catch (error) {
  console.error('❌ npm is not installed or not in PATH');
  process.exit(1);
}

// Check if required directories exist
const requiredDirs = [
  'public',
  'src/client',
  'src/server',
  'scripts'
];

console.log('\nChecking directory structure:');
let allDirsExist = true;
requiredDirs.forEach(dir => {
  const dirPath = path.join(__dirname, '..', dir);
  if (fs.existsSync(dirPath)) {
    console.log(`✅ ${dir} exists`);
  } else {
    console.error(`❌ ${dir} does not exist`);
    allDirsExist = false;
  }
});

if (!allDirsExist) {
  console.error('\n❌ Some required directories are missing');
  process.exit(1);
}

// Check if required files exist
const requiredFiles = [
  'package.json',
  'vite.config.js',
  'tailwind.config.js',
  'public/index.html',
  'src/client/index.jsx',
  'src/client/components/App.jsx'
];

console.log('\nChecking required files:');
let allFilesExist = true;
requiredFiles.forEach(file => {
  const filePath = path.join(__dirname, '..', file);
  if (fs.existsSync(filePath)) {
    console.log(`✅ ${file} exists`);
  } else {
    console.error(`❌ ${file} does not exist`);
    allFilesExist = false;
  }
});

if (!allFilesExist) {
  console.error('\n❌ Some required files are missing');
  process.exit(1);
}

// Check if dependencies are installed
console.log('\nChecking node_modules:');
const nodeModulesPath = path.join(__dirname, '..', 'node_modules');
if (fs.existsSync(nodeModulesPath)) {
  console.log('✅ Dependencies are installed');
} else {
  console.log('⚠️ Dependencies are not installed. Running npm install...');
  try {
    execSync('npm install', { stdio: 'inherit', cwd: path.join(__dirname, '..') });
    console.log('✅ Dependencies installed successfully');
  } catch (error) {
    console.error('❌ Failed to install dependencies');
    process.exit(1);
  }
}

// Check if port 3000 is available
console.log('\nChecking if port 3000 is available:');
const server = http.createServer();
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error('❌ Port 3000 is already in use');
    console.log('⚠️ You may need to use a different port or stop the process using port 3000');
  } else {
    console.error(`❌ Error checking port availability: ${e.message}`);
  }
});

server.on('listening', () => {
  console.log('✅ Port 3000 is available');
  server.close();
  
  console.log('\n🎉 All checks passed! Your StoryAI setup looks good.');
  console.log('\nYou can start the development server with:');
  console.log('npm run dev      # Start Vite development server');
  console.log('npm run dev:all  # Start both client and server');
});

server.listen(3000);