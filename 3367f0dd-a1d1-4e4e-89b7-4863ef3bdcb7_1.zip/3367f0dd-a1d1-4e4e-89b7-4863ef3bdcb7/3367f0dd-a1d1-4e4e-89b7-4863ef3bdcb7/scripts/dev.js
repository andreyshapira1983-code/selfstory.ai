const { spawn } = require('child_process');
const path = require('path');

// Start the Vite development server
const clientProcess = spawn('npm', ['run', 'dev'], {
  stdio: 'inherit',
  shell: true
});

// Start the Express server
const serverProcess = spawn('node', [path.join(__dirname, '../src/server/index.js')], {
  stdio: 'inherit',
  shell: true
});

// Handle process termination
const cleanup = () => {
  clientProcess.kill();
  serverProcess.kill();
};

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);
process.on('exit', cleanup);

console.log('Development servers started. Press Ctrl+C to stop.');