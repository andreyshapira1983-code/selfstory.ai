import React, { useState, useEffect, useRef } from 'react';

/**
 * GenreTagSystem - Component for managing genres and tags for stories
 * Provides genre selection, tag management, and suggestions
 */
const GenreTagSystem = ({ onChange, initialGenres = [], initialTags = [] }) => {
  const [selectedGenres, setSelectedGenres] = useState(initialGenres);
  const [tags, setTags] = useState(initialTags);
  const [tagInput, setTagInput] = useState('');
  const [tagSuggestions, setTagSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const tagInputRef = useRef(null);
  
  // Available genres with descriptions and icons
  const genres = [
    {
      id: 'fantasy',
      name: 'Fantasy',
      description: 'Magical worlds, mythical creatures, and epic adventures',
      icon: '🧙‍♂️',
      color: 'bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-100'
    },
    {
      id: 'sci-fi',
      name: 'Science Fiction',
      description: 'Futuristic technology, space exploration, and scientific concepts',
      icon: '🚀',
      color: 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-100'
    },
    {
      id: 'mystery',
      name: 'Mystery',
      description: 'Puzzling events, detective work, and suspenseful revelations',
      icon: '🔍',
      color: 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-100'
    },
    {
      id: 'romance',
      name: 'Romance',
      description: 'Love stories, relationships, and emotional connections',
      icon: '❤️',
      color: 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-100'
    },
    {
      id: 'horror',
      name: 'Horror',
      description: 'Fear-inducing tales, supernatural threats, and psychological terror',
      icon: '👻',
      color: 'bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-100'
    },
    {
      id: 'adventure',
      name: 'Adventure',
      description: 'Exciting journeys, exploration, and overcoming challenges',
      icon: '🗺️',
      color: 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-100'
    },
    {
      id: 'historical',
      name: 'Historical',
      description: 'Stories set in the past, often based on real events',
      icon: '📜',
      color: 'bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-100'
    },
    {
      id: 'cyberpunk',
      name: 'Cyberpunk',
      description: 'High-tech dystopias, hackers, and corporate control',
      icon: '🤖',
      color: 'bg-pink-100 dark:bg-pink-900 text-pink-800 dark:text-pink-100'
    },
    {
      id: 'folk',
      name: 'Folk & Fairy Tales',
      description: 'Traditional stories, moral lessons, and cultural heritage',
      icon: '🧚',
      color: 'bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-100'
    },
    {
      id: 'dystopian',
      name: 'Dystopian',
      description: 'Societies gone wrong, oppression, and resistance',
      icon: '🏙️',
      color: 'bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-100'
    },
    {
      id: 'humor',
      name: 'Humor',
      description: 'Comedic situations, witty dialogue, and lighthearted stories',
      icon: '😂',
      color: 'bg-lime-100 dark:bg-lime-900 text-lime-800 dark:text-lime-100'
    },
    {
      id: 'young-adult',
      name: 'Young Adult',
      description: 'Coming-of-age stories, teen protagonists, and identity themes',
      icon: '📚',
      color: 'bg-sky-100 dark:bg-sky-900 text-sky-800 dark:text-sky-100'
    }
  ];
  
  // Common tags for suggestion
  const commonTags = [
    // Themes
    'betrayal', 'redemption', 'coming-of-age', 'revenge', 'sacrifice', 'survival',
    'identity', 'transformation', 'power', 'justice', 'freedom', 'loyalty',
    
    // Elements
    'magic', 'technology', 'time-travel', 'artificial-intelligence', 'supernatural',
    'space', 'aliens', 'robots', 'dragons', 'vampires', 'zombies', 'ghosts',
    
    // Settings
    'urban', 'rural', 'medieval', 'futuristic', 'post-apocalyptic', 'dystopian',
    'utopian', 'alternate-history', 'parallel-universe', 'virtual-reality',
    
    // Character types
    'anti-hero', 'chosen-one', 'unlikely-hero', 'mentor', 'villain', 'ensemble-cast',
    
    // Plot elements
    'quest', 'heist', 'mystery', 'conspiracy', 'war', 'revolution', 'journey',
    'tournament', 'prophecy', 'forbidden-love', 'family-secret', 'hidden-identity'
  ];
  
  // Update parent component when genres or tags change
  useEffect(() => {
    if (onChange) {
      onChange({ genres: selectedGenres, tags });
    }
  }, [selectedGenres, tags, onChange]);
  
  // Handle genre selection
  const toggleGenre = (genreId) => {
    setSelectedGenres(prev => {
      if (prev.includes(genreId)) {
        return prev.filter(id => id !== genreId);
      } else {
        return [...prev, genreId];
      }
    });
  };
  
  // Handle tag input changes and show suggestions
  const handleTagInputChange = (e) => {
    const value = e.target.value;
    setTagInput(value);
    
    if (value.trim()) {
      // Filter suggestions based on input
      const filtered = commonTags
        .filter(tag => 
          tag.toLowerCase().includes(value.toLowerCase()) && 
          !tags.includes(tag)
        )
        .slice(0, 5); // Limit to 5 suggestions
      
      setTagSuggestions(filtered);
      setShowSuggestions(filtered.length > 0);
    } else {
      setTagSuggestions([]);
      setShowSuggestions(false);
    }
  };
  
  // Add a new tag
  const addTag = (tag) => {
    tag = tag.trim().toLowerCase().replace(/\s+/g, '-');
    
    if (tag && !tags.includes(tag)) {
      setTags(prev => [...prev, tag]);
      setTagInput('');
      setTagSuggestions([]);
      setShowSuggestions(false);
    }
  };
  
  // Remove a tag
  const removeTag = (tagToRemove) => {
    setTags(prev => prev.filter(tag => tag !== tagToRemove));
  };
  
  // Handle tag input key press (Enter to add tag)
  const handleTagInputKeyPress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTag(tagInput);
    }
  };
  
  // Handle clicking outside the suggestions dropdown to close it
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (tagInputRef.current && !tagInputRef.current.contains(event.target)) {
        setShowSuggestions(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  // Generate tag suggestions based on selected genres
  const getGenreBasedTagSuggestions = () => {
    const genreTagMap = {
      'fantasy': ['magic', 'dragons', 'quest', 'prophecy', 'magical-creatures'],
      'sci-fi': ['space', 'technology', 'aliens', 'artificial-intelligence', 'future'],
      'mystery': ['detective', 'crime', 'clues', 'investigation', 'suspense'],
      'romance': ['love', 'relationship', 'heartbreak', 'soulmates', 'wedding'],
      'horror': ['supernatural', 'fear', 'monster', 'survival', 'psychological'],
      'adventure': ['journey', 'exploration', 'danger', 'treasure', 'discovery'],
      'historical': ['period-drama', 'war', 'ancient', 'medieval', 'renaissance'],
      'cyberpunk': ['hacking', 'megacorporation', 'dystopian', 'virtual-reality', 'implants'],
      'folk': ['fairy-tale', 'legend', 'moral-lesson', 'traditional', 'magical'],
      'dystopian': ['oppression', 'rebellion', 'surveillance', 'post-apocalyptic', 'totalitarian'],
      'humor': ['comedy', 'satire', 'parody', 'funny', 'witty'],
      'young-adult': ['coming-of-age', 'teen', 'school', 'friendship', 'identity']
    };
    
    // Get tags for selected genres
    let suggestions = [];
    selectedGenres.forEach(genre => {
      if (genreTagMap[genre]) {
        suggestions = [...suggestions, ...genreTagMap[genre]];
      }
    });
    
    // Remove duplicates and already selected tags
    return [...new Set(suggestions)]
      .filter(tag => !tags.includes(tag))
      .slice(0, 8); // Limit to 8 suggestions
  };
  
  const genreBasedSuggestions = getGenreBasedTagSuggestions();

  return (
    <div className="genre-tag-system">
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-3">Genres</h3>
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
          Select the genres that best describe your story. You can select multiple genres.
        </p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {genres.map((genre) => (
            <div
              key={genre.id}
              className={`flex items-center p-3 rounded-lg cursor-pointer transition-all
                ${selectedGenres.includes(genre.id) 
                  ? `${genre.color} border-2 border-primary` 
                  : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:border-primary'
                }`}
              onClick={() => toggleGenre(genre.id)}
            >
              <span className="text-2xl mr-3">{genre.icon}</span>
              <div>
                <h4 className="font-medium">{genre.name}</h4>
                <p className="text-xs text-gray-600 dark:text-gray-300">{genre.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-3">Tags</h3>
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
          Add tags to help categorize and find your story. Tags can represent themes, elements, settings, or other attributes.
        </p>
        
        <div className="relative mb-4" ref={tagInputRef}>
          <div className="flex">
            <input
              type="text"
              className="input rounded-r-none flex-grow"
              placeholder="Add a tag..."
              value={tagInput}
              onChange={handleTagInputChange}
              onKeyPress={handleTagInputKeyPress}
              onFocus={() => {
                if (tagInput.trim() && tagSuggestions.length > 0) {
                  setShowSuggestions(true);
                }
              }}
            />
            <button
              className="btn bg-primary text-white rounded-l-none"
              onClick={() => addTag(tagInput)}
              disabled={!tagInput.trim()}
            >
              Add
            </button>
          </div>
          
          {/* Tag suggestions dropdown */}
          {showSuggestions && (
            <div className="absolute z-10 w-full bg-white dark:bg-gray-800 mt-1 rounded-md shadow-lg border border-gray-200 dark:border-gray-700 max-h-60 overflow-auto">
              {tagSuggestions.map((suggestion) => (
                <div
                  key={suggestion}
                  className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
                  onClick={() => {
                    addTag(suggestion);
                  }}
                >
                  {suggestion.replace(/-/g, ' ')}
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Current tags */}
        <div className="flex flex-wrap gap-2 mb-4">
          {tags.map((tag) => (
            <span
              key={tag}
              className="tag-badge bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100"
            >
              {tag.replace(/-/g, ' ')}
              <button
                className="ml-1 text-blue-600 dark:text-blue-300 hover:text-blue-800 dark:hover:text-blue-100"
                onClick={() => removeTag(tag)}
                aria-label={`Remove ${tag} tag`}
              >
                &times;
              </button>
            </span>
          ))}
          
          {tags.length === 0 && (
            <p className="text-sm text-gray-500 dark:text-gray-400 italic">
              No tags added yet. Tags help readers find your story.
            </p>
          )}
        </div>
        
        {/* Tag suggestions based on selected genres */}
        {selectedGenres.length > 0 && genreBasedSuggestions.length > 0 && (
          <div>
            <h4 className="text-sm font-medium mb-2">Suggested tags based on your genres:</h4>
            <div className="flex flex-wrap gap-2">
              {genreBasedSuggestions.map((suggestion) => (
                <button
                  key={suggestion}
                  className="px-3 py-1 text-xs rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600"
                  onClick={() => addTag(suggestion)}
                >
                  + {suggestion.replace(/-/g, ' ')}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
      
      <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
        <h4 className="font-medium mb-2 flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-blue-500" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
          </svg>
          Why are genres and tags important?
        </h4>
        <p className="text-sm text-gray-600 dark:text-gray-300">
          Genres help categorize your story and make it discoverable to readers interested in that type of content.
          Tags provide more specific details about themes, elements, and attributes of your story. Using relevant
          genres and tags increases the chances of your story being found by interested readers.
        </p>
      </div>
    </div>
  );
};

export default GenreTagSystem;