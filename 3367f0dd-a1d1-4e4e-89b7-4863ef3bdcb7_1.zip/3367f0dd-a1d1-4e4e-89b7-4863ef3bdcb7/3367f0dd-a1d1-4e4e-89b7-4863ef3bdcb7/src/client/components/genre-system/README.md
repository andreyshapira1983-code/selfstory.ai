# StoryAI Genre & Tag System

The Genre & Tag System allows users to categorize and find stories using a comprehensive taxonomy. This document explains the components, functionality, and usage of the genre and tag system.

## Components Overview

### GenreTagSystem.jsx
- Main component for managing genres and tags for stories
- Provides genre selection with visual cards
- Includes tag management with suggestions and auto-complete
- Generates tag recommendations based on selected genres

## Genre System

### Available Genres
- **Fantasy**: Magical worlds, mythical creatures, and epic adventures
- **Science Fiction**: Futuristic technology, space exploration, and scientific concepts
- **Mystery**: Puzzling events, detective work, and suspenseful revelations
- **Romance**: Love stories, relationships, and emotional connections
- **Horror**: Fear-inducing tales, supernatural threats, and psychological terror
- **Adventure**: Exciting journeys, exploration, and overcoming challenges
- **Historical**: Stories set in the past, often based on real events
- **Cyberpunk**: High-tech dystopias, hackers, and corporate control
- **Folk & Fairy Tales**: Traditional stories, moral lessons, and cultural heritage
- **Dystopian**: Societies gone wrong, oppression, and resistance
- **Humor**: Comedic situations, witty dialogue, and lighthearted stories
- **Young Adult**: Coming-of-age stories, teen protagonists, and identity themes

### Genre Features
- Visual cards with icons and descriptions
- Multi-selection support
- Color-coding for easy identification
- Responsive grid layout

## Tag System

### Tag Categories
- **Themes**: betrayal, redemption, coming-of-age, revenge, sacrifice, survival, etc.
- **Elements**: magic, technology, time-travel, artificial-intelligence, supernatural, etc.
- **Settings**: urban, rural, medieval, futuristic, post-apocalyptic, dystopian, etc.
- **Character Types**: anti-hero, chosen-one, unlikely-hero, mentor, villain, etc.
- **Plot Elements**: quest, heist, mystery, conspiracy, war, revolution, journey, etc.

### Tag Features
- Tag input with auto-complete suggestions
- Tag normalization (converting spaces to hyphens, lowercase)
- Duplicate prevention
- Easy tag removal
- Genre-based tag suggestions

## Data Structure

```javascript
{
  genres: string[],  // Array of genre IDs
  tags: string[]     // Array of normalized tag strings
}
```

## Features

### Genre Selection
- Visual selection of multiple genres
- Clear indication of selected genres
- Descriptions to help users understand each genre

### Tag Management
- Add tags with auto-complete suggestions
- Remove tags with one click
- Normalize tags for consistency
- Prevent duplicate tags

### Smart Suggestions
- Tag suggestions based on selected genres
- Common tags for quick selection
- Similar tag detection to prevent near-duplicates

## Usage

### In Story Creation
- The Genre & Tag System is used when creating or editing stories
- Selected genres and tags are saved with the story metadata

### In Story Discovery
- Genres and tags are used for filtering and searching stories
- Related stories can be found through shared genres and tags

### In Recommendations
- User preferences for genres influence story recommendations
- Tags help identify specific interests within genres

## Implementation Notes

- Genres use a fixed taxonomy defined in the application
- Tags are free-form but normalized for consistency
- The system supports both light and dark mode
- The component is fully responsive for all device sizes

## Future Enhancements

- Add sub-genres for more specific categorization
- Implement tag clustering for related concepts
- Add popularity indicators for trending tags
- Implement AI-assisted tagging based on story content
- Add localization support for genres and tags in multiple languages