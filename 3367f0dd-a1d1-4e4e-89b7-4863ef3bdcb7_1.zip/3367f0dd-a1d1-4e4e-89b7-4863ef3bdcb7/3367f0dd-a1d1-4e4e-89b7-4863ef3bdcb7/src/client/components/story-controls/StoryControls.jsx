import React, { useState } from 'react';

/**
 * StoryControls - Component for adjusting story parameters
 * Provides controls for tone, length, POV, and mood
 */
const StoryControls = ({ onChange, initialValues = {} }) => {
  const [controls, setControls] = useState({
    tone: initialValues.tone || 'neutral',
    length: initialValues.length || 'medium',
    pov: initialValues.pov || 'third',
    mood: initialValues.mood || 'neutral',
    ...initialValues
  });
  
  // Available options for each control
  const options = {
    tone: [
      { value: 'formal', label: 'Formal', description: 'Academic, professional, structured' },
      { value: 'neutral', label: 'Neutral', description: 'Balanced, standard, versatile' },
      { value: 'casual', label: 'Casual', description: 'Conversational, relaxed, friendly' },
      { value: 'poetic', label: 'Poetic', description: 'Lyrical, metaphorical, expressive' },
      { value: 'humorous', label: 'Humorous', description: 'Witty, playful, comedic' }
    ],
    length: [
      { value: 'very-short', label: 'Very Short', description: '100-300 words' },
      { value: 'short', label: 'Short', description: '300-1000 words' },
      { value: 'medium', label: 'Medium', description: '1000-3000 words' },
      { value: 'long', label: 'Long', description: '3000-7000 words' },
      { value: 'very-long', label: 'Very Long', description: '7000+ words' }
    ],
    pov: [
      { value: 'first', label: 'First Person', description: '"I" perspective, personal' },
      { value: 'second', label: 'Second Person', description: '"You" perspective, immersive' },
      { value: 'third', label: 'Third Person', description: '"He/She/They" perspective, observational' },
      { value: 'third-omniscient', label: 'Third Person Omniscient', description: 'All-knowing narrator' }
    ],
    mood: [
      { value: 'happy', label: 'Happy', description: 'Joyful, optimistic, uplifting' },
      { value: 'neutral', label: 'Neutral', description: 'Balanced emotional tone' },
      { value: 'mysterious', label: 'Mysterious', description: 'Enigmatic, intriguing, secretive' },
      { value: 'tense', label: 'Tense', description: 'Suspenseful, anxious, on-edge' },
      { value: 'melancholic', label: 'Melancholic', description: 'Sad, reflective, wistful' },
      { value: 'dark', label: 'Dark', description: 'Grim, foreboding, ominous' }
    ]
  };
  
  // Handle control changes
  const handleChange = (control, value) => {
    const updatedControls = { ...controls, [control]: value };
    setControls(updatedControls);
    
    if (onChange) {
      onChange(updatedControls);
    }
  };

  return (
    <div className="story-controls">
      <div className="bg-white dark:bg-gray-800 rounded-lg border p-6">
        <h3 className="text-lg font-semibold mb-4">Story Controls</h3>
        
        {/* Tone Control */}
        <div className="mb-6">
          <label className="block text-sm font-medium mb-2">Tone</label>
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
            {options.tone.map(option => (
              <button
                key={option.value}
                className={`p-2 rounded-md text-center text-sm transition-colors
                  ${controls.tone === option.value 
                    ? 'bg-primary text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600'
                  }`}
                onClick={() => handleChange('tone', option.value)}
                title={option.description}
              >
                {option.label}
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-1">
            {options.tone.find(o => o.value === controls.tone)?.description}
          </p>
        </div>
        
        {/* Length Control */}
        <div className="mb-6">
          <label className="block text-sm font-medium mb-2">Length</label>
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
            {options.length.map(option => (
              <button
                key={option.value}
                className={`p-2 rounded-md text-center text-sm transition-colors
                  ${controls.length === option.value 
                    ? 'bg-primary text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600'
                  }`}
                onClick={() => handleChange('length', option.value)}
                title={option.description}
              >
                {option.label}
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-1">
            {options.length.find(o => o.value === controls.length)?.description}
          </p>
        </div>
        
        {/* Point of View Control */}
        <div className="mb-6">
          <label className="block text-sm font-medium mb-2">Point of View</label>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
            {options.pov.map(option => (
              <button
                key={option.value}
                className={`p-2 rounded-md text-center text-sm transition-colors
                  ${controls.pov === option.value 
                    ? 'bg-primary text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600'
                  }`}
                onClick={() => handleChange('pov', option.value)}
                title={option.description}
              >
                {option.label}
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-1">
            {options.pov.find(o => o.value === controls.pov)?.description}
          </p>
        </div>
        
        {/* Mood Control */}
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">Mood</label>
          <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
            {options.mood.map(option => (
              <button
                key={option.value}
                className={`p-2 rounded-md text-center text-sm transition-colors
                  ${controls.mood === option.value 
                    ? 'bg-primary text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600'
                  }`}
                onClick={() => handleChange('mood', option.value)}
                title={option.description}
              >
                {option.label}
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-1">
            {options.mood.find(o => o.value === controls.mood)?.description}
          </p>
        </div>
        
        {/* Quick Adjustment Buttons */}
        <div className="mt-6 pt-4 border-t">
          <h4 className="text-sm font-medium mb-3">Quick Adjustments</h4>
          <div className="flex flex-wrap gap-2">
            <button className="btn btn-sm btn-outline">
              Make Longer
            </button>
            <button className="btn btn-sm btn-outline">
              Make Shorter
            </button>
            <button className="btn btn-sm btn-outline">
              More Descriptive
            </button>
            <button className="btn btn-sm btn-outline">
              More Dialogue
            </button>
            <button className="btn btn-sm btn-outline">
              More Action
            </button>
            <button className="btn btn-sm btn-outline">
              More Emotional
            </button>
          </div>
        </div>
        
        {/* Save as Preset Button */}
        <div className="mt-6 flex justify-end">
          <button className="btn btn-sm btn-secondary">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
            </svg>
            Save as Preset
          </button>
        </div>
      </div>
      
      {/* Control Presets */}
      <div className="mt-4">
        <h4 className="text-sm font-medium mb-2">Presets</h4>
        <div className="flex flex-wrap gap-2">
          <button 
            className="px-3 py-1 text-sm rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600"
            onClick={() => {
              const newControls = {
                tone: 'formal',
                length: 'medium',
                pov: 'third',
                mood: 'neutral'
              };
              setControls(newControls);
              if (onChange) onChange(newControls);
            }}
          >
            Academic
          </button>
          <button 
            className="px-3 py-1 text-sm rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600"
            onClick={() => {
              const newControls = {
                tone: 'casual',
                length: 'short',
                pov: 'first',
                mood: 'happy'
              };
              setControls(newControls);
              if (onChange) onChange(newControls);
            }}
          >
            Personal Blog
          </button>
          <button 
            className="px-3 py-1 text-sm rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600"
            onClick={() => {
              const newControls = {
                tone: 'poetic',
                length: 'medium',
                pov: 'third',
                mood: 'melancholic'
              };
              setControls(newControls);
              if (onChange) onChange(newControls);
            }}
          >
            Literary Fiction
          </button>
          <button 
            className="px-3 py-1 text-sm rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600"
            onClick={() => {
              const newControls = {
                tone: 'neutral',
                length: 'long',
                pov: 'third-omniscient',
                mood: 'mysterious'
              };
              setControls(newControls);
              if (onChange) onChange(newControls);
            }}
          >
            Mystery Novel
          </button>
          <button 
            className="px-3 py-1 text-sm rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600"
            onClick={() => {
              const newControls = {
                tone: 'humorous',
                length: 'short',
                pov: 'first',
                mood: 'happy'
              };
              setControls(newControls);
              if (onChange) onChange(newControls);
            }}
          >
            Comedy Sketch
          </button>
        </div>
      </div>
    </div>
  );
};

export default StoryControls;