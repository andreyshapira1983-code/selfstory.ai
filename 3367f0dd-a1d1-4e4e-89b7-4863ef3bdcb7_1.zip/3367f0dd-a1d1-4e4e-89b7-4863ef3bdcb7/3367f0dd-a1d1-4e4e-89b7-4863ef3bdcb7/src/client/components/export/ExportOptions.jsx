import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { exportToPDF, exportToEpub, exportToManuscript, generateCoverPage } from '../../utils/exportService';

/**
 * ExportOptions - Component for exporting stories in various formats
 * 
 * This component provides options for exporting stories as:
 * - PDF with customizable options
 * - ePub for e-readers
 * - Manuscript formats for submissions
 * - Print-ready formats
 * - Cover page generation
 */
const ExportOptions = ({ 
  content, 
  title, 
  author,
  onClose 
}) => {
  // Export format state
  const [exportFormat, setExportFormat] = useState('pdf');
  
  // PDF export options
  const [pdfOptions, setPdfOptions] = useState({
    pageSize: 'a4',
    font: 'helvetica',
    fontSize: 12,
    margins: { top: 25, right: 20, bottom: 25, left: 20 },
    includeHeader: true,
    includeFooter: true,
    headerText: '',
    footerText: ''
  });
  
  // ePub export options
  const [epubOptions, setEpubOptions] = useState({
    coverImage: '',
    chapters: [],
    metadata: {
      language: 'en',
      publisher: '',
      publicationDate: new Date().toISOString().split('T')[0]
    }
  });
  
  // Manuscript export options
  const [manuscriptOptions, setManuscriptOptions] = useState({
    format: 'standard',
    authorContact: '',
  });
  
  // Cover page options
  const [coverOptions, setCoverOptions] = useState({
    subtitle: '',
    template: 'modern',
    backgroundImage: '',
    backgroundColor: '#4f46e5',
    textColor: '#ffffff'
  });
  
  // Loading state
  const [isExporting, setIsExporting] = useState(false);
  const [exportStatus, setExportStatus] = useState('');
  
  // Handle PDF options change
  const handlePdfOptionChange = (option, value) => {
    setPdfOptions(prev => ({
      ...prev,
      [option]: value
    }));
  };
  
  // Handle PDF margin change
  const handlePdfMarginChange = (margin, value) => {
    setPdfOptions(prev => ({
      ...prev,
      margins: {
        ...prev.margins,
        [margin]: parseInt(value, 10) || 0
      }
    }));
  };
  
  // Handle ePub options change
  const handleEpubOptionChange = (option, value) => {
    setEpubOptions(prev => ({
      ...prev,
      [option]: value
    }));
  };
  
  // Handle ePub metadata change
  const handleEpubMetadataChange = (field, value) => {
    setEpubOptions(prev => ({
      ...prev,
      metadata: {
        ...prev.metadata,
        [field]: value
      }
    }));
  };
  
  // Handle manuscript options change
  const handleManuscriptOptionChange = (option, value) => {
    setManuscriptOptions(prev => ({
      ...prev,
      [option]: value
    }));
  };
  
  // Handle cover options change
  const handleCoverOptionChange = (option, value) => {
    setCoverOptions(prev => ({
      ...prev,
      [option]: value
    }));
  };
  
  // Handle export
  const handleExport = async () => {
    setIsExporting(true);
    setExportStatus('Preparing export...');
    
    try {
      switch (exportFormat) {
        case 'pdf':
          setExportStatus('Generating PDF...');
          await exportToPDF({
            content,
            title,
            author,
            filename: title.replace(/\s+/g, '_').toLowerCase(),
            ...pdfOptions
          });
          break;
          
        case 'epub':
          setExportStatus('Generating ePub...');
          await exportToEpub({
            content,
            title,
            author,
            filename: title.replace(/\s+/g, '_').toLowerCase(),
            ...epubOptions
          });
          break;
          
        case 'manuscript':
          setExportStatus('Generating manuscript...');
          await exportToManuscript({
            content,
            title,
            author,
            authorContact: manuscriptOptions.authorContact,
            filename: `${title.replace(/\s+/g, '_').toLowerCase()}_manuscript`,
            format: manuscriptOptions.format
          });
          break;
          
        case 'cover':
          setExportStatus('Generating cover...');
          await generateCoverPage({
            title,
            subtitle: coverOptions.subtitle,
            author,
            template: coverOptions.template,
            backgroundImage: coverOptions.backgroundImage,
            backgroundColor: coverOptions.backgroundColor,
            textColor: coverOptions.textColor
          });
          break;
          
        default:
          throw new Error(`Unsupported export format: ${exportFormat}`);
      }
      
      setExportStatus('Export completed successfully!');
    } catch (error) {
      console.error('Export failed:', error);
      setExportStatus(`Export failed: ${error.message}`);
    } finally {
      setTimeout(() => {
        setIsExporting(false);
      }, 2000);
    }
  };
  
  // Generate chapter options from content
  const generateChapters = () => {
    // Simple chapter detection based on headings
    const chapterRegex = /^#+\s+(.+)$/gm;
    const chapters = [];
    let match;
    
    while ((match = chapterRegex.exec(content)) !== null) {
      chapters.push({
        title: match[1],
        position: match.index
      });
    }
    
    setEpubOptions(prev => ({
      ...prev,
      chapters
    }));
  };
  
  return (
    <div className="export-options">
      <div className="export-options-overlay" onClick={onClose}></div>
      
      <div className="export-options-modal">
        <div className="export-options-header">
          <h2>Export Options</h2>
          <button className="close-btn" onClick={onClose}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </button>
        </div>
        
        <div className="export-options-content">
          <div className="export-format-selector">
            <label>Export Format</label>
            <div className="format-buttons">
              <button 
                className={`format-btn ${exportFormat === 'pdf' ? 'active' : ''}`}
                onClick={() => setExportFormat('pdf')}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                </svg>
                PDF
              </button>
              
              <button 
                className={`format-btn ${exportFormat === 'epub' ? 'active' : ''}`}
                onClick={() => setExportFormat('epub')}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M9 4.804A7.968 7.968 0 005.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 015.5 14c1.669 0 3.218.51 4.5 1.385A7.962 7.962 0 0114.5 14c1.255 0 2.443.29 3.5.804v-10A7.968 7.968 0 0014.5 4c-1.255 0-2.443.29-3.5.804V12a1 1 0 11-2 0V4.804z" />
                </svg>
                ePub
              </button>
              
              <button 
                className={`format-btn ${exportFormat === 'manuscript' ? 'active' : ''}`}
                onClick={() => setExportFormat('manuscript')}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" clipRule="evenodd" />
                </svg>
                Manuscript
              </button>
              
              <button 
                className={`format-btn ${exportFormat === 'cover' ? 'active' : ''}`}
                onClick={() => setExportFormat('cover')}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
                </svg>
                Cover Page
              </button>
            </div>
          </div>
          
          {/* PDF Options */}
          {exportFormat === 'pdf' && (
            <div className="format-options pdf-options">
              <h3>PDF Options</h3>
              
              <div className="option-group">
                <label>Page Size</label>
                <select 
                  value={pdfOptions.pageSize}
                  onChange={(e) => handlePdfOptionChange('pageSize', e.target.value)}
                >
                  <option value="a4">A4</option>
                  <option value="letter">Letter</option>
                  <option value="legal">Legal</option>
                </select>
              </div>
              
              <div className="option-group">
                <label>Font</label>
                <select 
                  value={pdfOptions.font}
                  onChange={(e) => handlePdfOptionChange('font', e.target.value)}
                >
                  <option value="helvetica">Helvetica</option>
                  <option value="times">Times</option>
                  <option value="courier">Courier</option>
                </select>
              </div>
              
              <div className="option-group">
                <label>Font Size (pt)</label>
                <input 
                  type="number" 
                  min="8" 
                  max="24" 
                  value={pdfOptions.fontSize}
                  onChange={(e) => handlePdfOptionChange('fontSize', parseInt(e.target.value, 10))}
                />
              </div>
              
              <div className="option-group margins">
                <label>Margins (mm)</label>
                <div className="margin-inputs">
                  <div className="margin-input">
                    <label>Top</label>
                    <input 
                      type="number" 
                      min="0" 
                      max="100" 
                      value={pdfOptions.margins.top}
                      onChange={(e) => handlePdfMarginChange('top', e.target.value)}
                    />
                  </div>
                  <div className="margin-input">
                    <label>Right</label>
                    <input 
                      type="number" 
                      min="0" 
                      max="100" 
                      value={pdfOptions.margins.right}
                      onChange={(e) => handlePdfMarginChange('right', e.target.value)}
                    />
                  </div>
                  <div className="margin-input">
                    <label>Bottom</label>
                    <input 
                      type="number" 
                      min="0" 
                      max="100" 
                      value={pdfOptions.margins.bottom}
                      onChange={(e) => handlePdfMarginChange('bottom', e.target.value)}
                    />
                  </div>
                  <div className="margin-input">
                    <label>Left</label>
                    <input 
                      type="number" 
                      min="0" 
                      max="100" 
                      value={pdfOptions.margins.left}
                      onChange={(e) => handlePdfMarginChange('left', e.target.value)}
                    />
                  </div>
                </div>
              </div>
              
              <div className="option-group checkbox">
                <label>
                  <input 
                    type="checkbox" 
                    checked={pdfOptions.includeHeader}
                    onChange={(e) => handlePdfOptionChange('includeHeader', e.target.checked)}
                  />
                  Include Header
                </label>
              </div>
              
              {pdfOptions.includeHeader && (
                <div className="option-group">
                  <label>Header Text (leave empty for title)</label>
                  <input 
                    type="text" 
                    value={pdfOptions.headerText}
                    onChange={(e) => handlePdfOptionChange('headerText', e.target.value)}
                    placeholder={title}
                  />
                </div>
              )}
              
              <div className="option-group checkbox">
                <label>
                  <input 
                    type="checkbox" 
                    checked={pdfOptions.includeFooter}
                    onChange={(e) => handlePdfOptionChange('includeFooter', e.target.checked)}
                  />
                  Include Footer
                </label>
              </div>
              
              {pdfOptions.includeFooter && (
                <div className="option-group">
                  <label>Footer Text (leave empty for page numbers)</label>
                  <input 
                    type="text" 
                    value={pdfOptions.footerText}
                    onChange={(e) => handlePdfOptionChange('footerText', e.target.value)}
                    placeholder="Page {page} of {pages}"
                  />
                </div>
              )}
            </div>
          )}
          
          {/* ePub Options */}
          {exportFormat === 'epub' && (
            <div className="format-options epub-options">
              <h3>ePub Options</h3>
              
              <div className="option-group">
                <label>Cover Image URL</label>
                <input 
                  type="text" 
                  value={epubOptions.coverImage}
                  onChange={(e) => handleEpubOptionChange('coverImage', e.target.value)}
                  placeholder="https://example.com/cover.jpg"
                />
              </div>
              
              <div className="option-group">
                <label>Chapters</label>
                <div className="chapters-control">
                  <button 
                    className="btn btn-sm btn-outline"
                    onClick={generateChapters}
                  >
                    Auto-detect Chapters
                  </button>
                  <span className="chapter-count">
                    {epubOptions.chapters.length} chapters detected
                  </span>
                </div>
                {epubOptions.chapters.length > 0 && (
                  <div className="chapters-list">
                    {epubOptions.chapters.map((chapter, index) => (
                      <div key={index} className="chapter-item">
                        {chapter.title}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              <div className="option-group">
                <label>Language</label>
                <select 
                  value={epubOptions.metadata.language}
                  onChange={(e) => handleEpubMetadataChange('language', e.target.value)}
                >
                  <option value="en">English</option>
                  <option value="es">Spanish</option>
                  <option value="fr">French</option>
                  <option value="de">German</option>
                  <option value="it">Italian</option>
                  <option value="ja">Japanese</option>
                  <option value="zh">Chinese</option>
                </select>
              </div>
              
              <div className="option-group">
                <label>Publisher</label>
                <input 
                  type="text" 
                  value={epubOptions.metadata.publisher}
                  onChange={(e) => handleEpubMetadataChange('publisher', e.target.value)}
                  placeholder="Publisher name"
                />
              </div>
              
              <div className="option-group">
                <label>Publication Date</label>
                <input 
                  type="date" 
                  value={epubOptions.metadata.publicationDate}
                  onChange={(e) => handleEpubMetadataChange('publicationDate', e.target.value)}
                />
              </div>
            </div>
          )}
          
          {/* Manuscript Options */}
          {exportFormat === 'manuscript' && (
            <div className="format-options manuscript-options">
              <h3>Manuscript Options</h3>
              
              <div className="option-group">
                <label>Format</label>
                <select 
                  value={manuscriptOptions.format}
                  onChange={(e) => handleManuscriptOptionChange('format', e.target.value)}
                >
                  <option value="standard">Standard Manuscript</option>
                  <option value="agent">Agent Submission</option>
                  <option value="publisher">Publisher Submission</option>
                </select>
              </div>
              
              <div className="option-group">
                <label>Author Contact Information</label>
                <textarea 
                  value={manuscriptOptions.authorContact}
                  onChange={(e) => handleManuscriptOptionChange('authorContact', e.target.value)}
                  placeholder="Email, phone, address, etc."
                  rows="3"
                />
              </div>
              
              <div className="manuscript-preview">
                <h4>Format Preview</h4>
                <div className="preview-box">
                  {manuscriptOptions.format === 'standard' && (
                    <div className="preview-content">
                      <p>Standard manuscript format includes:</p>
                      <ul>
                        <li>Double-spaced text in Courier font</li>
                        <li>1-inch margins on all sides</li>
                        <li>Author information in the top left</li>
                        <li>Title centered and in all caps</li>
                        <li>Page numbers in the header</li>
                      </ul>
                    </div>
                  )}
                  
                  {manuscriptOptions.format === 'agent' && (
                    <div className="preview-content">
                      <p>Agent submission format includes:</p>
                      <ul>
                        <li>Double-spaced text in Courier font</li>
                        <li>1-inch margins on all sides</li>
                        <li>Author contact information in the top left</li>
                        <li>Word count in the top right</li>
                        <li>Title centered and in all caps</li>
                        <li>Page numbers in the footer</li>
                      </ul>
                    </div>
                  )}
                  
                  {manuscriptOptions.format === 'publisher' && (
                    <div className="preview-content">
                      <p>Publisher submission format includes:</p>
                      <ul>
                        <li>Double-spaced text in Courier font</li>
                        <li>1-inch margins on all sides</li>
                        <li>"SUBMISSION" header</li>
                        <li>Author contact information</li>
                        <li>Title and author name centered</li>
                        <li>Word count below title</li>
                        <li>Page numbers with title in the footer</li>
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
          
          {/* Cover Page Options */}
          {exportFormat === 'cover' && (
            <div className="format-options cover-options">
              <h3>Cover Page Options</h3>
              
              <div className="option-group">
                <label>Subtitle</label>
                <input 
                  type="text" 
                  value={coverOptions.subtitle}
                  onChange={(e) => handleCoverOptionChange('subtitle', e.target.value)}
                  placeholder="Optional subtitle"
                />
              </div>
              
              <div className="option-group">
                <label>Template</label>
                <select 
                  value={coverOptions.template}
                  onChange={(e) => handleCoverOptionChange('template', e.target.value)}
                >
                  <option value="modern">Modern</option>
                  <option value="classic">Classic</option>
                  <option value="minimal">Minimal</option>
                </select>
              </div>
              
              <div className="option-group">
                <label>Background Image URL</label>
                <input 
                  type="text" 
                  value={coverOptions.backgroundImage}
                  onChange={(e) => handleCoverOptionChange('backgroundImage', e.target.value)}
                  placeholder="https://example.com/background.jpg"
                />
              </div>
              
              <div className="option-group">
                <label>Background Color</label>
                <input 
                  type="color" 
                  value={coverOptions.backgroundColor}
                  onChange={(e) => handleCoverOptionChange('backgroundColor', e.target.value)}
                />
              </div>
              
              <div className="option-group">
                <label>Text Color</label>
                <input 
                  type="color" 
                  value={coverOptions.textColor}
                  onChange={(e) => handleCoverOptionChange('textColor', e.target.value)}
                />
              </div>
              
              <div className="cover-preview">
                <h4>Template Preview</h4>
                <div 
                  className="preview-box cover-preview-box"
                  style={{
                    backgroundColor: coverOptions.backgroundImage ? 'transparent' : coverOptions.backgroundColor,
                    backgroundImage: coverOptions.backgroundImage ? `url(${coverOptions.backgroundImage})` : 'none',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    color: coverOptions.textColor
                  }}
                >
                  {coverOptions.template === 'modern' && (
                    <div className="preview-content modern-preview">
                      <div className="title-area">
                        <h2>{title}</h2>
                        {coverOptions.subtitle && <h3>{coverOptions.subtitle}</h3>}
                        <p>{author}</p>
                      </div>
                    </div>
                  )}
                  
                  {coverOptions.template === 'classic' && (
                    <div className="preview-content classic-preview">
                      <div className="subtitle-area">
                        {coverOptions.subtitle && <h3>{coverOptions.subtitle}</h3>}
                      </div>
                      <div className="title-area">
                        <h2>{title}</h2>
                      </div>
                      <div className="author-area">
                        <p>{author}</p>
                      </div>
                    </div>
                  )}
                  
                  {coverOptions.template === 'minimal' && (
                    <div className="preview-content minimal-preview">
                      <h2>{title}</h2>
                      {coverOptions.subtitle && <h3>{coverOptions.subtitle}</h3>}
                      <p>{author}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="export-options-footer">
          {exportStatus && (
            <div className={`export-status ${isExporting ? 'exporting' : ''}`}>
              {exportStatus}
            </div>
          )}
          
          <div className="export-buttons">
            <button 
              className="btn btn-outline"
              onClick={onClose}
            >
              Cancel
            </button>
            <button 
              className="btn btn-primary"
              onClick={handleExport}
              disabled={isExporting}
            >
              {isExporting ? (
                <>
                  <svg className="animate-spin h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Exporting...
                </>
              ) : `Export as ${exportFormat.toUpperCase()}`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

ExportOptions.propTypes = {
  content: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  author: PropTypes.string,
  onClose: PropTypes.func.isRequired
};

export default ExportOptions;