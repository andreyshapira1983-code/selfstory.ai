import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

/**
 * WritingAnalytics - Advanced analytics for writing insights
 * 
 * This component provides detailed analytics on writing style, readability,
 * pacing, character development, and more.
 */
const WritingAnalytics = ({ content, title, onClose }) => {
  // Analytics state
  const [isAnalyzing, setIsAnalyzing] = useState(true);
  const [analytics, setAnalytics] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  
  // Analyze content on component mount
  useEffect(() => {
    analyzeContent();
  }, [content]);
  
  // Analyze content and generate insights
  const analyzeContent = () => {
    setIsAnalyzing(true);
    
    // In a real implementation, this would call an API to analyze the content
    // For now, we'll simulate the analysis with a delay
    setTimeout(() => {
      const wordCount = content.split(/\s+/).filter(Boolean).length;
      const paragraphCount = content.split(/\n\n+/).filter(Boolean).length;
      const sentenceCount = content.split(/[.!?]+/).filter(Boolean).length;
      const characterCount = content.length;
      
      // Calculate readability metrics
      const wordsPerSentence = wordCount / sentenceCount;
      const charactersPerWord = characterCount / wordCount;
      
      // Simple Flesch-Kincaid Grade Level calculation
      const fleschKincaidGrade = 0.39 * (wordsPerSentence) + 11.8 * (charactersPerWord) - 15.59;
      
      // Extract headings for structure analysis
      const headings = [];
      const headingRegex = /^(#+)\s+(.+)$/gm;
      let match;
      while ((match = headingRegex.exec(content)) !== null) {
        headings.push({
          level: match[1].length,
          text: match[2],
          position: match.index
        });
      }
      
      // Extract paragraphs for pacing analysis
      const paragraphs = content.split(/\n\n+/).filter(Boolean).map(p => ({
        text: p,
        length: p.length,
        wordCount: p.split(/\s+/).filter(Boolean).length
      }));
      
      // Calculate paragraph length distribution
      const paragraphLengths = paragraphs.map(p => p.wordCount);
      const shortParagraphs = paragraphLengths.filter(l => l < 30).length;
      const mediumParagraphs = paragraphLengths.filter(l => l >= 30 && l < 100).length;
      const longParagraphs = paragraphLengths.filter(l => l >= 100).length;
      
      // Extract dialogue for dialogue analysis
      const dialogueRegex = /["']([^"']+)["']/g;
      const dialogueMatches = [...content.matchAll(dialogueRegex)];
      const dialogueCount = dialogueMatches.length;
      const dialogueWords = dialogueMatches.reduce((sum, match) => sum + match[1].split(/\s+/).filter(Boolean).length, 0);
      const dialoguePercentage = (dialogueWords / wordCount) * 100;
      
      // Extract character names for character analysis
      // This is a simplified approach - in a real implementation, we would use NLP
      const potentialCharacters = new Map();
      const nameRegex = /\b[A-Z][a-z]+\b/g;
      const nameMatches = [...content.matchAll(nameRegex)];
      
      nameMatches.forEach(match => {
        const name = match[0];
        if (name.length > 1 && !['The', 'A', 'An', 'But', 'And', 'Or', 'If', 'Then', 'So', 'I'].includes(name)) {
          potentialCharacters.set(name, (potentialCharacters.get(name) || 0) + 1);
        }
      });
      
      // Filter to likely character names (mentioned multiple times)
      const characters = Array.from(potentialCharacters.entries())
        .filter(([_, count]) => count > 3)
        .sort((a, b) => b[1] - a[1])
        .map(([name, count]) => ({ name, mentions: count }));
      
      // Calculate vocabulary diversity
      const words = content.toLowerCase().match(/\b[a-z]+\b/g) || [];
      const uniqueWords = new Set(words);
      const vocabularyDiversity = (uniqueWords.size / words.length) * 100;
      
      // Generate analytics object
      const analyticsData = {
        overview: {
          wordCount,
          characterCount,
          paragraphCount,
          sentenceCount,
          readingTime: Math.ceil(wordCount / 200), // Assuming 200 words per minute
          vocabularyDiversity: vocabularyDiversity.toFixed(1)
        },
        readability: {
          wordsPerSentence: wordsPerSentence.toFixed(1),
          charactersPerWord: charactersPerWord.toFixed(1),
          fleschKincaidGrade: Math.max(0, Math.min(12, fleschKincaidGrade)).toFixed(1),
          readabilityScore: Math.max(0, 100 - (fleschKincaidGrade * 5)).toFixed(0),
          readabilityLevel: getReadabilityLevel(fleschKincaidGrade),
          suggestions: getReadabilitySuggestions(fleschKincaidGrade, wordsPerSentence)
        },
        structure: {
          headings,
          headingDistribution: getHeadingDistribution(headings),
          structureScore: calculateStructureScore(headings, paragraphCount),
          suggestions: getStructureSuggestions(headings, paragraphCount)
        },
        pacing: {
          paragraphLengthDistribution: {
            short: shortParagraphs,
            medium: mediumParagraphs,
            long: longParagraphs
          },
          pacingScore: calculatePacingScore(paragraphLengths),
          pacingVariation: calculatePacingVariation(paragraphLengths),
          suggestions: getPacingSuggestions(paragraphLengths)
        },
        dialogue: {
          dialogueCount,
          dialogueWords,
          dialoguePercentage: dialoguePercentage.toFixed(1),
          dialogueToNarrationRatio: (dialogueWords / (wordCount - dialogueWords)).toFixed(2),
          suggestions: getDialogueSuggestions(dialoguePercentage)
        },
        characters: {
          characterCount: characters.length,
          mainCharacters: characters.slice(0, 5),
          characterDistribution: characters.map(c => ({ name: c.name, percentage: ((c.mentions / wordCount) * 100).toFixed(1) })),
          suggestions: getCharacterSuggestions(characters)
        }
      };
      
      setAnalytics(analyticsData);
      setIsAnalyzing(false);
    }, 2000);
  };
  
  // Helper function to get readability level
  const getReadabilityLevel = (grade) => {
    if (grade < 6) return 'Easy';
    if (grade < 8) return 'Average';
    if (grade < 10) return 'Fairly Difficult';
    if (grade < 12) return 'Difficult';
    return 'Very Difficult';
  };
  
  // Helper function to get readability suggestions
  const getReadabilitySuggestions = (grade, wordsPerSentence) => {
    const suggestions = [];
    
    if (grade > 10) {
      suggestions.push('Consider simplifying some sentences to improve readability.');
      suggestions.push('Use shorter, more common words where appropriate.');
    }
    
    if (wordsPerSentence > 20) {
      suggestions.push('Try breaking some long sentences into shorter ones.');
    }
    
    if (suggestions.length === 0) {
      suggestions.push('Your text has good readability. Keep up the good work!');
    }
    
    return suggestions;
  };
  
  // Helper function to get heading distribution
  const getHeadingDistribution = (headings) => {
    const distribution = [0, 0, 0, 0, 0, 0];
    
    headings.forEach(heading => {
      if (heading.level <= 6) {
        distribution[heading.level - 1]++;
      }
    });
    
    return distribution;
  };
  
  // Helper function to calculate structure score
  const calculateStructureScore = (headings, paragraphCount) => {
    if (headings.length === 0) return 30;
    
    const headingRatio = headings.length / paragraphCount;
    const hasH1 = headings.some(h => h.level === 1);
    const hasH2 = headings.some(h => h.level === 2);
    const hasProperHierarchy = checkHeadingHierarchy(headings);
    
    let score = 50;
    
    if (hasH1) score += 10;
    if (hasH2) score += 10;
    if (hasProperHierarchy) score += 20;
    
    if (headingRatio > 0.05 && headingRatio < 0.3) score += 10;
    
    return Math.min(100, score);
  };
  
  // Helper function to check heading hierarchy
  const checkHeadingHierarchy = (headings) => {
    let currentLevel = 0;
    
    for (const heading of headings) {
      if (heading.level > currentLevel + 1) {
        return false;
      }
      currentLevel = heading.level;
    }
    
    return true;
  };
  
  // Helper function to get structure suggestions
  const getStructureSuggestions = (headings, paragraphCount) => {
    const suggestions = [];
    
    if (headings.length === 0) {
      suggestions.push('Consider adding headings to organize your content.');
      return suggestions;
    }
    
    if (!headings.some(h => h.level === 1)) {
      suggestions.push('Consider adding a main heading (H1) to your document.');
    }
    
    if (!headings.some(h => h.level === 2)) {
      suggestions.push('Consider adding subheadings (H2) to break up your content.');
    }
    
    if (!checkHeadingHierarchy(headings)) {
      suggestions.push('Ensure your heading hierarchy is sequential (don\'t skip levels).');
    }
    
    const headingRatio = headings.length / paragraphCount;
    if (headingRatio < 0.05) {
      suggestions.push('Consider adding more headings to better organize your content.');
    } else if (headingRatio > 0.3) {
      suggestions.push('You may have too many headings relative to your content.');
    }
    
    if (suggestions.length === 0) {
      suggestions.push('Your document has a good structure. Keep up the good work!');
    }
    
    return suggestions;
  };
  
  // Helper function to calculate pacing score
  const calculatePacingScore = (paragraphLengths) => {
    if (paragraphLengths.length < 3) return 50;
    
    const avgLength = paragraphLengths.reduce((sum, len) => sum + len, 0) / paragraphLengths.length;
    const variation = calculatePacingVariation(paragraphLengths);
    
    let score = 50;
    
    // Ideal average paragraph length is between 40-80 words
    if (avgLength >= 40 && avgLength <= 80) score += 25;
    else if (avgLength >= 30 && avgLength <= 100) score += 15;
    
    // Good variation is between 0.4 and 0.7
    if (variation >= 0.4 && variation <= 0.7) score += 25;
    else if (variation >= 0.3 && variation <= 0.8) score += 15;
    
    return Math.min(100, score);
  };
  
  // Helper function to calculate pacing variation
  const calculatePacingVariation = (paragraphLengths) => {
    if (paragraphLengths.length < 3) return 0;
    
    const avgLength = paragraphLengths.reduce((sum, len) => sum + len, 0) / paragraphLengths.length;
    const squaredDiffs = paragraphLengths.map(len => Math.pow(len - avgLength, 2));
    const variance = squaredDiffs.reduce((sum, diff) => sum + diff, 0) / paragraphLengths.length;
    const stdDev = Math.sqrt(variance);
    
    // Coefficient of variation (normalized standard deviation)
    return stdDev / avgLength;
  };
  
  // Helper function to get pacing suggestions
  const getPacingSuggestions = (paragraphLengths) => {
    const suggestions = [];
    
    if (paragraphLengths.length < 3) {
      suggestions.push('Add more paragraphs to create a better pacing analysis.');
      return suggestions;
    }
    
    const avgLength = paragraphLengths.reduce((sum, len) => sum + len, 0) / paragraphLengths.length;
    const variation = calculatePacingVariation(paragraphLengths);
    
    if (avgLength > 100) {
      suggestions.push('Consider breaking up some of your longer paragraphs for better readability.');
    } else if (avgLength < 30) {
      suggestions.push('Your paragraphs are quite short. Consider combining some related paragraphs.');
    }
    
    if (variation < 0.3) {
      suggestions.push('Your paragraph lengths are very uniform. Consider varying paragraph length for better rhythm.');
    } else if (variation > 0.8) {
      suggestions.push('Your paragraph lengths vary significantly. Consider more consistency in some sections.');
    }
    
    if (suggestions.length === 0) {
      suggestions.push('Your document has good pacing. Keep up the good work!');
    }
    
    return suggestions;
  };
  
  // Helper function to get dialogue suggestions
  const getDialogueSuggestions = (dialoguePercentage) => {
    const suggestions = [];
    
    if (dialoguePercentage < 10) {
      suggestions.push('Your story has relatively little dialogue. Consider adding more character interactions if appropriate.');
    } else if (dialoguePercentage > 50) {
      suggestions.push('Your story is dialogue-heavy. Consider balancing with more narrative and description.');
    }
    
    if (suggestions.length === 0) {
      suggestions.push('Your dialogue-to-narrative ratio seems well-balanced.');
    }
    
    return suggestions;
  };
  
  // Helper function to get character suggestions
  const getCharacterSuggestions = (characters) => {
    const suggestions = [];
    
    if (characters.length === 0) {
      suggestions.push('No clear character names detected. Consider introducing named characters if appropriate for your content.');
      return suggestions;
    }
    
    if (characters.length > 10) {
      suggestions.push('Your story has many characters. Consider whether all are necessary to the narrative.');
    }
    
    const mainCharacter = characters[0];
    const secondaryCharacters = characters.slice(1, 3);
    
    if (mainCharacter && secondaryCharacters.length > 0) {
      const mainToSecondaryRatio = mainCharacter.mentions / secondaryCharacters.reduce((sum, c) => sum + c.mentions, 0);
      
      if (mainToSecondaryRatio > 3) {
        suggestions.push('Your main character dominates the narrative. Consider developing secondary characters more.');
      } else if (mainToSecondaryRatio < 1.2 && characters.length > 2) {
        suggestions.push('Your main characters have similar prominence. Consider establishing a clearer protagonist.');
      }
    }
    
    if (suggestions.length === 0) {
      suggestions.push('Your character distribution seems well-balanced.');
    }
    
    return suggestions;
  };
  
  // Render loading state
  if (isAnalyzing) {
    return (
      <div className="writing-analytics">
        <div className="analytics-overlay" onClick={onClose}></div>
        <div className="analytics-modal">
          <div className="analytics-header">
            <h2>Analyzing Writing...</h2>
            <button className="close-btn" onClick={onClose}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
          <div className="analytics-loading">
            <div className="loading-spinner"></div>
            <p>Analyzing your writing for insights...</p>
          </div>
        </div>
      </div>
    );
  }
  
  // Render analytics
  return (
    <div className="writing-analytics">
      <div className="analytics-overlay" onClick={onClose}></div>
      <div className="analytics-modal">
        <div className="analytics-header">
          <h2>Writing Analytics</h2>
          <button className="close-btn" onClick={onClose}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </button>
        </div>
        
        <div className="analytics-tabs">
          <button 
            className={`tab-btn ${activeTab === 'overview' ? 'active' : ''}`}
            onClick={() => setActiveTab('overview')}
          >
            Overview
          </button>
          <button 
            className={`tab-btn ${activeTab === 'readability' ? 'active' : ''}`}
            onClick={() => setActiveTab('readability')}
          >
            Readability
          </button>
          <button 
            className={`tab-btn ${activeTab === 'structure' ? 'active' : ''}`}
            onClick={() => setActiveTab('structure')}
          >
            Structure
          </button>
          <button 
            className={`tab-btn ${activeTab === 'pacing' ? 'active' : ''}`}
            onClick={() => setActiveTab('pacing')}
          >
            Pacing
          </button>
          <button 
            className={`tab-btn ${activeTab === 'dialogue' ? 'active' : ''}`}
            onClick={() => setActiveTab('dialogue')}
          >
            Dialogue
          </button>
          <button 
            className={`tab-btn ${activeTab === 'characters' ? 'active' : ''}`}
            onClick={() => setActiveTab('characters')}
          >
            Characters
          </button>
        </div>
        
        <div className="analytics-content">
          {/* Overview Tab */}
          {activeTab === 'overview' && analytics && (
            <div className="overview-tab">
              <div className="analytics-title-section">
                <h3>{title || 'Untitled Document'}</h3>
                <div className="analytics-meta">
                  <span className="reading-time">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                    </svg>
                    {analytics.overview.readingTime} min read
                  </span>
                </div>
              </div>
              
              <div className="stats-grid">
                <div className="stat-card">
                  <div className="stat-value">{analytics.overview.wordCount.toLocaleString()}</div>
                  <div className="stat-label">Words</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value">{analytics.overview.characterCount.toLocaleString()}</div>
                  <div className="stat-label">Characters</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value">{analytics.overview.sentenceCount.toLocaleString()}</div>
                  <div className="stat-label">Sentences</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value">{analytics.overview.paragraphCount.toLocaleString()}</div>
                  <div className="stat-label">Paragraphs</div>
                </div>
              </div>
              
              <div className="scores-section">
                <h4>Writing Scores</h4>
                <div className="score-bars">
                  <div className="score-bar">
                    <div className="score-label">Readability</div>
                    <div className="score-track">
                      <div 
                        className="score-fill" 
                        style={{ width: `${analytics.readability.readabilityScore}%` }}
                      ></div>
                    </div>
                    <div className="score-value">{analytics.readability.readabilityScore}/100</div>
                  </div>
                  <div className="score-bar">
                    <div className="score-label">Structure</div>
                    <div className="score-track">
                      <div 
                        className="score-fill" 
                        style={{ width: `${analytics.structure.structureScore}%` }}
                      ></div>
                    </div>
                    <div className="score-value">{analytics.structure.structureScore}/100</div>
                  </div>
                  <div className="score-bar">
                    <div className="score-label">Pacing</div>
                    <div className="score-track">
                      <div 
                        className="score-fill" 
                        style={{ width: `${analytics.pacing.pacingScore}%` }}
                      ></div>
                    </div>
                    <div className="score-value">{analytics.pacing.pacingScore}/100</div>
                  </div>
                </div>
              </div>
              
              <div className="vocabulary-section">
                <h4>Vocabulary Diversity</h4>
                <div className="vocabulary-meter">
                  <div 
                    className="vocabulary-fill" 
                    style={{ width: `${Math.min(100, analytics.overview.vocabularyDiversity * 2)}%` }}
                  ></div>
                </div>
                <div className="vocabulary-value">{analytics.overview.vocabularyDiversity}%</div>
                <p className="vocabulary-description">
                  {analytics.overview.vocabularyDiversity < 30 ? (
                    'Your vocabulary diversity is low. Consider using a wider range of words.'
                  ) : analytics.overview.vocabularyDiversity < 45 ? (
                    'Your vocabulary diversity is average. You could benefit from incorporating more varied word choices.'
                  ) : (
                    'Your vocabulary diversity is excellent, showing a rich and varied use of language.'
                  )}
                </p>
              </div>
              
              <div className="key-insights">
                <h4>Key Insights</h4>
                <ul>
                  <li>Your document is approximately {analytics.overview.readingTime} minutes to read.</li>
                  <li>The readability level is {analytics.readability.readabilityLevel}.</li>
                  <li>You have {analytics.characters.characterCount} main characters in your story.</li>
                  <li>Dialogue makes up {analytics.dialogue.dialoguePercentage}% of your content.</li>
                </ul>
              </div>
            </div>
          )}
          
          {/* Readability Tab */}
          {activeTab === 'readability' && analytics && (
            <div className="readability-tab">
              <div className="readability-score-section">
                <div className="readability-meter">
                  <svg viewBox="0 0 120 120" className="readability-gauge">
                    <circle cx="60" cy="60" r="54" className="gauge-background" />
                    <circle 
                      cx="60" 
                      cy="60" 
                      r="54" 
                      className="gauge-value" 
                      style={{ 
                        strokeDasharray: `${analytics.readability.readabilityScore * 3.39} 339.292`,
                        stroke: getScoreColor(analytics.readability.readabilityScore)
                      }} 
                    />
                    <text x="60" y="60" className="gauge-text">
                      {analytics.readability.readabilityScore}
                    </text>
                    <text x="60" y="75" className="gauge-label">
                      Readability
                    </text>
                  </svg>
                </div>
                
                <div className="readability-details">
                  <div className="readability-level">
                    <h4>Reading Level</h4>
                    <p className="level-value">{analytics.readability.readabilityLevel}</p>
                    <p className="level-description">
                      Grade level: {analytics.readability.fleschKincaidGrade}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="readability-metrics">
                <div className="metric-card">
                  <div className="metric-value">{analytics.readability.wordsPerSentence}</div>
                  <div className="metric-label">Words per Sentence</div>
                  <div className="metric-description">
                    {parseFloat(analytics.readability.wordsPerSentence) > 20 ? (
                      'Your sentences are longer than average. Consider shortening some sentences.'
                    ) : parseFloat(analytics.readability.wordsPerSentence) < 10 ? (
                      'Your sentences are shorter than average. This can make your writing punchy but may lack complexity.'
                    ) : (
                      'Your sentence length is well-balanced.'
                    )}
                  </div>
                </div>
                
                <div className="metric-card">
                  <div className="metric-value">{analytics.readability.charactersPerWord}</div>
                  <div className="metric-label">Characters per Word</div>
                  <div className="metric-description">
                    {parseFloat(analytics.readability.charactersPerWord) > 5.5 ? (
                      'You use longer words than average. This can make your writing more complex.'
                    ) : parseFloat(analytics.readability.charactersPerWord) < 4.5 ? (
                      'You use shorter words than average. This can make your writing more accessible.'
                    ) : (
                      'Your word length is well-balanced.'
                    )}
                  </div>
                </div>
              </div>
              
              <div className="suggestions-section">
                <h4>Readability Suggestions</h4>
                <ul>
                  {analytics.readability.suggestions.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}
          
          {/* Structure Tab */}
          {activeTab === 'structure' && analytics && (
            <div className="structure-tab">
              <div className="structure-score-section">
                <div className="structure-meter">
                  <svg viewBox="0 0 120 120" className="structure-gauge">
                    <circle cx="60" cy="60" r="54" className="gauge-background" />
                    <circle 
                      cx="60" 
                      cy="60" 
                      r="54" 
                      className="gauge-value" 
                      style={{ 
                        strokeDasharray: `${analytics.structure.structureScore * 3.39} 339.292`,
                        stroke: getScoreColor(analytics.structure.structureScore)
                      }} 
                    />
                    <text x="60" y="60" className="gauge-text">
                      {analytics.structure.structureScore}
                    </text>
                    <text x="60" y="75" className="gauge-label">
                      Structure
                    </text>
                  </svg>
                </div>
                
                <div className="structure-details">
                  <h4>Document Structure</h4>
                  <p>
                    Your document has {analytics.structure.headings.length} headings 
                    across {analytics.overview.paragraphCount} paragraphs.
                  </p>
                </div>
              </div>
              
              <div className="heading-distribution">
                <h4>Heading Distribution</h4>
                <div className="heading-bars">
                  {analytics.structure.headingDistribution.map((count, index) => (
                    <div className="heading-bar" key={index}>
                      <div className="heading-label">H{index + 1}</div>
                      <div className="heading-track">
                        <div 
                          className="heading-fill" 
                          style={{ width: `${Math.min(100, count * 5)}%` }}
                        ></div>
                      </div>
                      <div className="heading-count">{count}</div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="structure-outline">
                <h4>Document Outline</h4>
                {analytics.structure.headings.length > 0 ? (
                  <div className="outline-list">
                    {analytics.structure.headings.map((heading, index) => (
                      <div 
                        className={`outline-item level-${heading.level}`} 
                        key={index}
                      >
                        {heading.text}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="no-headings">No headings detected in your document.</p>
                )}
              </div>
              
              <div className="suggestions-section">
                <h4>Structure Suggestions</h4>
                <ul>
                  {analytics.structure.suggestions.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}
          
          {/* Pacing Tab */}
          {activeTab === 'pacing' && analytics && (
            <div className="pacing-tab">
              <div className="pacing-score-section">
                <div className="pacing-meter">
                  <svg viewBox="0 0 120 120" className="pacing-gauge">
                    <circle cx="60" cy="60" r="54" className="gauge-background" />
                    <circle 
                      cx="60" 
                      cy="60" 
                      r="54" 
                      className="gauge-value" 
                      style={{ 
                        strokeDasharray: `${analytics.pacing.pacingScore * 3.39} 339.292`,
                        stroke: getScoreColor(analytics.pacing.pacingScore)
                      }} 
                    />
                    <text x="60" y="60" className="gauge-text">
                      {analytics.pacing.pacingScore}
                    </text>
                    <text x="60" y="75" className="gauge-label">
                      Pacing
                    </text>
                  </svg>
                </div>
                
                <div className="pacing-details">
                  <h4>Pacing Analysis</h4>
                  <p>
                    Variation coefficient: {(analytics.pacing.pacingVariation).toFixed(2)}
                    <br />
                    {analytics.pacing.pacingVariation < 0.3 ? (
                      'Your pacing is very consistent, which may feel monotonous.'
                    ) : analytics.pacing.pacingVariation > 0.8 ? (
                      'Your pacing varies significantly, which may feel erratic.'
                    ) : (
                      'Your pacing has good variation, creating a natural rhythm.'
                    )}
                  </p>
                </div>
              </div>
              
              <div className="paragraph-distribution">
                <h4>Paragraph Length Distribution</h4>
                <div className="distribution-chart">
                  <div className="chart-bar">
                    <div className="bar-label">Short<br/>(&lt;30 words)</div>
                    <div className="bar-track">
                      <div 
                        className="bar-fill short" 
                        style={{ 
                          height: `${Math.min(100, (analytics.pacing.paragraphLengthDistribution.short / analytics.overview.paragraphCount) * 100)}%` 
                        }}
                      ></div>
                    </div>
                    <div className="bar-value">{analytics.pacing.paragraphLengthDistribution.short}</div>
                  </div>
                  <div className="chart-bar">
                    <div className="bar-label">Medium<br/>(30-100 words)</div>
                    <div className="bar-track">
                      <div 
                        className="bar-fill medium" 
                        style={{ 
                          height: `${Math.min(100, (analytics.pacing.paragraphLengthDistribution.medium / analytics.overview.paragraphCount) * 100)}%` 
                        }}
                      ></div>
                    </div>
                    <div className="bar-value">{analytics.pacing.paragraphLengthDistribution.medium}</div>
                  </div>
                  <div className="chart-bar">
                    <div className="bar-label">Long<br/>(&gt;100 words)</div>
                    <div className="bar-track">
                      <div 
                        className="bar-fill long" 
                        style={{ 
                          height: `${Math.min(100, (analytics.pacing.paragraphLengthDistribution.long / analytics.overview.paragraphCount) * 100)}%` 
                        }}
                      ></div>
                    </div>
                    <div className="bar-value">{analytics.pacing.paragraphLengthDistribution.long}</div>
                  </div>
                </div>
              </div>
              
              <div className="pacing-tips">
                <h4>Pacing Tips</h4>
                <ul>
                  <li>Short paragraphs increase reading speed and create tension</li>
                  <li>Long paragraphs slow the pace and are good for description</li>
                  <li>Varying paragraph length creates natural rhythm</li>
                  <li>Action scenes benefit from shorter paragraphs</li>
                  <li>Descriptive scenes benefit from longer paragraphs</li>
                </ul>
              </div>
              
              <div className="suggestions-section">
                <h4>Pacing Suggestions</h4>
                <ul>
                  {analytics.pacing.suggestions.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}
          
          {/* Dialogue Tab */}
          {activeTab === 'dialogue' && analytics && (
            <div className="dialogue-tab">
              <div className="dialogue-distribution">
                <h4>Dialogue vs. Narrative</h4>
                <div className="distribution-pie">
                  <svg viewBox="0 0 100 100" className="pie-chart">
                    <circle cx="50" cy="50" r="50" fill="#e0e7ff" />
                    <circle cx="50" cy="50" r="25" fill="white" />
                    <path 
                      d={`M50,50 L50,0 A50,50 0 ${parseFloat(analytics.dialogue.dialoguePercentage) > 50 ? 1 : 0},1 ${50 + 50 * Math.sin(2 * Math.PI * parseFloat(analytics.dialogue.dialoguePercentage) / 100)},${50 - 50 * Math.cos(2 * Math.PI * parseFloat(analytics.dialogue.dialoguePercentage) / 100)} Z`}
                      fill="#4f46e5"
                    />
                    <text x="50" y="45" className="pie-percentage">
                      {analytics.dialogue.dialoguePercentage}%
                    </text>
                    <text x="50" y="60" className="pie-label">
                      Dialogue
                    </text>
                  </svg>
                </div>
                
                <div className="dialogue-stats">
                  <div className="stat-item">
                    <div className="stat-label">Dialogue Count</div>
                    <div className="stat-value">{analytics.dialogue.dialogueCount}</div>
                  </div>
                  <div className="stat-item">
                    <div className="stat-label">Dialogue Words</div>
                    <div className="stat-value">{analytics.dialogue.dialogueWords}</div>
                  </div>
                  <div className="stat-item">
                    <div className="stat-label">Dialogue:Narration Ratio</div>
                    <div className="stat-value">{analytics.dialogue.dialogueToNarrationRatio}:1</div>
                  </div>
                </div>
              </div>
              
              <div className="dialogue-tips">
                <h4>Dialogue Tips</h4>
                <ul>
                  <li>Dialogue should reveal character and advance the plot</li>
                  <li>Balance dialogue with narrative description</li>
                  <li>Use dialogue tags sparingly</li>
                  <li>Each character should have a distinct voice</li>
                  <li>Avoid exposition-heavy dialogue ("As you know, Bob...")</li>
                </ul>
              </div>
              
              <div className="suggestions-section">
                <h4>Dialogue Suggestions</h4>
                <ul>
                  {analytics.dialogue.suggestions.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}
          
          {/* Characters Tab */}
          {activeTab === 'characters' && analytics && (
            <div className="characters-tab">
              <div className="character-count-section">
                <h4>Character Analysis</h4>
                <p>
                  {analytics.characters.characterCount === 0 ? (
                    'No clear character names detected in your document.'
                  ) : (
                    `Detected ${analytics.characters.characterCount} potential characters in your document.`
                  )}
                </p>
              </div>
              
              {analytics.characters.mainCharacters.length > 0 && (
                <div className="character-distribution">
                  <h4>Main Characters</h4>
                  <div className="character-bars">
                    {analytics.characters.mainCharacters.map((character, index) => (
                      <div className="character-bar" key={index}>
                        <div className="character-name">{character.name}</div>
                        <div className="character-track">
                          <div 
                            className="character-fill" 
                            style={{ 
                              width: `${Math.min(100, (character.mentions / analytics.characters.mainCharacters[0].mentions) * 100)}%` 
                            }}
                          ></div>
                        </div>
                        <div className="character-mentions">{character.mentions}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="character-tips">
                <h4>Character Development Tips</h4>
                <ul>
                  <li>Give each character a distinct voice and personality</li>
                  <li>Ensure main characters have clear motivations and goals</li>
                  <li>Show character growth through actions and decisions</li>
                  <li>Balance character development across your main cast</li>
                  <li>Use secondary characters to highlight aspects of main characters</li>
                </ul>
              </div>
              
              <div className="suggestions-section">
                <h4>Character Suggestions</h4>
                <ul>
                  {analytics.characters.suggestions.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Helper function to get color based on score
const getScoreColor = (score) => {
  if (score >= 80) return '#10b981'; // green
  if (score >= 60) return '#6366f1'; // indigo
  if (score >= 40) return '#f59e0b'; // amber
  return '#ef4444'; // red
};

WritingAnalytics.propTypes = {
  content: PropTypes.string.isRequired,
  title: PropTypes.string,
  onClose: PropTypes.func.isRequired
};

export default WritingAnalytics;