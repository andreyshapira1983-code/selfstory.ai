import React, { useState } from 'react';

/**
 * AI Feedback Collector Component
 * 
 * Collects user feedback on AI-generated content to improve future generations
 * Includes rating system, specific feedback options, and comments
 */
const AIFeedbackCollector = ({ 
  contentId,
  contentType = 'story', // story, suggestion, enhancement, style
  onSubmitFeedback,
  onDismiss
}) => {
  const [rating, setRating] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Feedback options based on content type
  const feedbackOptions = {
    story: [
      { id: 'creative', label: 'Creative and original' },
      { id: 'coherent', label: 'Coherent and logical' },
      { id: 'engaging', label: 'Engaging and interesting' },
      { id: 'flat', label: 'Flat or generic' },
      { id: 'repetitive', label: 'Repetitive or redundant' },
      { id: 'inconsistent', label: 'Inconsistent or contradictory' },
      { id: 'offtopic', label: 'Off-topic or irrelevant' }
    ],
    suggestion: [
      { id: 'helpful', label: 'Helpful and relevant' },
      { id: 'creative', label: 'Creative and inspiring' },
      { id: 'contextual', label: 'Fits well with my content' },
      { id: 'irrelevant', label: 'Irrelevant to my needs' },
      { id: 'generic', label: 'Too generic or obvious' },
      { id: 'confusing', label: 'Confusing or unclear' }
    ],
    enhancement: [
      { id: 'improved', label: 'Significantly improved the text' },
      { id: 'preserved', label: 'Preserved my original voice' },
      { id: 'grammar', label: 'Fixed grammar and style issues' },
      { id: 'changed', label: 'Changed my meaning' },
      { id: 'awkward', label: 'Made the text awkward' },
      { id: 'minimal', label: 'Made minimal improvements' }
    ],
    style: [
      { id: 'authentic', label: 'Authentic to the selected style' },
      { id: 'readable', label: 'Readable and well-written' },
      { id: 'preserved', label: 'Preserved my original meaning' },
      { id: 'inauthentic', label: 'Doesn\'t match the selected style' },
      { id: 'awkward', label: 'Awkward or unnatural phrasing' },
      { id: 'changed', label: 'Changed my original meaning' }
    ]
  };
  
  // Handle option selection
  const handleOptionToggle = (optionId) => {
    setSelectedOptions(prev => {
      if (prev.includes(optionId)) {
        return prev.filter(id => id !== optionId);
      } else {
        return [...prev, optionId];
      }
    });
  };
  
  // Handle comment change
  const handleCommentChange = (e) => {
    setComment(e.target.value);
  };
  
  // Handle submit
  const handleSubmit = async () => {
    if (rating === 0) {
      alert('Please provide a rating before submitting feedback.');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Prepare feedback data
      const feedbackData = {
        contentId,
        contentType,
        rating,
        options: selectedOptions,
        comment: comment.trim(),
        timestamp: new Date().toISOString()
      };
      
      // Submit feedback
      if (onSubmitFeedback) {
        await onSubmitFeedback(feedbackData);
      }
      
      // Show success state
      setSubmitted(true);
      
      // Auto-dismiss after 3 seconds
      setTimeout(() => {
        if (onDismiss) {
          onDismiss();
        }
      }, 3000);
    } catch (error) {
      console.error('Failed to submit feedback:', error);
      alert('Failed to submit feedback. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Handle dismiss
  const handleDismiss = () => {
    if (onDismiss) {
      onDismiss();
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 border border-gray-200 dark:border-gray-700">
      {submitted ? (
        <div className="text-center py-4">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-green-500 mx-auto mb-2" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <h3 className="text-lg font-medium mb-1">Thank You!</h3>
          <p className="text-gray-500 dark:text-gray-400">Your feedback helps improve our AI.</p>
        </div>
      ) : (
        <>
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium">How was this AI-generated content?</h3>
            <button
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              onClick={handleDismiss}
              disabled={isSubmitting}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
          
          {/* Star rating */}
          <div className="mb-4">
            <div className="flex items-center justify-center">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  className={`p-1 focus:outline-none ${isSubmitting ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                  onClick={() => !isSubmitting && setRating(star)}
                  disabled={isSubmitting}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className={`h-8 w-8 ${
                      star <= rating ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'
                    }`}
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                </button>
              ))}
            </div>
            <div className="text-center text-sm text-gray-500 dark:text-gray-400 mt-1">
              {rating === 0 && 'Select a rating'}
              {rating === 1 && 'Poor'}
              {rating === 2 && 'Fair'}
              {rating === 3 && 'Good'}
              {rating === 4 && 'Very Good'}
              {rating === 5 && 'Excellent'}
            </div>
          </div>
          
          {/* Feedback options */}
          <div className="mb-4">
            <label className="block text-sm font-medium mb-2">What did you think? (Select all that apply)</label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {feedbackOptions[contentType].map((option) => (
                <div
                  key={option.id}
                  className={`p-2 rounded-md border cursor-pointer ${
                    selectedOptions.includes(option.id)
                      ? 'border-primary bg-primary bg-opacity-10'
                      : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                  } ${isSubmitting ? 'opacity-50 cursor-not-allowed' : ''}`}
                  onClick={() => !isSubmitting && handleOptionToggle(option.id)}
                >
                  <div className="flex items-center">
                    <div className={`w-4 h-4 rounded-full mr-2 flex items-center justify-center ${
                      selectedOptions.includes(option.id)
                        ? 'bg-primary'
                        : 'border border-gray-400 dark:border-gray-500'
                    }`}>
                      {selectedOptions.includes(option.id) && (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                    <span className="text-sm">{option.label}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Additional comments */}
          <div className="mb-4">
            <label className="block text-sm font-medium mb-2">Additional comments (optional)</label>
            <textarea
              className="input w-full"
              rows={3}
              value={comment}
              onChange={handleCommentChange}
              placeholder="Tell us more about your experience..."
              disabled={isSubmitting}
            />
          </div>
          
          {/* Submit button */}
          <div className="flex justify-end">
            <button
              className="btn btn-primary"
              onClick={handleSubmit}
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Submitting...
                </span>
              ) : 'Submit Feedback'}
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default AIFeedbackCollector;