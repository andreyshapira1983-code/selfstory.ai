import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

/**
 * CollaborativeBrainstorming - Tools for collaborative idea generation
 * 
 * This component provides collaborative brainstorming features including:
 * - Mind mapping
 * - Idea voting
 * - Collaborative notes
 */
const CollaborativeBrainstorming = ({
  documentId,
  collaborators,
  currentUser,
  onClose,
  initialIdeas = []
}) => {
  const [activeTab, setActiveTab] = useState('ideas');
  const [ideas, setIdeas] = useState(initialIdeas);
  const [newIdea, setNewIdea] = useState('');
  const [notes, setNotes] = useState('');
  const [mindMap, setMindMap] = useState({
    nodes: [
      { id: 'central', text: 'Main Story', x: 400, y: 300, type: 'central' }
    ],
    connections: []
  });
  const [selectedNode, setSelectedNode] = useState(null);
  const [newNodeText, setNewNodeText] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [draggedNode, setDraggedNode] = useState(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  
  // Simulate collaborative updates
  useEffect(() => {
    // In a real implementation, this would subscribe to WebSocket events
    // For now, we'll simulate occasional updates from collaborators
    
    const simulateCollaborativeUpdates = () => {
      // Only simulate updates occasionally
      if (Math.random() > 0.7 && collaborators.length > 1) {
        const randomCollaborator = collaborators.find(c => c.id !== currentUser?.id);
        
        if (randomCollaborator) {
          // Randomly choose which feature to update
          const updateType = Math.random();
          
          if (updateType < 0.33) {
            // Add a new idea
            const newIdea = {
              id: `idea-${Date.now()}`,
              text: `Idea from ${randomCollaborator.name}: ${['Character development', 'Plot twist', 'Setting detail', 'Dialogue improvement'][Math.floor(Math.random() * 4)]}`,
              author: randomCollaborator,
              votes: [],
              timestamp: new Date().toISOString()
            };
            
            setIdeas(prev => [...prev, newIdea]);
          } else if (updateType < 0.66) {
            // Vote on an existing idea
            if (ideas.length > 0) {
              const randomIdeaIndex = Math.floor(Math.random() * ideas.length);
              
              setIdeas(prev => prev.map((idea, index) => {
                if (index === randomIdeaIndex && !idea.votes.includes(randomCollaborator.id)) {
                  return {
                    ...idea,
                    votes: [...idea.votes, randomCollaborator.id]
                  };
                }
                return idea;
              }));
            }
          } else {
            // Add a node to mind map
            if (mindMap.nodes.length > 0) {
              const centralNode = mindMap.nodes.find(node => node.type === 'central');
              if (centralNode) {
                const angle = Math.random() * Math.PI * 2;
                const distance = 100 + Math.random() * 50;
                const newNode = {
                  id: `node-${Date.now()}`,
                  text: `${['Character', 'Setting', 'Plot Point', 'Theme'][Math.floor(Math.random() * 4)]} idea`,
                  x: centralNode.x + Math.cos(angle) * distance,
                  y: centralNode.y + Math.sin(angle) * distance,
                  type: 'idea',
                  author: randomCollaborator
                };
                
                const newConnection = {
                  id: `conn-${Date.now()}`,
                  from: centralNode.id,
                  to: newNode.id
                };
                
                setMindMap(prev => ({
                  nodes: [...prev.nodes, newNode],
                  connections: [...prev.connections, newConnection]
                }));
              }
            }
          }
        }
      }
    };
    
    // Simulate updates every 15 seconds
    const interval = setInterval(simulateCollaborativeUpdates, 15000);
    
    return () => clearInterval(interval);
  }, [collaborators, currentUser, ideas, mindMap]);
  
  // Handle adding a new idea
  const handleAddIdea = (e) => {
    e.preventDefault();
    
    if (!newIdea.trim()) return;
    
    const idea = {
      id: `idea-${Date.now()}`,
      text: newIdea,
      author: currentUser,
      votes: [],
      timestamp: new Date().toISOString()
    };
    
    setIdeas(prev => [...prev, idea]);
    setNewIdea('');
  };
  
  // Handle voting on an idea
  const handleVote = (ideaId) => {
    setIdeas(prev => prev.map(idea => {
      if (idea.id === ideaId) {
        // Toggle vote
        if (idea.votes.includes(currentUser.id)) {
          return {
            ...idea,
            votes: idea.votes.filter(id => id !== currentUser.id)
          };
        } else {
          return {
            ...idea,
            votes: [...idea.votes, currentUser.id]
          };
        }
      }
      return idea;
    }));
  };
  
  // Handle notes change
  const handleNotesChange = (e) => {
    setNotes(e.target.value);
    
    // In a real implementation, this would sync with other users
    // For now, we'll just log it
    console.log('Notes updated:', e.target.value);
  };
  
  // Handle adding a node to mind map
  const handleAddNode = () => {
    if (!newNodeText.trim() || !selectedNode) return;
    
    const parentNode = mindMap.nodes.find(node => node.id === selectedNode);
    if (!parentNode) return;
    
    // Calculate position for new node
    const angle = Math.random() * Math.PI * 2;
    const distance = 100;
    const newNode = {
      id: `node-${Date.now()}`,
      text: newNodeText,
      x: parentNode.x + Math.cos(angle) * distance,
      y: parentNode.y + Math.sin(angle) * distance,
      type: 'idea',
      author: currentUser
    };
    
    const newConnection = {
      id: `conn-${Date.now()}`,
      from: parentNode.id,
      to: newNode.id
    };
    
    setMindMap(prev => ({
      nodes: [...prev.nodes, newNode],
      connections: [...prev.connections, newConnection]
    }));
    
    setNewNodeText('');
  };
  
  // Handle node selection
  const handleNodeSelect = (nodeId) => {
    setSelectedNode(nodeId === selectedNode ? null : nodeId);
  };
  
  // Handle node drag start
  const handleNodeDragStart = (e, nodeId) => {
    const node = mindMap.nodes.find(n => n.id === nodeId);
    if (!node) return;
    
    const rect = e.target.getBoundingClientRect();
    const offsetX = e.clientX - rect.left;
    const offsetY = e.clientY - rect.top;
    
    setIsDragging(true);
    setDraggedNode(nodeId);
    setDragOffset({ x: offsetX, y: offsetY });
  };
  
  // Handle node drag
  const handleNodeDrag = (e) => {
    if (!isDragging || !draggedNode) return;
    
    const mindMapElement = document.getElementById('mind-map');
    if (!mindMapElement) return;
    
    const rect = mindMapElement.getBoundingClientRect();
    const x = e.clientX - rect.left - dragOffset.x;
    const y = e.clientY - rect.top - dragOffset.y;
    
    setMindMap(prev => ({
      ...prev,
      nodes: prev.nodes.map(node => 
        node.id === draggedNode ? { ...node, x, y } : node
      )
    }));
  };
  
  // Handle node drag end
  const handleNodeDragEnd = () => {
    setIsDragging(false);
    setDraggedNode(null);
  };
  
  // Format timestamp
  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  return (
    <div className="collaborative-brainstorming">
      <div className="brainstorming-header">
        <h2>Collaborative Brainstorming</h2>
        <button 
          className="close-btn"
          onClick={onClose}
          aria-label="Close brainstorming"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        </button>
      </div>
      
      <div className="brainstorming-tabs">
        <button 
          className={`tab-btn ${activeTab === 'ideas' ? 'active' : ''}`}
          onClick={() => setActiveTab('ideas')}
        >
          Ideas & Voting
        </button>
        <button 
          className={`tab-btn ${activeTab === 'mindmap' ? 'active' : ''}`}
          onClick={() => setActiveTab('mindmap')}
        >
          Mind Map
        </button>
        <button 
          className={`tab-btn ${activeTab === 'notes' ? 'active' : ''}`}
          onClick={() => setActiveTab('notes')}
        >
          Shared Notes
        </button>
      </div>
      
      <div className="brainstorming-content">
        {/* Ideas & Voting Tab */}
        {activeTab === 'ideas' && (
          <div className="ideas-tab">
            <div className="ideas-list">
              {ideas.length === 0 ? (
                <div className="no-ideas">
                  <p>No ideas yet. Be the first to add one!</p>
                </div>
              ) : (
                ideas.map(idea => (
                  <div key={idea.id} className="idea-card">
                    <div className="idea-content">
                      <div className="idea-text">{idea.text}</div>
                      <div className="idea-meta">
                        <span className="idea-author">
                          {idea.author.name === currentUser?.name ? 'You' : idea.author.name}
                        </span>
                        <span className="idea-time">{formatTime(idea.timestamp)}</span>
                      </div>
                    </div>
                    <div className="idea-votes">
                      <button 
                        className={`vote-btn ${idea.votes.includes(currentUser?.id) ? 'voted' : ''}`}
                        onClick={() => handleVote(idea.id)}
                        aria-label={idea.votes.includes(currentUser?.id) ? "Remove vote" : "Vote for this idea"}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z" />
                        </svg>
                        <span className="vote-count">{idea.votes.length}</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
            
            <form className="add-idea-form" onSubmit={handleAddIdea}>
              <input
                type="text"
                value={newIdea}
                onChange={(e) => setNewIdea(e.target.value)}
                placeholder="Add your idea..."
                aria-label="Add your idea"
              />
              <button 
                type="submit" 
                disabled={!newIdea.trim()}
                aria-label="Add idea"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                </svg>
              </button>
            </form>
          </div>
        )}
        
        {/* Mind Map Tab */}
        {activeTab === 'mindmap' && (
          <div className="mindmap-tab">
            <div 
              id="mind-map" 
              className="mind-map"
              onMouseMove={isDragging ? handleNodeDrag : undefined}
              onMouseUp={isDragging ? handleNodeDragEnd : undefined}
              onMouseLeave={isDragging ? handleNodeDragEnd : undefined}
            >
              {/* Draw connections first so they appear behind nodes */}
              <svg className="connections-layer">
                {mindMap.connections.map(connection => {
                  const fromNode = mindMap.nodes.find(n => n.id === connection.from);
                  const toNode = mindMap.nodes.find(n => n.id === connection.to);
                  
                  if (!fromNode || !toNode) return null;
                  
                  return (
                    <line
                      key={connection.id}
                      x1={fromNode.x}
                      y1={fromNode.y}
                      x2={toNode.x}
                      y2={toNode.y}
                      stroke="#6b7280"
                      strokeWidth="2"
                    />
                  );
                })}
              </svg>
              
              {/* Draw nodes */}
              {mindMap.nodes.map(node => (
                <div
                  key={node.id}
                  className={`mind-map-node ${node.type} ${selectedNode === node.id ? 'selected' : ''}`}
                  style={{
                    left: `${node.x}px`,
                    top: `${node.y}px`,
                    backgroundColor: node.author?.color,
                  }}
                  onClick={() => handleNodeSelect(node.id)}
                  onMouseDown={(e) => handleNodeDragStart(e, node.id)}
                >
                  <div className="node-content">
                    {node.text}
                  </div>
                  {node.author && node.author.id !== currentUser?.id && (
                    <div className="node-author" title={`Added by ${node.author.name}`}>
                      {node.author.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            <div className="mind-map-controls">
              <div className="add-node-form">
                <select 
                  value={selectedNode || ''}
                  onChange={(e) => setSelectedNode(e.target.value)}
                  disabled={mindMap.nodes.length === 0}
                >
                  <option value="">Select a node to connect to...</option>
                  {mindMap.nodes.map(node => (
                    <option key={node.id} value={node.id}>
                      {node.text}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  value={newNodeText}
                  onChange={(e) => setNewNodeText(e.target.value)}
                  placeholder="New node text..."
                  disabled={!selectedNode}
                />
                <button 
                  onClick={handleAddNode}
                  disabled={!selectedNode || !newNodeText.trim()}
                >
                  Add Node
                </button>
              </div>
              
              <div className="mind-map-legend">
                <div className="legend-item">
                  <div className="legend-color central"></div>
                  <span>Central Topic</span>
                </div>
                <div className="legend-item">
                  <div className="legend-color idea"></div>
                  <span>Ideas</span>
                </div>
                {collaborators.map(collaborator => (
                  <div key={collaborator.id} className="legend-item">
                    <div 
                      className="legend-color" 
                      style={{ backgroundColor: collaborator.color }}
                    ></div>
                    <span>{collaborator.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
        
        {/* Shared Notes Tab */}
        {activeTab === 'notes' && (
          <div className="notes-tab">
            <div className="notes-header">
              <h3>Collaborative Notes</h3>
              <p className="notes-info">
                All changes are saved automatically and visible to all collaborators.
              </p>
            </div>
            
            <div className="notes-editor">
              <textarea
                value={notes}
                onChange={handleNotesChange}
                placeholder="Start typing shared notes here..."
                aria-label="Shared notes"
              />
            </div>
            
            <div className="notes-footer">
              <div className="active-users">
                <span>Currently editing: </span>
                {collaborators.map(collaborator => (
                  <div 
                    key={collaborator.id} 
                    className="active-user-avatar"
                    style={{ backgroundColor: collaborator.color }}
                    title={collaborator.name}
                  >
                    {collaborator.avatar ? (
                      <img src={collaborator.avatar} alt={collaborator.name} />
                    ) : (
                      collaborator.name.charAt(0).toUpperCase()
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

CollaborativeBrainstorming.propTypes = {
  documentId: PropTypes.string.isRequired,
  collaborators: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      avatar: PropTypes.string,
      color: PropTypes.string,
    })
  ).isRequired,
  currentUser: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    avatar: PropTypes.string,
  }),
  onClose: PropTypes.func.isRequired,
  initialIdeas: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      text: PropTypes.string.isRequired,
      author: PropTypes.object.isRequired,
      votes: PropTypes.array.isRequired,
      timestamp: PropTypes.string.isRequired,
    })
  ),
};

export default CollaborativeBrainstorming;