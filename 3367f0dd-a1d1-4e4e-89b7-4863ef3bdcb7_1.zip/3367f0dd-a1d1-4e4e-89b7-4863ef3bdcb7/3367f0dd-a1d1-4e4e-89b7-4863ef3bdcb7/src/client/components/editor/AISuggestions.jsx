import React, { useState, useEffect } from 'react';
import { getSuggestions } from '../../utils/aiService';

/**
 * AI Suggestions Component
 * 
 * Provides real-time AI-powered suggestions for the story editor
 * Suggestions are context-aware and can be applied with a single click
 */
const AISuggestions = ({ 
  content, 
  cursorPosition, 
  onApplySuggestion,
  isVisible = true,
  suggestionType = 'next'
}) => {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedType, setSelectedType] = useState(suggestionType);
  
  // Fetch suggestions when content changes (with debounce)
  useEffect(() => {
    // Don't fetch if component is hidden
    if (!isVisible) return;
    
    // Clear previous timeout
    const timeoutId = setTimeout(() => {
      fetchSuggestions();
    }, 1000); // 1 second debounce
    
    return () => clearTimeout(timeoutId);
  }, [content, cursorPosition, selectedType, isVisible]);
  
  // Fetch suggestions from AI service
  const fetchSuggestions = async () => {
    // Don't fetch if content is too short
    if (!content || content.length < 20) {
      setSuggestions([]);
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const result = await getSuggestions({
        content,
        cursorPosition,
        suggestionType: selectedType
      });
      
      setSuggestions(result.suggestions || []);
    } catch (err) {
      console.error('Failed to get suggestions:', err);
      setError('Failed to load suggestions');
      setSuggestions([]);
    } finally {
      setLoading(false);
    }
  };
  
  // Handle suggestion type change
  const handleTypeChange = (type) => {
    setSelectedType(type);
  };
  
  // Handle manual refresh
  const handleRefresh = () => {
    fetchSuggestions();
  };
  
  // If component is hidden, don't render anything
  if (!isVisible) return null;
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-4">
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-lg font-medium">AI Suggestions</h3>
        <button 
          onClick={handleRefresh}
          className="text-primary hover:text-primary-dark"
          disabled={loading}
          title="Refresh suggestions"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${loading ? 'animate-spin' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        </button>
      </div>
      
      {/* Suggestion type selector */}
      <div className="flex space-x-2 mb-3 overflow-x-auto pb-2">
        <button
          className={`px-3 py-1 rounded-full text-sm ${selectedType === 'next' ? 'bg-primary text-white' : 'bg-gray-100 dark:bg-gray-700'}`}
          onClick={() => handleTypeChange('next')}
        >
          Next Steps
        </button>
        <button
          className={`px-3 py-1 rounded-full text-sm ${selectedType === 'plot' ? 'bg-primary text-white' : 'bg-gray-100 dark:bg-gray-700'}`}
          onClick={() => handleTypeChange('plot')}
        >
          Plot Ideas
        </button>
        <button
          className={`px-3 py-1 rounded-full text-sm ${selectedType === 'character' ? 'bg-primary text-white' : 'bg-gray-100 dark:bg-gray-700'}`}
          onClick={() => handleTypeChange('character')}
        >
          Character
        </button>
        <button
          className={`px-3 py-1 rounded-full text-sm ${selectedType === 'setting' ? 'bg-primary text-white' : 'bg-gray-100 dark:bg-gray-700'}`}
          onClick={() => handleTypeChange('setting')}
        >
          Setting
        </button>
      </div>
      
      {/* Loading state */}
      {loading && (
        <div className="flex justify-center items-center py-4">
          <div className="animate-pulse flex space-x-2">
            <div className="h-2 w-2 bg-gray-400 rounded-full"></div>
            <div className="h-2 w-2 bg-gray-400 rounded-full"></div>
            <div className="h-2 w-2 bg-gray-400 rounded-full"></div>
          </div>
        </div>
      )}
      
      {/* Error state */}
      {error && (
        <div className="text-red-500 text-center py-2">
          {error}
        </div>
      )}
      
      {/* Suggestions list */}
      {!loading && !error && suggestions.length === 0 && (
        <div className="text-gray-500 dark:text-gray-400 text-center py-2">
          {content && content.length >= 20 
            ? "No suggestions available. Try writing more or changing the suggestion type."
            : "Write at least a few sentences to get suggestions."}
        </div>
      )}
      
      {!loading && !error && suggestions.length > 0 && (
        <ul className="space-y-2">
          {suggestions.map((suggestion, index) => (
            <li key={index}>
              <button
                className="w-full text-left p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex justify-between items-center group"
                onClick={() => onApplySuggestion(suggestion.text)}
              >
                <span>{suggestion.text}</span>
                <span className="text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 0l-3 3a1 1 0 001.414 1.414L9 9.414V13a1 1 0 102 0V9.414l1.293 1.293a1 1 0 001.414-1.414z" clipRule="evenodd" />
                  </svg>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
      
      <div className="mt-3 text-xs text-gray-500 dark:text-gray-400">
        Suggestions are generated based on your current content and may be refined as you write more.
      </div>
    </div>
  );
};

export default AISuggestions;