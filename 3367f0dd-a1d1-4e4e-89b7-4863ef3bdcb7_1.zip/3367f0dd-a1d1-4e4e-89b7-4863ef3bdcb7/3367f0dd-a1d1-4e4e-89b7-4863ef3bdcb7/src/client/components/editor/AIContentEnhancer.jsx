import React, { useState } from 'react';
import { enhanceContent } from '../../utils/aiService';

/**
 * AI Content Enhancer Component
 * 
 * Provides tools to enhance and improve story content using AI
 * Includes options for grammar, style, descriptions, and dialogue
 */
const AIContentEnhancer = ({ content, onApplyEnhancement }) => {
  const [focusArea, setFocusArea] = useState('grammar');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [enhancedContent, setEnhancedContent] = useState('');
  const [selectedSection, setSelectedSection] = useState('all');
  const [customControls, setCustomControls] = useState({
    tone: 'neutral',
    mood: 'neutral'
  });
  
  // Focus area options
  const focusOptions = [
    { id: 'grammar', name: 'Grammar & Clarity', icon: 'check' },
    { id: 'style', name: 'Style & Flow', icon: 'sparkles' },
    { id: 'description', name: 'Descriptions', icon: 'eye' },
    { id: 'dialogue', name: 'Dialogue', icon: 'chat' }
  ];
  
  // Handle focus area selection
  const handleFocusSelect = (focus) => {
    setFocusArea(focus);
    setEnhancedContent('');
  };
  
  // Handle section selection
  const handleSectionSelect = (e) => {
    setSelectedSection(e.target.value);
    setEnhancedContent('');
  };
  
  // Handle custom control change
  const handleControlChange = (control, value) => {
    setCustomControls(prev => ({
      ...prev,
      [control]: value
    }));
  };
  
  // Get content to enhance based on selected section
  const getContentToEnhance = () => {
    if (selectedSection === 'all' || !content) {
      return content;
    }
    
    // In a real implementation, this would use a more sophisticated
    // approach to identify paragraphs or sections
    const paragraphs = content.split('\n\n');
    
    if (selectedSection === 'last' && paragraphs.length > 0) {
      return paragraphs[paragraphs.length - 1];
    }
    
    if (selectedSection === 'selection') {
      // This would use the actual text selection from the editor
      // For now, we'll just return a sample portion
      return content.substring(0, Math.min(content.length, 500));
    }
    
    return content;
  };
  
  // Enhance content
  const handleEnhance = async () => {
    const contentToEnhance = getContentToEnhance();
    if (!contentToEnhance) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const result = await enhanceContent({
        content: contentToEnhance,
        focus: focusArea,
        controls: customControls
      });
      
      setEnhancedContent(result.enhanced);
    } catch (err) {
      console.error('Failed to enhance content:', err);
      setError('Failed to enhance content');
    } finally {
      setLoading(false);
    }
  };
  
  // Apply enhanced content
  const handleApply = () => {
    if (!enhancedContent) return;
    
    onApplyEnhancement(enhancedContent, selectedSection);
    setEnhancedContent('');
  };
  
  // Get icon for focus area
  const getIcon = (iconName) => {
    switch (iconName) {
      case 'check':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
        );
      case 'sparkles':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M5 2a1 1 0 011 1v1h1a1 1 0 010 2H6v1a1 1 0 01-2 0V6H3a1 1 0 010-2h1V3a1 1 0 011-1zm0 10a1 1 0 011 1v1h1a1 1 0 110 2H6v1a1 1 0 11-2 0v-1H3a1 1 0 110-2h1v-1a1 1 0 011-1zM12 2a1 1 0 01.967.744L14.146 7.2 17.5 9.134a1 1 0 010 1.732l-3.354 1.935-1.18 4.455a1 1 0 01-1.933 0L9.854 12.8 6.5 10.866a1 1 0 010-1.732l3.354-1.935 1.18-4.455A1 1 0 0112 2z" clipRule="evenodd" />
          </svg>
        );
      case 'eye':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
            <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
          </svg>
        );
      case 'chat':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z" clipRule="evenodd" />
          </svg>
        );
      default:
        return null;
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
      <h3 className="text-lg font-medium mb-3">Enhance Content</h3>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Focus Area</label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {focusOptions.map((option) => (
            <button
              key={option.id}
              className={`p-3 rounded-md border flex flex-col items-center ${
                focusArea === option.id
                  ? 'border-primary bg-primary bg-opacity-10'
                  : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
              onClick={() => handleFocusSelect(option.id)}
            >
              <div className="mb-1">{getIcon(option.icon)}</div>
              <div className="text-sm">{option.name}</div>
            </button>
          ))}
        </div>
      </div>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Section to Enhance</label>
        <select
          value={selectedSection}
          onChange={handleSectionSelect}
          className="w-full rounded-md border-gray-300 dark:border-gray-700 dark:bg-gray-800"
        >
          <option value="all">Entire Content</option>
          <option value="last">Last Paragraph</option>
          <option value="selection">Selected Text</option>
        </select>
      </div>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Custom Controls</label>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs mb-1">Tone</label>
            <select
              value={customControls.tone}
              onChange={(e) => handleControlChange('tone', e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-700 dark:bg-gray-800 text-sm"
            >
              <option value="neutral">Neutral</option>
              <option value="formal">Formal</option>
              <option value="casual">Casual</option>
              <option value="poetic">Poetic</option>
              <option value="humorous">Humorous</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1">Mood</label>
            <select
              value={customControls.mood}
              onChange={(e) => handleControlChange('mood', e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-700 dark:bg-gray-800 text-sm"
            >
              <option value="neutral">Neutral</option>
              <option value="happy">Happy</option>
              <option value="sad">Sad</option>
              <option value="tense">Tense</option>
              <option value="mysterious">Mysterious</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Enhanced content preview */}
      {enhancedContent && (
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">Enhanced Content</label>
          <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded border border-gray-200 dark:border-gray-600 text-sm max-h-60 overflow-y-auto">
            {enhancedContent}
          </div>
        </div>
      )}
      
      {/* Error message */}
      {error && (
        <div className="text-red-500 text-sm mb-4">
          {error}
        </div>
      )}
      
      <div className="flex space-x-3">
        <button
          className="btn btn-primary"
          onClick={handleEnhance}
          disabled={!content || loading}
        >
          {loading ? (
            <span className="flex items-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Enhancing...
            </span>
          ) : 'Enhance Content'}
        </button>
        {enhancedContent && (
          <button
            className="btn btn-outline"
            onClick={handleApply}
          >
            Apply Changes
          </button>
        )}
      </div>
      
      <div className="mt-3 text-xs text-gray-500 dark:text-gray-400">
        Content enhancement will improve your writing while preserving your unique voice and style.
      </div>
    </div>
  );
};

export default AIContentEnhancer;