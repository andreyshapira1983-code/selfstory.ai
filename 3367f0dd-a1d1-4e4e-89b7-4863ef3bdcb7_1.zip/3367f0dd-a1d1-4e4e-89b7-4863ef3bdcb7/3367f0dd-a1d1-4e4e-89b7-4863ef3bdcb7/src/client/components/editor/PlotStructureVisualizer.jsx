import React, { useState, useEffect } from 'react';
import { generatePlot } from '../../utils/aiService';

/**
 * Plot Structure Visualizer Component
 * 
 * Provides tools for visualizing and planning story plot structure
 * Includes different plot structure templates and AI-assisted plot generation
 */
const PlotStructureVisualizer = ({
  initialPlotPoints = {},
  storyGenre = 'fantasy',
  onUpdatePlotPoints
}) => {
  const [plotStructure, setPlotStructure] = useState('three-act');
  const [plotPoints, setPlotPoints] = useState(initialPlotPoints);
  const [activePoint, setActivePoint] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showAIOptions, setShowAIOptions] = useState(false);
  
  // Plot structure templates
  const structureTemplates = {
    'three-act': {
      name: 'Three-Act Structure',
      description: 'Classic beginning, middle, and end structure used in most stories',
      points: {
        act1: {
          setup: { title: 'Setup', description: 'Introduce the world and characters' },
          incitingIncident: { title: 'Inciting Incident', description: 'Event that sets the story in motion' },
          firstPlotPoint: { title: 'First Plot Point', description: 'Decision that propels the protagonist into the main conflict' }
        },
        act2: {
          risingAction: { title: 'Rising Action', description: 'Series of obstacles and complications' },
          midpoint: { title: 'Midpoint', description: 'Major revelation or reversal' },
          lowestPoint: { title: 'Lowest Point', description: 'All seems lost moment' }
        },
        act3: {
          climax: { title: 'Climax', description: 'Final confrontation' },
          resolution: { title: 'Resolution', description: 'Aftermath and new equilibrium' }
        }
      }
    },
    'hero-journey': {
      name: 'Hero\'s Journey',
      description: 'Joseph Campbell\'s monomyth structure for epic adventures',
      points: {
        ordinaryWorld: { title: 'Ordinary World', description: 'Protagonist in their normal environment' },
        callToAdventure: { title: 'Call to Adventure', description: 'Challenge or opportunity presented' },
        refusalOfCall: { title: 'Refusal of the Call', description: 'Initial reluctance' },
        meetingTheMentor: { title: 'Meeting the Mentor', description: 'Guidance received' },
        crossingTheThreshold: { title: 'Crossing the Threshold', description: 'Commitment to the adventure' },
        tests: { title: 'Tests, Allies, and Enemies', description: 'Challenges and allies' },
        approach: { title: 'Approach to the Inmost Cave', description: 'Preparation for major challenge' },
        ordeal: { title: 'The Ordeal', description: 'Central crisis' },
        reward: { title: 'Reward (Seizing the Sword)', description: 'Achievement of goal' },
        roadBack: { title: 'The Road Back', description: 'Consequences and pursuit' },
        resurrection: { title: 'Resurrection', description: 'Final test' },
        returnWithElixir: { title: 'Return with the Elixir', description: 'Mastery and giving back' }
      }
    },
    'save-the-cat': {
      name: 'Save the Cat',
      description: 'Blake Snyder\'s 15-beat screenplay structure',
      points: {
        openingImage: { title: 'Opening Image', description: 'First impression of the story world' },
        theme: { title: 'Theme Stated', description: 'What the story is really about' },
        setup: { title: 'Setup', description: 'Establish the main character and their world' },
        catalyst: { title: 'Catalyst', description: 'Inciting incident that changes everything' },
        debate: { title: 'Debate', description: 'Protagonist questions whether to proceed' },
        breakIntoTwo: { title: 'Break into Two', description: 'Protagonist decides to take action' },
        bSection: { title: 'B Story', description: 'Secondary story or relationship begins' },
        funAndGames: { title: 'Fun and Games', description: 'Promise of the premise explored' },
        midpoint: { title: 'Midpoint', description: 'Raises the stakes, false victory or defeat' },
        badGuysCloseIn: { title: 'Bad Guys Close In', description: 'Antagonist forces apply pressure' },
        allIsLost: { title: 'All Is Lost', description: 'Protagonist at their lowest point' },
        darkNightOfSoul: { title: 'Dark Night of the Soul', description: 'Protagonist must dig deep' },
        breakIntoThree: { title: 'Break into Three', description: 'Protagonist finds the solution' },
        finale: { title: 'Finale', description: 'Protagonist proves they\'ve changed' },
        finalImage: { title: 'Final Image', description: 'Bookend to the opening image' }
      }
    },
    'seven-point': {
      name: 'Seven-Point Structure',
      description: 'Streamlined structure focusing on key turning points',
      points: {
        hook: { title: 'Hook', description: 'Grab the reader\'s attention' },
        plotTurn1: { title: 'Plot Turn 1', description: 'Event that sets the story in motion' },
        pinchPoint1: { title: 'Pinch Point 1', description: 'First encounter with antagonistic force' },
        midpoint: { title: 'Midpoint', description: 'Protagonist shifts from reaction to action' },
        pinchPoint2: { title: 'Pinch Point 2', description: 'Antagonistic force applies pressure' },
        plotTurn2: { title: 'Plot Turn 2', description: 'Final piece of the puzzle' },
        resolution: { title: 'Resolution', description: 'Climax and aftermath' }
      }
    }
  };
  
  // Initialize plot points based on structure
  useEffect(() => {
    if (Object.keys(initialPlotPoints).length === 0) {
      // If no initial plot points, use template
      const template = structureTemplates[plotStructure];
      const emptyPoints = {};
      
      // Create empty content for each plot point
      Object.entries(template.points).forEach(([section, points]) => {
        if (typeof points === 'object' && !Array.isArray(points)) {
          emptyPoints[section] = {};
          Object.keys(points).forEach(point => {
            emptyPoints[section][point] = {
              ...template.points[section][point],
              content: ''
            };
          });
        } else {
          emptyPoints[section] = {
            ...template.points[section],
            content: ''
          };
        }
      });
      
      setPlotPoints(emptyPoints);
    } else {
      // Use provided plot points
      setPlotPoints(initialPlotPoints);
    }
  }, [initialPlotPoints, plotStructure]);
  
  // Handle structure change
  const handleStructureChange = (structure) => {
    if (structure !== plotStructure) {
      // Confirm if there's existing content
      const hasContent = Object.values(plotPoints).some(section => {
        if (typeof section === 'object') {
          return Object.values(section).some(point => point.content && point.content.trim() !== '');
        }
        return false;
      });
      
      if (hasContent) {
        if (window.confirm('Changing the structure will reset your plot points. Continue?')) {
          setPlotStructure(structure);
          
          // Reset plot points based on new structure
          const template = structureTemplates[structure];
          const emptyPoints = {};
          
          // Create empty content for each plot point
          Object.entries(template.points).forEach(([section, points]) => {
            if (typeof points === 'object' && !Array.isArray(points)) {
              emptyPoints[section] = {};
              Object.keys(points).forEach(point => {
                emptyPoints[section][point] = {
                  ...template.points[section][point],
                  content: ''
                };
              });
            } else {
              emptyPoints[section] = {
                ...template.points[section],
                content: ''
              };
            }
          });
          
          setPlotPoints(emptyPoints);
          setActivePoint(null);
          
          // Update parent component
          if (onUpdatePlotPoints) {
            onUpdatePlotPoints(emptyPoints);
          }
        }
      } else {
        setPlotStructure(structure);
        
        // Reset plot points based on new structure
        const template = structureTemplates[structure];
        const emptyPoints = {};
        
        // Create empty content for each plot point
        Object.entries(template.points).forEach(([section, points]) => {
          if (typeof points === 'object' && !Array.isArray(points)) {
            emptyPoints[section] = {};
            Object.keys(points).forEach(point => {
              emptyPoints[section][point] = {
                ...template.points[section][point],
                content: ''
              };
            });
          } else {
            emptyPoints[section] = {
              ...template.points[section],
              content: ''
            };
          }
        });
        
        setPlotPoints(emptyPoints);
        setActivePoint(null);
        
        // Update parent component
        if (onUpdatePlotPoints) {
          onUpdatePlotPoints(emptyPoints);
        }
      }
    }
  };
  
  // Handle plot point selection
  const handleSelectPoint = (section, point) => {
    setActivePoint({ section, point });
  };
  
  // Handle plot point content change
  const handleContentChange = (e) => {
    if (activePoint) {
      const { section, point } = activePoint;
      const updatedPoints = { ...plotPoints };
      
      if (typeof updatedPoints[section] === 'object' && !Array.isArray(updatedPoints[section])) {
        updatedPoints[section][point] = {
          ...updatedPoints[section][point],
          content: e.target.value
        };
      } else {
        updatedPoints[section] = {
          ...updatedPoints[section],
          content: e.target.value
        };
      }
      
      setPlotPoints(updatedPoints);
      
      // Update parent component
      if (onUpdatePlotPoints) {
        onUpdatePlotPoints(updatedPoints);
      }
    }
  };
  
  // Generate plot with AI
  const handleGeneratePlot = async () => {
    setIsGenerating(true);
    
    try {
      const result = await generatePlot({
        premise: '',
        genre: storyGenre,
        structure: plotStructure
      });
      
      // Map AI response to plot points
      const updatedPoints = { ...plotPoints };
      
      // Process the AI-generated plot structure
      Object.entries(result.plot.structure).forEach(([section, content]) => {
        if (typeof content === 'string' && updatedPoints[section]) {
          // For simple structures
          updatedPoints[section] = {
            ...updatedPoints[section],
            content
          };
        } else if (typeof content === 'object' && !Array.isArray(content)) {
          // For nested structures
          Object.entries(content).forEach(([point, pointContent]) => {
            if (updatedPoints[section] && updatedPoints[section][point]) {
              updatedPoints[section][point] = {
                ...updatedPoints[section][point],
                content: typeof pointContent === 'string' ? pointContent : pointContent.description || ''
              };
            }
          });
        }
      });
      
      setPlotPoints(updatedPoints);
      
      // Update parent component
      if (onUpdatePlotPoints) {
        onUpdatePlotPoints(updatedPoints);
      }
    } catch (error) {
      console.error('Failed to generate plot:', error);
      alert('Failed to generate plot. Please try again.');
    } finally {
      setIsGenerating(false);
      setShowAIOptions(false);
    }
  };
  
  // Generate a single plot point with AI
  const handleGeneratePoint = async () => {
    if (!activePoint) return;
    
    setIsGenerating(true);
    
    try {
      const { section, point } = activePoint;
      const pointTitle = plotPoints[section][point].title;
      const pointDescription = plotPoints[section][point].description;
      
      const result = await generatePlot({
        premise: `Generate content for the "${pointTitle}" (${pointDescription}) plot point in a ${storyGenre} story.`,
        genre: storyGenre,
        structure: 'custom'
      });
      
      // Extract the generated content
      let generatedContent = '';
      if (result.plot && result.plot.premise) {
        generatedContent = result.plot.premise;
      } else {
        // Fallback to a generic response
        generatedContent = `Content for ${pointTitle}: This is where you would describe the ${pointDescription.toLowerCase()} in your ${storyGenre} story.`;
      }
      
      // Update the plot point
      const updatedPoints = { ...plotPoints };
      updatedPoints[section][point] = {
        ...updatedPoints[section][point],
        content: generatedContent
      };
      
      setPlotPoints(updatedPoints);
      
      // Update parent component
      if (onUpdatePlotPoints) {
        onUpdatePlotPoints(updatedPoints);
      }
    } catch (error) {
      console.error('Failed to generate plot point:', error);
      alert('Failed to generate plot point. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };
  
  // Render the plot structure visualization
  const renderPlotStructure = () => {
    const template = structureTemplates[plotStructure];
    
    switch (plotStructure) {
      case 'three-act':
        return (
          <div className="plot-structure three-act">
            {/* Act 1 */}
            <div className="mb-6">
              <h4 className="font-medium text-lg mb-2">Act 1: Setup</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.entries(plotPoints.act1 || {}).map(([point, data]) => (
                  <div
                    key={point}
                    className={`p-3 border rounded-md cursor-pointer ${
                      activePoint?.section === 'act1' && activePoint?.point === point
                        ? 'border-primary bg-primary bg-opacity-10'
                        : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                    }`}
                    onClick={() => handleSelectPoint('act1', point)}
                  >
                    <h5 className="font-medium">{data.title}</h5>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{data.description}</p>
                    {data.content && (
                      <div className="mt-2 text-sm">
                        <div className="line-clamp-2">{data.content}</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            {/* Act 2 */}
            <div className="mb-6">
              <h4 className="font-medium text-lg mb-2">Act 2: Confrontation</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.entries(plotPoints.act2 || {}).map(([point, data]) => (
                  <div
                    key={point}
                    className={`p-3 border rounded-md cursor-pointer ${
                      activePoint?.section === 'act2' && activePoint?.point === point
                        ? 'border-primary bg-primary bg-opacity-10'
                        : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                    }`}
                    onClick={() => handleSelectPoint('act2', point)}
                  >
                    <h5 className="font-medium">{data.title}</h5>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{data.description}</p>
                    {data.content && (
                      <div className="mt-2 text-sm">
                        <div className="line-clamp-2">{data.content}</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            {/* Act 3 */}
            <div>
              <h4 className="font-medium text-lg mb-2">Act 3: Resolution</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(plotPoints.act3 || {}).map(([point, data]) => (
                  <div
                    key={point}
                    className={`p-3 border rounded-md cursor-pointer ${
                      activePoint?.section === 'act3' && activePoint?.point === point
                        ? 'border-primary bg-primary bg-opacity-10'
                        : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                    }`}
                    onClick={() => handleSelectPoint('act3', point)}
                  >
                    <h5 className="font-medium">{data.title}</h5>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{data.description}</p>
                    {data.content && (
                      <div className="mt-2 text-sm">
                        <div className="line-clamp-2">{data.content}</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
        
      case 'hero-journey':
        return (
          <div className="plot-structure hero-journey">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {Object.entries(plotPoints).map(([point, data]) => (
                <div
                  key={point}
                  className={`p-3 border rounded-md cursor-pointer ${
                    activePoint?.section === point
                      ? 'border-primary bg-primary bg-opacity-10'
                      : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                  onClick={() => handleSelectPoint(point, null)}
                >
                  <h5 className="font-medium">{data.title}</h5>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{data.description}</p>
                  {data.content && (
                    <div className="mt-2 text-sm">
                      <div className="line-clamp-2">{data.content}</div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        );
        
      case 'save-the-cat':
        return (
          <div className="plot-structure save-the-cat">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {Object.entries(plotPoints).map(([point, data]) => (
                <div
                  key={point}
                  className={`p-3 border rounded-md cursor-pointer ${
                    activePoint?.section === point
                      ? 'border-primary bg-primary bg-opacity-10'
                      : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                  onClick={() => handleSelectPoint(point, null)}
                >
                  <h5 className="font-medium">{data.title}</h5>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{data.description}</p>
                  {data.content && (
                    <div className="mt-2 text-sm">
                      <div className="line-clamp-2">{data.content}</div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        );
        
      case 'seven-point':
        return (
          <div className="plot-structure seven-point">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {Object.entries(plotPoints).map(([point, data]) => (
                <div
                  key={point}
                  className={`p-3 border rounded-md cursor-pointer ${
                    activePoint?.section === point
                      ? 'border-primary bg-primary bg-opacity-10'
                      : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                  onClick={() => handleSelectPoint(point, null)}
                >
                  <h5 className="font-medium">{data.title}</h5>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{data.description}</p>
                  {data.content && (
                    <div className="mt-2 text-sm">
                      <div className="line-clamp-2">{data.content}</div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        );
        
      default:
        return (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            Select a plot structure to begin
          </div>
        );
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      {/* Header */}
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-b border-gray-200 dark:border-gray-600">
        <h2 className="text-lg font-medium flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-primary" viewBox="0 0 20 20" fill="currentColor">
            <path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z" />
            <path d="M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z" />
          </svg>
          Plot Structure Visualizer
        </h2>
      </div>
      
      {/* Main content */}
      <div className="p-4">
        {/* Structure selector and AI options */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 space-y-4 md:space-y-0">
          <div>
            <label className="block text-sm font-medium mb-1">Plot Structure</label>
            <select
              className="input"
              value={plotStructure}
              onChange={(e) => handleStructureChange(e.target.value)}
            >
              {Object.entries(structureTemplates).map(([key, template]) => (
                <option key={key} value={key}>{template.name}</option>
              ))}
            </select>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              {structureTemplates[plotStructure].description}
            </p>
          </div>
          
          <div className="relative">
            <button
              className="btn btn-secondary"
              onClick={() => setShowAIOptions(!showAIOptions)}
              disabled={isGenerating}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
              </svg>
              AI Assist
            </button>
            
            {showAIOptions && (
              <div className="absolute z-10 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg border border-gray-200 dark:border-gray-700 right-0">
                <div className="py-1">
                  <button
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                    onClick={handleGeneratePlot}
                    disabled={isGenerating}
                  >
                    Generate Full Plot
                  </button>
                  <button
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                    onClick={handleGeneratePoint}
                    disabled={isGenerating || !activePoint}
                  >
                    Generate Selected Point
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Loading state */}
        {isGenerating && (
          <div className="flex justify-center items-center py-8">
            <div className="text-center">
              <svg className="animate-spin h-8 w-8 mx-auto text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              <p className="mt-2 font-medium">Generating plot structure...</p>
            </div>
          </div>
        )}
        
        {/* Plot structure visualization */}
        {!isGenerating && (
          <div className="mb-6">
            {renderPlotStructure()}
          </div>
        )}
        
        {/* Plot point editor */}
        {activePoint && !isGenerating && (
          <div className="mt-8 border-t border-gray-200 dark:border-gray-700 pt-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-medium text-lg">
                {plotStructure === 'three-act' 
                  ? plotPoints[activePoint.section][activePoint.point].title
                  : plotPoints[activePoint.section].title}
              </h3>
              {activePoint && (
                <button
                  className="btn btn-sm btn-outline"
                  onClick={handleGeneratePoint}
                  disabled={isGenerating}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
                  </svg>
                  Generate
                </button>
              )}
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
              {plotStructure === 'three-act' 
                ? plotPoints[activePoint.section][activePoint.point].description
                : plotPoints[activePoint.section].description}
            </p>
            <textarea
              className="input w-full"
              rows={6}
              value={plotStructure === 'three-act' 
                ? plotPoints[activePoint.section][activePoint.point].content
                : plotPoints[activePoint.section].content}
              onChange={handleContentChange}
              placeholder="Describe this plot point..."
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default PlotStructureVisualizer;