import React, { useState, useEffect, useRef } from 'react';

/**
 * Interactive Timeline Component
 * 
 * Provides a visual timeline for plotting story events
 * Allows for creating, editing, and organizing events chronologically
 */
const InteractiveTimeline = ({
  events = [],
  onAddEvent,
  onUpdateEvent,
  onDeleteEvent,
  onReorderEvents
}) => {
  const [timelineEvents, setTimelineEvents] = useState(events);
  const [activeEvent, setActiveEvent] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [draggedEvent, setDraggedEvent] = useState(null);
  const [dragOverIndex, setDragOverIndex] = useState(null);
  const [timelineScale, setTimelineScale] = useState('relative'); // relative, absolute
  const [zoomLevel, setZoomLevel] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  
  const timelineRef = useRef(null);
  
  // New event template
  const newEventTemplate = {
    id: '',
    title: '',
    description: '',
    time: '', // Can be relative ("Chapter 3") or absolute ("Day 42")
    characters: [],
    locations: [],
    importance: 'medium', // minor, medium, major
    type: 'event', // event, revelation, decision, etc.
    color: '#3B82F6', // Default blue
    notes: ''
  };
  
  // Event being edited
  const [editingEvent, setEditingEvent] = useState({...newEventTemplate});
  
  // Event types with colors
  const eventTypes = [
    { id: 'event', name: 'Event', color: '#3B82F6' }, // Blue
    { id: 'revelation', name: 'Revelation', color: '#8B5CF6' }, // Purple
    { id: 'decision', name: 'Decision', color: '#10B981' }, // Green
    { id: 'conflict', name: 'Conflict', color: '#EF4444' }, // Red
    { id: 'resolution', name: 'Resolution', color: '#F59E0B' }, // Amber
    { id: 'setup', name: 'Setup', color: '#6B7280' }, // Gray
    { id: 'payoff', name: 'Payoff', color: '#EC4899' }, // Pink
    { id: 'twist', name: 'Twist', color: '#6366F1' } // Indigo
  ];
  
  // Initialize timeline events
  useEffect(() => {
    setTimelineEvents(events);
  }, [events]);
  
  // Handle event selection
  const handleSelectEvent = (event) => {
    setActiveEvent(event);
    setEditingEvent(event);
    setIsEditing(false);
    setIsCreating(false);
  };
  
  // Handle creating new event
  const handleCreateNew = () => {
    const newId = `event-${Date.now()}`;
    const newPosition = timelineEvents.length;
    
    setEditingEvent({
      ...newEventTemplate,
      id: newId,
      time: timelineEvents.length > 0 ? `After ${timelineEvents[timelineEvents.length - 1].title}` : 'Beginning'
    });
    
    setActiveEvent(null);
    setIsEditing(false);
    setIsCreating(true);
  };
  
  // Handle editing event
  const handleEdit = () => {
    setIsEditing(true);
    setIsCreating(false);
  };
  
  // Handle saving event
  const handleSave = () => {
    if (isCreating) {
      const newEvent = { ...editingEvent };
      
      // Add the new event
      const updatedEvents = [...timelineEvents, newEvent];
      setTimelineEvents(updatedEvents);
      setActiveEvent(newEvent);
      
      // Notify parent component
      if (onAddEvent) {
        onAddEvent(newEvent);
      }
      
      // Notify parent of reordering
      if (onReorderEvents) {
        onReorderEvents(updatedEvents);
      }
    } else {
      // Update the existing event
      const updatedEvents = timelineEvents.map(event => 
        event.id === editingEvent.id ? editingEvent : event
      );
      
      setTimelineEvents(updatedEvents);
      setActiveEvent(editingEvent);
      
      // Notify parent component
      if (onUpdateEvent) {
        onUpdateEvent(editingEvent);
      }
    }
    
    setIsEditing(false);
    setIsCreating(false);
  };
  
  // Handle deleting event
  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete "${activeEvent.title}"?`)) {
      // Remove the event
      const updatedEvents = timelineEvents.filter(event => event.id !== activeEvent.id);
      setTimelineEvents(updatedEvents);
      setActiveEvent(null);
      setEditingEvent({...newEventTemplate});
      setIsEditing(false);
      setIsCreating(false);
      
      // Notify parent component
      if (onDeleteEvent) {
        onDeleteEvent(activeEvent.id);
      }
      
      // Notify parent of reordering
      if (onReorderEvents) {
        onReorderEvents(updatedEvents);
      }
    }
  };
  
  // Handle field change
  const handleFieldChange = (field, value) => {
    setEditingEvent(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  // Handle array field change (for characters, locations)
  const handleArrayFieldChange = (field, value) => {
    const values = value.split(',').map(item => item.trim()).filter(item => item);
    
    setEditingEvent(prev => ({
      ...prev,
      [field]: values
    }));
  };
  
  // Handle event type change
  const handleEventTypeChange = (type) => {
    const selectedType = eventTypes.find(t => t.id === type);
    
    setEditingEvent(prev => ({
      ...prev,
      type,
      color: selectedType ? selectedType.color : '#3B82F6'
    }));
  };
  
  // Handle drag start
  const handleDragStart = (event) => {
    setDraggedEvent(event);
  };
  
  // Handle drag over
  const handleDragOver = (e, index) => {
    e.preventDefault();
    setDragOverIndex(index);
  };
  
  // Handle drop
  const handleDrop = (e, dropIndex) => {
    e.preventDefault();
    
    if (!draggedEvent) return;
    
    // Find the current index of the dragged event
    const dragIndex = timelineEvents.findIndex(event => event.id === draggedEvent.id);
    
    // Don't do anything if dropping onto the same item
    if (dragIndex === dropIndex) {
      setDraggedEvent(null);
      setDragOverIndex(null);
      return;
    }
    
    // Create a new array without the dragged event
    const newEvents = timelineEvents.filter(event => event.id !== draggedEvent.id);
    
    // Insert the dragged event at the drop position
    newEvents.splice(dropIndex, 0, draggedEvent);
    
    // Update state
    setTimelineEvents(newEvents);
    setDraggedEvent(null);
    setDragOverIndex(null);
    
    // Notify parent component
    if (onReorderEvents) {
      onReorderEvents(newEvents);
    }
  };
  
  // Handle zoom change
  const handleZoomChange = (e) => {
    setZoomLevel(parseFloat(e.target.value));
  };
  
  // Handle timeline scale change
  const handleScaleChange = (scale) => {
    setTimelineScale(scale);
  };
  
  // Filter events based on search term
  const filteredEvents = timelineEvents.filter(event => 
    event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.time.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Get event type name
  const getEventTypeName = (typeId) => {
    const type = eventTypes.find(t => t.id === typeId);
    return type ? type.name : 'Event';
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      {/* Header */}
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-b border-gray-200 dark:border-gray-600">
        <h2 className="text-lg font-medium flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-primary" viewBox="0 0 20 20" fill="currentColor">
            <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM14 11a1 1 0 011 1v1h1a1 1 0 110 2h-1v1a1 1 0 11-2 0v-1h-1a1 1 0 110-2h1v-1a1 1 0 011-1z" />
          </svg>
          Interactive Timeline
        </h2>
      </div>
      
      {/* Main content */}
      <div className="p-4">
        {/* Controls */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 space-y-2 md:space-y-0">
          <div className="flex items-center space-x-2">
            <button
              className="btn btn-primary"
              onClick={handleCreateNew}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
              </svg>
              Add Event
            </button>
            
            <div className="flex items-center space-x-1">
              <button
                className={`px-2 py-1 text-xs font-medium rounded ${
                  timelineScale === 'relative'
                    ? 'bg-primary text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                }`}
                onClick={() => handleScaleChange('relative')}
              >
                Relative
              </button>
              <button
                className={`px-2 py-1 text-xs font-medium rounded ${
                  timelineScale === 'absolute'
                    ? 'bg-primary text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                }`}
                onClick={() => handleScaleChange('absolute')}
              >
                Absolute
              </button>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 w-full md:w-auto">
            <input
              type="text"
              className="input"
              placeholder="Search events..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            
            <div className="flex items-center space-x-1">
              <button
                className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
                onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.1))}
                title="Zoom Out"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M5 10a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1z" clipRule="evenodd" />
                </svg>
              </button>
              <input
                type="range"
                min="0.5"
                max="2"
                step="0.1"
                value={zoomLevel}
                onChange={handleZoomChange}
                className="w-20"
              />
              <button
                className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
                onClick={() => setZoomLevel(Math.min(2, zoomLevel + 0.1))}
                title="Zoom In"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          </div>
        </div>
        
        {/* Timeline visualization */}
        <div 
          className="relative mb-6 overflow-x-auto"
          ref={timelineRef}
          style={{ 
            minHeight: '200px',
            transform: `scale(${zoomLevel})`,
            transformOrigin: 'left top'
          }}
        >
          {filteredEvents.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <p className="text-gray-500 dark:text-gray-400">
                {searchTerm ? 'No events match your search' : 'No events yet. Click "Add Event" to create one.'}
              </p>
            </div>
          ) : (
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-300 dark:bg-gray-600"></div>
              
              {/* Timeline events */}
              <div className="ml-4">
                {filteredEvents.map((event, index) => (
                  <div
                    key={event.id}
                    className={`relative pl-8 py-4 ${
                      index !== filteredEvents.length - 1 ? 'border-b border-gray-200 dark:border-gray-700' : ''
                    } ${
                      dragOverIndex === index ? 'bg-gray-50 dark:bg-gray-700' : ''
                    } ${
                      activeEvent?.id === event.id ? 'bg-blue-50 dark:bg-blue-900 dark:bg-opacity-20' : ''
                    }`}
                    onClick={() => handleSelectEvent(event)}
                    draggable
                    onDragStart={() => handleDragStart(event)}
                    onDragOver={(e) => handleDragOver(e, index)}
                    onDrop={(e) => handleDrop(e, index)}
                  >
                    {/* Timeline dot */}
                    <div 
                      className="absolute left-0 w-4 h-4 rounded-full border-2 border-white dark:border-gray-800"
                      style={{ 
                        backgroundColor: event.color,
                        top: '1.5rem',
                        transform: 'translateX(-50%)'
                      }}
                    ></div>
                    
                    {/* Event content */}
                    <div className="flex flex-col md:flex-row md:items-center justify-between">
                      <div>
                        <div className="flex items-center">
                          <h3 className="font-medium text-lg">{event.title}</h3>
                          <span 
                            className="ml-2 px-2 py-0.5 text-xs rounded-full text-white"
                            style={{ backgroundColor: event.color }}
                          >
                            {getEventTypeName(event.type)}
                          </span>
                        </div>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">{event.time}</p>
                        <p className="text-sm line-clamp-2">{event.description}</p>
                      </div>
                      
                      <div className="flex mt-2 md:mt-0">
                        {event.characters.length > 0 && (
                          <div className="mr-4">
                            <span className="text-xs text-gray-500 dark:text-gray-400 block">Characters</span>
                            <span className="text-sm">{event.characters.join(', ')}</span>
                          </div>
                        )}
                        
                        {event.locations.length > 0 && (
                          <div>
                            <span className="text-xs text-gray-500 dark:text-gray-400 block">Locations</span>
                            <span className="text-sm">{event.locations.join(', ')}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        
        {/* Event detail/edit panel */}
        {activeEvent && !isEditing && !isCreating ? (
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-medium text-xl">{activeEvent.title}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">{activeEvent.time}</p>
              </div>
              <div className="flex space-x-2">
                <button
                  className="btn btn-sm btn-outline"
                  onClick={handleEdit}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                  </svg>
                  Edit
                </button>
                <button
                  className="btn btn-sm btn-danger"
                  onClick={handleDelete}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  Delete
                </button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Type</span>
                <div className="flex items-center">
                  <div 
                    className="w-3 h-3 rounded-full mr-1"
                    style={{ backgroundColor: activeEvent.color }}
                  ></div>
                  <p>{getEventTypeName(activeEvent.type)}</p>
                </div>
              </div>
              
              <div>
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Importance</span>
                <p className="capitalize">{activeEvent.importance}</p>
              </div>
            </div>
            
            <div className="mb-4">
              <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Description</span>
              <p className="whitespace-pre-line">{activeEvent.description}</p>
            </div>
            
            {activeEvent.characters.length > 0 && (
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Characters</span>
                <p>{activeEvent.characters.join(', ')}</p>
              </div>
            )}
            
            {activeEvent.locations.length > 0 && (
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Locations</span>
                <p>{activeEvent.locations.join(', ')}</p>
              </div>
            )}
            
            {activeEvent.notes && (
              <div>
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Notes</span>
                <p className="whitespace-pre-line">{activeEvent.notes}</p>
              </div>
            )}
          </div>
        ) : (isEditing || isCreating) ? (
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <h3 className="font-medium mb-4">
              {isCreating ? 'Create New Event' : `Edit ${editingEvent.title}`}
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Title</label>
                <input
                  type="text"
                  className="input w-full"
                  value={editingEvent.title}
                  onChange={(e) => handleFieldChange('title', e.target.value)}
                  placeholder="Event title"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Time/Position</label>
                <input
                  type="text"
                  className="input w-full"
                  value={editingEvent.time}
                  onChange={(e) => handleFieldChange('time', e.target.value)}
                  placeholder={timelineScale === 'relative' ? "e.g., Chapter 3, After the battle" : "e.g., Day 42, January 15th"}
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  {timelineScale === 'relative' 
                    ? 'Use relative positioning like "Chapter 3" or "After the battle"'
                    : 'Use absolute timing like "Day 42" or "January 15th"'}
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Event Type</label>
                  <select
                    className="input w-full"
                    value={editingEvent.type}
                    onChange={(e) => handleEventTypeChange(e.target.value)}
                  >
                    {eventTypes.map(type => (
                      <option key={type.id} value={type.id}>{type.name}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Importance</label>
                  <select
                    className="input w-full"
                    value={editingEvent.importance}
                    onChange={(e) => handleFieldChange('importance', e.target.value)}
                  >
                    <option value="minor">Minor</option>
                    <option value="medium">Medium</option>
                    <option value="major">Major</option>
                  </select>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Description</label>
                <textarea
                  className="input w-full"
                  rows={3}
                  value={editingEvent.description}
                  onChange={(e) => handleFieldChange('description', e.target.value)}
                  placeholder="Describe what happens in this event"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Characters (comma separated)</label>
                <input
                  type="text"
                  className="input w-full"
                  value={editingEvent.characters.join(', ')}
                  onChange={(e) => handleArrayFieldChange('characters', e.target.value)}
                  placeholder="Characters involved in this event"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Locations (comma separated)</label>
                <input
                  type="text"
                  className="input w-full"
                  value={editingEvent.locations.join(', ')}
                  onChange={(e) => handleArrayFieldChange('locations', e.target.value)}
                  placeholder="Locations where this event takes place"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Notes</label>
                <textarea
                  className="input w-full"
                  rows={2}
                  value={editingEvent.notes}
                  onChange={(e) => handleFieldChange('notes', e.target.value)}
                  placeholder="Additional notes about this event"
                />
              </div>
              
              <div className="flex justify-end space-x-3">
                <button
                  className="btn btn-outline"
                  onClick={() => {
                    if (isCreating) {
                      setIsCreating(false);
                    } else {
                      setIsEditing(false);
                    }
                  }}
                >
                  Cancel
                </button>
                <button
                  className="btn btn-primary"
                  onClick={handleSave}
                  disabled={!editingEvent.title}
                >
                  {isCreating ? 'Create Event' : 'Save Changes'}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 text-center">
            <p className="text-gray-500 dark:text-gray-400">
              Select an event to view details or click "Add Event" to create a new one.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default InteractiveTimeline;