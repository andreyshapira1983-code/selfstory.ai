import React, { useState, useEffect } from 'react';
import { generateCharacter } from '../../utils/aiService';

/**
 * Character Manager Component
 * 
 * Provides tools for creating, editing, and managing story characters
 * Includes AI-assisted character generation and development
 */
const CharacterManager = ({ 
  characters = [], 
  onAddCharacter, 
  onUpdateCharacter, 
  onDeleteCharacter,
  storyGenre = 'fantasy'
}) => {
  const [activeCharacter, setActiveCharacter] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [showAIGenerator, setShowAIGenerator] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // New character template
  const newCharacterTemplate = {
    id: '',
    name: '',
    role: 'supporting', // protagonist, antagonist, supporting
    age: '',
    occupation: '',
    physicalDescription: '',
    personality: {
      traits: [],
      flaws: [],
      motivations: []
    },
    background: '',
    relationships: [],
    arc: '',
    notes: ''
  };
  
  // Character being edited
  const [editingCharacter, setEditingCharacter] = useState({...newCharacterTemplate});
  
  // AI generation parameters
  const [aiParams, setAiParams] = useState({
    name: '',
    role: 'supporting',
    genre: storyGenre,
    traits: []
  });
  
  // Handle character selection
  const handleSelectCharacter = (character) => {
    setActiveCharacter(character);
    setEditingCharacter(character);
    setIsEditing(false);
    setIsCreating(false);
    setShowAIGenerator(false);
  };
  
  // Handle creating new character
  const handleCreateNew = () => {
    const newId = `character-${Date.now()}`;
    setEditingCharacter({...newCharacterTemplate, id: newId});
    setActiveCharacter(null);
    setIsEditing(false);
    setIsCreating(true);
    setShowAIGenerator(false);
  };
  
  // Handle editing character
  const handleEdit = () => {
    setIsEditing(true);
    setIsCreating(false);
  };
  
  // Handle saving character
  const handleSave = () => {
    if (isCreating) {
      onAddCharacter(editingCharacter);
      setActiveCharacter(editingCharacter);
    } else {
      onUpdateCharacter(editingCharacter);
      setActiveCharacter(editingCharacter);
    }
    
    setIsEditing(false);
    setIsCreating(false);
  };
  
  // Handle deleting character
  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete ${activeCharacter.name}?`)) {
      onDeleteCharacter(activeCharacter.id);
      setActiveCharacter(null);
      setEditingCharacter({...newCharacterTemplate});
      setIsEditing(false);
      setIsCreating(false);
    }
  };
  
  // Handle field change
  const handleFieldChange = (field, value) => {
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      setEditingCharacter(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: value
        }
      }));
    } else {
      setEditingCharacter(prev => ({
        ...prev,
        [field]: value
      }));
    }
  };
  
  // Handle array field change (for traits, flaws, motivations)
  const handleArrayFieldChange = (field, value) => {
    const [parent, child] = field.split('.');
    const values = value.split(',').map(item => item.trim()).filter(item => item);
    
    setEditingCharacter(prev => ({
      ...prev,
      [parent]: {
        ...prev[parent],
        [child]: values
      }
    }));
  };
  
  // Handle relationship add
  const handleAddRelationship = () => {
    setEditingCharacter(prev => ({
      ...prev,
      relationships: [
        ...prev.relationships,
        { type: '', description: '' }
      ]
    }));
  };
  
  // Handle relationship update
  const handleUpdateRelationship = (index, field, value) => {
    setEditingCharacter(prev => {
      const updatedRelationships = [...prev.relationships];
      updatedRelationships[index] = {
        ...updatedRelationships[index],
        [field]: value
      };
      
      return {
        ...prev,
        relationships: updatedRelationships
      };
    });
  };
  
  // Handle relationship delete
  const handleDeleteRelationship = (index) => {
    setEditingCharacter(prev => {
      const updatedRelationships = [...prev.relationships];
      updatedRelationships.splice(index, 1);
      
      return {
        ...prev,
        relationships: updatedRelationships
      };
    });
  };
  
  // Handle AI parameter change
  const handleAIParamChange = (param, value) => {
    setAiParams(prev => ({
      ...prev,
      [param]: value
    }));
  };
  
  // Handle AI traits change
  const handleAITraitsChange = (value) => {
    const traits = value.split(',').map(trait => trait.trim()).filter(trait => trait);
    setAiParams(prev => ({
      ...prev,
      traits
    }));
  };
  
  // Generate character with AI
  const handleGenerateCharacter = async () => {
    setLoading(true);
    
    try {
      const result = await generateCharacter(aiParams);
      
      // Create a new character from the AI result
      const aiCharacter = {
        id: `character-${Date.now()}`,
        name: result.character.name,
        role: result.character.role,
        age: result.character.age.toString(),
        occupation: result.character.occupation,
        physicalDescription: result.character.physicalDescription,
        personality: {
          traits: result.character.personality.traits,
          flaws: result.character.personality.flaws,
          motivations: result.character.personality.motivations
        },
        background: result.character.background,
        relationships: result.character.relationships.map(rel => ({
          type: rel.type,
          description: rel.description
        })),
        arc: result.character.arc,
        notes: `AI-generated character based on ${aiParams.genre} genre.`
      };
      
      setEditingCharacter(aiCharacter);
      setIsCreating(true);
      setIsEditing(false);
      setShowAIGenerator(false);
    } catch (error) {
      console.error('Failed to generate character:', error);
      alert('Failed to generate character. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  // Filter characters based on search term
  const filteredCharacters = characters.filter(character => 
    character.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    character.role.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      {/* Header */}
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-b border-gray-200 dark:border-gray-600">
        <h2 className="text-lg font-medium flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-primary" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
          </svg>
          Character Manager
        </h2>
      </div>
      
      {/* Main content */}
      <div className="flex flex-col md:flex-row">
        {/* Character list sidebar */}
        <div className="w-full md:w-1/3 border-r border-gray-200 dark:border-gray-600">
          <div className="p-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium">Characters</h3>
              <div className="flex space-x-2">
                <button
                  className="btn btn-sm btn-outline"
                  onClick={() => setShowAIGenerator(!showAIGenerator)}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
                  </svg>
                  AI
                </button>
                <button
                  className="btn btn-sm btn-primary"
                  onClick={handleCreateNew}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                  </svg>
                  New
                </button>
              </div>
            </div>
            
            {/* Search */}
            <div className="mb-4">
              <input
                type="text"
                className="input w-full"
                placeholder="Search characters..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            {/* Character list */}
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {filteredCharacters.length === 0 ? (
                <div className="text-center py-4 text-gray-500 dark:text-gray-400">
                  {searchTerm ? 'No characters match your search' : 'No characters yet'}
                </div>
              ) : (
                filteredCharacters.map(character => (
                  <div
                    key={character.id}
                    className={`p-3 rounded-md cursor-pointer ${
                      activeCharacter?.id === character.id
                        ? 'bg-primary bg-opacity-10 border border-primary'
                        : 'hover:bg-gray-100 dark:hover:bg-gray-700 border border-transparent'
                    }`}
                    onClick={() => handleSelectCharacter(character)}
                  >
                    <div className="font-medium">{character.name}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400 flex justify-between">
                      <span>{character.role}</span>
                      {character.age && <span>Age: {character.age}</span>}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
        
        {/* Character detail/edit panel */}
        <div className="w-full md:w-2/3 p-4">
          {showAIGenerator ? (
            <div>
              <h3 className="font-medium mb-4">AI Character Generator</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Name (optional)</label>
                  <input
                    type="text"
                    className="input w-full"
                    placeholder="Leave blank for AI to generate"
                    value={aiParams.name}
                    onChange={(e) => handleAIParamChange('name', e.target.value)}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Role</label>
                  <select
                    className="input w-full"
                    value={aiParams.role}
                    onChange={(e) => handleAIParamChange('role', e.target.value)}
                  >
                    <option value="protagonist">Protagonist</option>
                    <option value="antagonist">Antagonist</option>
                    <option value="supporting">Supporting Character</option>
                    <option value="mentor">Mentor</option>
                    <option value="sidekick">Sidekick</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Genre</label>
                  <select
                    className="input w-full"
                    value={aiParams.genre}
                    onChange={(e) => handleAIParamChange('genre', e.target.value)}
                  >
                    <option value="fantasy">Fantasy</option>
                    <option value="sci-fi">Science Fiction</option>
                    <option value="mystery">Mystery</option>
                    <option value="romance">Romance</option>
                    <option value="thriller">Thriller</option>
                    <option value="horror">Horror</option>
                    <option value="historical">Historical</option>
                    <option value="adventure">Adventure</option>
                    <option value="comedy">Comedy</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Character Traits (comma separated)</label>
                  <input
                    type="text"
                    className="input w-full"
                    placeholder="brave, intelligent, stubborn"
                    value={aiParams.traits.join(', ')}
                    onChange={(e) => handleAITraitsChange(e.target.value)}
                  />
                </div>
                
                <div className="flex justify-end space-x-3">
                  <button
                    className="btn btn-outline"
                    onClick={() => setShowAIGenerator(false)}
                  >
                    Cancel
                  </button>
                  <button
                    className="btn btn-primary"
                    onClick={handleGenerateCharacter}
                    disabled={loading}
                  >
                    {loading ? (
                      <span className="flex items-center">
                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Generating...
                      </span>
                    ) : 'Generate Character'}
                  </button>
                </div>
              </div>
            </div>
          ) : activeCharacter && !isEditing && !isCreating ? (
            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-medium text-xl">{activeCharacter.name}</h3>
                <div className="flex space-x-2">
                  <button
                    className="btn btn-sm btn-outline"
                    onClick={handleEdit}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                    </svg>
                    Edit
                  </button>
                  <button
                    className="btn btn-sm btn-danger"
                    onClick={handleDelete}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    Delete
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Role</span>
                  <p className="capitalize">{activeCharacter.role}</p>
                </div>
                
                <div>
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Age</span>
                  <p>{activeCharacter.age}</p>
                </div>
                
                <div>
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Occupation</span>
                  <p>{activeCharacter.occupation}</p>
                </div>
              </div>
              
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Physical Description</span>
                <p className="whitespace-pre-line">{activeCharacter.physicalDescription}</p>
              </div>
              
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Personality</span>
                <div className="ml-4">
                  <div>
                    <span className="text-xs font-medium text-gray-500 dark:text-gray-400">Traits</span>
                    <p>{activeCharacter.personality.traits.join(', ')}</p>
                  </div>
                  <div>
                    <span className="text-xs font-medium text-gray-500 dark:text-gray-400">Flaws</span>
                    <p>{activeCharacter.personality.flaws.join(', ')}</p>
                  </div>
                  <div>
                    <span className="text-xs font-medium text-gray-500 dark:text-gray-400">Motivations</span>
                    <p>{activeCharacter.personality.motivations.join(', ')}</p>
                  </div>
                </div>
              </div>
              
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Background</span>
                <p className="whitespace-pre-line">{activeCharacter.background}</p>
              </div>
              
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Character Arc</span>
                <p className="whitespace-pre-line">{activeCharacter.arc}</p>
              </div>
              
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Relationships</span>
                {activeCharacter.relationships.length === 0 ? (
                  <p className="text-gray-500 dark:text-gray-400 italic">No relationships defined</p>
                ) : (
                  <div className="space-y-2 ml-4">
                    {activeCharacter.relationships.map((rel, index) => (
                      <div key={index}>
                        <span className="text-xs font-medium">{rel.type}</span>
                        <p>{rel.description}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              {activeCharacter.notes && (
                <div>
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Notes</span>
                  <p className="whitespace-pre-line">{activeCharacter.notes}</p>
                </div>
              )}
            </div>
          ) : (isEditing || isCreating) ? (
            <div>
              <h3 className="font-medium mb-4">
                {isCreating ? 'Create New Character' : `Edit ${editingCharacter.name}`}
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Name</label>
                  <input
                    type="text"
                    className="input w-full"
                    value={editingCharacter.name}
                    onChange={(e) => handleFieldChange('name', e.target.value)}
                    placeholder="Character name"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Role</label>
                    <select
                      className="input w-full"
                      value={editingCharacter.role}
                      onChange={(e) => handleFieldChange('role', e.target.value)}
                    >
                      <option value="protagonist">Protagonist</option>
                      <option value="antagonist">Antagonist</option>
                      <option value="supporting">Supporting Character</option>
                      <option value="mentor">Mentor</option>
                      <option value="sidekick">Sidekick</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1">Age</label>
                    <input
                      type="text"
                      className="input w-full"
                      value={editingCharacter.age}
                      onChange={(e) => handleFieldChange('age', e.target.value)}
                      placeholder="Character age"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Occupation</label>
                  <input
                    type="text"
                    className="input w-full"
                    value={editingCharacter.occupation}
                    onChange={(e) => handleFieldChange('occupation', e.target.value)}
                    placeholder="Character occupation"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Physical Description</label>
                  <textarea
                    className="input w-full"
                    rows={3}
                    value={editingCharacter.physicalDescription}
                    onChange={(e) => handleFieldChange('physicalDescription', e.target.value)}
                    placeholder="Describe the character's physical appearance"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Personality</label>
                  
                  <div className="space-y-2 ml-4">
                    <div>
                      <label className="block text-xs font-medium mb-1">Traits (comma separated)</label>
                      <input
                        type="text"
                        className="input w-full"
                        value={editingCharacter.personality.traits.join(', ')}
                        onChange={(e) => handleArrayFieldChange('personality.traits', e.target.value)}
                        placeholder="brave, intelligent, curious"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs font-medium mb-1">Flaws (comma separated)</label>
                      <input
                        type="text"
                        className="input w-full"
                        value={editingCharacter.personality.flaws.join(', ')}
                        onChange={(e) => handleArrayFieldChange('personality.flaws', e.target.value)}
                        placeholder="stubborn, impatient, arrogant"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs font-medium mb-1">Motivations (comma separated)</label>
                      <input
                        type="text"
                        className="input w-full"
                        value={editingCharacter.personality.motivations.join(', ')}
                        onChange={(e) => handleArrayFieldChange('personality.motivations', e.target.value)}
                        placeholder="revenge, love, discovery"
                      />
                    </div>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Background</label>
                  <textarea
                    className="input w-full"
                    rows={3}
                    value={editingCharacter.background}
                    onChange={(e) => handleFieldChange('background', e.target.value)}
                    placeholder="Character's history and background"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Character Arc</label>
                  <textarea
                    className="input w-full"
                    rows={2}
                    value={editingCharacter.arc}
                    onChange={(e) => handleFieldChange('arc', e.target.value)}
                    placeholder="How the character changes throughout the story"
                  />
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-medium">Relationships</label>
                    <button
                      type="button"
                      className="btn btn-xs btn-outline"
                      onClick={handleAddRelationship}
                    >
                      Add Relationship
                    </button>
                  </div>
                  
                  {editingCharacter.relationships.length === 0 ? (
                    <p className="text-gray-500 dark:text-gray-400 italic text-sm">No relationships defined</p>
                  ) : (
                    <div className="space-y-3">
                      {editingCharacter.relationships.map((rel, index) => (
                        <div key={index} className="flex space-x-2 items-start">
                          <div className="flex-grow grid grid-cols-1 md:grid-cols-2 gap-2">
                            <input
                              type="text"
                              className="input"
                              value={rel.type}
                              onChange={(e) => handleUpdateRelationship(index, 'type', e.target.value)}
                              placeholder="Relationship type"
                            />
                            <input
                              type="text"
                              className="input"
                              value={rel.description}
                              onChange={(e) => handleUpdateRelationship(index, 'description', e.target.value)}
                              placeholder="Description"
                            />
                          </div>
                          <button
                            type="button"
                            className="btn btn-xs btn-danger"
                            onClick={() => handleDeleteRelationship(index)}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                              <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                            </svg>
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Notes</label>
                  <textarea
                    className="input w-full"
                    rows={2}
                    value={editingCharacter.notes}
                    onChange={(e) => handleFieldChange('notes', e.target.value)}
                    placeholder="Additional notes about the character"
                  />
                </div>
                
                <div className="flex justify-end space-x-3">
                  <button
                    className="btn btn-outline"
                    onClick={() => {
                      if (isCreating) {
                        setIsCreating(false);
                      } else {
                        setIsEditing(false);
                      }
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    className="btn btn-primary"
                    onClick={handleSave}
                    disabled={!editingCharacter.name}
                  >
                    {isCreating ? 'Create Character' : 'Save Changes'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-64">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              <p className="text-gray-500 dark:text-gray-400 mb-4">Select a character or create a new one</p>
              <button
                className="btn btn-primary"
                onClick={handleCreateNew}
              >
                Create New Character
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CharacterManager;