import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';

/**
 * CollaborativeChat - Real-time chat for document collaborators
 * 
 * This component provides a chat interface for collaborators to discuss
 * the document they're working on in real-time.
 */
const CollaborativeChat = ({ 
  documentId, 
  collaborators, 
  currentUser,
  onSendMessage,
  initialMessages = []
}) => {
  const [messages, setMessages] = useState(initialMessages);
  const [newMessage, setNewMessage] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const messagesEndRef = useRef(null);
  
  // Scroll to bottom of messages when new messages arrive
  useEffect(() => {
    if (isOpen && messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
    
    // If chat is closed and we receive new messages, increment unread count
    if (!isOpen && messages.length > initialMessages.length) {
      setUnreadCount(prev => prev + (messages.length - initialMessages.length));
    }
  }, [messages, isOpen, initialMessages.length]);
  
  // Reset unread count when opening chat
  useEffect(() => {
    if (isOpen) {
      setUnreadCount(0);
    }
  }, [isOpen]);
  
  // Subscribe to new messages
  useEffect(() => {
    // In a real implementation, this would subscribe to WebSocket events
    // For now, we'll simulate receiving messages
    
    const simulateIncomingMessage = () => {
      // Only simulate messages occasionally
      if (Math.random() > 0.7) {
        const randomCollaborator = collaborators.find(c => c.id !== currentUser?.id);
        if (randomCollaborator) {
          const newMsg = {
            id: `msg-${Date.now()}`,
            text: `This is a simulated message from ${randomCollaborator.name}`,
            sender: randomCollaborator,
            timestamp: new Date().toISOString()
          };
          
          setMessages(prev => [...prev, newMsg]);
        }
      }
    };
    
    // Simulate occasional incoming messages
    const interval = setInterval(simulateIncomingMessage, 20000);
    
    return () => clearInterval(interval);
  }, [collaborators, currentUser]);
  
  // Handle sending a new message
  const handleSendMessage = (e) => {
    e.preventDefault();
    
    if (!newMessage.trim()) return;
    
    const message = {
      id: `msg-${Date.now()}`,
      text: newMessage,
      sender: currentUser,
      timestamp: new Date().toISOString()
    };
    
    // Add message to local state
    setMessages(prev => [...prev, message]);
    
    // Clear input
    setNewMessage('');
    
    // Send to server (in a real implementation)
    if (onSendMessage) {
      onSendMessage(message);
    }
  };
  
  // Format timestamp
  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  // Toggle chat open/closed
  const toggleChat = () => {
    setIsOpen(!isOpen);
  };
  
  // Check if a message contains an @mention of the current user
  const containsMention = (text) => {
    return currentUser && text.includes(`@${currentUser.name}`);
  };
  
  return (
    <div className={`collaborative-chat ${isOpen ? 'open' : 'closed'}`}>
      {/* Chat toggle button */}
      <button 
        className="chat-toggle-btn"
        onClick={toggleChat}
        aria-label={isOpen ? "Close chat" : "Open chat"}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z" clipRule="evenodd" />
        </svg>
        {unreadCount > 0 && (
          <span className="unread-badge">{unreadCount}</span>
        )}
      </button>
      
      {/* Chat panel */}
      {isOpen && (
        <div className="chat-panel">
          <div className="chat-header">
            <h3>Document Chat</h3>
            <button 
              className="close-btn"
              onClick={toggleChat}
              aria-label="Close chat"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
          
          <div className="chat-messages">
            {messages.length === 0 ? (
              <div className="no-messages">
                No messages yet. Start the conversation!
              </div>
            ) : (
              messages.map(message => (
                <div 
                  key={message.id} 
                  className={`chat-message ${message.sender.id === currentUser?.id ? 'own-message' : ''} ${containsMention(message.text) ? 'mention' : ''}`}
                >
                  <div className="message-avatar" style={{ backgroundColor: message.sender.color || '#' + ((1<<24)*Math.random() | 0).toString(16) }}>
                    {message.sender.avatar ? (
                      <img src={message.sender.avatar} alt={message.sender.name} />
                    ) : (
                      message.sender.name.charAt(0).toUpperCase()
                    )}
                  </div>
                  <div className="message-content">
                    <div className="message-header">
                      <span className="sender-name">{message.sender.name}</span>
                      <span className="message-time">{formatTime(message.timestamp)}</span>
                    </div>
                    <div className="message-text">
                      {/* Parse @mentions and make them bold */}
                      {message.text.split(/(@\w+)/).map((part, index) => (
                        part.startsWith('@') ? (
                          <strong key={index} className="mention-text">{part}</strong>
                        ) : (
                          <span key={index}>{part}</span>
                        )
                      ))}
                    </div>
                  </div>
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>
          
          <form className="chat-input" onSubmit={handleSendMessage}>
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              aria-label="Type a message"
            />
            <button 
              type="submit" 
              disabled={!newMessage.trim()}
              aria-label="Send message"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </form>
          
          <div className="chat-footer">
            <p className="collaborator-tip">
              Tip: Use @username to mention someone
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

CollaborativeChat.propTypes = {
  documentId: PropTypes.string.isRequired,
  collaborators: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      avatar: PropTypes.string,
      color: PropTypes.string,
    })
  ).isRequired,
  currentUser: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    avatar: PropTypes.string,
  }),
  onSendMessage: PropTypes.func,
  initialMessages: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      text: PropTypes.string.isRequired,
      sender: PropTypes.object.isRequired,
      timestamp: PropTypes.string.isRequired,
    })
  ),
};

export default CollaborativeChat;