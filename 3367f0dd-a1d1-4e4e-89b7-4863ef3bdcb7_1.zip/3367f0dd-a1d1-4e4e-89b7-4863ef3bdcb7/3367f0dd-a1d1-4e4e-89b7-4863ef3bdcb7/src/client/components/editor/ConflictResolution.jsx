import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

/**
 * ConflictResolution - Handles conflicts in collaborative editing
 * 
 * This component provides an interface for resolving conflicts that occur
 * when multiple users edit the same section of a document simultaneously.
 */
const ConflictResolution = ({
  conflicts,
  onResolve,
  onCancel
}) => {
  const [selectedVersions, setSelectedVersions] = useState({});
  const [customResolutions, setCustomResolutions] = useState({});
  const [activeConflict, setActiveConflict] = useState(null);
  
  // Initialize selected versions with default choices (user's version)
  useEffect(() => {
    if (conflicts && conflicts.length > 0) {
      const initialSelections = {};
      conflicts.forEach(conflict => {
        initialSelections[conflict.id] = 'yours'; // Default to user's version
      });
      setSelectedVersions(initialSelections);
      setActiveConflict(conflicts[0].id);
    }
  }, [conflicts]);
  
  // Handle version selection for a conflict
  const handleVersionSelect = (conflictId, version) => {
    setSelectedVersions(prev => ({
      ...prev,
      [conflictId]: version
    }));
    
    // Clear custom resolution if selecting a predefined version
    if (version !== 'custom') {
      setCustomResolutions(prev => ({
        ...prev,
        [conflictId]: undefined
      }));
    }
  };
  
  // Handle custom resolution text changes
  const handleCustomResolutionChange = (conflictId, text) => {
    setCustomResolutions(prev => ({
      ...prev,
      [conflictId]: text
    }));
    
    // Set selection to custom
    setSelectedVersions(prev => ({
      ...prev,
      [conflictId]: 'custom'
    }));
  };
  
  // Handle resolving all conflicts
  const handleResolveAll = () => {
    const resolutions = conflicts.map(conflict => {
      const selection = selectedVersions[conflict.id];
      let resolvedText;
      
      if (selection === 'yours') {
        resolvedText = conflict.yourVersion;
      } else if (selection === 'theirs') {
        resolvedText = conflict.theirVersion;
      } else if (selection === 'both') {
        resolvedText = `${conflict.yourVersion}\n\n${conflict.theirVersion}`;
      } else if (selection === 'custom') {
        resolvedText = customResolutions[conflict.id] || conflict.yourVersion;
      } else {
        resolvedText = conflict.yourVersion; // Default to yours
      }
      
      return {
        id: conflict.id,
        resolvedText,
        selection
      };
    });
    
    onResolve(resolutions);
  };
  
  // If no conflicts, don't render
  if (!conflicts || conflicts.length === 0) {
    return null;
  }
  
  return (
    <div className="conflict-resolution">
      <div className="conflict-resolution-overlay" />
      
      <div className="conflict-resolution-modal">
        <div className="conflict-resolution-header">
          <h2>Resolve Editing Conflicts</h2>
          <p>
            {conflicts.length === 1 
              ? 'There is 1 conflict that needs to be resolved.' 
              : `There are ${conflicts.length} conflicts that need to be resolved.`
            }
          </p>
        </div>
        
        <div className="conflict-resolution-content">
          <div className="conflict-list">
            {conflicts.map(conflict => (
              <button
                key={conflict.id}
                className={`conflict-item ${activeConflict === conflict.id ? 'active' : ''}`}
                onClick={() => setActiveConflict(conflict.id)}
              >
                <span className="conflict-item-title">
                  Conflict {conflict.index + 1}
                </span>
                <span className="conflict-item-status">
                  {selectedVersions[conflict.id] === 'yours' && 'Your version'}
                  {selectedVersions[conflict.id] === 'theirs' && `${conflict.user.name}'s version`}
                  {selectedVersions[conflict.id] === 'both' && 'Both versions'}
                  {selectedVersions[conflict.id] === 'custom' && 'Custom resolution'}
                </span>
              </button>
            ))}
          </div>
          
          <div className="conflict-details">
            {conflicts.map(conflict => (
              <div 
                key={conflict.id}
                className={`conflict-detail ${activeConflict === conflict.id ? 'active' : ''}`}
              >
                <div className="conflict-info">
                  <p>
                    <strong>Location:</strong> {conflict.location}
                  </p>
                  <p>
                    <strong>Conflicting with:</strong> {conflict.user.name}
                  </p>
                  <p>
                    <strong>Last edited:</strong> {new Date(conflict.timestamp).toLocaleString()}
                  </p>
                </div>
                
                <div className="conflict-versions">
                  <div className="version-selector">
                    <label className={`version-option ${selectedVersions[conflict.id] === 'yours' ? 'selected' : ''}`}>
                      <input
                        type="radio"
                        name={`version-${conflict.id}`}
                        checked={selectedVersions[conflict.id] === 'yours'}
                        onChange={() => handleVersionSelect(conflict.id, 'yours')}
                      />
                      <span className="version-label">Your Version</span>
                    </label>
                    
                    <label className={`version-option ${selectedVersions[conflict.id] === 'theirs' ? 'selected' : ''}`}>
                      <input
                        type="radio"
                        name={`version-${conflict.id}`}
                        checked={selectedVersions[conflict.id] === 'theirs'}
                        onChange={() => handleVersionSelect(conflict.id, 'theirs')}
                      />
                      <span className="version-label">Their Version</span>
                    </label>
                    
                    <label className={`version-option ${selectedVersions[conflict.id] === 'both' ? 'selected' : ''}`}>
                      <input
                        type="radio"
                        name={`version-${conflict.id}`}
                        checked={selectedVersions[conflict.id] === 'both'}
                        onChange={() => handleVersionSelect(conflict.id, 'both')}
                      />
                      <span className="version-label">Keep Both</span>
                    </label>
                    
                    <label className={`version-option ${selectedVersions[conflict.id] === 'custom' ? 'selected' : ''}`}>
                      <input
                        type="radio"
                        name={`version-${conflict.id}`}
                        checked={selectedVersions[conflict.id] === 'custom'}
                        onChange={() => handleVersionSelect(conflict.id, 'custom')}
                      />
                      <span className="version-label">Custom</span>
                    </label>
                  </div>
                  
                  <div className="version-comparison">
                    <div className="version-content yours">
                      <h4>Your Version</h4>
                      <div className="version-text">
                        {conflict.yourVersion}
                      </div>
                    </div>
                    
                    <div className="version-content theirs">
                      <h4>Their Version</h4>
                      <div className="version-text">
                        {conflict.theirVersion}
                      </div>
                    </div>
                  </div>
                  
                  {selectedVersions[conflict.id] === 'custom' && (
                    <div className="custom-resolution">
                      <h4>Custom Resolution</h4>
                      <textarea
                        value={customResolutions[conflict.id] || ''}
                        onChange={(e) => handleCustomResolutionChange(conflict.id, e.target.value)}
                        placeholder="Enter your custom resolution here..."
                        rows={5}
                      />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="conflict-resolution-footer">
          <button 
            className="btn btn-outline"
            onClick={onCancel}
          >
            Cancel
          </button>
          <button 
            className="btn btn-primary"
            onClick={handleResolveAll}
          >
            Resolve All Conflicts
          </button>
        </div>
      </div>
    </div>
  );
};

ConflictResolution.propTypes = {
  conflicts: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      index: PropTypes.number.isRequired,
      location: PropTypes.string.isRequired,
      yourVersion: PropTypes.string.isRequired,
      theirVersion: PropTypes.string.isRequired,
      user: PropTypes.shape({
        id: PropTypes.string.isRequired,
        name: PropTypes.string.isRequired,
      }).isRequired,
      timestamp: PropTypes.string.isRequired,
    })
  ).isRequired,
  onResolve: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
};

export default ConflictResolution;