import React, { useState, useRef } from 'react';
import PropTypes from 'prop-types';
import StoryEditor from './StoryEditor';
import WritingAnalytics from '../analytics/WritingAnalytics';

/**
 * StoryEditorWithAnalytics - Enhanced story editor with writing analytics
 * 
 * This component wraps the StoryEditor component and adds advanced writing analytics
 * for insights into readability, structure, pacing, dialogue, and character development.
 */
const StoryEditorWithAnalytics = ({ initialStory, onSave }) => {
  const [story, setStory] = useState(initialStory || {});
  const [showAnalytics, setShowAnalytics] = useState(false);
  const editorRef = useRef(null);
  
  // Handle story save
  const handleSave = (updatedStory) => {
    setStory(updatedStory);
    
    if (onSave) {
      onSave(updatedStory);
    }
  };
  
  // Toggle analytics modal
  const toggleAnalytics = () => {
    setShowAnalytics(!showAnalytics);
  };
  
  return (
    <div className="story-editor-with-analytics">
      {/* Analytics button */}
      <div className="analytics-button-container">
        <button 
          className="analytics-button"
          onClick={toggleAnalytics}
          title="Analyze writing"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
            <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
          </svg>
          Analyze
        </button>
      </div>
      
      {/* Story Editor */}
      <StoryEditor 
        ref={editorRef}
        initialStory={initialStory}
        onSave={handleSave}
      />
      
      {/* Writing Analytics Modal */}
      {showAnalytics && (
        <WritingAnalytics
          content={story.content || ''}
          title={story.title || 'Untitled Story'}
          onClose={toggleAnalytics}
        />
      )}
    </div>
  );
};

StoryEditorWithAnalytics.propTypes = {
  initialStory: PropTypes.shape({
    id: PropTypes.string,
    title: PropTypes.string,
    content: PropTypes.string,
    author: PropTypes.string,
    genres: PropTypes.arrayOf(PropTypes.string),
    tags: PropTypes.arrayOf(PropTypes.string),
    controls: PropTypes.object,
    template: PropTypes.string,
    createdAt: PropTypes.string,
    updatedAt: PropTypes.string
  }),
  onSave: PropTypes.func
};

export default StoryEditorWithAnalytics;