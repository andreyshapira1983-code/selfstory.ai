import React, { useState, useEffect, useRef } from 'react';

/**
 * World Map Builder Component
 * 
 * Provides an interactive map creation tool for story settings
 * Allows for creating, editing, and organizing locations on a map
 */
const WorldMapBuilder = ({
  mapData = null,
  locations = [],
  onSaveMap,
  onAddMapLocation,
  onUpdateMapLocation,
  onDeleteMapLocation
}) => {
  // Map state
  const [map, setMap] = useState({
    id: mapData?.id || `map-${Date.now()}`,
    name: mapData?.name || 'New Map',
    description: mapData?.description || '',
    width: mapData?.width || 1000,
    height: mapData?.height || 800,
    backgroundImage: mapData?.backgroundImage || null,
    backgroundType: mapData?.backgroundType || 'grid', // grid, image, color
    backgroundColor: mapData?.backgroundColor || '#f3f4f6',
    gridSize: mapData?.gridSize || 20,
    gridColor: mapData?.gridColor || '#e5e7eb',
    scale: mapData?.scale || { unit: 'miles', value: 10 }, // miles, km, days, etc.
    locations: mapData?.locations || []
  });
  
  // UI state
  const [activeLocation, setActiveLocation] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [isEditingMap, setIsEditingMap] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [mapOffset, setMapOffset] = useState({ x: 0, y: 0 });
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTool, setSelectedTool] = useState('select'); // select, add, measure, pan
  const [showGrid, setShowGrid] = useState(true);
  const [showLabels, setShowLabels] = useState(true);
  const [imageFile, setImageFile] = useState(null);
  
  // Refs
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const fileInputRef = useRef(null);
  
  // New location template
  const newLocationTemplate = {
    id: '',
    name: '',
    type: 'landmark', // landmark, city, dungeon, etc.
    description: '',
    x: 0,
    y: 0,
    icon: 'circle', // circle, square, triangle, star, custom
    iconColor: '#3B82F6',
    size: 10, // Size in pixels
    notes: '',
    connections: [] // IDs of connected locations
  };
  
  // Location being edited
  const [editingLocation, setEditingLocation] = useState({...newLocationTemplate});
  
  // Location types with icons and colors
  const locationTypes = [
    { id: 'landmark', name: 'Landmark', icon: 'circle', color: '#3B82F6' }, // Blue
    { id: 'city', name: 'City', icon: 'square', color: '#10B981' }, // Green
    { id: 'town', name: 'Town', icon: 'square', color: '#6B7280' }, // Gray
    { id: 'dungeon', name: 'Dungeon', icon: 'triangle', color: '#EF4444' }, // Red
    { id: 'forest', name: 'Forest', icon: 'circle', color: '#10B981' }, // Green
    { id: 'mountain', name: 'Mountain', icon: 'triangle', color: '#6B7280' }, // Gray
    { id: 'water', name: 'Water', icon: 'circle', color: '#3B82F6' }, // Blue
    { id: 'poi', name: 'Point of Interest', icon: 'star', color: '#F59E0B' } // Amber
  ];
  
  // Initialize map locations
  useEffect(() => {
    if (mapData) {
      setMap(mapData);
    } else if (locations.length > 0) {
      // Convert regular locations to map locations
      const mapLocations = locations.map(loc => ({
        id: loc.id,
        name: loc.name,
        type: 'landmark',
        description: loc.description || '',
        x: Math.random() * 800, // Random position
        y: Math.random() * 600, // Random position
        icon: 'circle',
        iconColor: '#3B82F6',
        size: 10,
        notes: loc.notes || '',
        connections: []
      }));
      
      setMap(prev => ({
        ...prev,
        locations: mapLocations
      }));
    }
  }, [mapData, locations]);
  
  // Draw the map when it changes
  useEffect(() => {
    drawMap();
  }, [map, zoomLevel, mapOffset, showGrid, showLabels, activeLocation]);
  
  // Handle location selection
  const handleSelectLocation = (location) => {
    setActiveLocation(location);
    setEditingLocation(location);
    setIsEditing(false);
    setIsCreating(false);
    setSelectedTool('select');
  };
  
  // Handle creating new location
  const handleCreateNew = (x = null, y = null) => {
    const newId = `map-location-${Date.now()}`;
    
    // If x and y are provided, use them; otherwise use center of visible area
    const canvas = canvasRef.current;
    const centerX = x !== null ? x : (canvas.width / 2 - mapOffset.x) / zoomLevel;
    const centerY = y !== null ? y : (canvas.height / 2 - mapOffset.y) / zoomLevel;
    
    setEditingLocation({
      ...newLocationTemplate,
      id: newId,
      x: centerX,
      y: centerY
    });
    
    setActiveLocation(null);
    setIsEditing(false);
    setIsCreating(true);
    setSelectedTool('select');
  };
  
  // Handle editing location
  const handleEdit = () => {
    setIsEditing(true);
    setIsCreating(false);
    setSelectedTool('select');
  };
  
  // Handle saving location
  const handleSaveLocation = () => {
    if (isCreating) {
      // Add the new location
      const updatedLocations = [...map.locations, editingLocation];
      
      setMap(prev => ({
        ...prev,
        locations: updatedLocations
      }));
      
      setActiveLocation(editingLocation);
      
      // Notify parent component
      if (onAddMapLocation) {
        onAddMapLocation(editingLocation);
      }
    } else {
      // Update the existing location
      const updatedLocations = map.locations.map(loc => 
        loc.id === editingLocation.id ? editingLocation : loc
      );
      
      setMap(prev => ({
        ...prev,
        locations: updatedLocations
      }));
      
      setActiveLocation(editingLocation);
      
      // Notify parent component
      if (onUpdateMapLocation) {
        onUpdateMapLocation(editingLocation);
      }
    }
    
    setIsEditing(false);
    setIsCreating(false);
    
    // Save the entire map
    if (onSaveMap) {
      onSaveMap({
        ...map,
        locations: isCreating 
          ? [...map.locations, editingLocation]
          : map.locations.map(loc => loc.id === editingLocation.id ? editingLocation : loc)
      });
    }
  };
  
  // Handle deleting location
  const handleDeleteLocation = () => {
    if (window.confirm(`Are you sure you want to delete "${activeLocation.name}"?`)) {
      // Remove the location
      const updatedLocations = map.locations.filter(loc => loc.id !== activeLocation.id);
      
      // Also remove any connections to this location
      const locationsWithUpdatedConnections = updatedLocations.map(loc => ({
        ...loc,
        connections: loc.connections.filter(id => id !== activeLocation.id)
      }));
      
      setMap(prev => ({
        ...prev,
        locations: locationsWithUpdatedConnections
      }));
      
      setActiveLocation(null);
      setEditingLocation({...newLocationTemplate});
      setIsEditing(false);
      setIsCreating(false);
      
      // Notify parent component
      if (onDeleteMapLocation) {
        onDeleteMapLocation(activeLocation.id);
      }
      
      // Save the entire map
      if (onSaveMap) {
        onSaveMap({
          ...map,
          locations: locationsWithUpdatedConnections
        });
      }
    }
  };
  
  // Handle saving map settings
  const handleSaveMapSettings = () => {
    setIsEditingMap(false);
    
    // Save the entire map
    if (onSaveMap) {
      onSaveMap(map);
    }
  };
  
  // Handle field change for location
  const handleLocationFieldChange = (field, value) => {
    setEditingLocation(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  // Handle field change for map
  const handleMapFieldChange = (field, value) => {
    setMap(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  // Handle location type change
  const handleLocationTypeChange = (type) => {
    const selectedType = locationTypes.find(t => t.id === type);
    
    setEditingLocation(prev => ({
      ...prev,
      type,
      icon: selectedType ? selectedType.icon : 'circle',
      iconColor: selectedType ? selectedType.color : '#3B82F6'
    }));
  };
  
  // Handle connection toggle
  const handleConnectionToggle = (locationId) => {
    setEditingLocation(prev => {
      const connections = [...prev.connections];
      const index = connections.indexOf(locationId);
      
      if (index === -1) {
        connections.push(locationId);
      } else {
        connections.splice(index, 1);
      }
      
      return {
        ...prev,
        connections
      };
    });
  };
  
  // Handle zoom change
  const handleZoomChange = (e) => {
    setZoomLevel(parseFloat(e.target.value));
  };
  
  // Handle mouse down on canvas
  const handleMouseDown = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / zoomLevel - mapOffset.x / zoomLevel;
    const y = (e.clientY - rect.top) / zoomLevel - mapOffset.y / zoomLevel;
    
    if (selectedTool === 'pan') {
      setIsDragging(true);
      setDragStart({ x: e.clientX, y: e.clientY });
    } else if (selectedTool === 'add') {
      handleCreateNew(x, y);
    } else if (selectedTool === 'select') {
      // Check if a location was clicked
      const clickedLocation = map.locations.find(loc => {
        const dx = loc.x - x;
        const dy = loc.y - y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        return distance <= loc.size / 2;
      });
      
      if (clickedLocation) {
        handleSelectLocation(clickedLocation);
      } else {
        setActiveLocation(null);
      }
    }
  };
  
  // Handle mouse move on canvas
  const handleMouseMove = (e) => {
    if (isDragging && selectedTool === 'pan') {
      const dx = e.clientX - dragStart.x;
      const dy = e.clientY - dragStart.y;
      
      setMapOffset(prev => ({
        x: prev.x + dx,
        y: prev.y + dy
      }));
      
      setDragStart({ x: e.clientX, y: e.clientY });
    }
  };
  
  // Handle mouse up on canvas
  const handleMouseUp = () => {
    setIsDragging(false);
  };
  
  // Handle background image upload
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    setImageFile(file);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      // Create an image element to get dimensions
      const img = new Image();
      img.onload = () => {
        setMap(prev => ({
          ...prev,
          backgroundImage: event.target.result,
          backgroundType: 'image',
          width: img.width,
          height: img.height
        }));
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  };
  
  // Draw the map
  const drawMap = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const container = containerRef.current;
    
    // Set canvas size to match container
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Apply zoom and offset
    ctx.save();
    ctx.translate(mapOffset.x, mapOffset.y);
    ctx.scale(zoomLevel, zoomLevel);
    
    // Draw background
    if (map.backgroundType === 'image' && map.backgroundImage) {
      // Draw background image
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, map.width, map.height);
        
        // Continue drawing the rest of the map
        drawMapContent(ctx);
      };
      img.src = map.backgroundImage;
    } else {
      // Draw background color
      ctx.fillStyle = map.backgroundColor;
      ctx.fillRect(0, 0, map.width, map.height);
      
      // Draw grid if enabled
      if (showGrid && map.backgroundType === 'grid') {
        ctx.strokeStyle = map.gridColor;
        ctx.lineWidth = 1;
        
        // Draw vertical lines
        for (let x = 0; x <= map.width; x += map.gridSize) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, map.height);
          ctx.stroke();
        }
        
        // Draw horizontal lines
        for (let y = 0; y <= map.height; y += map.gridSize) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(map.width, y);
          ctx.stroke();
        }
      }
      
      // Continue drawing the rest of the map
      drawMapContent(ctx);
    }
    
    ctx.restore();
  };
  
  // Draw map content (locations, connections, etc.)
  const drawMapContent = (ctx) => {
    // Draw connections between locations
    map.locations.forEach(loc => {
      if (loc.connections && loc.connections.length > 0) {
        loc.connections.forEach(connId => {
          const connectedLoc = map.locations.find(l => l.id === connId);
          if (connectedLoc) {
            ctx.beginPath();
            ctx.moveTo(loc.x, loc.y);
            ctx.lineTo(connectedLoc.x, connectedLoc.y);
            ctx.strokeStyle = '#9CA3AF';
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        });
      }
    });
    
    // Draw locations
    map.locations.forEach(loc => {
      // Draw location icon
      ctx.fillStyle = loc.iconColor;
      
      if (loc.icon === 'circle') {
        ctx.beginPath();
        ctx.arc(loc.x, loc.y, loc.size / 2, 0, 2 * Math.PI);
        ctx.fill();
      } else if (loc.icon === 'square') {
        ctx.fillRect(loc.x - loc.size / 2, loc.y - loc.size / 2, loc.size, loc.size);
      } else if (loc.icon === 'triangle') {
        ctx.beginPath();
        ctx.moveTo(loc.x, loc.y - loc.size / 2);
        ctx.lineTo(loc.x + loc.size / 2, loc.y + loc.size / 2);
        ctx.lineTo(loc.x - loc.size / 2, loc.y + loc.size / 2);
        ctx.closePath();
        ctx.fill();
      } else if (loc.icon === 'star') {
        const spikes = 5;
        const outerRadius = loc.size / 2;
        const innerRadius = outerRadius / 2;
        
        ctx.beginPath();
        for (let i = 0; i < spikes * 2; i++) {
          const radius = i % 2 === 0 ? outerRadius : innerRadius;
          const angle = (Math.PI * i) / spikes;
          ctx.lineTo(
            loc.x + radius * Math.sin(angle),
            loc.y - radius * Math.cos(angle)
          );
        }
        ctx.closePath();
        ctx.fill();
      }
      
      // Highlight active location
      if (activeLocation && loc.id === activeLocation.id) {
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        // Draw selection ring
        ctx.beginPath();
        ctx.arc(loc.x, loc.y, loc.size / 2 + 4, 0, 2 * Math.PI);
        ctx.strokeStyle = '#3B82F6';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      
      // Draw location label if showLabels is true
      if (showLabels) {
        ctx.fillStyle = '#000000';
        ctx.font = '12px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';
        ctx.fillText(loc.name, loc.x, loc.y + loc.size / 2 + 4);
      }
    });
  };
  
  // Get location type name
  const getLocationTypeName = (typeId) => {
    const type = locationTypes.find(t => t.id === typeId);
    return type ? type.name : 'Location';
  };
  
  // Filter locations based on search term
  const filteredLocations = map.locations.filter(loc => 
    loc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    loc.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    getLocationTypeName(loc.type).toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      {/* Header */}
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-b border-gray-200 dark:border-gray-600">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-medium flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-primary" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M12 1.586l-4 4v12.828l4-4V1.586zM3.707 3.293A1 1 0 002 4v10a1 1 0 00.293.707L6 18.414V5.586L3.707 3.293zM17.707 5.293L14 1.586v12.828l2.293 2.293A1 1 0 0018 16V6a1 1 0 00-.293-.707z" clipRule="evenodd" />
            </svg>
            {map.name}
          </h2>
          <button
            className="btn btn-sm btn-outline"
            onClick={() => setIsEditingMap(true)}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
            </svg>
            Map Settings
          </button>
        </div>
      </div>
      
      {/* Main content */}
      <div className="p-4">
        {/* Map settings modal */}
        {isEditingMap && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-2xl font-bold">Map Settings</h2>
                  <button
                    className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                    onClick={() => setIsEditingMap(false)}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Map Name</label>
                    <input
                      type="text"
                      className="input w-full"
                      value={map.name}
                      onChange={(e) => handleMapFieldChange('name', e.target.value)}
                      placeholder="Map name"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1">Description</label>
                    <textarea
                      className="input w-full"
                      rows={3}
                      value={map.description}
                      onChange={(e) => handleMapFieldChange('description', e.target.value)}
                      placeholder="Map description"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Width (px)</label>
                      <input
                        type="number"
                        className="input w-full"
                        value={map.width}
                        onChange={(e) => handleMapFieldChange('width', parseInt(e.target.value))}
                        min={100}
                        max={5000}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Height (px)</label>
                      <input
                        type="number"
                        className="input w-full"
                        value={map.height}
                        onChange={(e) => handleMapFieldChange('height', parseInt(e.target.value))}
                        min={100}
                        max={5000}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1">Background Type</label>
                    <div className="flex space-x-4">
                      <label className="inline-flex items-center">
                        <input
                          type="radio"
                          className="form-radio"
                          name="backgroundType"
                          value="grid"
                          checked={map.backgroundType === 'grid'}
                          onChange={() => handleMapFieldChange('backgroundType', 'grid')}
                        />
                        <span className="ml-2">Grid</span>
                      </label>
                      <label className="inline-flex items-center">
                        <input
                          type="radio"
                          className="form-radio"
                          name="backgroundType"
                          value="color"
                          checked={map.backgroundType === 'color'}
                          onChange={() => handleMapFieldChange('backgroundType', 'color')}
                        />
                        <span className="ml-2">Color</span>
                      </label>
                      <label className="inline-flex items-center">
                        <input
                          type="radio"
                          className="form-radio"
                          name="backgroundType"
                          value="image"
                          checked={map.backgroundType === 'image'}
                          onChange={() => handleMapFieldChange('backgroundType', 'image')}
                        />
                        <span className="ml-2">Image</span>
                      </label>
                    </div>
                  </div>
                  
                  {map.backgroundType === 'grid' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Grid Size</label>
                        <input
                          type="number"
                          className="input w-full"
                          value={map.gridSize}
                          onChange={(e) => handleMapFieldChange('gridSize', parseInt(e.target.value))}
                          min={10}
                          max={100}
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-1">Grid Color</label>
                        <input
                          type="color"
                          className="input w-full h-10"
                          value={map.gridColor}
                          onChange={(e) => handleMapFieldChange('gridColor', e.target.value)}
                        />
                      </div>
                    </div>
                  )}
                  
                  {map.backgroundType === 'color' && (
                    <div>
                      <label className="block text-sm font-medium mb-1">Background Color</label>
                      <input
                        type="color"
                        className="input w-full h-10"
                        value={map.backgroundColor}
                        onChange={(e) => handleMapFieldChange('backgroundColor', e.target.value)}
                      />
                    </div>
                  )}
                  
                  {map.backgroundType === 'image' && (
                    <div>
                      <label className="block text-sm font-medium mb-1">Background Image</label>
                      <div className="flex items-center space-x-2">
                        <button
                          className="btn btn-outline"
                          onClick={() => fileInputRef.current.click()}
                        >
                          {map.backgroundImage ? 'Change Image' : 'Upload Image'}
                        </button>
                        {map.backgroundImage && (
                          <button
                            className="btn btn-danger"
                            onClick={() => handleMapFieldChange('backgroundImage', null)}
                          >
                            Remove Image
                          </button>
                        )}
                      </div>
                      <input
                        type="file"
                        ref={fileInputRef}
                        className="hidden"
                        accept="image/*"
                        onChange={handleImageUpload}
                      />
                      {map.backgroundImage && (
                        <div className="mt-2">
                          <img
                            src={map.backgroundImage}
                            alt="Map background"
                            className="max-h-40 rounded border border-gray-200 dark:border-gray-700"
                          />
                        </div>
                      )}
                    </div>
                  )}
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Scale Unit</label>
                      <select
                        className="input w-full"
                        value={map.scale.unit}
                        onChange={(e) => handleMapFieldChange('scale', { ...map.scale, unit: e.target.value })}
                      >
                        <option value="miles">Miles</option>
                        <option value="km">Kilometers</option>
                        <option value="days">Travel Days</option>
                        <option value="custom">Custom</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Scale Value (per 100px)</label>
                      <input
                        type="number"
                        className="input w-full"
                        value={map.scale.value}
                        onChange={(e) => handleMapFieldChange('scale', { ...map.scale, value: parseFloat(e.target.value) })}
                        min={0.1}
                        step={0.1}
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-end space-x-3 mt-6">
                    <button
                      className="btn btn-outline"
                      onClick={() => setIsEditingMap(false)}
                    >
                      Cancel
                    </button>
                    <button
                      className="btn btn-primary"
                      onClick={handleSaveMapSettings}
                    >
                      Save Settings
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Controls */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 space-y-2 md:space-y-0">
          <div className="flex items-center space-x-2">
            <div className="flex space-x-1 border border-gray-200 dark:border-gray-700 rounded-md">
              <button
                className={`p-2 ${
                  selectedTool === 'select'
                    ? 'bg-primary text-white'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
                onClick={() => setSelectedTool('select')}
                title="Select Tool"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M6.672 1.911a1 1 0 10-1.932.518l.259.966a1 1 0 001.932-.518l-.26-.966zM2.429 4.74a1 1 0 10-.517 1.932l.966.259a1 1 0 00.517-1.932l-.966-.26zm8.814-.569a1 1 0 00-1.415-1.414l-.707.707a1 1 0 101.415 1.415l.707-.708zm-7.071 7.072l.707-.707A1 1 0 003.465 9.12l-.708.707a1 1 0 001.415 1.415zm3.2-5.171a1 1 0 00-1.3 1.3l4 10a1 1 0 001.823.075l1.38-2.759 3.018 3.02a1 1 0 001.414-1.415l-3.019-3.02 2.76-1.379a1 1 0 00-.076-1.822l-10-4z" clipRule="evenodd" />
                </svg>
              </button>
              <button
                className={`p-2 ${
                  selectedTool === 'add'
                    ? 'bg-primary text-white'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
                onClick={() => setSelectedTool('add')}
                title="Add Location"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                </svg>
              </button>
              <button
                className={`p-2 ${
                  selectedTool === 'pan'
                    ? 'bg-primary text-white'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
                onClick={() => setSelectedTool('pan')}
                title="Pan Tool"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M7.707 3.293a1 1 0 010 1.414L5.414 7H11a7 7 0 017 7v2a1 1 0 11-2 0v-2a5 5 0 00-5-5H5.414l2.293 2.293a1 1 0 11-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
            
            <button
              className="btn btn-primary"
              onClick={() => handleCreateNew()}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
              </svg>
              Add Location
            </button>
          </div>
          
          <div className="flex items-center space-x-2 w-full md:w-auto">
            <input
              type="text"
              className="input"
              placeholder="Search locations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            
            <div className="flex items-center space-x-2">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="showGrid"
                  className="mr-1"
                  checked={showGrid}
                  onChange={() => setShowGrid(!showGrid)}
                />
                <label htmlFor="showGrid" className="text-sm">Grid</label>
              </div>
              
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="showLabels"
                  className="mr-1"
                  checked={showLabels}
                  onChange={() => setShowLabels(!showLabels)}
                />
                <label htmlFor="showLabels" className="text-sm">Labels</label>
              </div>
              
              <div className="flex items-center space-x-1">
                <button
                  className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
                  onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.1))}
                  title="Zoom Out"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M5 10a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1z" clipRule="evenodd" />
                  </svg>
                </button>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={zoomLevel}
                  onChange={handleZoomChange}
                  className="w-20"
                />
                <button
                  className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
                  onClick={() => setZoomLevel(Math.min(2, zoomLevel + 0.1))}
                  title="Zoom In"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Map visualization */}
        <div 
          className="relative mb-6 bg-gray-50 dark:bg-gray-700 rounded-lg overflow-hidden"
          ref={containerRef}
          style={{ height: '500px' }}
        >
          <canvas 
            ref={canvasRef} 
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            className="cursor-pointer"
          />
        </div>
        
        {/* Location list */}
        <div className="mb-6">
          <h3 className="font-medium mb-2">Locations</h3>
          
          {filteredLocations.length === 0 ? (
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 text-center">
              <p className="text-gray-500 dark:text-gray-400">
                {searchTerm ? 'No locations match your search' : 'No locations on this map yet.'}
              </p>
            </div>
          ) : (
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-600">
                  <thead className="bg-gray-100 dark:bg-gray-800">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Name</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Type</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Description</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Connections</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-600">
                    {filteredLocations.map(loc => (
                      <tr 
                        key={loc.id}
                        className={`hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer ${
                          activeLocation?.id === loc.id ? 'bg-blue-50 dark:bg-blue-900 dark:bg-opacity-20' : ''
                        }`}
                        onClick={() => handleSelectLocation(loc)}
                      >
                        <td className="px-4 py-2">{loc.name}</td>
                        <td className="px-4 py-2">
                          <span 
                            className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium text-white"
                            style={{ 
                              backgroundColor: loc.iconColor
                            }}
                          >
                            {getLocationTypeName(loc.type)}
                          </span>
                        </td>
                        <td className="px-4 py-2 truncate max-w-xs">{loc.description}</td>
                        <td className="px-4 py-2">
                          {loc.connections.length > 0 ? (
                            <span className="text-sm">
                              {loc.connections.length} connection{loc.connections.length !== 1 ? 's' : ''}
                            </span>
                          ) : (
                            <span className="text-sm text-gray-500 dark:text-gray-400">None</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
        
        {/* Location detail/edit panel */}
        {activeLocation && !isEditing && !isCreating ? (
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-medium text-xl">{activeLocation.name}</h3>
                <div className="flex items-center mt-1">
                  <span 
                    className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium text-white mr-2"
                    style={{ 
                      backgroundColor: activeLocation.iconColor
                    }}
                  >
                    {getLocationTypeName(activeLocation.type)}
                  </span>
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    Position: {Math.round(activeLocation.x)}, {Math.round(activeLocation.y)}
                  </span>
                </div>
              </div>
              <div className="flex space-x-2">
                <button
                  className="btn btn-sm btn-outline"
                  onClick={handleEdit}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                  </svg>
                  Edit
                </button>
                <button
                  className="btn btn-sm btn-danger"
                  onClick={handleDeleteLocation}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  Delete
                </button>
              </div>
            </div>
            
            {activeLocation.description && (
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Description</span>
                <p className="whitespace-pre-line">{activeLocation.description}</p>
              </div>
            )}
            
            {activeLocation.connections.length > 0 && (
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Connected to</span>
                <div className="flex flex-wrap gap-2 mt-1">
                  {activeLocation.connections.map(connId => {
                    const connLoc = map.locations.find(l => l.id === connId);
                    return connLoc ? (
                      <span 
                        key={connId}
                        className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 dark:bg-gray-600"
                      >
                        {connLoc.name}
                      </span>
                    ) : null;
                  })}
                </div>
              </div>
            )}
            
            {activeLocation.notes && (
              <div>
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Notes</span>
                <p className="whitespace-pre-line">{activeLocation.notes}</p>
              </div>
            )}
          </div>
        ) : (isEditing || isCreating) ? (
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <h3 className="font-medium mb-4">
              {isCreating ? 'Create New Location' : `Edit ${editingLocation.name}`}
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Name</label>
                <input
                  type="text"
                  className="input w-full"
                  value={editingLocation.name}
                  onChange={(e) => handleLocationFieldChange('name', e.target.value)}
                  placeholder="Location name"
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Location Type</label>
                  <select
                    className="input w-full"
                    value={editingLocation.type}
                    onChange={(e) => handleLocationTypeChange(e.target.value)}
                  >
                    {locationTypes.map(type => (
                      <option key={type.id} value={type.id}>{type.name}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Icon Color</label>
                  <input
                    type="color"
                    className="input w-full h-10"
                    value={editingLocation.iconColor}
                    onChange={(e) => handleLocationFieldChange('iconColor', e.target.value)}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Size</label>
                  <input
                    type="number"
                    className="input w-full"
                    value={editingLocation.size}
                    onChange={(e) => handleLocationFieldChange('size', parseInt(e.target.value))}
                    min={5}
                    max={30}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">X Position</label>
                  <input
                    type="number"
                    className="input w-full"
                    value={Math.round(editingLocation.x)}
                    onChange={(e) => handleLocationFieldChange('x', parseInt(e.target.value))}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Y Position</label>
                  <input
                    type="number"
                    className="input w-full"
                    value={Math.round(editingLocation.y)}
                    onChange={(e) => handleLocationFieldChange('y', parseInt(e.target.value))}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Description</label>
                <textarea
                  className="input w-full"
                  rows={3}
                  value={editingLocation.description}
                  onChange={(e) => handleLocationFieldChange('description', e.target.value)}
                  placeholder="Describe this location"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Connected Locations</label>
                {map.locations.length <= 1 ? (
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    No other locations available to connect to.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-40 overflow-y-auto p-2 border border-gray-200 dark:border-gray-700 rounded">
                    {map.locations
                      .filter(loc => loc.id !== editingLocation.id)
                      .map(loc => (
                        <label key={loc.id} className="flex items-center">
                          <input
                            type="checkbox"
                            className="mr-2"
                            checked={editingLocation.connections.includes(loc.id)}
                            onChange={() => handleConnectionToggle(loc.id)}
                          />
                          <span>{loc.name}</span>
                        </label>
                      ))
                    }
                  </div>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Notes</label>
                <textarea
                  className="input w-full"
                  rows={2}
                  value={editingLocation.notes}
                  onChange={(e) => handleLocationFieldChange('notes', e.target.value)}
                  placeholder="Additional notes about this location"
                />
              </div>
              
              <div className="flex justify-end space-x-3">
                <button
                  className="btn btn-outline"
                  onClick={() => {
                    if (isCreating) {
                      setIsCreating(false);
                    } else {
                      setIsEditing(false);
                    }
                  }}
                >
                  Cancel
                </button>
                <button
                  className="btn btn-primary"
                  onClick={handleSaveLocation}
                  disabled={!editingLocation.name}
                >
                  {isCreating ? 'Create Location' : 'Save Changes'}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 text-center">
            <p className="text-gray-500 dark:text-gray-400">
              Select a location to view details or click "Add Location" to create a new one.
              <br />
              You can also click directly on the map to add a location at that position.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default WorldMapBuilder;