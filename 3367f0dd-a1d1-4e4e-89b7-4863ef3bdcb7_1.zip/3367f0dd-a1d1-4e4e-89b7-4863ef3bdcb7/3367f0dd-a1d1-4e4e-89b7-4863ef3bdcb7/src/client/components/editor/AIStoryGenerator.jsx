import React, { useState } from 'react';
import { generateStory, continueStory } from '../../utils/aiService';

/**
 * AI Story Generator Component
 * 
 * Provides tools to generate new story content or continue existing content
 * Includes options for genre, tone, length, and other parameters
 */
const AIStoryGenerator = ({ 
  existingContent = '',
  genres = [],
  controls = {},
  onInsertContent,
  onReplaceContent
}) => {
  const [generationType, setGenerationType] = useState(existingContent ? 'continue' : 'new');
  const [prompt, setPrompt] = useState('');
  const [generationParams, setGenerationParams] = useState({
    genre: genres[0] || 'fantasy',
    tone: controls.tone || 'neutral',
    length: controls.length || 'medium',
    pov: controls.pov || 'third',
    mood: controls.mood || 'neutral',
    paragraphs: 1
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [generatedContent, setGeneratedContent] = useState('');
  
  // Genre options
  const genreOptions = [
    'fantasy', 'sci-fi', 'mystery', 'romance', 'thriller', 
    'horror', 'adventure', 'historical', 'comedy', 'drama'
  ];
  
  // Handle generation type change
  const handleTypeChange = (type) => {
    setGenerationType(type);
    setGeneratedContent('');
  };
  
  // Handle prompt change
  const handlePromptChange = (e) => {
    setPrompt(e.target.value);
  };
  
  // Handle parameter change
  const handleParamChange = (param, value) => {
    setGenerationParams(prev => ({
      ...prev,
      [param]: value
    }));
  };
  
  // Generate content
  const handleGenerate = async () => {
    setLoading(true);
    setError(null);
    
    try {
      let result;
      
      if (generationType === 'new') {
        // Generate new story
        result = await generateStory({
          prompt,
          ...generationParams
        });
        
        setGeneratedContent(result.content);
      } else {
        // Continue existing story
        result = await continueStory({
          content: existingContent,
          genre: generationParams.genre,
          controls: {
            tone: generationParams.tone,
            mood: generationParams.mood,
            pov: generationParams.pov
          },
          paragraphs: generationParams.paragraphs
        });
        
        setGeneratedContent(result.continuation);
      }
    } catch (err) {
      console.error('Failed to generate content:', err);
      setError('Failed to generate content');
    } finally {
      setLoading(false);
    }
  };
  
  // Insert generated content
  const handleInsert = () => {
    if (!generatedContent) return;
    onInsertContent(generatedContent);
    setGeneratedContent('');
  };
  
  // Replace with generated content
  const handleReplace = () => {
    if (!generatedContent) return;
    onReplaceContent(generatedContent);
    setGeneratedContent('');
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
      <h3 className="text-lg font-medium mb-3">Story Generator</h3>
      
      {/* Generation type selector */}
      <div className="flex space-x-2 mb-4">
        <button
          className={`px-4 py-2 rounded-md ${
            generationType === 'new'
              ? 'bg-primary text-white'
              : 'bg-gray-100 dark:bg-gray-700'
          }`}
          onClick={() => handleTypeChange('new')}
        >
          New Story
        </button>
        <button
          className={`px-4 py-2 rounded-md ${
            generationType === 'continue'
              ? 'bg-primary text-white'
              : 'bg-gray-100 dark:bg-gray-700'
          }`}
          onClick={() => handleTypeChange('continue')}
          disabled={!existingContent}
        >
          Continue Story
        </button>
      </div>
      
      {/* New story prompt */}
      {generationType === 'new' && (
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">Story Prompt</label>
          <textarea
            value={prompt}
            onChange={handlePromptChange}
            placeholder="Describe your story idea or starting point..."
            className="w-full rounded-md border-gray-300 dark:border-gray-700 dark:bg-gray-800"
            rows={3}
          />
        </div>
      )}
      
      {/* Generation parameters */}
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Generation Parameters</label>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs mb-1">Genre</label>
            <select
              value={generationParams.genre}
              onChange={(e) => handleParamChange('genre', e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-700 dark:bg-gray-800 text-sm"
            >
              {genreOptions.map((genre) => (
                <option key={genre} value={genre}>
                  {genre.charAt(0).toUpperCase() + genre.slice(1)}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1">Tone</label>
            <select
              value={generationParams.tone}
              onChange={(e) => handleParamChange('tone', e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-700 dark:bg-gray-800 text-sm"
            >
              <option value="neutral">Neutral</option>
              <option value="formal">Formal</option>
              <option value="casual">Casual</option>
              <option value="poetic">Poetic</option>
              <option value="humorous">Humorous</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1">Length</label>
            <select
              value={generationParams.length}
              onChange={(e) => handleParamChange('length', e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-700 dark:bg-gray-800 text-sm"
            >
              <option value="short">Short</option>
              <option value="medium">Medium</option>
              <option value="long">Long</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1">Point of View</label>
            <select
              value={generationParams.pov}
              onChange={(e) => handleParamChange('pov', e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-700 dark:bg-gray-800 text-sm"
            >
              <option value="first">First Person</option>
              <option value="second">Second Person</option>
              <option value="third">Third Person</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1">Mood</label>
            <select
              value={generationParams.mood}
              onChange={(e) => handleParamChange('mood', e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-700 dark:bg-gray-800 text-sm"
            >
              <option value="neutral">Neutral</option>
              <option value="happy">Happy</option>
              <option value="sad">Sad</option>
              <option value="tense">Tense</option>
              <option value="mysterious">Mysterious</option>
            </select>
          </div>
          {generationType === 'continue' && (
            <div>
              <label className="block text-xs mb-1">Paragraphs</label>
              <select
                value={generationParams.paragraphs}
                onChange={(e) => handleParamChange('paragraphs', parseInt(e.target.value))}
                className="w-full rounded-md border-gray-300 dark:border-gray-700 dark:bg-gray-800 text-sm"
              >
                <option value="1">1 Paragraph</option>
                <option value="2">2 Paragraphs</option>
                <option value="3">3 Paragraphs</option>
                <option value="5">5 Paragraphs</option>
              </select>
            </div>
          )}
        </div>
      </div>
      
      {/* Generated content preview */}
      {generatedContent && (
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">Generated Content</label>
          <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded border border-gray-200 dark:border-gray-600 text-sm max-h-60 overflow-y-auto">
            {generatedContent}
          </div>
        </div>
      )}
      
      {/* Error message */}
      {error && (
        <div className="text-red-500 text-sm mb-4">
          {error}
        </div>
      )}
      
      <div className="flex space-x-3">
        <button
          className="btn btn-primary"
          onClick={handleGenerate}
          disabled={generationType === 'new' && !prompt || loading}
        >
          {loading ? (
            <span className="flex items-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating...
            </span>
          ) : generationType === 'new' ? 'Generate Story' : 'Continue Story'}
        </button>
        {generatedContent && (
          <>
            <button
              className="btn btn-outline"
              onClick={handleInsert}
            >
              Insert
            </button>
            <button
              className="btn btn-outline"
              onClick={handleReplace}
            >
              Replace
            </button>
          </>
        )}
      </div>
      
      <div className="mt-3 text-xs text-gray-500 dark:text-gray-400">
        {generationType === 'new' 
          ? 'Generate a new story based on your prompt and selected parameters.'
          : 'Continue your existing story with AI assistance.'}
      </div>
    </div>
  );
};

export default AIStoryGenerator;