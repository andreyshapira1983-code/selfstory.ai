import React, { useState } from 'react';
import CharacterManager from './CharacterManager';
import LocationManager from './LocationManager';
import PlotStructureVisualizer from './PlotStructureVisualizer';
import AdvancedFormattingToolbar from './AdvancedFormattingToolbar';
import AIFeedbackCollector from './AIFeedbackCollector';
import AIPersonalizationManager from './AIPersonalizationManager';

/**
 * Story Editor Toolbox Component
 * 
 * Provides access to all advanced story editing tools in a tabbed interface
 * Includes character management, location management, plot structure, formatting, and AI tools
 */
const StoryEditorToolbox = ({
  storyId,
  storyGenre = 'fantasy',
  userId,
  userContent = [],
  characters = [],
  locations = [],
  plotPoints = {},
  onAddCharacter,
  onUpdateCharacter,
  onDeleteCharacter,
  onAddLocation,
  onUpdateLocation,
  onDeleteLocation,
  onUpdatePlotPoints,
  onFormat,
  onInsert,
  onSubmitFeedback,
  onTrainAIModel,
  onUpdateAISettings
}) => {
  const [activeTab, setActiveTab] = useState('characters');
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedbackContentId, setFeedbackContentId] = useState(null);
  const [feedbackContentType, setFeedbackContentType] = useState('story');
  
  // Handle tab change
  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };
  
  // Handle showing feedback collector
  const handleShowFeedback = (contentId, contentType) => {
    setFeedbackContentId(contentId);
    setFeedbackContentType(contentType);
    setShowFeedback(true);
  };
  
  // Handle dismissing feedback collector
  const handleDismissFeedback = () => {
    setShowFeedback(false);
  };
  
  // Handle submitting feedback
  const handleSubmitFeedback = (feedbackData) => {
    if (onSubmitFeedback) {
      onSubmitFeedback(feedbackData);
    }
    setShowFeedback(false);
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
      {/* Header */}
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-b border-gray-200 dark:border-gray-600">
        <h2 className="text-lg font-medium flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-primary" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M5 4a3 3 0 00-3 3v6a3 3 0 003 3h10a3 3 0 003-3V7a3 3 0 00-3-3H5zm-1 9v-1h5v2H5a1 1 0 01-1-1zm7 1h4a1 1 0 001-1v-1h-5v2zm0-4h5V8h-5v2zM9 8H4v2h5V8z" clipRule="evenodd" />
          </svg>
          Story Editor Toolbox
        </h2>
      </div>
      
      {/* Tabs */}
      <div className="border-b border-gray-200 dark:border-gray-600">
        <nav className="flex overflow-x-auto">
          <button
            className={`py-3 px-4 text-sm font-medium whitespace-nowrap ${
              activeTab === 'characters'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('characters')}
          >
            Characters
          </button>
          <button
            className={`py-3 px-4 text-sm font-medium whitespace-nowrap ${
              activeTab === 'locations'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('locations')}
          >
            Locations
          </button>
          <button
            className={`py-3 px-4 text-sm font-medium whitespace-nowrap ${
              activeTab === 'plot'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('plot')}
          >
            Plot Structure
          </button>
          <button
            className={`py-3 px-4 text-sm font-medium whitespace-nowrap ${
              activeTab === 'formatting'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('formatting')}
          >
            Formatting
          </button>
          <button
            className={`py-3 px-4 text-sm font-medium whitespace-nowrap ${
              activeTab === 'ai'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('ai')}
          >
            AI Settings
          </button>
          <button
            className={`py-3 px-4 text-sm font-medium whitespace-nowrap ${
              activeTab === 'feedback'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('feedback')}
          >
            Feedback
          </button>
        </nav>
      </div>
      
      {/* Tab content */}
      <div className="p-4">
        {/* Characters tab */}
        {activeTab === 'characters' && (
          <CharacterManager
            characters={characters}
            onAddCharacter={onAddCharacter}
            onUpdateCharacter={onUpdateCharacter}
            onDeleteCharacter={onDeleteCharacter}
            storyGenre={storyGenre}
          />
        )}
        
        {/* Locations tab */}
        {activeTab === 'locations' && (
          <LocationManager
            locations={locations}
            onAddLocation={onAddLocation}
            onUpdateLocation={onUpdateLocation}
            onDeleteLocation={onDeleteLocation}
          />
        )}
        
        {/* Plot structure tab */}
        {activeTab === 'plot' && (
          <PlotStructureVisualizer
            initialPlotPoints={plotPoints}
            storyGenre={storyGenre}
            onUpdatePlotPoints={onUpdatePlotPoints}
          />
        )}
        
        {/* Formatting tab */}
        {activeTab === 'formatting' && (
          <div>
            <h3 className="font-medium mb-4">Text Formatting</h3>
            <AdvancedFormattingToolbar
              onFormat={onFormat}
              onInsert={onInsert}
              expanded={true}
            />
            
            <div className="mt-6">
              <h4 className="font-medium mb-2">Formatting Tips</h4>
              <div className="bg-gray-50 dark:bg-gray-700 rounded-md p-4">
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Use <strong>headings</strong> to organize your story into chapters or sections.</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Apply <em>emphasis</em> or <strong>strong emphasis</strong> to highlight important words or phrases.</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Use lists for sequences of events or items.</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Insert horizontal rules to indicate scene breaks or time passages.</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Use character and location references to maintain consistency throughout your story.</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        )}
        
        {/* AI settings tab */}
        {activeTab === 'ai' && (
          <AIPersonalizationManager
            userId={userId}
            userContent={userContent}
            onTrainModel={onTrainAIModel}
            onUpdateSettings={onUpdateAISettings}
          />
        )}
        
        {/* Feedback tab */}
        {activeTab === 'feedback' && (
          <div>
            <h3 className="font-medium mb-4">AI Content Feedback</h3>
            
            {showFeedback ? (
              <AIFeedbackCollector
                contentId={feedbackContentId}
                contentType={feedbackContentType}
                onSubmitFeedback={handleSubmitFeedback}
                onDismiss={handleDismissFeedback}
              />
            ) : (
              <div>
                <p className="text-gray-500 dark:text-gray-400 mb-4">
                  Your feedback helps us improve our AI-generated content. Select the type of content you'd like to provide feedback on:
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button
                    className="p-4 border border-gray-200 dark:border-gray-700 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 text-left"
                    onClick={() => handleShowFeedback(storyId, 'story')}
                  >
                    <h4 className="font-medium mb-1">Story Generation</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Provide feedback on AI-generated story content
                    </p>
                  </button>
                  
                  <button
                    className="p-4 border border-gray-200 dark:border-gray-700 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 text-left"
                    onClick={() => handleShowFeedback(storyId, 'suggestion')}
                  >
                    <h4 className="font-medium mb-1">AI Suggestions</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Provide feedback on AI writing suggestions
                    </p>
                  </button>
                  
                  <button
                    className="p-4 border border-gray-200 dark:border-gray-700 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 text-left"
                    onClick={() => handleShowFeedback(storyId, 'enhancement')}
                  >
                    <h4 className="font-medium mb-1">Content Enhancement</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Provide feedback on AI content enhancement
                    </p>
                  </button>
                  
                  <button
                    className="p-4 border border-gray-200 dark:border-gray-700 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 text-left"
                    onClick={() => handleShowFeedback(storyId, 'style')}
                  >
                    <h4 className="font-medium mb-1">Style Transfer</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Provide feedback on AI style transfer
                    </p>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default StoryEditorToolbox;