# AI Components for StoryAI

This directory contains AI-powered components that enhance the story writing experience in StoryAI.

## Overview

The AI components provide intelligent assistance for story creation, enhancement, and style transfer. These components connect to the AI service API to generate content, provide suggestions, and enhance existing text.

## Components

### AIToolsPanel

The main container component that integrates all AI tools into a single panel with tabs for different functionalities.

**Features:**
- Tab-based navigation between different AI tools
- Unified interface for all AI functionality
- Responsive design that works alongside the main editor

**Usage:**
```jsx
<AIToolsPanel
  content={storyContent}
  cursorPosition={cursorPosition}
  genres={storyGenres}
  controls={storyControls}
  onInsertContent={handleInsertContent}
  onReplaceContent={handleReplaceContent}
  onApplySuggestion={handleApplySuggestion}
  isVisible={true}
/>
```

### AISuggestions

Provides real-time, context-aware suggestions based on the current content and cursor position.

**Features:**
- Different suggestion types (next steps, plot ideas, character, setting)
- One-click application of suggestions
- Debounced API calls to prevent excessive requests

**Usage:**
```jsx
<AISuggestions
  content={storyContent}
  cursorPosition={cursorPosition}
  onApplySuggestion={handleApplySuggestion}
  isVisible={true}
  suggestionType="next"
/>
```

### AIStyleTransfer

Allows users to apply different writing styles to their content, such as Hemingway, Tolkien, etc.

**Features:**
- Multiple predefined style presets
- Adjustable style transfer strength
- Preview functionality before applying changes

**Usage:**
```jsx
<AIStyleTransfer
  content={storyContent}
  onApplyStyle={handleApplyStyle}
/>
```

### AIContentEnhancer

Provides tools to enhance and improve story content using AI, focusing on grammar, style, descriptions, and dialogue.

**Features:**
- Multiple focus areas for enhancement
- Section selection (entire content, last paragraph, selection)
- Custom controls for tone and mood

**Usage:**
```jsx
<AIContentEnhancer
  content={storyContent}
  onApplyEnhancement={handleApplyEnhancement}
/>
```

### AIStoryGenerator

Generates new story content or continues existing content based on specified parameters.

**Features:**
- New story generation from prompts
- Continuation of existing stories
- Customizable parameters (genre, tone, length, POV, mood)

**Usage:**
```jsx
<AIStoryGenerator
  existingContent={storyContent}
  genres={storyGenres}
  controls={storyControls}
  onInsertContent={handleInsertContent}
  onReplaceContent={handleReplaceContent}
/>
```

## AI Service

The AI components use the `aiService.js` utility to communicate with the server-side AI API. This service provides methods for:

- Story generation
- Content continuation
- Content enhancement
- Style transfer
- Suggestions
- Story analysis
- Character generation
- Plot generation

## Integration with Editor

The AI components are integrated into the StoryEditor component, which:

1. Tracks cursor position for context-aware suggestions
2. Provides handlers for inserting and replacing content
3. Manages the visibility of the AI tools panel
4. Applies AI-generated content to the editor

## Future Enhancements

Planned enhancements for the AI components include:

1. Character and location management tools
2. Plot structure visualization and assistance
3. Advanced formatting options
4. User feedback collection for AI-generated content
5. Personalized AI models based on user writing style