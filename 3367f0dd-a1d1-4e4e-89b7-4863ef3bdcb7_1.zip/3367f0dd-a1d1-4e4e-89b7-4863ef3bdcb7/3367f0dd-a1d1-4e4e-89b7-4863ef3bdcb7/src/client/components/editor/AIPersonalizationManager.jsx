import React, { useState, useEffect } from 'react';

/**
 * AI Personalization Manager Component
 * 
 * Manages personalized AI models based on user writing style
 * Includes model training, style analysis, and personalization settings
 */
const AIPersonalizationManager = ({
  userId,
  userContent = [],
  onTrainModel,
  onUpdateSettings
}) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isTraining, setIsTraining] = useState(false);
  const [styleAnalysis, setStyleAnalysis] = useState(null);
  const [modelStatus, setModelStatus] = useState('not_trained'); // not_trained, training, ready
  const [settings, setSettings] = useState({
    styleAdherence: 0.7, // 0-1, how closely to follow user's style
    creativity: 0.7, // 0-1, how creative the AI should be
    vocabulary: 0.5, // 0-1, how complex the vocabulary should be
    sentenceLength: 0.5, // 0-1, preference for shorter vs longer sentences
    usePersonalizedModel: true // whether to use the personalized model
  });
  
  // Load model status on component mount
  useEffect(() => {
    // In a real implementation, this would check the status of the user's personalized model
    // For now, we'll simulate a check based on the userId
    const checkModelStatus = async () => {
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // For demo purposes, we'll set a status based on the userId length
        if (userId && userId.length > 10) {
          setModelStatus('ready');
        } else {
          setModelStatus('not_trained');
        }
      } catch (error) {
        console.error('Failed to check model status:', error);
      }
    };
    
    checkModelStatus();
  }, [userId]);
  
  // Handle analyzing user's writing style
  const handleAnalyzeStyle = async () => {
    if (userContent.length === 0) {
      alert('No content available for analysis. Please create some stories first.');
      return;
    }
    
    setIsAnalyzing(true);
    
    try {
      // In a real implementation, this would call an API to analyze the user's writing style
      // For now, we'll simulate an analysis
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Generate a simulated analysis
      const analysis = {
        vocabulary: {
          uniqueWords: Math.floor(Math.random() * 1000) + 500,
          complexityScore: Math.random() * 0.6 + 0.2,
          favoredWords: ['perhaps', 'certainly', 'nevertheless', 'despite', 'however'],
          avoidedWords: ['very', 'really', 'actually', 'basically', 'literally']
        },
        sentenceStructure: {
          averageLength: Math.floor(Math.random() * 10) + 10,
          complexityScore: Math.random() * 0.6 + 0.2,
          varietyScore: Math.random() * 0.6 + 0.2
        },
        style: {
          formality: Math.random() * 0.6 + 0.2,
          descriptiveness: Math.random() * 0.6 + 0.2,
          dialogueFrequency: Math.random() * 0.6 + 0.2
        },
        patterns: {
          openingTendency: Math.random() > 0.5 ? 'description' : 'dialogue',
          closingTendency: Math.random() > 0.5 ? 'reflection' : 'action',
          transitionPreference: Math.random() > 0.5 ? 'abrupt' : 'gradual'
        }
      };
      
      setStyleAnalysis(analysis);
    } catch (error) {
      console.error('Failed to analyze writing style:', error);
      alert('Failed to analyze writing style. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };
  
  // Handle training personalized model
  const handleTrainModel = async () => {
    setIsTraining(true);
    setModelStatus('training');
    
    try {
      // In a real implementation, this would call an API to train a personalized model
      // For now, we'll simulate training
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Update model status
      setModelStatus('ready');
      
      // Notify parent component
      if (onTrainModel) {
        onTrainModel({
          userId,
          status: 'ready',
          timestamp: new Date().toISOString()
        });
      }
    } catch (error) {
      console.error('Failed to train personalized model:', error);
      alert('Failed to train personalized model. Please try again.');
      setModelStatus('not_trained');
    } finally {
      setIsTraining(false);
    }
  };
  
  // Handle settings change
  const handleSettingChange = (setting, value) => {
    setSettings(prev => {
      const updated = {
        ...prev,
        [setting]: value
      };
      
      // Notify parent component
      if (onUpdateSettings) {
        onUpdateSettings(updated);
      }
      
      return updated;
    });
  };
  
  // Format percentage for display
  const formatPercentage = (value) => {
    return `${Math.round(value * 100)}%`;
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      {/* Header */}
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-b border-gray-200 dark:border-gray-600">
        <h2 className="text-lg font-medium flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-primary" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-6-3a2 2 0 11-4 0 2 2 0 014 0zm-2 4a5 5 0 00-4.546 2.916A5.986 5.986 0 005 10a6 6 0 0012 0c0-.35-.035-.691-.1-1.02A5 5 0 0010 11z" clipRule="evenodd" />
          </svg>
          Personalized AI
        </h2>
      </div>
      
      {/* Main content */}
      <div className="p-4">
        {/* Model status */}
        <div className="mb-6">
          <h3 className="font-medium mb-2">Your Personalized AI Model</h3>
          <div className="bg-gray-50 dark:bg-gray-700 rounded-md p-4">
            <div className="flex items-center">
              {modelStatus === 'not_trained' && (
                <div className="w-3 h-3 rounded-full bg-gray-400 mr-2"></div>
              )}
              {modelStatus === 'training' && (
                <div className="w-3 h-3 rounded-full bg-yellow-400 mr-2 animate-pulse"></div>
              )}
              {modelStatus === 'ready' && (
                <div className="w-3 h-3 rounded-full bg-green-400 mr-2"></div>
              )}
              
              <span className="font-medium">
                {modelStatus === 'not_trained' && 'Not Trained'}
                {modelStatus === 'training' && 'Training in Progress'}
                {modelStatus === 'ready' && 'Ready to Use'}
              </span>
            </div>
            
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
              {modelStatus === 'not_trained' && 'Your personalized AI model hasn\'t been trained yet. Train it to get AI-generated content that matches your writing style.'}
              {modelStatus === 'training' && 'Your personalized AI model is currently being trained. This may take a few minutes.'}
              {modelStatus === 'ready' && 'Your personalized AI model is ready to use. It has been trained on your writing style and will generate content that matches your style.'}
            </p>
            
            <div className="mt-4">
              {modelStatus === 'not_trained' && (
                <button
                  className="btn btn-primary"
                  onClick={handleTrainModel}
                  disabled={isTraining || userContent.length === 0}
                >
                  {isTraining ? (
                    <span className="flex items-center">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Training...
                    </span>
                  ) : 'Train Model'}
                </button>
              )}
              
              {modelStatus === 'training' && (
                <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2.5">
                  <div className="bg-primary h-2.5 rounded-full animate-pulse w-3/4"></div>
                </div>
              )}
              
              {modelStatus === 'ready' && (
                <button
                  className="btn btn-outline"
                  onClick={handleTrainModel}
                  disabled={isTraining}
                >
                  {isTraining ? 'Training...' : 'Retrain Model'}
                </button>
              )}
            </div>
          </div>
        </div>
        
        {/* Style analysis */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-medium">Writing Style Analysis</h3>
            <button
              className="btn btn-sm btn-outline"
              onClick={handleAnalyzeStyle}
              disabled={isAnalyzing || userContent.length === 0}
            >
              {isAnalyzing ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Analyzing...
                </span>
              ) : 'Analyze Style'}
            </button>
          </div>
          
          {styleAnalysis ? (
            <div className="bg-gray-50 dark:bg-gray-700 rounded-md p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium mb-2">Vocabulary</h4>
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Simple</span>
                        <span>Complex</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full"
                          style={{ width: `${styleAnalysis.vocabulary.complexityScore * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      <span className="font-medium">Unique Words:</span> {styleAnalysis.vocabulary.uniqueWords}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      <span className="font-medium">Favored Words:</span> {styleAnalysis.vocabulary.favoredWords.join(', ')}
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-2">Sentence Structure</h4>
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Short</span>
                        <span>Long</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full"
                          style={{ width: `${styleAnalysis.sentenceStructure.complexityScore * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      <span className="font-medium">Average Length:</span> {styleAnalysis.sentenceStructure.averageLength} words
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      <span className="font-medium">Variety:</span> {formatPercentage(styleAnalysis.sentenceStructure.varietyScore)}
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-2">Style Characteristics</h4>
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Casual</span>
                        <span>Formal</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full"
                          style={{ width: `${styleAnalysis.style.formality * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Direct</span>
                        <span>Descriptive</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full"
                          style={{ width: `${styleAnalysis.style.descriptiveness * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-2">Writing Patterns</h4>
                  <div className="space-y-1 text-sm">
                    <div>
                      <span className="font-medium">Opening Tendency:</span> {styleAnalysis.patterns.openingTendency}
                    </div>
                    <div>
                      <span className="font-medium">Closing Tendency:</span> {styleAnalysis.patterns.closingTendency}
                    </div>
                    <div>
                      <span className="font-medium">Transitions:</span> {styleAnalysis.patterns.transitionPreference}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-gray-50 dark:bg-gray-700 rounded-md p-4 text-center">
              <p className="text-gray-500 dark:text-gray-400">
                {userContent.length === 0
                  ? 'No content available for analysis. Create some stories first.'
                  : 'Click "Analyze Style" to analyze your writing style.'}
              </p>
            </div>
          )}
        </div>
        
        {/* Personalization settings */}
        <div>
          <h3 className="font-medium mb-2">Personalization Settings</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  className="sr-only peer"
                  checked={settings.usePersonalizedModel}
                  onChange={(e) => handleSettingChange('usePersonalizedModel', e.target.checked)}
                  disabled={modelStatus !== 'ready'}
                />
                <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary"></div>
                <span className="ml-3 text-sm font-medium">Use personalized model</span>
              </label>
              
              {modelStatus !== 'ready' && (
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  (Train model first)
                </span>
              )}
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Style Adherence</span>
                <span>{formatPercentage(settings.styleAdherence)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={settings.styleAdherence}
                onChange={(e) => handleSettingChange('styleAdherence', parseFloat(e.target.value))}
                className="w-full"
                disabled={!settings.usePersonalizedModel || modelStatus !== 'ready'}
              />
              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                <span>Flexible</span>
                <span>Strict</span>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Creativity</span>
                <span>{formatPercentage(settings.creativity)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={settings.creativity}
                onChange={(e) => handleSettingChange('creativity', parseFloat(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                <span>Conservative</span>
                <span>Experimental</span>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Vocabulary</span>
                <span>{formatPercentage(settings.vocabulary)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={settings.vocabulary}
                onChange={(e) => handleSettingChange('vocabulary', parseFloat(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                <span>Simple</span>
                <span>Complex</span>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Sentence Length</span>
                <span>{formatPercentage(settings.sentenceLength)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={settings.sentenceLength}
                onChange={(e) => handleSettingChange('sentenceLength', parseFloat(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                <span>Shorter</span>
                <span>Longer</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIPersonalizationManager;