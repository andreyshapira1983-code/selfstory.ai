import React, { useState } from 'react';
import WelcomeStep from './WelcomeStep';
import GenreSelectionStep from './GenreSelectionStep';
import TemplateSelectionStep from './TemplateSelectionStep';
import FirstStoryStep from './FirstStoryStep';

/**
 * OnboardingFlow - Main component that manages the onboarding process
 * Handles step navigation and data collection throughout the onboarding experience
 */
const OnboardingFlow = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [userData, setUserData] = useState({
    name: '',
    preferredGenres: [],
    selectedTemplate: null,
    firstStory: null
  });

  // Steps in the onboarding process
  const steps = [
    {
      id: 'welcome',
      title: 'Welcome to StoryAI',
      component: (
        <WelcomeStep 
          onNext={(name) => {
            setUserData(prev => ({ ...prev, name }));
            setCurrentStep(1);
          }} 
        />
      )
    },
    {
      id: 'genre',
      title: 'Choose Your Genres',
      component: (
        <GenreSelectionStep 
          onNext={(preferredGenres) => {
            setUserData(prev => ({ ...prev, preferredGenres }));
            setCurrentStep(2);
          }}
          onBack={() => setCurrentStep(0)}
          initialGenres={userData.preferredGenres}
        />
      )
    },
    {
      id: 'template',
      title: 'Select a Template',
      component: (
        <TemplateSelectionStep 
          onNext={(selectedTemplate) => {
            setUserData(prev => ({ ...prev, selectedTemplate }));
            setCurrentStep(3);
          }}
          onBack={() => setCurrentStep(1)}
          selectedGenres={userData.preferredGenres}
          initialTemplate={userData.selectedTemplate}
        />
      )
    },
    {
      id: 'first-story',
      title: 'Your First Story',
      component: (
        <FirstStoryStep 
          onComplete={(firstStory) => {
            setUserData(prev => ({ ...prev, firstStory }));
            onComplete({ ...userData, firstStory });
          }}
          onBack={() => setCurrentStep(2)}
          template={userData.selectedTemplate}
        />
      )
    }
  ];

  // Progress calculation
  const progress = ((currentStep + 1) / steps.length) * 100;

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-indigo-50 to-white dark:from-gray-900 dark:to-gray-800">
      <div className="flex-1 max-w-4xl mx-auto w-full px-4 py-8">
        {/* Progress bar */}
        <div className="w-full bg-gray-200 rounded-full h-2.5 mb-8 dark:bg-gray-700">
          <div 
            className="bg-primary h-2.5 rounded-full transition-all duration-300 ease-in-out" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
        
        {/* Step title */}
        <h1 className="text-3xl font-bold mb-8 text-center">
          {steps[currentStep].title}
        </h1>
        
        {/* Current step content */}
        <div className="onboarding-step">
          {steps[currentStep].component}
        </div>
      </div>
      
      {/* Footer */}
      <div className="py-4 text-center text-sm text-gray-500 dark:text-gray-400">
        <p>Step {currentStep + 1} of {steps.length}</p>
      </div>
    </div>
  );
};

export default OnboardingFlow;