import React, { useState, useEffect } from 'react';
import templates from './templateData';

/**
 * TemplateBrowser - Component for browsing and selecting story templates
 * Allows filtering by genre, searching, and previewing templates
 */
const TemplateBrowser = ({ onSelectTemplate, selectedGenres = [], initialTemplate = null }) => {
  const [filteredTemplates, setFilteredTemplates] = useState(templates);
  const [selectedTemplate, setSelectedTemplate] = useState(initialTemplate);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeGenreFilter, setActiveGenreFilter] = useState('all');
  
  // All available genres from templates
  const allGenres = [...new Set(templates.flatMap(template => template.genres))].sort();
  
  // Filter templates based on selected genre and search query
  useEffect(() => {
    let filtered = [...templates];
    
    // Filter by genre if not "all"
    if (activeGenreFilter !== 'all') {
      filtered = filtered.filter(template => 
        template.genres.includes(activeGenreFilter)
      );
    }
    
    // Filter by search query if present
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      filtered = filtered.filter(template => 
        template.title.toLowerCase().includes(query) || 
        template.description.toLowerCase().includes(query) ||
        template.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }
    
    // Prioritize templates matching user's selected genres
    if (selectedGenres.length > 0) {
      filtered.sort((a, b) => {
        const aMatches = a.genres.filter(genre => selectedGenres.includes(genre)).length;
        const bMatches = b.genres.filter(genre => selectedGenres.includes(genre)).length;
        return bMatches - aMatches;
      });
    }
    
    setFilteredTemplates(filtered);
  }, [activeGenreFilter, searchQuery, selectedGenres]);
  
  // Handle template selection
  const handleSelectTemplate = (template) => {
    setSelectedTemplate(template);
    if (onSelectTemplate) {
      onSelectTemplate(template);
    }
  };

  return (
    <div className="template-browser">
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
          <h2 className="text-2xl font-bold">Story Templates</h2>
          
          {/* Search input */}
          <div className="relative">
            <input
              type="text"
              className="input pl-10"
              placeholder="Search templates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>
        
        {/* Genre filter tabs */}
        <div className="flex flex-wrap gap-2 mb-4">
          <button
            className={`px-3 py-1 rounded-full text-sm font-medium transition-colors
              ${activeGenreFilter === 'all' 
                ? 'bg-primary text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600'
              }`}
            onClick={() => setActiveGenreFilter('all')}
          >
            All
          </button>
          
          {allGenres.map(genre => (
            <button
              key={genre}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors
                ${activeGenreFilter === genre 
                  ? 'bg-primary text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600'
                }`}
              onClick={() => setActiveGenreFilter(genre)}
            >
              {genre.charAt(0).toUpperCase() + genre.slice(1)}
            </button>
          ))}
        </div>
      </div>
      
      {filteredTemplates.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg dark:bg-gray-800">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h3 className="text-lg font-medium mb-2">No matching templates</h3>
          <p className="text-gray-500 dark:text-gray-400">
            Try adjusting your filters or search query
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map((template) => (
            <div
              key={template.id}
              className={`template-card cursor-pointer transition-all hover:shadow-md
                ${selectedTemplate?.id === template.id ? 'selected ring-2 ring-primary' : 'hover:border-primary'}`}
              onClick={() => handleSelectTemplate(template)}
            >
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-lg">{template.title}</h3>
                
                {/* Recommended badge if template matches user's genres */}
                {selectedGenres.some(genre => template.genres.includes(genre)) && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">
                    Recommended
                  </span>
                )}
              </div>
              
              <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">{template.description}</p>
              
              <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md mb-3 text-sm italic">
                "{template.preview}"
              </div>
              
              <div className="flex flex-wrap gap-1 mb-3">
                {template.genres.map(genre => (
                  <span 
                    key={genre} 
                    className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100"
                  >
                    {genre.charAt(0).toUpperCase() + genre.slice(1)}
                  </span>
                ))}
              </div>
              
              <div className="flex flex-wrap gap-1">
                {template.tags.map(tag => (
                  <span 
                    key={tag} 
                    className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                  >
                    #{tag.replace('-', ' ')}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Selected template preview */}
      {selectedTemplate && (
        <div className="mt-8 p-6 border rounded-lg bg-white dark:bg-gray-800 shadow-sm">
          <h3 className="text-xl font-bold mb-2">{selectedTemplate.title}</h3>
          <p className="mb-4">{selectedTemplate.description}</p>
          
          <div className="mb-4">
            <h4 className="font-medium mb-2">Story Beginning:</h4>
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-md whitespace-pre-line">
              {selectedTemplate.content}
            </div>
          </div>
          
          <div className="mb-4">
            <h4 className="font-medium mb-2">Writing Prompts:</h4>
            <ul className="list-disc pl-5 space-y-1">
              {selectedTemplate.promptSuggestions.map((prompt, index) => (
                <li key={index}>{prompt}</li>
              ))}
            </ul>
          </div>
          
          <div className="flex justify-end mt-4">
            <button 
              className="btn btn-primary"
              onClick={() => handleSelectTemplate(selectedTemplate)}
            >
              Use This Template
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default TemplateBrowser;