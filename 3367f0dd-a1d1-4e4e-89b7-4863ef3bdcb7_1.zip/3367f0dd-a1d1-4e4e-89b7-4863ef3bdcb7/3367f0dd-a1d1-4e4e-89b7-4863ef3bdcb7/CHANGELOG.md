# Changelog

All notable changes to the StoryAI project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial project setup with React and Vite
- User onboarding flow with step-by-step guidance
- Story templates system with multiple genres
- Story controls for adjusting tone, length, POV, and mood
- Genre and tag system for story categorization
- Story editor with AI assistance features
- Server setup with Express and Socket.IO
- Basic API routes for stories
- Testing setup with Jest and Testing Library

## [1.0.0] - 2025-08-03

### Added
- Initial release of StoryAI platform
- User onboarding experience
- Story creation with templates
- AI-powered writing assistance
- Genre and tag management
- Story controls and parameters
- Basic collaborative features