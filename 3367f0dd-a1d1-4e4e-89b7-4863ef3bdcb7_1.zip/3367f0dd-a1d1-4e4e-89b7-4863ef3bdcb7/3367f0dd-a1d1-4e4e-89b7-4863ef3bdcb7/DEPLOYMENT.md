# StoryAI Deployment Guide

This guide provides instructions for deploying the StoryAI platform to various environments.

## Prerequisites

- Node.js 16.x or higher
- npm 7.x or higher
- Git
- Access to a hosting service (Vercel, Netlify, Heroku, AWS, etc.)

## Local Deployment

### 1. Build the Application

```bash
# Install dependencies
npm install

# Build the client
npm run build
```

This will create a `dist` directory with the built client application.

### 2. Start the Server

```bash
# Start the server
npm run server
```

The application will be available at `http://localhost:5000`.

## Deployment Options

### Option 1: Vercel (Frontend Only)

1. Create a Vercel account at [vercel.com](https://vercel.com)
2. Install the Vercel CLI:
   ```bash
   npm install -g vercel
   ```
3. Login to Vercel:
   ```bash
   vercel login
   ```
4. Deploy the application:
   ```bash
   vercel
   ```
5. For production deployment:
   ```bash
   vercel --prod
   ```

### Option 2: Netlify (Frontend Only)

1. Create a Netlify account at [netlify.com](https://netlify.com)
2. Install the Netlify CLI:
   ```bash
   npm install -g netlify-cli
   ```
3. Login to Netlify:
   ```bash
   netlify login
   ```
4. Deploy the application:
   ```bash
   netlify deploy
   ```
5. For production deployment:
   ```bash
   netlify deploy --prod
   ```

### Option 3: Heroku (Full Stack)

1. Create a Heroku account at [heroku.com](https://heroku.com)
2. Install the Heroku CLI:
   ```bash
   npm install -g heroku
   ```
3. Login to Heroku:
   ```bash
   heroku login
   ```
4. Create a new Heroku app:
   ```bash
   heroku create story-ai-app
   ```
5. Add a Procfile to the root directory:
   ```
   web: npm start
   ```
6. Commit the changes:
   ```bash
   git add .
   git commit -m "Add Procfile for Heroku deployment"
   ```
7. Deploy the application:
   ```bash
   git push heroku main
   ```

### Option 4: Docker Deployment

1. Create a Dockerfile in the root directory:
   ```dockerfile
   FROM node:16-alpine

   WORKDIR /app

   COPY package*.json ./
   RUN npm install

   COPY . .
   RUN npm run build

   EXPOSE 5000

   CMD ["npm", "start"]
   ```
2. Build the Docker image:
   ```bash
   docker build -t story-ai .
   ```
3. Run the Docker container:
   ```bash
   docker run -p 5000:5000 story-ai
   ```

## Environment Variables

The following environment variables should be set in your deployment environment:

- `PORT`: The port on which the server will run (default: 5000)
- `NODE_ENV`: The environment (development, production, test)
- `VITE_API_URL`: The URL of the API server
- `VITE_SOCKET_URL`: The URL for WebSocket connections

## Continuous Integration/Continuous Deployment (CI/CD)

### GitHub Actions

Create a `.github/workflows/deploy.yml` file:

```yaml
name: Deploy

on:
  push:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - uses: actions/checkout@v2
    
    - name: Setup Node.js
      uses: actions/setup-node@v2
      with:
        node-version: '16'
        
    - name: Install dependencies
      run: npm install
      
    - name: Run tests
      run: npm test
      
    - name: Build
      run: npm run build
      
    - name: Deploy to Heroku
      uses: akhileshns/heroku-deploy@v3.12.12
      with:
        heroku_api_key: ${{ secrets.HEROKU_API_KEY }}
        heroku_app_name: "story-ai-app"
        heroku_email: ${{ secrets.HEROKU_EMAIL }}
```

## Monitoring and Logging

### Logging

Add a logging library like Winston:

```bash
npm install winston
```

Create a logger utility:

```javascript
// src/server/utils/logger.js
const winston = require('winston');

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});

module.exports = logger;
```

### Monitoring

Consider using a monitoring service like:
- New Relic
- Datadog
- Sentry

## Security Considerations

1. **HTTPS**: Always use HTTPS in production
2. **CORS**: Configure CORS properly in the server
3. **Rate Limiting**: Implement rate limiting for API endpoints
4. **Input Validation**: Validate all user inputs
5. **Authentication**: Implement proper authentication for user accounts
6. **Environment Variables**: Never commit sensitive information to the repository

## Scaling

### Horizontal Scaling

1. Use a load balancer to distribute traffic across multiple instances
2. Implement sticky sessions for WebSocket connections
3. Use a Redis adapter for Socket.IO to support multiple instances

### Database Scaling

1. Use a managed database service
2. Implement database sharding for large datasets
3. Use connection pooling for efficient database connections

## Backup and Recovery

1. Regularly backup the database
2. Implement a disaster recovery plan
3. Test the recovery process periodically

## Conclusion

This deployment guide provides a starting point for deploying the StoryAI platform. Depending on your specific requirements and infrastructure, you may need to adapt these instructions.

For any questions or issues, please contact the development team.