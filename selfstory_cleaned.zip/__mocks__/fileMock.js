// Mock file imports for Jest
module.exports = 'test-file-stub';