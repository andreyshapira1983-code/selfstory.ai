const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const chalk = require('chalk') || { green: (text) => text, blue: (text) => text, yellow: (text) => text, red: (text) => text };

console.log(chalk.blue('🚀 Starting StoryAI in development mode with hot reloading...'));

// Check if nodemon is installed
try {
  require.resolve('nodemon');
  console.log(chalk.green('✅ nodemon is installed'));
} catch (error) {
  console.log(chalk.yellow('⚠️ nodemon is not installed. Installing...'));
  try {
    require('child_process').execSync('npm install --save-dev nodemon', { stdio: 'inherit' });
    console.log(chalk.green('✅ nodemon installed successfully'));
  } catch (error) {
    console.error(chalk.red('❌ Failed to install nodemon:'), error.message);
    process.exit(1);
  }
}

// Check if concurrently is installed
try {
  require.resolve('concurrently');
  console.log(chalk.green('✅ concurrently is installed'));
} catch (error) {
  console.log(chalk.yellow('⚠️ concurrently is not installed. Installing...'));
  try {
    require('child_process').execSync('npm install --save-dev concurrently', { stdio: 'inherit' });
    console.log(chalk.green('✅ concurrently installed successfully'));
  } catch (error) {
    console.error(chalk.red('❌ Failed to install concurrently:'), error.message);
    process.exit(1);
  }
}

// Create a .env file if it doesn't exist
const envPath = path.join(__dirname, '../.env');
if (!fs.existsSync(envPath)) {
  console.log(chalk.yellow('⚠️ .env file not found. Creating from .env.example...'));
  try {
    if (fs.existsSync(path.join(__dirname, '../.env.example'))) {
      fs.copyFileSync(path.join(__dirname, '../.env.example'), envPath);
      console.log(chalk.green('✅ .env file created from .env.example'));
    } else {
      fs.writeFileSync(envPath, `PORT=5000
NODE_ENV=development
VITE_API_URL=http://localhost:5000
VITE_SOCKET_URL=http://localhost:5000`);
      console.log(chalk.green('✅ .env file created with default values'));
    }
  } catch (error) {
    console.error(chalk.red('❌ Failed to create .env file:'), error.message);
    process.exit(1);
  }
}

// Start the client and server
console.log(chalk.blue('🌐 Starting client and server...'));

// Use concurrently to run both processes
const concurrently = require('concurrently');

try {
  concurrently([
    { 
      command: 'npm run dev', 
      name: 'client', 
      prefixColor: 'blue',
      env: { FORCE_COLOR: 'true' }
    },
    { 
      command: 'npm run server:dev', 
      name: 'server', 
      prefixColor: 'green',
      env: { FORCE_COLOR: 'true' }
    }
  ], {
    prefix: 'name',
    killOthers: ['failure', 'success'],
    restartTries: 3,
    restartDelay: 1000
  }).then(
    () => {
      console.log(chalk.green('✅ All processes exited successfully'));
    },
    (error) => {
      console.error(chalk.red('❌ Error running processes:'), error);
    }
  );
} catch (error) {
  console.error(chalk.red('❌ Failed to start development servers:'), error.message);
  process.exit(1);
}