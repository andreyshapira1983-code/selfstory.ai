# Contributing to StoryAI

Thank you for your interest in contributing to StoryAI! This document provides guidelines and instructions for contributing to the project.

## Code of Conduct

Please read and follow our [Code of Conduct](CODE_OF_CONDUCT.md) to foster an open and welcoming environment.

## Getting Started

### Prerequisites

- Node.js 16.x or higher
- npm 7.x or higher
- Git

### Setup

1. Fork the repository on GitHub
2. Clone your fork locally:
   ```bash
   git clone https://github.com/your-username/story-ai.git
   cd story-ai
   ```
3. Add the original repository as a remote:
   ```bash
   git remote add upstream https://github.com/original-owner/story-ai.git
   ```
4. Install dependencies:
   ```bash
   npm run setup
   ```
5. Verify your setup:
   ```bash
   npm run check
   ```

## Development Workflow

### Branching Strategy

- `main`: Production-ready code
- `develop`: Development branch for integrating features
- `feature/*`: Feature branches for new functionality
- `bugfix/*`: Bug fix branches
- `hotfix/*`: Urgent fixes for production issues

### Creating a Branch

```bash
# Update your local repository
git checkout develop
git pull upstream develop

# Create a new branch
git checkout -b feature/your-feature-name
```

### Making Changes

1. Make your changes in the branch
2. Follow the coding standards and guidelines
3. Add tests for your changes
4. Run tests to ensure they pass:
   ```bash
   npm test
   ```
5. Format your code:
   ```bash
   npm run format
   ```
6. Lint your code:
   ```bash
   npm run lint
   ```

### Committing Changes

We follow the [Conventional Commits](https://www.conventionalcommits.org/) specification:

```bash
git commit -m "feat: add new feature"
git commit -m "fix: resolve issue with component"
git commit -m "docs: update README"
git commit -m "style: format code"
git commit -m "refactor: improve component structure"
git commit -m "test: add tests for feature"
git commit -m "chore: update dependencies"
```

### Submitting a Pull Request

1. Push your branch to your fork:
   ```bash
   git push origin feature/your-feature-name
   ```
2. Go to the original repository on GitHub
3. Create a Pull Request from your branch to the `develop` branch
4. Fill in the PR template with details about your changes
5. Request a review from a maintainer
6. Address any feedback and make necessary changes
7. Once approved, your PR will be merged

## Project Structure

```
story-ai/
├── public/              # Static assets
├── src/
│   ├── client/
│   │   ├── components/  # React components
│   │   ├── styles/      # Global styles
│   │   └── utils/       # Utility functions
│   └── server/          # Server-side code
├── scripts/             # Utility scripts
└── __mocks__/           # Test mocks
```

## Component Guidelines

### Creating a New Component

1. Create a new directory in `src/client/components/` for your component
2. Create the component file with a `.jsx` extension
3. Create a README.md file explaining the component's purpose and usage
4. Create a test file with a `.test.jsx` extension
5. Export the component in an `index.js` file

Example:
```
src/client/components/your-component/
├── YourComponent.jsx
├── YourComponent.test.jsx
├── README.md
└── index.js
```

### Component Structure

```jsx
import React from 'react';
import PropTypes from 'prop-types';

/**
 * YourComponent - Description of your component
 */
const YourComponent = ({ prop1, prop2 }) => {
  // Component logic here
  
  return (
    <div className="your-component">
      {/* Component JSX here */}
    </div>
  );
};

YourComponent.propTypes = {
  prop1: PropTypes.string.isRequired,
  prop2: PropTypes.number
};

YourComponent.defaultProps = {
  prop2: 0
};

export default YourComponent;
```

## Testing Guidelines

### Writing Tests

- Write tests for all components and utilities
- Test both success and failure cases
- Mock external dependencies
- Use descriptive test names

Example:
```jsx
import React from 'react';
import { render, screen } from '@testing-library/react';
import YourComponent from './YourComponent';

describe('YourComponent', () => {
  test('renders correctly with default props', () => {
    render(<YourComponent prop1="test" />);
    expect(screen.getByText('test')).toBeInTheDocument();
  });
  
  test('handles prop2 correctly', () => {
    render(<YourComponent prop1="test" prop2={42} />);
    expect(screen.getByText('42')).toBeInTheDocument();
  });
});
```

## Documentation Guidelines

### Component Documentation

Each component should have a README.md file that includes:

1. Component purpose and description
2. Props API
3. Usage examples
4. Any special considerations or limitations

### Code Comments

- Use JSDoc comments for functions and components
- Add inline comments for complex logic
- Keep comments up-to-date with code changes

## Styling Guidelines

- Use TailwindCSS utility classes for styling
- Follow the existing color scheme and design patterns
- Ensure components are responsive and accessible
- Use semantic HTML elements

## Additional Resources

- [React Documentation](https://reactjs.org/docs/getting-started.html)
- [TailwindCSS Documentation](https://tailwindcss.com/docs)
- [Jest Documentation](https://jestjs.io/docs/getting-started)
- [Testing Library Documentation](https://testing-library.com/docs/)

## Questions and Support

If you have questions or need help, please:

1. Check existing issues and documentation
2. Open a new issue with the "question" label
3. Reach out to the maintainers

Thank you for contributing to StoryAI!