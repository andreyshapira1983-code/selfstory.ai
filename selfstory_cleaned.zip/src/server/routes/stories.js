const express = require('express');
const router = express.Router();

// Sample data - in a real app, this would come from a database
let stories = [
  {
    id: 'story-1',
    title: 'The Mysterious Forest',
    content: 'Deep in the heart of the ancient forest, a secret lay hidden for centuries...',
    genres: ['fantasy', 'mystery'],
    tags: ['forest', 'ancient', 'secret'],
    controls: {
      tone: 'neutral',
      length: 'medium',
      pov: 'third',
      mood: 'mysterious'
    },
    template: 'fantasy-quest',
    createdAt: '2023-08-01T12:00:00.000Z',
    updatedAt: '2023-08-02T14:30:00.000Z'
  },
  {
    id: 'story-2',
    title: 'City of Dreams',
    content: 'The neon lights of the city reflected in the puddles as Rio plugged into the network...',
    genres: ['cyberpunk', 'sci-fi'],
    tags: ['city', 'future', 'technology'],
    controls: {
      tone: 'casual',
      length: 'medium',
      pov: 'first',
      mood: 'tense'
    },
    template: 'cyberpunk-heist',
    createdAt: '2023-08-03T09:15:00.000Z',
    updatedAt: '2023-08-03T10:45:00.000Z'
  }
];

// Get all stories
router.get('/', (req, res) => {
  res.json(stories);
});

// Get a specific story
router.get('/:id', (req, res) => {
  const story = stories.find(s => s.id === req.params.id);
  
  if (!story) {
    return res.status(404).json({ message: 'Story not found' });
  }
  
  res.json(story);
});

// Create a new story
router.post('/', (req, res) => {
  const { title, content, genres, tags, controls, template } = req.body;
  
  if (!title) {
    return res.status(400).json({ message: 'Title is required' });
  }
  
  const newStory = {
    id: `story-${Date.now()}`,
    title,
    content: content || '',
    genres: genres || [],
    tags: tags || [],
    controls: controls || {
      tone: 'neutral',
      length: 'medium',
      pov: 'third',
      mood: 'neutral'
    },
    template,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  stories.push(newStory);
  res.status(201).json(newStory);
});

// Update a story
router.put('/:id', (req, res) => {
  const { title, content, genres, tags, controls } = req.body;
  const storyIndex = stories.findIndex(s => s.id === req.params.id);
  
  if (storyIndex === -1) {
    return res.status(404).json({ message: 'Story not found' });
  }
  
  const updatedStory = {
    ...stories[storyIndex],
    title: title || stories[storyIndex].title,
    content: content !== undefined ? content : stories[storyIndex].content,
    genres: genres || stories[storyIndex].genres,
    tags: tags || stories[storyIndex].tags,
    controls: controls || stories[storyIndex].controls,
    updatedAt: new Date().toISOString()
  };
  
  stories[storyIndex] = updatedStory;
  res.json(updatedStory);
});

// Delete a story
router.delete('/:id', (req, res) => {
  const storyIndex = stories.findIndex(s => s.id === req.params.id);
  
  if (storyIndex === -1) {
    return res.status(404).json({ message: 'Story not found' });
  }
  
  const deletedStory = stories[storyIndex];
  stories = stories.filter(s => s.id !== req.params.id);
  
  res.json({ message: 'Story deleted successfully', story: deletedStory });
});

module.exports = router;