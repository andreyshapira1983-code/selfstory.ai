/**
 * AI Routes - API endpoints for AI-powered story features
 */

const express = require('express');
const router = express.Router();
const aiController = require('../controllers/aiController');

/**
 * @route   POST /api/ai/generate
 * @desc    Generate story content based on parameters
 * @access  Public (would be restricted in production)
 */
router.post('/generate', aiController.generateStory);

/**
 * @route   POST /api/ai/continue
 * @desc    Continue existing story content
 * @access  Public (would be restricted in production)
 */
router.post('/continue', aiController.continueStory);

/**
 * @route   POST /api/ai/enhance
 * @desc    Enhance existing content (grammar, style, etc.)
 * @access  Public (would be restricted in production)
 */
router.post('/enhance', aiController.enhanceContent);

/**
 * @route   POST /api/ai/style
 * @desc    Apply a specific writing style to content
 * @access  Public (would be restricted in production)
 */
router.post('/style', aiController.applyStyle);

/**
 * @route   POST /api/ai/suggest
 * @desc    Get real-time suggestions based on current content
 * @access  Public (would be restricted in production)
 */
router.post('/suggest', aiController.getSuggestions);

/**
 * @route   POST /api/ai/analyze
 * @desc    Analyze story content for insights
 * @access  Public (would be restricted in production)
 */
router.post('/analyze', aiController.analyzeStory);

/**
 * @route   POST /api/ai/character
 * @desc    Generate character details
 * @access  Public (would be restricted in production)
 */
router.post('/character', aiController.generateCharacter);

/**
 * @route   POST /api/ai/plot
 * @desc    Generate plot outline
 * @access  Public (would be restricted in production)
 */
router.post('/plot', aiController.generatePlot);

/**
 * @route   GET /api/ai/status
 * @desc    Check AI service status
 * @access  Public
 */
router.get('/status', (req, res) => {
  res.json({
    status: 'operational',
    models: ['gpt-4', 'gpt-3.5-turbo'],
    timestamp: new Date().toISOString(),
    requestsRemaining: 1000, // Would be actual quota in production
    version: '1.0.0'
  });
});

module.exports = router;