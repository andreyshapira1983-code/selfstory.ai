/**
 * AI Service - Handles communication with AI services for story generation and enhancement
 * 
 * This module provides utilities for:
 * - Story generation based on prompts and parameters
 * - Style transfer between different writing styles
 * - Content enhancement and suggestions
 * - Character and plot development assistance
 */

// Configuration for AI service
const AI_CONFIG = {
  baseUrl: process.env.AI_SERVICE_URL || '/api/ai',
  defaultModel: 'gpt-4',
  maxTokens: 2048,
  temperature: 0.7,
  topP: 0.9,
  presencePenalty: 0.6,
  frequencyPenalty: 0.5,
};

/**
 * Generate story content based on provided parameters
 * 
 * @param {Object} params - Generation parameters
 * @param {string} params.prompt - The main prompt or story starter
 * @param {string} params.genre - The genre of the story
 * @param {string} params.tone - The tone of the writing (formal, casual, etc.)
 * @param {string} params.length - Desired length (short, medium, long)
 * @param {string} params.pov - Point of view (first, third, etc.)
 * @param {string} params.mood - The mood of the story
 * @param {Array<string>} [params.tags] - Additional tags for context
 * @returns {Promise<Object>} - Generated content and metadata
 */
export const generateStory = async (params) => {
  try {
    const response = await fetch(`${AI_CONFIG.baseUrl}/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...params,
        model: AI_CONFIG.defaultModel,
        max_tokens: AI_CONFIG.maxTokens,
        temperature: AI_CONFIG.temperature,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to generate story');
    }

    return await response.json();
  } catch (error) {
    console.error('Story generation failed:', error);
    throw error;
  }
};

/**
 * Continue writing from existing content
 * 
 * @param {Object} params - Continuation parameters
 * @param {string} params.content - Existing story content
 * @param {string} params.genre - The genre of the story
 * @param {Object} params.controls - Story controls (tone, mood, etc.)
 * @param {number} [params.paragraphs=1] - Number of paragraphs to generate
 * @returns {Promise<Object>} - Generated continuation and metadata
 */
export const continueStory = async (params) => {
  try {
    const response = await fetch(`${AI_CONFIG.baseUrl}/continue`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...params,
        model: AI_CONFIG.defaultModel,
        max_tokens: AI_CONFIG.maxTokens,
        temperature: AI_CONFIG.temperature,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to continue story');
    }

    return await response.json();
  } catch (error) {
    console.error('Story continuation failed:', error);
    throw error;
  }
};

/**
 * Enhance existing content (improve grammar, style, etc.)
 * 
 * @param {Object} params - Enhancement parameters
 * @param {string} params.content - Content to enhance
 * @param {string} [params.focus='grammar'] - Focus area (grammar, style, description, dialogue)
 * @param {Object} [params.controls] - Story controls (tone, mood, etc.)
 * @returns {Promise<Object>} - Enhanced content and metadata
 */
export const enhanceContent = async (params) => {
  try {
    const response = await fetch(`${AI_CONFIG.baseUrl}/enhance`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...params,
        model: AI_CONFIG.defaultModel,
        max_tokens: AI_CONFIG.maxTokens,
        temperature: 0.4, // Lower temperature for more focused enhancements
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to enhance content');
    }

    return await response.json();
  } catch (error) {
    console.error('Content enhancement failed:', error);
    throw error;
  }
};

/**
 * Apply a specific writing style to content
 * 
 * @param {Object} params - Style transfer parameters
 * @param {string} params.content - Content to transform
 * @param {string} params.style - Target style (hemingway, tolkien, etc.)
 * @param {number} [params.strength=0.7] - Style transfer strength (0-1)
 * @returns {Promise<Object>} - Styled content and metadata
 */
export const applyStyle = async (params) => {
  try {
    const response = await fetch(`${AI_CONFIG.baseUrl}/style`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...params,
        model: AI_CONFIG.defaultModel,
        max_tokens: AI_CONFIG.maxTokens,
        temperature: 0.6,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to apply style');
    }

    return await response.json();
  } catch (error) {
    console.error('Style application failed:', error);
    throw error;
  }
};

/**
 * Get real-time suggestions based on current content
 * 
 * @param {Object} params - Suggestion parameters
 * @param {string} params.content - Current content
 * @param {string} params.cursorPosition - Position of cursor in content
 * @param {string} [params.suggestionType='next'] - Type of suggestion (next, plot, character, setting)
 * @returns {Promise<Object>} - Suggestions and metadata
 */
export const getSuggestions = async (params) => {
  try {
    const response = await fetch(`${AI_CONFIG.baseUrl}/suggest`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...params,
        model: AI_CONFIG.defaultModel,
        max_tokens: 256, // Shorter for suggestions
        temperature: 0.8, // Higher for creative suggestions
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to get suggestions');
    }

    return await response.json();
  } catch (error) {
    console.error('Getting suggestions failed:', error);
    throw error;
  }
};

/**
 * Analyze story content for insights
 * 
 * @param {Object} params - Analysis parameters
 * @param {string} params.content - Story content to analyze
 * @param {Array<string>} [params.aspects=['tone', 'pacing', 'characters']] - Aspects to analyze
 * @returns {Promise<Object>} - Analysis results
 */
export const analyzeStory = async (params) => {
  try {
    const response = await fetch(`${AI_CONFIG.baseUrl}/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...params,
        model: AI_CONFIG.defaultModel,
        max_tokens: 1024,
        temperature: 0.3, // Lower for more analytical results
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to analyze story');
    }

    return await response.json();
  } catch (error) {
    console.error('Story analysis failed:', error);
    throw error;
  }
};

/**
 * Generate character details
 * 
 * @param {Object} params - Character generation parameters
 * @param {string} [params.name] - Character name (optional)
 * @param {string} [params.role] - Character role in story
 * @param {string} params.genre - Story genre
 * @param {Object} [params.traits] - Specific character traits to include
 * @returns {Promise<Object>} - Generated character details
 */
export const generateCharacter = async (params) => {
  try {
    const response = await fetch(`${AI_CONFIG.baseUrl}/character`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...params,
        model: AI_CONFIG.defaultModel,
        max_tokens: 1024,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to generate character');
    }

    return await response.json();
  } catch (error) {
    console.error('Character generation failed:', error);
    throw error;
  }
};

/**
 * Generate plot outline
 * 
 * @param {Object} params - Plot generation parameters
 * @param {string} params.premise - Basic premise or concept
 * @param {string} params.genre - Story genre
 * @param {string} [params.structure='three-act'] - Plot structure
 * @param {Array<string>} [params.elements] - Required plot elements
 * @returns {Promise<Object>} - Generated plot outline
 */
export const generatePlot = async (params) => {
  try {
    const response = await fetch(`${AI_CONFIG.baseUrl}/plot`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...params,
        model: AI_CONFIG.defaultModel,
        max_tokens: 1536,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to generate plot');
    }

    return await response.json();
  } catch (error) {
    console.error('Plot generation failed:', error);
    throw error;
  }
};

export default {
  generateStory,
  continueStory,
  enhanceContent,
  applyStyle,
  getSuggestions,
  analyzeStory,
  generateCharacter,
  generatePlot,
};