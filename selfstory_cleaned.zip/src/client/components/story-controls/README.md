# StoryAI Story Controls System

The Story Controls system allows users to adjust parameters like tone, length, point of view, and mood for their stories. This document explains the components, functionality, and usage of the story controls feature.

## Components Overview

### StoryControls.jsx
- Main component for adjusting story parameters
- Provides controls for tone, length, POV, and mood
- Includes preset options and quick adjustment buttons
- Allows saving custom presets

## Control Parameters

### Tone
- **Formal**: Academic, professional, structured writing style
- **Neutral**: Balanced, standard, versatile writing style
- **Casual**: Conversational, relaxed, friendly writing style
- **Poetic**: Lyrical, metaphorical, expressive writing style
- **Humorous**: Witty, playful, comedic writing style

### Length
- **Very Short**: 100-300 words
- **Short**: 300-1000 words
- **Medium**: 1000-3000 words
- **Long**: 3000-7000 words
- **Very Long**: 7000+ words

### Point of View (POV)
- **First Person**: "I" perspective, personal and intimate
- **Second Person**: "You" perspective, immersive and direct
- **Third Person**: "He/She/They" perspective, observational
- **Third Person Omniscient**: All-knowing narrator perspective

### Mood
- **Happy**: Joyful, optimistic, uplifting emotional tone
- **Neutral**: Balanced emotional tone
- **Mysterious**: Enigmatic, intriguing, secretive emotional tone
- **Tense**: Suspenseful, anxious, on-edge emotional tone
- **Melancholic**: Sad, reflective, wistful emotional tone
- **Dark**: Grim, foreboding, ominous emotional tone

## Data Structure

```javascript
{
  tone: string,    // 'formal', 'neutral', 'casual', 'poetic', 'humorous'
  length: string,  // 'very-short', 'short', 'medium', 'long', 'very-long'
  pov: string,     // 'first', 'second', 'third', 'third-omniscient'
  mood: string     // 'happy', 'neutral', 'mysterious', 'tense', 'melancholic', 'dark'
}
```

## Features

### Visual Controls
- Button-based selection for each parameter
- Clear visual indication of selected options
- Descriptive tooltips for each option

### Presets
- Pre-defined combinations of parameters for common writing styles
- Academic, Personal Blog, Literary Fiction, Mystery Novel, Comedy Sketch
- One-click application of presets

### Quick Adjustments
- Make Longer/Shorter buttons for quick length adjustments
- More Descriptive button for enhancing descriptions
- More Dialogue button for increasing conversation
- More Action button for adding dynamic scenes
- More Emotional button for enhancing emotional content

### Custom Presets
- Save current control settings as a custom preset
- Name and manage custom presets
- Apply custom presets with one click

## Usage

### In Story Editor
- The Story Controls component is integrated into the Story Editor
- Controls affect AI-generated content and suggestions
- Changes can be applied to existing content or used for new generations

### With AI Generation
- Control parameters are passed to the AI generation service
- AI adapts its output based on the selected parameters
- Results reflect the chosen tone, length, POV, and mood

## Implementation Notes

- Controls use a consistent visual design with the rest of the application
- All controls are accessible and work with keyboard navigation
- Controls support both light and dark mode
- The component is fully responsive for all device sizes

## Future Enhancements

- Add more granular controls for specific aspects of writing
- Implement a slider-based intensity control for each parameter
- Add visualization of how parameters affect the story
- Integrate with AI to provide real-time preview of parameter changes
- Add collaborative control sharing for team writing projects