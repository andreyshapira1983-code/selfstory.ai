/**
 * Enhanced Features for StoryAI
 * 
 * This file exports all enhanced features for easy integration into the StoryAI platform.
 */

// Collaborative Editing Components
export { default as CursorPresence } from '../editor/CursorPresence';
export { default as CollaborativeChat } from '../editor/CollaborativeChat';
export { default as ConflictResolution } from '../editor/ConflictResolution';
export { default as CollaborativeBrainstorming } from '../editor/CollaborativeBrainstorming';
export { default as EnhancedCollaborativeEditor } from '../editor/EnhancedCollaborativeEditor';

// Export Options Components
export { default as ExportOptions } from '../export/ExportOptions';
export { default as StoryEditorWithExport } from '../editor/StoryEditorWithExport';

// Writing Analytics Components
export { default as WritingAnalytics } from '../analytics/WritingAnalytics';
export { default as StoryEditorWithAnalytics } from '../editor/StoryEditorWithAnalytics';

// Comprehensive Enhanced Editor
export { default as EnhancedStoryEditor } from '../editor/EnhancedStoryEditor';

// Demo Pages
export { default as CollaborativeEditorDemo } from '../pages/CollaborativeEditorDemo';
export { default as ExportOptionsDemo } from '../pages/ExportOptionsDemo';
export { default as WritingAnalyticsDemo } from '../pages/WritingAnalyticsDemo';
export { default as EnhancedFeaturesDemo } from '../pages/EnhancedFeaturesDemo';

// Utility Services
export { default as exportService } from '../../utils/exportService';
export { default as useEnhancedCollaboration } from '../../hooks/useEnhancedCollaboration';

/**
 * Integration Guide:
 * 
 * 1. Collaborative Editing:
 *    - Use EnhancedCollaborativeEditor for a complete collaborative editing experience
 *    - Or use individual components (CursorPresence, CollaborativeChat, etc.) for custom integration
 * 
 * 2. Export Options:
 *    - Use StoryEditorWithExport for a story editor with export capabilities
 *    - Or use ExportOptions component directly for custom integration
 * 
 * 3. Writing Analytics:
 *    - Use StoryEditorWithAnalytics for a story editor with analytics capabilities
 *    - Or use WritingAnalytics component directly for custom integration
 * 
 * 4. Comprehensive Solution:
 *    - Use EnhancedStoryEditor for a complete solution with all enhanced features
 * 
 * 5. Demo Pages:
 *    - Use demo pages to showcase features to users
 * 
 * 6. Utility Services:
 *    - Use exportService for programmatic export functionality
 *    - Use useEnhancedCollaboration hook for custom collaborative editing integration
 */