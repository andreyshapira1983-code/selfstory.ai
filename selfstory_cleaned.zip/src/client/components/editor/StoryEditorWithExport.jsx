import React, { useState, useRef } from 'react';
import PropTypes from 'prop-types';
import StoryEditor from './StoryEditor';
import ExportOptions from '../export/ExportOptions';

/**
 * StoryEditorWithExport - Enhanced story editor with export capabilities
 * 
 * This component wraps the StoryEditor component and adds export functionality
 * for publishing stories in various formats.
 */
const StoryEditorWithExport = ({ initialStory, onSave }) => {
  const [story, setStory] = useState(initialStory || {});
  const [showExportOptions, setShowExportOptions] = useState(false);
  const editorRef = useRef(null);
  
  // Handle story save
  const handleSave = (updatedStory) => {
    setStory(updatedStory);
    
    if (onSave) {
      onSave(updatedStory);
    }
  };
  
  // Toggle export options modal
  const toggleExportOptions = () => {
    setShowExportOptions(!showExportOptions);
  };
  
  return (
    <div className="story-editor-with-export">
      {/* Export button */}
      <div className="export-button-container">
        <button 
          className="export-button"
          onClick={toggleExportOptions}
          title="Export story"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
          Export
        </button>
      </div>
      
      {/* Story Editor */}
      <StoryEditor 
        ref={editorRef}
        initialStory={initialStory}
        onSave={handleSave}
      />
      
      {/* Export Options Modal */}
      {showExportOptions && (
        <ExportOptions
          content={story.content || ''}
          title={story.title || 'Untitled Story'}
          author={story.author || ''}
          onClose={toggleExportOptions}
        />
      )}
    </div>
  );
};

StoryEditorWithExport.propTypes = {
  initialStory: PropTypes.shape({
    id: PropTypes.string,
    title: PropTypes.string,
    content: PropTypes.string,
    author: PropTypes.string,
    genres: PropTypes.arrayOf(PropTypes.string),
    tags: PropTypes.arrayOf(PropTypes.string),
    controls: PropTypes.object,
    template: PropTypes.string,
    createdAt: PropTypes.string,
    updatedAt: PropTypes.string
  }),
  onSave: PropTypes.func
};

export default StoryEditorWithExport;