import React, { useState } from 'react';
import AISuggestions from './AISuggestions';
import AIStyleTransfer from './AIStyleTransfer';
import AIContentEnhancer from './AIContentEnhancer';
import AIStoryGenerator from './AIStoryGenerator';

/**
 * AI Tools Panel Component
 * 
 * Provides a unified interface for all AI-powered writing tools
 * Includes tabs for different tool categories
 */
const AIToolsPanel = ({
  content,
  cursorPosition,
  genres,
  controls,
  onInsertContent,
  onReplaceContent,
  onApplySuggestion,
  isVisible = true
}) => {
  const [activeTab, setActiveTab] = useState('suggestions');
  
  // Handle tab change
  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };
  
  // If panel is not visible, don't render anything
  if (!isVisible) return null;
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
      {/* Header */}
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-b border-gray-200 dark:border-gray-600">
        <h2 className="text-lg font-medium flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-primary" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
          </svg>
          AI Writing Assistant
        </h2>
      </div>
      
      {/* Tabs */}
      <div className="border-b border-gray-200 dark:border-gray-600">
        <nav className="flex -mb-px">
          <button
            className={`py-3 px-4 text-sm font-medium ${
              activeTab === 'suggestions'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('suggestions')}
          >
            Suggestions
          </button>
          <button
            className={`py-3 px-4 text-sm font-medium ${
              activeTab === 'generate'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('generate')}
          >
            Generate
          </button>
          <button
            className={`py-3 px-4 text-sm font-medium ${
              activeTab === 'enhance'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('enhance')}
          >
            Enhance
          </button>
          <button
            className={`py-3 px-4 text-sm font-medium ${
              activeTab === 'style'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('style')}
          >
            Style
          </button>
        </nav>
      </div>
      
      {/* Tab content */}
      <div className="p-4">
        {activeTab === 'suggestions' && (
          <AISuggestions
            content={content}
            cursorPosition={cursorPosition}
            onApplySuggestion={onApplySuggestion}
            isVisible={true}
          />
        )}
        
        {activeTab === 'generate' && (
          <AIStoryGenerator
            existingContent={content}
            genres={genres}
            controls={controls}
            onInsertContent={onInsertContent}
            onReplaceContent={onReplaceContent}
          />
        )}
        
        {activeTab === 'enhance' && (
          <AIContentEnhancer
            content={content}
            onApplyEnhancement={(enhancedContent, section) => {
              if (section === 'all') {
                onReplaceContent(enhancedContent);
              } else {
                onInsertContent(enhancedContent);
              }
            }}
          />
        )}
        
        {activeTab === 'style' && (
          <AIStyleTransfer
            content={content}
            onApplyStyle={onReplaceContent}
          />
        )}
      </div>
      
      {/* Footer */}
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-t border-gray-200 dark:border-gray-600 text-xs text-gray-500 dark:text-gray-400">
        AI tools help enhance your writing but maintain your unique voice. Content is processed securely.
      </div>
    </div>
  );
};

export default AIToolsPanel;