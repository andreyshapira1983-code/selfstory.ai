import React, { useState, useRef } from 'react';
import PropTypes from 'prop-types';
import StoryEditor from './StoryEditor';
import ExportOptions from '../export/ExportOptions';
import WritingAnalytics from '../analytics/WritingAnalytics';
import EnhancedCollaborativeEditor from './EnhancedCollaborativeEditor';
import CollaborativeBrainstorming from './CollaborativeBrainstorming';

/**
 * EnhancedStoryEditor - Comprehensive story editor with all enhanced features
 * 
 * This component integrates all the enhanced features we've built:
 * - Collaborative editing with cursor presence, chat, and conflict resolution
 * - Export options for publishing in various formats
 * - Advanced writing analytics
 * - Collaborative brainstorming tools
 */
const EnhancedStoryEditor = ({ 
  initialStory, 
  collaborators = [],
  currentUser,
  onSave 
}) => {
  const [story, setStory] = useState(initialStory || {});
  const [showExportOptions, setShowExportOptions] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [showBrainstorming, setShowBrainstorming] = useState(false);
  const [isCollaborative, setIsCollaborative] = useState(collaborators.length > 1);
  const editorRef = useRef(null);
  
  // Handle story save
  const handleSave = (updatedStory) => {
    setStory(updatedStory);
    
    if (onSave) {
      onSave(updatedStory);
    }
  };
  
  // Toggle export options modal
  const toggleExportOptions = () => {
    setShowExportOptions(!showExportOptions);
  };
  
  // Toggle analytics modal
  const toggleAnalytics = () => {
    setShowAnalytics(!showAnalytics);
  };
  
  // Toggle brainstorming panel
  const toggleBrainstorming = () => {
    setShowBrainstorming(!showBrainstorming);
  };
  
  // Toggle collaborative mode
  const toggleCollaborativeMode = () => {
    setIsCollaborative(!isCollaborative);
  };
  
  return (
    <div className="enhanced-story-editor">
      {/* Feature buttons */}
      <div className="feature-buttons-container">
        <button 
          className="feature-button export-btn"
          onClick={toggleExportOptions}
          title="Export story"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
          <span className="button-text">Export</span>
        </button>
        
        <button 
          className="feature-button analytics-btn"
          onClick={toggleAnalytics}
          title="Analyze writing"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
          </svg>
          <span className="button-text">Analyze</span>
        </button>
        
        <button 
          className="feature-button brainstorm-btn"
          onClick={toggleBrainstorming}
          title="Collaborative brainstorming"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
          </svg>
          <span className="button-text">Brainstorm</span>
        </button>
        
        <button 
          className={`feature-button collab-btn ${isCollaborative ? 'active' : ''}`}
          onClick={toggleCollaborativeMode}
          title={isCollaborative ? "Disable collaborative mode" : "Enable collaborative mode"}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" />
          </svg>
          <span className="button-text">{isCollaborative ? "Collaborative" : "Solo"}</span>
        </button>
      </div>
      
      {/* Editor Component - Either collaborative or standard */}
      {isCollaborative ? (
        <EnhancedCollaborativeEditor
          documentId={story.id || `story-${Date.now()}`}
          initialContent={story.content || ''}
          collaborators={collaborators}
          currentUser={currentUser}
          onSave={handleSave}
        />
      ) : (
        <StoryEditor 
          ref={editorRef}
          initialStory={story}
          onSave={handleSave}
        />
      )}
      
      {/* Export Options Modal */}
      {showExportOptions && (
        <ExportOptions
          content={story.content || ''}
          title={story.title || 'Untitled Story'}
          author={currentUser?.name || ''}
          onClose={toggleExportOptions}
        />
      )}
      
      {/* Writing Analytics Modal */}
      {showAnalytics && (
        <WritingAnalytics
          content={story.content || ''}
          title={story.title || 'Untitled Story'}
          onClose={toggleAnalytics}
        />
      )}
      
      {/* Collaborative Brainstorming */}
      {showBrainstorming && (
        <CollaborativeBrainstorming
          documentId={story.id || `story-${Date.now()}`}
          collaborators={collaborators}
          currentUser={currentUser}
          onClose={toggleBrainstorming}
        />
      )}
    </div>
  );
};

EnhancedStoryEditor.propTypes = {
  initialStory: PropTypes.shape({
    id: PropTypes.string,
    title: PropTypes.string,
    content: PropTypes.string,
    author: PropTypes.string,
    genres: PropTypes.arrayOf(PropTypes.string),
    tags: PropTypes.arrayOf(PropTypes.string),
    controls: PropTypes.object,
    template: PropTypes.string,
    createdAt: PropTypes.string,
    updatedAt: PropTypes.string
  }),
  collaborators: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      avatar: PropTypes.string,
      color: PropTypes.string,
    })
  ),
  currentUser: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    avatar: PropTypes.string,
  }),
  onSave: PropTypes.func
};

export default EnhancedStoryEditor;