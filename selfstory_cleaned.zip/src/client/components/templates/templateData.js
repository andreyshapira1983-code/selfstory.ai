/**
 * Story templates data
 * These templates provide pre-filled story starters for different genres and styles
 */

const templates = [
  {
    id: 'romantic-encounter',
    title: 'Romantic Encounter',
    description: 'Two strangers meet by chance and feel an immediate connection',
    preview: 'The café was crowded, but somehow their eyes met across the room...',
    content: `The café was crowded, but somehow their eyes met across the room. Sarah paused, her coffee halfway to her lips, as the stranger smiled. There was something familiar about him, though she was certain they had never met before.

"Is this seat taken?" he asked, gesturing to the empty chair at her table.

Sarah hesitated only briefly before nodding. "It is now," she replied with a smile.

As he sat down, introducing himself as Michael, Sarah couldn't help but feel that this chance meeting was somehow meant to be. The afternoon sun streamed through the windows, casting a golden glow over their conversation as they discovered shared interests and parallel life paths.

"It's strange," Michael said after they'd been talking for nearly an hour, "but I feel like I've known you for years."`,
    genres: ['romance'],
    tags: ['meet-cute', 'contemporary', 'love-at-first-sight'],
    promptSuggestions: [
      'What secret is one character hiding?',
      'Add a complication that threatens their connection',
      'How does their relationship develop over time?'
    ]
  },
  {
    id: 'mystery-mansion',
    title: 'The Mysterious Mansion',
    description: 'A detective investigates strange occurrences in an old mansion',
    preview: 'The mansion stood silent on the hill, its windows like watchful eyes...',
    content: `The mansion stood silent on the hill, its windows like watchful eyes observing Detective Claire Morgan as she approached. The gravel driveway crunched beneath her feet, announcing her arrival to whatever—or whoever—waited inside.

Three people had disappeared within these walls in the past month. Her job was to find out why.

"Quite the place, isn't it?" said Officer Reynolds, who had been first on the scene after the latest disappearance.

Claire nodded, studying the Victorian architecture with its ornate turrets and shadowed alcoves. "Who's the owner again?"

"That's part of the mystery. Property records show it belongs to the Blackwood Trust, but no one seems to know who controls the trust."

As they reached the massive oak door, Claire noticed something unusual—scratch marks on the threshold, as if someone had desperately tried to claw their way out.`,
    genres: ['mystery', 'horror'],
    tags: ['detective', 'haunted-house', 'investigation'],
    promptSuggestions: [
      'What does the detective discover in the basement?',
      'Who is the mysterious owner of the mansion?',
      'Is there a supernatural explanation or a human culprit?'
    ]
  },
  {
    id: 'space-adventure',
    title: 'Galactic Expedition',
    description: 'A crew of explorers discovers an uncharted planet with surprising secrets',
    preview: 'Captain Lena Zhang checked the ship's scanners again. "That's impossible," she whispered...',
    content: `Captain Lena Zhang checked the ship's scanners again. "That's impossible," she whispered, but the readings remained unchanged. The planet before them—which appeared on no star charts—was showing signs of both advanced technology and life forms unlike any in the known galaxy.

"What do we do, Captain?" asked Navigator Suresh, his voice betraying his nervousness.

The exploratory vessel Horizon had been mapping this sector for three months without incident. They were supposed to be heading home next week. A discovery like this would change everything.

"Prepare a landing party," Lena decided. "Minimal crew, maximum precautions. Whatever's down there, the Alliance will want to know about it."

As the ship entered orbit, strange energy patterns began interfering with their systems. Through the viewport, they could see vast geometric structures on the surface that seemed to shift and change even as they watched.`,
    genres: ['sci-fi', 'adventure'],
    tags: ['space', 'exploration', 'alien-contact'],
    promptSuggestions: [
      'What do they discover on the planet surface?',
      'Is there a hidden danger the crew doesn't expect?',
      'How does this discovery change their understanding of the universe?'
    ]
  },
  {
    id: 'fantasy-quest',
    title: 'The Ancient Artifact',
    description: 'A young hero embarks on a quest to find a legendary artifact',
    preview: 'The old map trembled in Elian's hands as he stood at the edge of the Whispering Forest...',
    content: `The old map trembled in Elian's hands as he stood at the edge of the Whispering Forest. According to the village elders, no one who had sought the Crystal of Alandria had ever returned. But if the legends were true, the Crystal could heal his sister from the wasting sickness.

"You don't have to do this alone," said Kira, his childhood friend who had insisted on accompanying him despite the dangers.

Elian traced the path marked on the parchment. "The map shows three trials we must overcome: the Forest of Illusions, the Chasm of Echoes, and the Guardian's Labyrinth."

A cool wind rustled through the ancient trees before them, carrying whispers that sounded almost like words. Elian took a deep breath, adjusted the sword at his hip, and took his first step into the forest.

The adventure that would change their world had begun.`,
    genres: ['fantasy', 'adventure'],
    tags: ['quest', 'magic', 'coming-of-age'],
    promptSuggestions: [
      'What is the first trial they face in the forest?',
      'What unexpected ally do they meet on their journey?',
      'Is the artifact what they expected it to be?'
    ]
  },
  {
    id: 'horror-cabin',
    title: 'Cabin in the Woods',
    description: 'Friends on a weekend getaway discover they're not alone in the forest',
    preview: 'The laughter stopped abruptly when they heard the knock at the door...',
    content: `The laughter stopped abruptly when they heard the knock at the door. Five friends turned to stare at the cabin's entrance, their card game forgotten.

"Who could that be?" whispered Mia. "The nearest town is twenty miles away."

"And in this storm?" added Jason, glancing at the windows where rain lashed against the glass.

The knock came again, more insistent this time.

Mark, always the brave one, stood up. "Probably just a hiker caught in the rain," he said, moving toward the door.

"Don't—" began Lily, but Mark had already turned the handle.

The door swung open to reveal... nothing. Just darkness and the sound of rain.

"Hello?" Mark called, peering outside.

That's when they noticed the footprints on the wooden floor—wet, muddy prints that led from the doorway into the cabin. Prints that hadn't been there moments before.`,
    genres: ['horror'],
    tags: ['isolation', 'survival', 'supernatural'],
    promptSuggestions: [
      'What is creating the mysterious footprints?',
      'Which character has a secret that puts everyone in danger?',
      'How do they try to escape from the threat?'
    ]
  },
  {
    id: 'fairy-tale',
    title: 'Modern Fairy Tale',
    description: 'A contemporary retelling of classic fairy tale elements',
    preview: 'No one believed in magic anymore—no one except Mira...',
    content: `No one believed in magic anymore—no one except Mira. In a world of smartphones and self-driving cars, she alone saw the shimmer in the air when a wish was made, or noticed how plants grew better when sung to under the full moon.

Her grandmother had taught her to look for magic in everyday things before she passed away, leaving Mira a curious silver key with no apparent lock to open.

"When the time comes, you'll know what it's for," her grandmother had said.

That time arrived on Mira's sixteenth birthday, when a strange door appeared in her bedroom wall—a door that definitely hadn't been there before. The key fit perfectly.

Beyond the threshold lay not her apartment building's hallway, but a vast meadow under an impossibly blue sky, where flowers bloomed in colors she had never seen before and distant mountains floated among the clouds.`,
    genres: ['fantasy', 'folk'],
    tags: ['fairy-tale', 'magic', 'modern-setting'],
    promptSuggestions: [
      'What creatures or beings does Mira encounter in the magical realm?',
      'Is there a task or quest she must complete?',
      'How does her knowledge of both worlds help her overcome challenges?'
    ]
  },
  {
    id: 'cyberpunk-heist',
    title: 'Digital Heist',
    description: 'A team of hackers plans to steal valuable data from a megacorporation',
    preview: 'The neon lights of the city reflected in the puddles as Rio plugged into the network...',
    content: `The neon lights of the city reflected in the puddles as Rio plugged into the network. Her neural implants hummed as data flowed directly into her consciousness, the corporate security systems materializing in her mind as towering red walls.

"I'm in," she subvocalized to her team. "Security's tighter than we expected. They've added quantum encryption since our last intel."

"Can you crack it?" came Dex's voice through the implant.

Rio's fingers danced over her holographic interface. "Of course I can. But it'll take time we don't have."

From his lookout position, Vex cut in: "We've got company. Corporate security drones, three blocks out and closing."

The job was supposed to be simple: infiltrate MegaTech's servers, steal the prototype AI code, get out clean. Ten million credits split four ways. Now it was looking like a suicide mission.

"Plan B," decided Rio. "We're going loud."`,
    genres: ['cyberpunk', 'sci-fi'],
    tags: ['heist', 'hacking', 'dystopian'],
    promptSuggestions: [
      'What unexpected obstacle do they encounter during the heist?',
      'Is there a traitor on the team?',
      'What is special about the data they're trying to steal?'
    ]
  },
  {
    id: 'historical-romance',
    title: 'Forbidden Love',
    description: 'Two people from different social classes fall in love despite societal barriers',
    preview: 'The ballroom was filled with the elite of London society, but she only had eyes for the gardener's son...',
    content: `The ballroom was filled with the elite of London society, but she only had eyes for the gardener's son. Lady Eleanor Harrington knew her father would never approve—the Earl of Westmoreland had made it clear she was to marry Lord Blackwood before the season's end.

But Thomas had grown from the boy who taught her to climb trees into a man whose gaze made her heart flutter. Now he was here, at the Midsummer Ball, not as a servant but as the guest of the renowned painter he apprenticed under.

"You shouldn't be looking at me that way," Thomas murmured as they passed each other between dances. "People will talk."

"Let them," Eleanor replied, though she knew the consequences could be severe for both of them.

As the orchestra began a waltz, Thomas extended his hand in a gesture that defied every social boundary between them. "May I have this dance, my lady?"`,
    genres: ['romance', 'historical'],
    tags: ['class-difference', 'forbidden-love', 'period-drama'],
    promptSuggestions: [
      'How do they continue their relationship in secret?',
      'What obstacle threatens to separate them forever?',
      'Who becomes their unexpected ally?'
    ]
  },
  {
    id: 'childrens-adventure',
    title: 'The Secret Clubhouse',
    description: 'A group of children discover something magical in their neighborhood',
    preview: 'It was Jamie who found the old treehouse first, hidden behind a curtain of ivy...',
    content: `It was Jamie who found the old treehouse first, hidden behind a curtain of ivy in the woods behind their neighborhood. At first glance, it looked like any ordinary treehouse—a bit weathered, with wooden planks nailed to the trunk forming a ladder up to a small platform with walls and a roof.

"Come on up!" Jamie called to his friends, Max and Leila, who were still making their way through the underbrush.

But when all three of them crowded into the small space, something strange happened. The interior seemed much larger than it had appeared from outside. And there, carved into the center of the floor, was a symbol none of them recognized—a spiral with five stars positioned around it.

"What do you think it means?" whispered Leila.

Max shrugged, reaching out to trace the carving with his finger. As soon as he touched it, the symbol began to glow with a soft blue light.

The three friends looked at each other with wide eyes as the floor beneath them started to descend like an elevator, taking them down into a hidden world they never knew existed.`,
    genres: ['fantasy', 'young-adult'],
    tags: ['adventure', 'friendship', 'discovery'],
    promptSuggestions: [
      'What magical world or secret do they discover?',
      'What challenge must they overcome together?',
      'How does their discovery change them?'
    ]
  },
  {
    id: 'dystopian-rebellion',
    title: 'The Resistance',
    description: 'In a controlled society, one person discovers the truth and joins the resistance',
    preview: 'The City announced another Adjustment Day as Maya walked to work, her gray uniform matching everyone else's...',
    content: `The City announced another Adjustment Day as Maya walked to work, her gray uniform matching everyone else's. The message played on every screen and speaker: "Citizens, tomorrow is Adjustment Day. Please prepare for your scheduled Harmony Treatments. Remember: Harmony brings peace. Conformity brings prosperity."

Maya had never questioned the monthly treatments—no one did. They kept society functioning smoothly, or so everyone was told. But last week, she had missed her appointment due to a scheduling error, and something strange had happened: she had started to feel more. Colors seemed brighter. Music evoked emotions she couldn't name. And questions—so many questions—had begun forming in her mind.

Now, as she passed a blank wall, she noticed something she'd never seen before: a small symbol etched into the concrete. A circle with a line through it. It would have been easy to miss if she hadn't been looking more closely at everything lately.

As she stared at it, someone bumped into her—a man in the same gray uniform as everyone else. "I'm sorry," he said, but his eyes held hers for a moment too long. And as he walked away, she felt something in her pocket that hadn't been there before.

A note, with the same symbol and three words: "You are awake."`,
    genres: ['dystopian', 'sci-fi'],
    tags: ['rebellion', 'control', 'awakening'],
    promptSuggestions: [
      'Who is part of the resistance and how do they operate?',
      'What is the truth about the Harmony Treatments?',
      'How does Maya decide whether to join the resistance?'
    ]
  },
  {
    id: 'murder-mystery',
    title: 'The Silent Witness',
    description: 'A murder in a small town reveals long-buried secrets',
    preview: 'Sheriff Reeves stared at the body by the lake, knowing this wasn't just another accident...',
    content: `Sheriff Reeves stared at the body by the lake, knowing this wasn't just another accident. Stanley Moore, the town's most prominent businessman, lay face down at the water's edge, a dark stain spreading across his expensive suit jacket.

"Who found him?" Reeves asked, turning to his deputy.

"Jogger came through around 6 AM. Said she almost tripped over him in the morning fog."

Millfield hadn't seen a murder in fifteen years—not since the Henderson case that still haunted Reeves. As he knelt to examine the scene more closely, he noticed something clutched in Moore's hand: a torn photograph.

Carefully extracting it, Reeves felt his blood run cold. It was an old picture, the missing half of a photo he recognized. One that connected to secrets he thought had been buried long ago.

"Sheriff?" His deputy was watching him with concern. "You okay?"

Reeves pocketed the photograph. "Call the state police," he said. "And don't tell anyone what we found here. Not yet."

As he walked back to his cruiser, Reeves knew that this case would unravel more than just a murder. It would unravel the whole town—and his own past with it.`,
    genres: ['mystery', 'thriller'],
    tags: ['small-town', 'secrets', 'investigation'],
    promptSuggestions: [
      'What is in the photograph and why is it significant?',
      'Which town residents might have wanted Moore dead?',
      'How is the sheriff connected to the case?'
    ]
  },
  {
    id: 'time-travel',
    title: 'Temporal Displacement',
    description: 'A scientist accidentally travels through time and must find a way back',
    preview: 'Dr. Eliza Chen checked her calculations one last time before activating the quantum field generator...',
    content: `Dr. Eliza Chen checked her calculations one last time before activating the quantum field generator. The lab was empty at this late hour—exactly how she wanted it. If her theory was correct, the device would create a momentary glimpse into another time period, just long enough to prove her hypothesis about temporal observation.

"Recording test 37-B of the Quantum Temporal Viewer," she spoke into her recorder. "Power at 60% capacity, targeting 1985 based on the resonance signatures."

She pressed the activation sequence and watched as the air in the center of the ring-shaped device began to shimmer and distort. A sphere of blue-white energy formed, growing larger than in any previous test.

"Energy field is stable," she noted, excitement building. "I'm getting temporal shift indicators consistent with—"

The sphere pulsed suddenly, expanding outward with a blinding flash. Eliza felt herself being pulled forward, a sensation like falling and flying simultaneously.

When her vision cleared, she was standing in the same lab—but everything was different. Older equipment. Different layout. A calendar on the wall read "September 1985."

The device that should have been in front of her was gone. And with it, her way home.`,
    genres: ['sci-fi', 'adventure'],
    tags: ['time-travel', 'science', 'paradox'],
    promptSuggestions: [
      'Who does she meet in the past that changes everything?',
      'What paradox must she avoid creating?',
      'How might she recreate her device with 1980s technology?'
    ]
  }
];

export default templates;