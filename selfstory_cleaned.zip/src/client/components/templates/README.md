# StoryAI Templates System

The templates system provides pre-filled story starters for different genres and styles. This document explains the components, data structure, and usage of the templates feature.

## Components Overview

### TemplateBrowser.jsx
- Main component for browsing and selecting templates
- Provides filtering by genre, searching, and previewing templates
- Handles template selection and passes it to the parent component

### templateData.js
- Contains the template data used by the application
- Each template includes title, description, preview text, full content, genres, and tags
- Provides prompt suggestions for each template to help users continue the story

## Template Data Structure

```javascript
{
  id: string,                // Unique identifier
  title: string,             // Template title
  description: string,       // Short description
  preview: string,           // Preview text (first few sentences)
  content: string,           // Full template content
  genres: string[],          // Array of genre IDs
  tags: string[],            // Array of tags
  promptSuggestions: string[] // Writing prompts to help continue the story
}
```

## Features

### Genre Filtering
- Templates can be filtered by genre
- Genre tabs allow quick switching between categories
- "All Templates" option shows all available templates

### Search Functionality
- Search by title, description, or tags
- Real-time filtering as the user types
- Clear indication when no templates match the search criteria

### Personalization
- Templates matching the user's preferred genres are marked as "Recommended"
- Templates are sorted to prioritize those matching user preferences
- Recently used templates can be accessed quickly

### Template Preview
- Preview shows the template title, description, and starting text
- Genre and tag badges provide additional context
- Full template content is displayed when selected
- Writing prompts suggest ways to continue the story

## Usage

### In Onboarding
- The templates system is used in the onboarding flow to help new users start their first story
- Templates are filtered based on the genres selected during onboarding

### In Story Creation
- Users can browse templates when creating a new story
- Selected template provides the initial content and metadata for the story

### Template Application
- When a template is applied, it populates the story content
- The template's genres and tags are added to the story metadata
- The template ID is stored with the story for reference

## Implementation Notes

- Templates are stored as static data in the application
- In a production environment, templates would be stored in a database and fetched via API
- Templates support both light and dark mode
- The template browser is fully responsive for all device sizes

## Future Enhancements

- Allow users to create and save their own templates
- Implement template rating and popularity sorting
- Add more detailed categorization and filtering options
- Integrate AI-generated templates based on user preferences
- Add template versioning and updates