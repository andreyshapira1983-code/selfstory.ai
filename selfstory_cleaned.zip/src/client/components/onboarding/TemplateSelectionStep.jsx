import React, { useState, useEffect } from 'react';

/**
 * TemplateSelectionStep - Allows users to select a story template
 * Templates are pre-filled story starters that help users begin writing
 */
const TemplateSelectionStep = ({ onNext, onBack, selectedGenres = [], initialTemplate = null }) => {
  const [templates, setTemplates] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState(initialTemplate);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  // Template categories
  const categories = [
    { id: 'all', name: 'All Templates' },
    { id: 'fantasy', name: 'Fantasy' },
    { id: 'sci-fi', name: 'Science Fiction' },
    { id: 'romance', name: 'Romance' },
    { id: 'mystery', name: 'Mystery' },
    { id: 'horror', name: 'Horror' }
  ];
  
  const [activeCategory, setActiveCategory] = useState('all');

  // Sample templates - in a real app, these would come from an API
  const allTemplates = [
    {
      id: 'romantic-encounter',
      title: 'Romantic Encounter',
      description: 'Two strangers meet by chance and feel an immediate connection',
      preview: 'The café was crowded, but somehow their eyes met across the room...',
      genres: ['romance'],
      tags: ['meet-cute', 'contemporary', 'love-at-first-sight']
    },
    {
      id: 'mystery-mansion',
      title: 'The Mysterious Mansion',
      description: 'A detective investigates strange occurrences in an old mansion',
      preview: 'The mansion stood silent on the hill, its windows like watchful eyes...',
      genres: ['mystery', 'horror'],
      tags: ['detective', 'haunted-house', 'investigation']
    },
    {
      id: 'space-adventure',
      title: 'Galactic Expedition',
      description: 'A crew of explorers discovers an uncharted planet with surprising secrets',
      preview: 'Captain Lena Zhang checked the ship's scanners again. "That's impossible," she whispered...',
      genres: ['sci-fi', 'adventure'],
      tags: ['space', 'exploration', 'alien-contact']
    },
    {
      id: 'fantasy-quest',
      title: 'The Ancient Artifact',
      description: 'A young hero embarks on a quest to find a legendary artifact',
      preview: 'The old map trembled in Elian's hands as he stood at the edge of the Whispering Forest...',
      genres: ['fantasy', 'adventure'],
      tags: ['quest', 'magic', 'coming-of-age']
    },
    {
      id: 'horror-cabin',
      title: 'Cabin in the Woods',
      description: 'Friends on a weekend getaway discover they're not alone in the forest',
      preview: 'The laughter stopped abruptly when they heard the knock at the door...',
      genres: ['horror'],
      tags: ['isolation', 'survival', 'supernatural']
    },
    {
      id: 'fairy-tale',
      title: 'Modern Fairy Tale',
      description: 'A contemporary retelling of classic fairy tale elements',
      preview: 'No one believed in magic anymore—no one except Mira...',
      genres: ['fantasy', 'folk'],
      tags: ['fairy-tale', 'magic', 'modern-setting']
    },
    {
      id: 'cyberpunk-heist',
      title: 'Digital Heist',
      description: 'A team of hackers plans to steal valuable data from a megacorporation',
      preview: 'The neon lights of the city reflected in the puddles as Rio plugged into the network...',
      genres: ['cyberpunk', 'sci-fi'],
      tags: ['heist', 'hacking', 'dystopian']
    },
    {
      id: 'historical-romance',
      title: 'Forbidden Love',
      description: 'Two people from different social classes fall in love despite societal barriers',
      preview: 'The ballroom was filled with the elite of London society, but she only had eyes for the gardener's son...',
      genres: ['romance', 'historical'],
      tags: ['class-difference', 'forbidden-love', 'period-drama']
    }
  ];

  // Filter templates based on selected genres and active category
  useEffect(() => {
    setLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      let filteredTemplates = [...allTemplates];
      
      // Filter by user's selected genres if they've made selections
      if (selectedGenres.length > 0) {
        filteredTemplates = filteredTemplates.filter(template => 
          template.genres.some(genre => selectedGenres.includes(genre))
        );
      }
      
      // Filter by active category if not "all"
      if (activeCategory !== 'all') {
        filteredTemplates = filteredTemplates.filter(template => 
          template.genres.includes(activeCategory)
        );
      }
      
      setTemplates(filteredTemplates);
      setLoading(false);
    }, 500);
  }, [selectedGenres, activeCategory]);

  const handleSubmit = () => {
    if (!selectedTemplate) {
      setError('Please select a template to continue');
      return;
    }
    
    onNext(selectedTemplate);
  };

  return (
    <div className="flex flex-col">
      <p className="text-center mb-6">
        Choose a template to jumpstart your story. Each template provides a starting point that you can customize.
      </p>
      
      {/* Category tabs */}
      <div className="flex flex-wrap gap-2 mb-6 justify-center">
        {categories.map(category => (
          <button
            key={category.id}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors
              ${activeCategory === category.id 
                ? 'bg-primary text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600'
              }`}
            onClick={() => setActiveCategory(category.id)}
          >
            {category.name}
          </button>
        ))}
      </div>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 border border-red-200 text-red-700 rounded-md">
          {error}
        </div>
      )}
      
      {loading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      ) : templates.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg dark:bg-gray-800">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h3 className="text-lg font-medium mb-2">No matching templates</h3>
          <p className="text-gray-500 dark:text-gray-400">
            Try selecting different genres or categories
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {templates.map((template) => (
            <div
              key={template.id}
              className={`template-card ${selectedTemplate?.id === template.id ? 'selected' : ''}`}
              onClick={() => {
                setSelectedTemplate(template);
                if (error) setError('');
              }}
            >
              <h3 className="font-semibold text-lg mb-1">{template.title}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">{template.description}</p>
              
              <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md mb-3 text-sm italic">
                "{template.preview}"
              </div>
              
              <div className="flex flex-wrap gap-1">
                {template.tags.map(tag => (
                  <span key={tag} className="tag-badge">
                    {tag.replace('-', ' ')}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
      
      <div className="flex justify-between mt-6">
        <button 
          type="button" 
          className="btn btn-outline"
          onClick={onBack}
        >
          Back
        </button>
        
        <button 
          type="button" 
          className="btn btn-primary"
          onClick={handleSubmit}
          disabled={loading}
        >
          Continue
        </button>
      </div>
      
      {selectedTemplate && (
        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <h4 className="font-medium mb-2">Selected: {selectedTemplate.title}</h4>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            You can always change your template or start from scratch later.
          </p>
        </div>
      )}
    </div>
  );
};

export default TemplateSelectionStep;