import React, { useState, useEffect } from 'react';
import EnhancedCollaborativeEditor from '../editor/EnhancedCollaborativeEditor';

/**
 * CollaborativeEditorDemo - Demonstration page for enhanced collaborative editing features
 * 
 * This page showcases the advanced collaborative editing features including:
 * - Real-time cursor presence
 * - User avatars
 * - Conflict resolution
 * - Real-time chat
 * - Collaborative brainstorming tools
 */
const CollaborativeEditorDemo = () => {
  const [documentId] = useState(`demo-doc-${Date.now()}`);
  const [currentUser] = useState({
    id: 'user-1',
    name: 'Current User',
    color: '#4f46e5'
  });
  
  // Simulated collaborators
  const [collaborators, setCollaborators] = useState([
    {
      id: 'user-1',
      name: 'Current User',
      color: '#4f46e5'
    },
    {
      id: 'user-2',
      name: 'Jane Smith',
      color: '#10b981'
    }
  ]);
  
  // Sample initial content
  const initialContent = `# Collaborative Story: The Lost City

In the heart of the Amazon rainforest, rumors persisted of a city made entirely of gold. For centuries, explorers had sought this legendary place, but none had returned to tell the tale.

Dr. Elena Rodriguez, a renowned archaeologist, believed she had finally discovered the location of the lost city. After years of research, deciphering ancient texts, and analyzing satellite imagery, she was ready to embark on the expedition of a lifetime.

"This could be the greatest archaeological discovery of the century," she told her team as they prepared for the journey. "But it won't be easy. The rainforest is unforgiving, and there's a reason no one has found this place before."

The team consisted of:

- Dr. Elena Rodriguez - Lead Archaeologist
- James Chen - Botanist and Survival Expert
- Maria Gonzalez - Linguist specializing in ancient South American languages
- Thomas Wright - Photographer and Documentarian

As they ventured deeper into the dense jungle, the air grew thick with humidity and the sounds of wildlife surrounded them. Strange eyes watched from the canopy above, and the ground seemed to shift beneath their feet.

"According to my calculations, we should reach the first marker by nightfall," Elena said, studying her map. "From there, we'll need to follow the river upstream for three days."

What the team didn't know was that they were being followed...`;

  // Simulate adding a new collaborator after a delay
  useEffect(() => {
    const timer = setTimeout(() => {
      setCollaborators(prev => [
        ...prev,
        {
          id: 'user-3',
          name: 'Alex Johnson',
          color: '#f59e0b'
        }
      ]);
    }, 30000); // Add after 30 seconds
    
    return () => clearTimeout(timer);
  }, []);
  
  // Handle content save
  const handleSave = (content) => {
    console.log('Saving content:', content);
    // In a real app, this would save to a database
  };
  
  return (
    <div className="collaborative-editor-demo">
      <div className="demo-header">
        <h1>Enhanced Collaborative Editor</h1>
        <p className="demo-description">
          Experience real-time collaboration with advanced features including cursor presence, 
          chat, conflict resolution, and brainstorming tools.
        </p>
      </div>
      
      <div className="demo-features">
        <div className="feature-card">
          <div className="feature-icon">👥</div>
          <h3>Cursor Presence</h3>
          <p>See where others are editing in real-time with user avatars and cursor indicators.</p>
        </div>
        
        <div className="feature-card">
          <div className="feature-icon">💬</div>
          <h3>Real-time Chat</h3>
          <p>Discuss your document with collaborators without leaving the editor.</p>
        </div>
        
        <div className="feature-card">
          <div className="feature-icon">🔄</div>
          <h3>Conflict Resolution</h3>
          <p>Smart merging of conflicting edits with visual comparison tools.</p>
        </div>
        
        <div className="feature-card">
          <div className="feature-icon">💡</div>
          <h3>Brainstorming Tools</h3>
          <p>Collaborative idea generation, mind mapping, and shared notes.</p>
        </div>
      </div>
      
      <div className="demo-collaborators">
        <h2>Current Collaborators</h2>
        <div className="collaborator-list">
          {collaborators.map(collaborator => (
            <div key={collaborator.id} className="collaborator-item">
              <div 
                className="collaborator-avatar"
                style={{ backgroundColor: collaborator.color }}
              >
                {collaborator.name.charAt(0).toUpperCase()}
              </div>
              <span className="collaborator-name">
                {collaborator.name}
                {collaborator.id === currentUser.id && ' (You)'}
              </span>
            </div>
          ))}
        </div>
      </div>
      
      <div className="demo-editor-container">
        <EnhancedCollaborativeEditor
          documentId={documentId}
          initialContent={initialContent}
          collaborators={collaborators}
          currentUser={currentUser}
          onSave={handleSave}
        />
      </div>
      
      <div className="demo-instructions">
        <h2>How to Use</h2>
        <ul>
          <li>Edit the document to see real-time collaboration features</li>
          <li>Click the chat icon in the bottom right to open the chat panel</li>
          <li>Click "Brainstorm" to open collaborative brainstorming tools</li>
          <li>Conflicts will occasionally be simulated for demonstration purposes</li>
          <li>New collaborators will join periodically to demonstrate presence features</li>
        </ul>
      </div>
    </div>
  );
};

export default CollaborativeEditorDemo;