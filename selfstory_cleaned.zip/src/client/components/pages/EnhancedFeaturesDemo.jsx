import React, { useState } from 'react';
import EnhancedStoryEditor from '../editor/EnhancedStoryEditor';

/**
 * EnhancedFeaturesDemo - Demonstration page for all enhanced StoryAI features
 * 
 * This page showcases all the enhanced features we've built:
 * - Collaborative editing with cursor presence, chat, and conflict resolution
 * - Export options for publishing in various formats
 * - Advanced writing analytics
 * - Collaborative brainstorming tools
 */
const EnhancedFeaturesDemo = () => {
  // Sample story for demonstration
  const [sampleStory] = useState({
    id: `demo-story-${Date.now()}`,
    title: "The Forgotten Lighthouse",
    content: `# The Forgotten Lighthouse

The old lighthouse stood on the edge of the cliff, its paint peeling and windows clouded with salt and time. For decades, it had been abandoned, forgotten by the town that once depended on its guiding light. But today, someone was climbing the winding path that led to its door.

Sarah Parker, a marine historian with a passion for coastal architecture, had been researching the forgotten lighthouses of New England for her upcoming book. This particular lighthouse, known locally as "The Sentinel," had caught her attention because of its unusual history. According to local records, the last lighthouse keeper had disappeared without a trace in 1952, and since then, the lighthouse had remained untouched.

"It's even more impressive up close," Sarah muttered to herself as she approached the weathered structure. The lighthouse tower rose nearly a hundred feet into the air, its once-white exterior now a patchwork of faded paint and exposed brick. The keeper's house attached to its base seemed to lean slightly toward the sea, as if yearning to join it.

Sarah set down her backpack and took out her camera, capturing several angles of the lighthouse against the dramatic backdrop of churning waves and gray skies. The October wind whipped her hair around her face as she worked, the salt spray occasionally reaching her even at this height.

After taking sufficient exterior photographs, she approached the entrance. The door was secured with a rusted padlock, but Sarah had obtained permission from the local historical society to enter. She fumbled with the key they had provided, struggling to make it turn in the corroded mechanism. Finally, with a screech of metal, the lock gave way.

The door swung open with a haunting creak, revealing a dust-filled interior untouched by modern hands. Sarah stepped inside, allowing her eyes to adjust to the dimness. The air was thick with the smell of salt, mildew, and something else she couldn't quite identify—something almost metallic.`,
    genres: ['mystery', 'historical'],
    tags: ['lighthouse', 'new england', 'investigation'],
    controls: {
      tone: 'mysterious',
      length: 'medium',
      pov: 'third',
      mood: 'suspenseful'
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  });
  
  // Simulated collaborators
  const [collaborators] = useState([
    {
      id: 'user-1',
      name: 'You',
      color: '#4f46e5'
    },
    {
      id: 'user-2',
      name: 'Jane Smith',
      color: '#10b981'
    },
    {
      id: 'user-3',
      name: 'Alex Johnson',
      color: '#f59e0b'
    }
  ]);
  
  // Current user
  const [currentUser] = useState({
    id: 'user-1',
    name: 'You',
    color: '#4f46e5'
  });
  
  // Handle story save
  const handleSave = (updatedStory) => {
    console.log('Story saved:', updatedStory);
    // In a real app, this would save to a database
  };
  
  return (
    <div className="enhanced-features-demo">
      <div className="demo-header">
        <h1>StoryAI Enhanced Features</h1>
        <p className="demo-description">
          Experience the full power of StoryAI with all enhanced features including collaborative editing,
          export options, writing analytics, and brainstorming tools.
        </p>
      </div>
      
      <div className="feature-highlights">
        <div className="feature-highlight">
          <div className="highlight-icon">👥</div>
          <div className="highlight-content">
            <h3>Collaborative Editing</h3>
            <p>See real-time cursor positions, chat with collaborators, and resolve editing conflicts seamlessly.</p>
          </div>
        </div>
        
        <div className="feature-highlight">
          <div className="highlight-icon">📊</div>
          <div className="highlight-content">
            <h3>Writing Analytics</h3>
            <p>Get detailed insights into readability, structure, pacing, dialogue, and character development.</p>
          </div>
        </div>
        
        <div className="feature-highlight">
          <div className="highlight-icon">📄</div>
          <div className="highlight-content">
            <h3>Export Options</h3>
            <p>Export your story in various formats including PDF, ePub, and manuscript formats.</p>
          </div>
        </div>
        
        <div className="feature-highlight">
          <div className="highlight-icon">💡</div>
          <div className="highlight-content">
            <h3>Brainstorming Tools</h3>
            <p>Collaborate on ideas, create mind maps, and take shared notes to develop your story.</p>
          </div>
        </div>
      </div>
      
      <div className="demo-instructions">
        <h2>How to Use This Demo</h2>
        <ol>
          <li>Use the buttons at the top of the editor to access different features</li>
          <li>Toggle between collaborative and solo modes with the "Collaborative" button</li>
          <li>Click "Export" to see publishing options in various formats</li>
          <li>Click "Analyze" to get detailed writing insights</li>
          <li>Click "Brainstorm" to access collaborative brainstorming tools</li>
        </ol>
        <p className="note">
          This demo simulates a collaborative environment with multiple users. In a real implementation,
          changes would be synchronized in real-time across all collaborators.
        </p>
      </div>
      
      <div className="editor-container">
        <EnhancedStoryEditor
          initialStory={sampleStory}
          collaborators={collaborators}
          currentUser={currentUser}
          onSave={handleSave}
        />
      </div>
    </div>
  );
};

export default EnhancedFeaturesDemo;