import React, { useState, useEffect } from 'react';
import OnboardingFlow from './onboarding/OnboardingFlow';
import StoryEditor from './editor/StoryEditor';
import TemplateBrowser from './templates/TemplateBrowser';

/**
 * App - Main application component
 * Manages application state and navigation between different views
 */
const App = () => {
  // Application state
  const [user, setUser] = useState(null);
  const [stories, setStories] = useState([]);
  const [currentStory, setCurrentStory] = useState(null);
  const [view, setView] = useState('loading'); // loading, onboarding, dashboard, editor, templates
  const [isLoading, setIsLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  
  // Check if user has completed onboarding
  useEffect(() => {
    // In a real app, this would check local storage or an API
    // For now, we'll simulate a loading delay
    setTimeout(() => {
      const savedUser = localStorage.getItem('storyai_user');
      const savedStories = localStorage.getItem('storyai_stories');
      
      if (savedUser) {
        setUser(JSON.parse(savedUser));
        setView('dashboard');
      } else {
        setView('onboarding');
      }
      
      if (savedStories) {
        setStories(JSON.parse(savedStories));
      }
      
      // Check for dark mode preference
      if (localStorage.getItem('darkMode') === 'true' || 
          (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        setDarkMode(true);
        document.documentElement.classList.add('dark');
      }
      
      setIsLoading(false);
    }, 1000);
  }, []);
  
  // Handle dark mode toggle
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('darkMode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('darkMode', 'false');
    }
  }, [darkMode]);
  
  // Handle onboarding completion
  const handleOnboardingComplete = (userData) => {
    // Create user
    const newUser = {
      id: `user-${Date.now()}`,
      name: userData.name,
      preferredGenres: userData.preferredGenres,
      createdAt: new Date().toISOString()
    };
    
    // Create first story
    const newStory = {
      id: `story-${Date.now()}`,
      title: userData.firstStory.title,
      content: userData.firstStory.content,
      template: userData.firstStory.template,
      genres: userData.preferredGenres,
      tags: [],
      controls: userData.firstStory.controls,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    // Update state
    setUser(newUser);
    setStories([newStory]);
    setCurrentStory(newStory);
    
    // Save to local storage
    localStorage.setItem('storyai_user', JSON.stringify(newUser));
    localStorage.setItem('storyai_stories', JSON.stringify([newStory]));
    
    // Navigate to editor
    setView('editor');
  };
  
  // Handle story save
  const handleSaveStory = (updatedStory) => {
    // Update stories array
    const updatedStories = stories.map(story => 
      story.id === updatedStory.id ? updatedStory : story
    );
    
    // If this is a new story, add it to the array
    if (!stories.find(story => story.id === updatedStory.id)) {
      updatedStories.push(updatedStory);
    }
    
    // Update state
    setStories(updatedStories);
    setCurrentStory(updatedStory);
    
    // Save to local storage
    localStorage.setItem('storyai_stories', JSON.stringify(updatedStories));
  };
  
  // Handle creating a new story
  const handleCreateStory = (template = null) => {
    const newStory = {
      id: `story-${Date.now()}`,
      title: template ? `My ${template.title}` : 'Untitled Story',
      content: template ? template.content : '',
      template: template ? template.id : null,
      genres: template ? template.genres : [],
      tags: template ? template.tags : [],
      controls: {
        tone: 'neutral',
        length: 'medium',
        pov: 'third',
        mood: 'neutral'
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    setCurrentStory(newStory);
    setView('editor');
  };
  
  // Handle selecting a story to edit
  const handleSelectStory = (storyId) => {
    const story = stories.find(s => s.id === storyId);
    if (story) {
      setCurrentStory(story);
      setView('editor');
    }
  };
  
  // Handle selecting a template
  const handleSelectTemplate = (template) => {
    handleCreateStory(template);
  };
  
  // Handle navigation
  const navigateTo = (destination) => {
    setView(destination);
  };
  
  // Render loading screen
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-indigo-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary mx-auto"></div>
          <h2 className="mt-4 text-xl font-semibold">Loading StoryAI...</h2>
        </div>
      </div>
    );
  }
  
  // Render onboarding flow
  if (view === 'onboarding') {
    return <OnboardingFlow onComplete={handleOnboardingComplete} />;
  }
  
  // Render main application
  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              {/* Logo */}
              <div className="flex-shrink-0 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                </svg>
                <span className="ml-2 text-xl font-bold">StoryAI</span>
              </div>
              
              {/* Navigation */}
              <nav className="ml-6 flex space-x-4">
                <button
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    view === 'dashboard'
                      ? 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white'
                      : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => navigateTo('dashboard')}
                >
                  Dashboard
                </button>
                <button
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    view === 'templates'
                      ? 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white'
                      : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => navigateTo('templates')}
                >
                  Templates
                </button>
              </nav>
            </div>
            
            <div className="flex items-center">
              {/* Dark mode toggle */}
              <button
                className="p-2 rounded-md text-gray-500 hover:text-gray-900 dark:hover:text-white"
                onClick={() => setDarkMode(!darkMode)}
                aria-label="Toggle dark mode"
              >
                {darkMode ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" clipRule="evenodd" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" />
                  </svg>
                )}
              </button>
              
              {/* User menu */}
              <div className="ml-3 relative">
                <div className="flex items-center">
                  <span className="text-sm font-medium mr-2">
                    {user?.name || 'User'}
                  </span>
                  <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white">
                    {user?.name?.charAt(0) || 'U'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      
      {/* Main content */}
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Dashboard view */}
          {view === 'dashboard' && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Your Stories</h1>
                <button
                  className="btn btn-primary"
                  onClick={() => navigateTo('templates')}
                >
                  Create New Story
                </button>
              </div>
              
              {stories.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-lg dark:bg-gray-800">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                  </svg>
                  <h3 className="text-lg font-medium mb-2">No stories yet</h3>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">
                    Create your first story to get started
                  </p>
                  <button
                    className="btn btn-primary"
                    onClick={() => navigateTo('templates')}
                  >
                    Create New Story
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {stories.map((story) => (
                    <div
                      key={story.id}
                      className="border rounded-lg overflow-hidden bg-white dark:bg-gray-800 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => handleSelectStory(story.id)}
                    >
                      <div className="p-6">
                        <h2 className="text-xl font-semibold mb-2 line-clamp-1">{story.title}</h2>
                        <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-3">
                          {story.content.substring(0, 150)}...
                        </p>
                        
                        <div className="flex flex-wrap gap-1 mb-4">
                          {story.genres.map(genre => (
                            <span 
                              key={genre} 
                              className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100"
                            >
                              {genre.charAt(0).toUpperCase() + genre.slice(1)}
                            </span>
                          ))}
                        </div>
                        
                        <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
                          <span>
                            {new Date(story.updatedAt).toLocaleDateString()}
                          </span>
                          <span>
                            {story.content.split(/\s+/).length} words
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
          
          {/* Editor view */}
          {view === 'editor' && (
            <StoryEditor
              initialStory={currentStory}
              onSave={handleSaveStory}
            />
          )}
          
          {/* Templates view */}
          {view === 'templates' && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Story Templates</h1>
                <button
                  className="btn btn-outline"
                  onClick={() => handleCreateStory()}
                >
                  Start from Scratch
                </button>
              </div>
              
              <TemplateBrowser
                onSelectTemplate={handleSelectTemplate}
                selectedGenres={user?.preferredGenres || []}
              />
            </div>
          )}
        </div>
      </main>
      
      {/* Footer */}
      <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-500 dark:text-gray-400">
              &copy; {new Date().getFullYear()} StoryAI. All rights reserved.
            </div>
            <div className="text-sm">
              <a href="#" className="text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">
                Terms
              </a>
              <span className="mx-2 text-gray-300 dark:text-gray-600">|</span>
              <a href="#" className="text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">
                Privacy
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;